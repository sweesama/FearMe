init python:
    gallery = Gallery()

    # Buttons for day 1
    gallery.button("moment_1")
    gallery.unlock_image("cg1")
    gallery.unlock_image("cg2")

    gallery.button("moment_2")
    gallery.unlock_image("cg3")
    gallery.unlock_image("cg4")
    gallery.unlock_image("cg5")
    gallery.unlock_image("cg6")
    gallery.unlock_image("cg7")
    gallery.unlock_image("cg8")


    # Buttons for day 2
    gallery.button("moment_3")
    gallery.unlock_image("cg9")
    gallery.unlock_image("cg10")
    gallery.unlock_image("cg11")
    gallery.unlock_image("cg12")
    gallery.unlock_image("cg13")

    gallery.button("moment_4")
    gallery.unlock_image("cg14")
    gallery.unlock_image("cg15")

    # Buttons for day 3
    gallery.button("moment_5")
    gallery.unlock_image("cg16")

    gallery.button("moment_6")
    gallery.unlock_image("cg17")


    # Buttons for day 4
    gallery.button("moment_7")
    gallery.unlock_image("cg18")
    gallery.unlock_image("cg19")

    gallery.button("moment_8")
    gallery.unlock_image("cg20")
    gallery.unlock_image("cg21")
    gallery.unlock_image("cg22")
    
    # Buttons for day 5

    gallery.button("moment_9")
    gallery.unlock_image("cg23")

    gallery.button("moment_10")
    gallery.unlock_image("cg27")

    gallery.button("moment_11")
    gallery.unlock_image("cg24")
    gallery.unlock_image("cg25")
    gallery.unlock_image("cg26")

    gallery.button("moment_12")
    gallery.unlock_image("cg28")
    gallery.unlock_image("cg29")
    gallery.unlock_image("cg30")

    # Buttons for day 6

    gallery.button("moment_13")
    gallery.unlock_image("cg31")

    gallery.button("moment_14")
    gallery.unlock_image("cg32")
    gallery.unlock_image("cg33")
    gallery.unlock_image("cg34")

    # Buttons for day 7
    gallery.button("moment_15")
    gallery.unlock_image("cg35")
    gallery.unlock_image("cg36")
    gallery.unlock_image("cg37")

    gallery.button("moment_16")
    gallery.unlock_image("cg38")

    gallery.button("moment_17")
    gallery.unlock_image("cg39")
    gallery.unlock_image("cg40")
    
    gallery.transition = dissolve

screen day_1:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25 
            
            add gallery.make_button("moment_1", unlocked = im.Scale("cg/cg1.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_2", unlocked = im.Scale("cg/cg3.png",600,337), locked = "locked.jpg")
           

screen day_2:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_3", unlocked = im.Scale("cg/cg9.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_4", unlocked = im.Scale("cg/cg14.png",600,337), locked = "locked.jpg")

screen day_3:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_5", unlocked = im.Scale("cg/cg16.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_6", unlocked = im.Scale("cg/cg17.png",600,337), locked = "locked.jpg")

screen day_4:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_7", unlocked = im.Scale("cg/cg18.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_8", unlocked = im.Scale("cg/cg20.png",600,337), locked = "locked.jpg")

screen day_5:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_9", unlocked = im.Scale("cg/cg23.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_10", unlocked = im.Scale("cg/cg27.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_11", unlocked = im.Scale("cg/cg24.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_12", unlocked = im.Scale("cg/cg28.png",600,337), locked = "locked.jpg")

screen day_6:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_13", unlocked = im.Scale("cg/cg31.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_14", unlocked = im.Scale("cg/cg32.png",600,337), locked = "locked.jpg")

screen day_7:
    tag menu
    add "images/bg_gallery.jpg"
    hbox:
        yalign 0.5
        xalign 0.5
        
        use gallery_navigation

        grid 3 2:
            spacing 25

            add gallery.make_button("moment_15", unlocked = im.Scale("cg/cg35.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_16", unlocked = im.Scale("cg/cg38.png",600,337), locked = "locked.jpg")
            add gallery.make_button("moment_17", unlocked = im.Scale("cg/cg39.png",600,337), locked = "locked.jpg")