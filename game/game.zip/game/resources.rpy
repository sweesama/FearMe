#Personajes
define pov = Character ("[povname]", color='CBCBCB')
define Stranger = Character('???', color='#FFFFFF')
define J = Character(_('Jeff'), color='#C10F0F')
define C = Character(_('Cindy'), color='#FF96DC')
define DR = Character(_('Dr. Salazar'), color='#2CDECC')
define TW = Character(_('T. Wes'), color='#41A314')
define DS = Character(_('D. Sean'), color='#AD67D6')
define Peri = Character (_('Periodista'), color='#07B36E')
define T = Character(_('Terapeuta'), color='#DE7F00')
define P = Character(_('Policia'), color='#143AA3')

#transform

transform shake_bg:
    xoffset 0 yoffset 0
    linear 0.05 xoffset 10 yoffset 0
    linear 0.05 xoffset -10 yoffset 0
    linear 0.05 xoffset 10 yoffset 0
    linear 0.05 xoffset -10 yoffset 0
    linear 0.05 xoffset 0 yoffset 0
    repeat 5

transform jumpscare_top:
    anchor (0.5, 0.0)   # centro horizontal, arriba vertical
    xalign 0.5          # mantener centrado horizontalmente
    yalign 0.0          # anclar arriba de la pantalla
    zoom 0.5
    linear 0.3 zoom 2.0

transform jumpscare_reset:
    anchor (0.5, 0.5)    # centro del sprite
    xalign 0.5           # centrado horizontal
    yalign 0.5           # centrado vertical
    zoom 2.0             # parte del zoom del jumpscare
    linear 0.4 zoom 1.0  # vuelve suavemente al tamaño original

transform mover_derecha:
    linear 1.0 xalign 0.8  # tarda 1 segundo en moverse al 80% del ancho de pantalla

#effect

define whitefade = Fade(1.0, 0.5, 1.0, color="#fff")
#Afecto

init:
    $ afecto = 0

#dias

image Day1 = "images/screens/Day 1.png"
image Day2 = "images/screens/Day 2.png"
image Day3 = "images/screens/Day 3.png"
image Day4 = "images/screens/Day 4.png"
image Day5 = "images/screens/Day 5.png"
image Day6 = "images/screens/Day 6.png"
image Day7 = "images/screens/Day 7.png"
image Death = "images/screens/Death.png"


#mapa


#tienda
screen mapa_tienda():

    fixed:

        add "images/maps/store/store.png" 

        # Mostrador
        imagebutton:
            idle "images/maps/store/mostrador_idle.png"
            hover "images/maps/store/mostrador_hover.png"
            xpos 1300
            ypos 1010
            action Jump("mostrador")

        # Pasillo 1
        imagebutton:
            idle "images/maps/store/pasillo_1_idle.png"
            hover "images/maps/store/pasillo_1_hover.png"
            xpos 1000
            ypos 850
            action Jump("pasillo1")

        # Pasillo 2
        imagebutton:
            idle "images/maps/store/pasillo_2_idle.png"
            hover "images/maps/store/pasillo_2_hover.png"
            xpos 1500
            ypos 450
            action Jump("pasillo2")

        # Trastienda
        imagebutton:
            idle "images/maps/store/trastienda_idle.png"
            hover "images/maps/store/trastienda_hover.png"
            xpos 630
            ypos 200
            action Jump("trastienda")

#home
screen mapa_home(time=10, timeout="game_over"):

    fixed:

        add "images/maps/home/home.png" 

        # Closet
        imagebutton:
            idle "images/maps/home/closet_idle.png"
            hover "images/maps/home/closet_hover.png"
            xpos 1100
            ypos 800
            action Jump("muerte_closet")

        # Cama
        imagebutton:
            idle "images/maps/home/cama_idle.png"
            hover "images/maps/home/cama_hover.png"
            xpos 800
            ypos 400
            action Jump("supervivencia_8")

        # Baño
        imagebutton:
            idle "images/maps/home/bano_idle.png"
            hover "images/maps/home/bano_hover.png"
            xpos 800
            ypos 950
            action Jump("muerte_baño")

        # Sala
        imagebutton:
            idle "images/maps/home/sala_idle.png"
            hover "images/maps/home/sala_hover.png"
            xpos 1530
            ypos 400
            action Jump("muerte_sala")
    
        # --- Barra de tiempo (reutiliza el visual del timed_choice.rpy) ---
    if time and timeout:
        default adjusted_time = time * (1 / persistent.timed_choice_speed)
        timer adjusted_time action Jump(timeout)

        # Muestra la barra de tiempo
        vbox:
            xalign 0.5
            yalign 0.4
            use timed_choice_visual(adjusted_time)

screen supervivencia_9(time=10, timeout="game_over"):

    fixed:

        add "images/maps/home/home.png" 

        # Closet
        imagebutton:
            idle "images/maps/home/closet_idle.png"
            hover "images/maps/home/closet_hover.png"
            xpos 1100
            ypos 800
            action Jump("muerte_closet")

        # Cama
        imagebutton:
            idle "images/maps/home/cama_idle.png"
            hover "images/maps/home/cama_hover.png"
            xpos 800
            ypos 400
            action Jump("muerte_cama")

        # Baño
        imagebutton:
            idle "images/maps/home/bano_idle.png"
            hover "images/maps/home/bano_hover.png"
            xpos 800
            ypos 950
            action Jump("supervivencia_9")

        # Sala
        imagebutton:
            idle "images/maps/home/sala_idle.png"
            hover "images/maps/home/sala_hover.png"
            xpos 1530
            ypos 400
            action Jump("muerte_sala")
        
    if time and timeout:
        default adjusted_time = time * (1 / persistent.timed_choice_speed)
        timer adjusted_time action Jump(timeout)

        # Muestra la barra de tiempo
        vbox:
            xalign 0.5
            yalign 0.4
            use timed_choice_visual(adjusted_time)

screen supervivencia_10(time=10, timeout="game_over"):

    fixed:

        add "images/maps/home/home.png" 

        # Closet
        imagebutton:
            idle "images/maps/home/closet_idle.png"
            hover "images/maps/home/closet_hover.png"
            xpos 1100
            ypos 800
            action Jump("muerte_closet")

        # Cama
        imagebutton:
            idle "images/maps/home/cama_idle.png"
            hover "images/maps/home/cama_hover.png"
            xpos 800
            ypos 400
            action Jump("muerte_cama")

        # Baño
        imagebutton:
            idle "images/maps/home/bano_idle.png"
            hover "images/maps/home/bano_hover.png"
            xpos 800
            ypos 950
            action Jump("muerte_baño")

        # Sala
        imagebutton:
            idle "images/maps/home/sala_idle.png"
            hover "images/maps/home/sala_hover.png"
            xpos 1530
            ypos 400
            action Jump("supervivencia_10")
    
    if time and timeout:
        default adjusted_time = time * (1 / persistent.timed_choice_speed)
        timer adjusted_time action Jump(timeout)

        # Muestra la barra de tiempo
        vbox:
            xalign 0.5
            yalign 0.4
            use timed_choice_visual(adjusted_time)

screen supervivencia_11(time=10, timeout="game_over"):

    fixed:

        add "images/maps/home/home.png" 

        # Closet
        imagebutton:
            idle "images/maps/home/closet_idle.png"
            hover "images/maps/home/closet_hover.png"
            xpos 1100
            ypos 800
            action Jump("supervivencia_11")

        # Cama
        imagebutton:
            idle "images/maps/home/cama_idle.png"
            hover "images/maps/home/cama_hover.png"
            xpos 800
            ypos 400
            action Jump("muerte_cama")

        # Baño
        imagebutton:
            idle "images/maps/home/bano_idle.png"
            hover "images/maps/home/bano_hover.png"
            xpos 800
            ypos 950
            action Jump("muerte_baño")

        # Sala
        imagebutton:
            idle "images/maps/home/sala_idle.png"
            hover "images/maps/home/sala_hover.png"
            xpos 1530
            ypos 400
            action Jump("muerte_sala")

    if time and timeout:
        default adjusted_time = time * (1 / persistent.timed_choice_speed)
        timer adjusted_time action Jump(timeout)

        # Muestra la barra de tiempo
        vbox:
            xalign 0.5
            yalign 0.4
            use timed_choice_visual(adjusted_time)

#creditos

screen credits_music():
    tag menu
    frame:
        xalign 0.5
        yalign 0.5
        xmaximum 1200
        ypadding 20
        background Solid("#00000088")

        vbox:
            spacing 8
            xalign 0.5          # centra horizontalmente
            yalign 0.5          # centra verticalmente dentro del frame

            text "BGM:" size 60 color "#FFFFFF" bold True xalign 0.5
            # Lista de canciones (cada item será una línea)
            $ songs = [
                "Tension And Fear by AmethystMusic",
                "Lofi Relax Music by Lofium",
                "Horror Background Atmosphere #2 by TrenoX8",
                "Suspenseful Dark Atmosphere by TrenoX8",
                "Dark and Scary Wind by JuliusH",
                "Dedpression by krym1964",
                "Lofi Song by Jinsei by Lofium",
                "Creepy Ambient Soundscape by Megalix ",
                "Sexy Lounge Music by saavane",
                "Romantic Piano Bitter Sweet Romance by pianocafe_Kumi",
                "Nostalgic Romance by Mircea Iancu"

            ]

            for s in songs:
                text s size 47 color "#FFFFFF" xalign 0.5 text_align 0.5


#house
screen mapa_house:

    fixed:

        add "images/maps/house/house.png"

        # cocina
        imagebutton:
            idle "images/maps/house/cocina_idle.png"
            hover "images/maps/house/cocina_hover.png"
            xpos 1750
            ypos 700
            action Jump("cocina_j")

        # habitacion
        imagebutton:
            idle "images/maps/house/habitacion_idle.png"
            hover "images/maps/house/habitacion_hover.png"
            xpos 600
            ypos 550
            action Jump("habitacion_j")

        # Baño
        imagebutton:
            idle "images/maps/house/bano_idle.png"
            hover "images/maps/house/bano_hover.png"
            xpos 1010
            ypos 400
            action Jump("baño_j")

        # Sala
        imagebutton:
            idle "images/maps/house/sala_idle.png"
            hover "images/maps/house/sala_hover.png"
            xpos 800
            ypos 900
            action Jump("sala_j")

        # Sotano
        imagebutton:
            idle "images/maps/house/sotano_idle.png"
            hover "images/maps/house/sotano_hover.png"
            xpos 1800
            ypos 200
            action Jump("sotano")

#logo

image logo = "images/screens/N_C_LOGO.png"


#Sprites

#jeff

layeredimage jeff1:
    always:
        "images/sprites/jeff/j_body1.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"
        attribute shy:
            "images/sprites/jeff/j_shy.png"

    group extra:
        attribute blush:
            "images/sprites/jeff/j_blush.png"
        attribute none:
            "images/sprites/none.png"
        attribute bandana:
                "images/sprites/jeff/j_bandana.png"
        attribute shot:
                "images/sprites/jeff/j_shot.png"

layeredimage jeff2:
    always:
        "images/sprites/jeff/j_body2.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"
        attribute shy:
            "images/sprites/jeff/j_shy.png"

    group extra:
        attribute blush:
            "images/sprites/jeff/j_blush.png"
        attribute none:
            "images/sprites/none.png"
        attribute bandana:
                "images/sprites/jeff/j_bandana.png"

layeredimage jeff3:
    always:
        "images/sprites/jeff/j_body3.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"
        attribute shy:
            "images/sprites/jeff/j_shy.png"

    group extra:
        attribute blush:
            "images/sprites/jeff/j_blush.png"
        attribute none:
            "images/sprites/none.png"

layeredimage jeff4:
    always:
        "images/sprites/jeff/j_body4.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"
        attribute shy:
            "images/sprites/jeff/j_shy.png"

    group extra:
        attribute blush:
            "images/sprites/jeff/j_blush.png"
        attribute none:
            "images/sprites/none.png"


layeredimage jeffknife1:
    always:
        "images/sprites/jeff/j_knife1.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"

layeredimage jeffknife2:
    always:
        "images/sprites/jeff/j_knife2.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"

layeredimage jeffknife3:
    always:
        "images/sprites/jeff/j_knife3.png"

    group face:
        attribute neutral:
            "images/sprites/jeff/j_neutral.png"
        attribute smile:
            "images/sprites/jeff/j_smile.png"
        attribute happy:
            "images/sprites/jeff/j_happy.png"
        attribute smirk:
            "images/sprites/jeff/j_smirk.png"
        attribute angry:
            "images/sprites/jeff/j_angry.png"
        attribute mad:
            "images/sprites/jeff/j_mad.png"
        attribute sorpresa:
            "images/sprites/jeff/j_sorpresa.png"
        attribute pensativo:
            "images/sprites/jeff/j_pensativo.png"
        attribute hurt:
            "images/sprites/jeff/j_hurt.png"
        attribute sad:
            "images/sprites/jeff/j_sad.png"

# cindy

layeredimage cindy1:
    always:
        "images/sprites/cindy/c_body1.png"

    group face:
        attribute neutral:
            "images/sprites/cindy/c_neutral.png"
        attribute smile:
            "images/sprites/cindy/c_smile.png"
        attribute shy:
            "images/sprites/cindy/c_shy.png"
        attribute angry:
            "images/sprites/cindy/c_angry.png"
        attribute incomoda:
            "images/sprites/cindy/c_incomoda.png"
        attribute sad:
            "images/sprites/cindy/c_sad.png"

    group extra:
        attribute blush:
            "images/sprites/cindy/c_blush.png"
        attribute none:
            "images/sprites/none.png"    

layeredimage cindy2:
    always:
        "images/sprites/cindy/c_body2.png"

    group face:
        attribute neutral:
            "images/sprites/cindy/c_neutral.png"
        attribute smile:
            "images/sprites/cindy/c_smile.png"
        attribute shy:
            "images/sprites/cindy/c_shy.png"
        attribute angry:
            "images/sprites/cindy/c_angry.png"
        attribute incomoda:
            "images/sprites/cindy/c_incomoda.png"
        attribute sad:
            "images/sprites/cindy/c_sad.png"

    group extra:
        attribute blush:
            "images/sprites/cindy/c_blush.png"
        attribute none:
            "images/sprites/none.png"

layeredimage cindy3:
    always:
        "images/sprites/cindy/c_body3.png"

    group face:
        attribute neutral:
            "images/sprites/cindy/c_neutral.png"
        attribute smile:
            "images/sprites/cindy/c_smile.png"
        attribute shy:
            "images/sprites/cindy/c_shy.png"
        attribute angry:
            "images/sprites/cindy/c_angry.png"
        attribute incomoda:
            "images/sprites/cindy/c_incomoda.png"
        attribute sad:
            "images/sprites/cindy/c_sad.png"

    group extra:
        attribute blush:
            "images/sprites/cindy/c_blush.png"
        attribute none:
            "images/sprites/none.png"  


# salazar

layeredimage salazar1:
    always:
        "images/sprites/salazar/s_body1.png"

    group face:
        attribute neutral:
            "images/sprites/salazar/s_neutral.png"
        attribute smile:
            "images/sprites/salazar/s_smile.png"
        attribute shy:
            "images/sprites/salazar/s_shy.png"
        attribute incomodo:
            "images/sprites/salazar/s_incomodo.png"
        attribute sad:
            "images/sprites/salazar/s_sad.png"

    group extra:
        attribute blush:
            "images/sprites/salazar/s_blush.png"
        attribute none:
            "images/sprites/none.png"  
        
    group lentes:
        attribute lentes:
            "images/sprites/salazar/s_lentes.png"


layeredimage salazar2:
    always:
        "images/sprites/salazar/s_body2.png"

    group face:
        attribute neutral:
            "images/sprites/salazar/s_neutral.png"
        attribute smile:
            "images/sprites/salazar/s_smile.png"
        attribute shy:
            "images/sprites/salazar/s_shy.png"
        attribute incomodo:
            "images/sprites/salazar/s_incomodo.png"
        attribute sad:
            "images/sprites/salazar/s_sad.png"

    group extra:
        attribute blush:
            "images/sprites/salazar/s_blush.png"
        attribute none:
            "images/sprites/none.png"

# t.wes

layeredimage tw:
    always:
        "images/sprites/wes/tw_body.png"

    group face:
        attribute neutral:
            "images/sprites/wes/tw_neutral.png"
        attribute smile:
            "images/sprites/wes/tw_smile.png"


# d.sean

layeredimage ds:
    always:
        "images/sprites/sean/ds_body.png"

    group face:
        attribute neutral:
            "images/sprites/sean/ds_neutral.png"
        attribute incomoda:
            "images/sprites/sean/ds_incomoda.png"
    group extra:
        attribute blush:
            "images/sprites/sean/ds_blush.png"
        attribute none:
            "images/sprites/none.png"

#items

image credencial = "images/items/credencial.png"
image s_card = "images/items/s_card.png"
image w_card = "images/items/w_card.png"
image ds_card = "images/items/ds_card.png"
image coffee = "images/items/coffee.png"
image money = "images/items/money.png"
image muffin = "images/items/muffin.png"
image sandwich = "images/items/sandwich.png"
image jar1 = "images/items/jar1.png"
image jar2 = "images/items/jar2.png"

#Bg

#day 1

image office = "images/bgs/office.jpg"
image alley = "images/bgs/alley.jpg"
image backroom = "images/bgs/back room.jpg"
image closed = "images/bgs/closed.jpg"
image closed2 = "images/bgs/closed2.jpg"
image fall = "images/bgs/fall.jpg"
image fall2 = "images/bgs/fall2.jpg"
image floor = "images/bgs/floor.jpg"
image floor2 = "images/bgs/floor2.jpg"
image sky1 = "images/bgs/sky day.jpg"
image sky2 = "images/bgs/sky night.jpg"
image store1 = "images/bgs/store day.jpg"
image store2 = "images/bgs/store night.jpg"
image streetnight = "images/bgs/street night.jpg"
image wall = "images/bgs/wall.jpg"

#day 2

image elvator = "images/bgs/elevator.jpg"
image elevator2 = "images/bgs/elevator2.jpg"
image hospitalhall = "images/bgs/hospital hall.jpg"
image hospitalroom = "images/bgs/hospital room.jpg"

#day 3

image hospitalexit = "images/bgs/hospital exit.jpg"
image car = "images/bgs/car.jpg"
image streetday = "images/bgs/street day.jpg"
image hall = "images/bgs/hall.jpg"
image living = "images/bgs/living.jpg"
image living2 = "images/bgs/living night.jpg"
image kitchen = "images/bgs/kitchen.jpg"
image kitchen2 = "images/bgs/kitchen2.jpg"
image bathroom = "images/bgs/bathroom.jpg"
image bathroom2 = "images/bgs/bathroom night.jpg"
image room = "images/bgs/room.jpg"
image room2 = "images/bgs/room night.jpg"
image bed = "images/bgs/bed.jpg"
image batroom = "images/bgs/bathroom.jpg"
image closet = "images/bgs/closet.jpg"

#day 4

image miniarket = "images/bgs/minimarket.jpg"
image walk = "images/bgs/walk.jpg"
image walk2 = "images/bgs/walk2.png"
image barstreet = "images/bgs/bar street.jpg"
image bar = "images/bgs/bar.jpg"




#day 5
#day 6

image run1 = "images/bgs/run1.jpg"
image run2 = "images/bgs/run2.jpg"
image room_j = "images/bgs/room_j.jpg"
image kitchen_j = "images/bgs/kitchen_j.jpg"
image living_j = "images/bgs/living_j.jpg"
image house_j = "images/bgs/house_j.jpg"
image dinningroom_j = "images/bgs/dinningroom_j.jpg"
image bathroom_j = "images/bgs/bathroom_j.jpg"

#day 7

image basementdoor = "images/bgs/basement door.jpg"
image basement = "images/bgs/basement.jpg"
image cliff = "images/bgs/cliff.jpg"
image newroom = "images/bgs/new room.jpg"
image newroom2 = "images/bgs/new room2.jpg"
image sewer = "images/bgs/sewer.jpg"
image sewerexit = "images/bgs/sewer exit.jpg"
image woods = "images/bgs/woods.jpg"

#Cgs
#day1
image cg1 = "images/cg/cg1.png"
image cg2 = "images/cg/cg2.png"
image cg3 = "images/cg/cg3.png"
image cg4 = "images/cg/cg4.png"
image cg5 = "images/cg/cg5.png"
image cg6 = "images/cg/cg6.png"
image cg7 = "images/cg/cg7.png"
image cg8 = "images/cg/cg8.png"
#day2
image cg9 = "images/cg/cg9.png"
image cg10 = "images/cg/cg10.png"
image cg11 = "images/cg/cg11.png"
image cg12 = "images/cg/cg12.png"
image cg13 = "images/cg/cg13.png"
image cg14 = "images/cg/cg14.png"
image cg15 = "images/cg/cg15.png"

#Screen color

image black = "images/screens/black.png"
image red = "images/screens/red.png"

#audio

play music "audio/music/tension-and-fear-108408.mp3" #play music "audio/music/Aylex - Tension Rising.mp3"
#play music "audio/music/chill-sky-bar-nhac-jazz-thu-gian-222698.mp3"
play music "audio/music/lofi-relax-music-lofium-123264.mp3" #play music "audio/music/Hoffy Beats - Riding the Waves.mp3"
play music "audio/music/horror-background-atmosphere-2-289424.mp3" #play music "audio/music/Horror suspense tension by DELOSound.mp3"
play music "audio/music/suspenseful-dark-atmosphere-303538.mp3" #play music "audio/music/Horror tension by DELOSound.mp3"
play music "audio/music/Nostalgic-Romance-Piano-and-Violin by Mircea Iancu.mp3"
play music "audio/music/dark-and-scary-wind-9658.mp3" #play music "audio/music/Project Ex - Area 16.mp3"
play music "audio/music/dedpression-339994.mp3" #play music "audio/music/Project Ex - Frozen Worlds.mp3"
play music "audio/music/romantic-pianobittersweet-romance-324562.mp3"
play music "audio/music/sexy-lounge-music-131701.mp3"
play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3" #play music "audio/music/Soyb - Departure.mp3"
play music "audio/music/creepy-ambient-soundscape-360808.mp3" #play musicaudio/music/Walen - Dark Heart.mp3"

play music "audio/ambience/night-atmosphere-wind-city.mp3"

#day 1 - 2
play sound "audio/sfx/391898__edinaldoapsantos__high_five.wav"
play sound "audio/sfx/bisturi.mp3"
play sound "audio/sfx/blade-scrape.mp3"
play sound "audio/sfx/blood dripping.mp3"
play sound "audio/sfx/character-falling-on-ground-250069.mp3"
play sound "audio/sfx/cloth.mp3"
play sound "audio/sfx/drinking-water.mp3"
play sound "audio/sfx/ekg-fast.mp3"
play sound "audio/sfx/ekg-normal.mp3"
play sound "audio/sfx/elevator_open.mp3"
play sound "audio/sfx/Equip2.ogg"
play sound "audio/sfx/falling.mp3"
play sound "audio/sfx/gore1.mp3"
play sound "audio/sfx/gore2.mp3"
play sound "audio/sfx/gore3.mp3"
play sound "audio/sfx/gore4.mp3"
play sound "audio/sfx/hang.mp3"
play sound "audio/sfx/heart beat.mp3"
play sound "audio/sfx/keys.mp3"
play sound "audio/sfx/knock-on-glass.ogg"
play sound "audio/sfx/metal-clink.mp3"
play sound "audio/sfx/person-knocked-down.mp3"
play sound "audio/sfx/pouring-water.mp3"
play sound "audio/sfx/push.mp3"
play sound "audio/sfx/running-on-concrete.mp3"
play sound "audio/sfx/rush__blade.mp3"
play sound "audio/sfx/stab.mp3"
play sound "audio/sfx/submerged.mp3"

#day 3 - 7

play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
play sound "audio/sfx/85549__maj061785__glass-clinking.mp3"
play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
play sound "audio/sfx/275570__kwahmah_02__doorbell-d.mp3"
play sound "audio/sfx/403355__corpocracy__door_slam01.mp3"
play sound "audio/sfx/471602__wifisfuneral__move_knob-02.mp3"
play sound "audio/sfx/515007__jusebago__cerrando-puerta-de-carro-closing-car-door.mp3"
play sound "audio/sfx/528595__robinhood76__09358-running-into-lake-water.mp3"
play sound "audio/sfx/587930__robotortoise__knocking-and-banging-on-my-apartment-door-no-reverb.mp3"
play sound "audio/sfx/629997__trexlasso__glass-clink.mp3"
play sound "audio/sfx/649345__isaacburkevideo__glass-clink.mp3"
play sound "audio/sfx/Crash.ogg"
play sound "audio/sfx/Gun1.ogg"
#play sound "audio/sfx/441588__danielajq__18-barriendo.wav"
#play sound "audio/sfx/609139__nataliafranco__nevera.mp3"
#play sound "audio/sfx/740313__fossarts__bathroom-faucet-turned-on-1.mp3"
#play sound "audio/sfx/609727__theplax__door-lock-1.wav"
#play sound "audio/sfx/735844__milcahrawr__muffled-news-program.wav"
#play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
#play sound "audio/sfx/652346__weak_hero__door-closed_1.wav"
#play sound "audio/sfx/186114__carlosramon__16-paper-arrugat.wav"
#play sound "audio/sfx/478579__toklant__drop-mug-on-a-plate-in-a-kitchen.mp3"
#play sound "audio/sfx/346661__deleted_user_2104797__kiss_01.mp3"
#play sound "audio/sfx/352345__noahpardo__npx-male-wet-kiss-3.wav"
#play sound "audio/sfx/658348__dversexxxstudio__kiss.mp3"
#play sound "audio/sfx/765250__damiana79__police-siren.wav"
#play sound "audio/sfx/348223__tbrook__switch-light-07.wav"
#play sound "audio/sfx/637493__kyles__door-wood-old-open-hall-echo.mp3"
#play sound "audio/sfx/442334__liongrill__jumpscare-sound.mp3"
#play sound "audio/sfx/457738__magnumdafolf__sensual-breathing.wav"
#play sound "audio/sfx/508142__headwalker__running-in-the-woods.wav"
#play sound "audio/sfx/
#play sound "audio/sfx/
#play sound "audio/sfx/
#play sound "audio/sfx/
#play sound "audio/sfx/
#play sound "audio/sfx/
#play sound "audio/sfx/