﻿default easy_mode = True

default show_interfaz = False

init:
    $ afecto = 0

init python:
    def show_affection(who, amount):
        if who == "J":
            renpy.show_screen("affection_popup", message=_("*+{0}").format(amount))

init python:
    def show_live(who):
        if who == "YouLive":
            renpy.show_screen("affection_popup", message=_("¡Vives!"))

screen interfaz():
    text "{color=#F02800}{size=70}*: [afecto]{/color}":
        xpos 0.1
        ypos 0.1

#logo

label splashscreen:
    # Mostrar logo (ajustá la ruta a tu imagen)
    scene black
    show logo
    with fade

    pause 2.0   # espera 2 segundos

    hide logo
    with fade

    # Mostrar advertencia
    #with dissolve
    show screen language_select
    $ renpy.pause(99999, hard=True)  # espera hasta que se pulse un botón

label splash_warnings:

    hide screen language_select

    pause 2.0

    show text _("{size=70}Este juego contiene {size=80}{color=#F02800}violencia, gore, asesinato, acoso, abuso, manipulación y muerte de personaje principal{/color}{/size}")
    with dissolve

    pause 4.0

    hide text
    with fade

    show text _("{size=70}Está dirigido a una audiencia {color=#FFED0A}MADURA(+18){/color}{/size}")
    with dissolve

    pause 4.0

    hide text
    with fade

    show text _("{size=70}{color=#ffffff}Por favor juega con discreción{/color}{/size}")
    with dissolve
    pause 4.0

    hide text
    with fade

    return


label start:

   #Prólogo

    stop music fadeout 3.0

    #show screen interfaz

    if easy_mode:
        show screen affection_popup(_("Easy Mode ON"))

    if show_interfaz:
        show screen interfaz
   
    scene office with fade

    "La habitación está en silencio, iluminada por la cálida luz del mediodía que se filtra por la ventana."
    "Miras a cualquier parte que no sea tu terapeuta. Aún no tenías la confianza de hablar con familiaridad."
    "Asistir a esas sesiones se sentía como tarea. Más que por tu bien, parecía ser una manera de vigilarte."
    T "Sabes que no tienes obligación de hablar de él."
    "El terapeuta te miraba con paciencia, apoyando su espalda en el respaldo de su sillón con calma."
    T "Puedes hablar de lo que quieras."
    "Tú resoplas con ironía, sin dar respuesta."
    T "Fueron 7 días. Suficiente para que alguien cambie, ¿No crees?"
    "Instintivamente, alzas la mano al lado izquierdo de tu rostro, donde tienes un parche cubriendo el lugar de tu ojo izquierdo." 
    T "Te hizo daño, no hay duda de eso. La policía, el hospital... todos tienen su versión. Pero yo quiero la tuya."
    "Te encoges de hombros."
    T "Está bien. El silencio es una respuesta."
    "Miras hacia la ventana, en el vidrio se distinguía la silueta de tu reflejo."
    "A pesar de que no te veías con tanta claridad, tu postura y expresión eran notablemente diferentes a una semana atrás."

    stop music fadeout 5.0

    window hide

    #dia 1

    show Day1 with fade

    pause 2.0

    scene store with fade

    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"

    window show

    "El inicio de tu turno es como el botón “Comenzar” de tu vida."
    "Tienes una rutina clara, despertar, trabajar y dormir."
    "No tienes un legado, no tienes ambiciones, no tienes asuntos pendientes."
    "Cumpliste con tus deberes como estudiante y terminaste la escuela."
    "Pero no tienes motivaciones para perseguir un sueño o una meta más allá de donde estás ahora."
    "Sientes como si no tuvieras el un rol protagónico en el mundo, porque nada en especial te ha sucedido (todavía)."
    "De hecho, se podría decir que te dejas llevar por la apatía."
    "Una apatía que te hace sentir las emociones fuertes entumecidas."
    "¿Una vuelta en una montaña rusa?, Agradable, ¿Te tropiezas y caes de bruces en el suelo en público?, No es el fin del mundo."
    "Positivo o negativo, tu rango de emociones era muy bajo."
    "Como un perfecto papel en blanco."
    "De todas maneras, intentas hacer tu vida lo más cómoda posible."
    "Por más raro que suene, trabajas en una tienda de películas que sólo atrae a nostálgicos y a cinéfilos."

    menu:
        "Te encantan las películas":
            $ cine = "Si"
            "La principal razón por la que tomaste el empleo es porque es algo que te gusta."
            "Puedes pasar horas viendo películas y nunca aburrirte."
            jump character_1


        "Las películas están bien":
            $ cine = "No"
            "No te entusiasman mucho."
            "El hecho de que para hacer bien tu trabajo debes saber al menos una película decente de cada género, lo hace más conveniente."
            "Ni siquiera tienes que verlas, con sólo tomar la opinión de personas a las que si les gustan las películas puedes arreglártelas."
            jump character_1

    
    label character_1:

    "El lugar es lo suficientemente colorido como para no deprimirte con sólo estar ahí, y si tienes suerte, puedes encontrarte uno que otro personaje."
    "Claro, aparte de los personajes que ya existen."
    show cindy1 neutral at center
    with dissolve
    C "¿Recuperando el tiempo perdido?"
    C "Por un momento pensé que no vendrías."
    "Cindy, tu compañera de trabajo."
    "No es muy buena en lo que hace, lo cual es decir mucho ya que ser dependiente de una tienda perdida en el tiempo no requiere mucho esfuerzo, pero es la hija del dueño."
    "Tú eres la otra persona que trabaja full-time, y te desempeñas bien."
    "Ustedes no se llevan ni muy bien ni muy mal, se soportan."
    C "¿Dónde está tu credencial?"
    "Instintivamente te llevaste la mano al cuello, y efectivamente, tu credencial de empleado no estaba."
    C "Es raro, pero siento que no puedo decir tu nombre sin tu credencial."
    "Cindy se encogió de hombros y se retiró a la trastienda con una caja llena de películas."
    hide cindy1 with dissolve
    "De alguna manera, lo que te dijo ella  tenía algo de sentido."
    "Es como si tampoco pudieras recordar tu nombre si no estaba escrito frente a ti." 
    "Como si los nombres solo existieran si alguien más los decía en voz alta."
    "Bueno, recordabas haberlo sacado entre tus cosas cuando llegaste, lo más seguro es que estaba en la tienda."
    jump tienda

    label tienda:

    window hide

    call screen mapa_tienda

    label mostrador:
    hide screen mapa_tienda
    window show
    "Revisas detrás del mostrador, en el suelo no hay nada."
    jump tienda

    label trastienda:
    hide screen mapa_tienda
    scene backroom with fade
    window show
    show cindy1 neutral at left
    with dissolve
    "Tal vez lo hayas dejado caer en la trastienda, pero sólo te encontraste a Cindy viendo su teléfono junto a las cajas que se había llevado."
    "Cindy te dio una mirada rápida, para luego volver a ignorarte."
    "Tú seguiste su ejemplo y te enfocas en buscar tu credencial."
    hide cindy1 with dissolve
    "Sip, no estaba ahí."
    scene store with fade
    jump tienda

    label pasillo1:
    hide screen mapa_tienda
    window show
    "Entre los estantes llenos de películas de acción, tu credencial no está ahí."
    jump tienda

    label pasillo2:
    hide screen mapa_tienda
    window show
    "Te inclinas para intentar ver mejor el suelo, con esperanza de que tu credencial esté por ahí."
    "Avanzas por el pequeño pasillo, determinado por estanterías llenas de películas de terror y thriller."
    jump movimiento_1

    label movimiento_1:

    hide tienda

    window hide

    show credencial at truecenter
    with dissolve

    window show

    "Hasta que visualizas el inconfundible pedazo de plástico, casi llegando al final del pasillo."
    play sound "audio/sfx/Equip2.ogg"
    "Estás por alcanzar tu credencial, pero una mano blanca se te adelanta, recogiendo con lentitud el pedazo de plástico."
    hide credencial with dissolve
    show jeff2 neutral bandana at center
    with dissolve
    "Miras hacia arriba y te encuentras con un hombre alto, encapuchado y con la cara cubierta."
    "Parece un criminal en potencia, o alguien resfriado."
    "Pero no tienes energías de preocuparte."
    "Te enderezas en tu lugar, quedando frente a frente."
    "El hombre parece ignorarte, más interesado en tu credencial en su mano."
    Stranger "¿Es tuya?"
    "Su voz, suavizada por la tela, es grave y ligeramente rasposa."
    "Asientes en silencio, mirando con sospecha al hombre."
    "Por el cómo ladeó la cabeza." 
    Stranger "Pruébalo."
    "Ahora, por fin puedes visualizar tu nombre."
    $ povname = renpy.input(_("Tu nombre es..."), length=25)
    Stranger "…."
    "El hombre mira en silencio la credencial, y por un momento de verdad pensaste que quizás te equivocaste después de todo, pero entonces él te ofreció el pedazo de plástico."
    Stranger "De acuerdo, [povname]."
    "Recibes la credencial en tus manos, dedicándole una mirada al tipo."
    menu: 
        "Agradecer":
            pov "Gracias, señor."
            Stranger "… No me digas así, no soy tan viejo."
            pov "Lo siento, pero no tengo manera de saberlo cuando no veo tu cara."
            Stranger "Mmh, supongo que tienes un punto."
            pov "Además, por la piel de tus manos, puedo decir que no eres exactamente un jovencito-"
            Stranger "Sí, ya entendí."
            "La voz del sujeto se escuchaba irritada."
            "Una parte de ti te decía que debías ser más “dulce” con los clientes, pero si con tu palabrería lograste molestarlo, podrías considerarlo un logro."
            "Este tipo te daba mala espina."
            jump ruta_normal_1

        "Burlarte":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Quién eres?, ¿La seguridad de credenciales?"
            "El hombre se encoge de hombros, despreocupado."
            Stranger "Sólo quería asegurarme de dárselo a la persona correcta."
            pov "Evidentemente trabajo aquí."
            "Él se ríe entre dientes."
            Stranger "Sí~ pero podría haberle pertenecido a algún otro trabajador."
            pov "Literalmente tiene mi foto impresa."
            "El sujeto restó importancia con un gesto de mano."
            Stranger "¿Hubieras preferido que le diera tu credencial a cualquiera con uniforme que la reclame como suya?"
            "Su lógica era extrañamente convincente."
            pov "… Supongo que no."
            "El hombre ladeó la cabeza con burla." 
            "No podías verlo por la bandana, pero sabías que estaba sonriendo."
            Stranger "¿Ves?, no soy tan malo."
            "Que él dijera eso te hizo pensar lo contrario."
            jump ruta_normal_1

    label ruta_normal_1:
    
    play sound "audio/sfx/cloth.mp3"
    "Te colocas en silencio la credencial en tu cuello, mientras él seguía inmóvil en su lugar."
    "Te moviste lentamente en dirección al mostrador."
    "El tipo te miró fijamente mientras te movías, lo que hizo empeorar tu incomodidad."
    hide jeff2 with dissolve
    "Decidiste ignorarlo, desviando tu atención a uno de los monitores junto a ti."
    "Podrías, si el sujeto encapuchado de antes dejara de darse tantas vueltas por la tienda de manera sospechosa."
    "Lo ignorabas con todas las ganas, pero era imposible no notarlo."
    "Quizás lo estaba haciendo a propósito."
    show cindy1 neutral at center
    with dissolve
    C "Hey, [povname]."
    "Ante el llamado de tu nombre, alzaste la mirada hacia Cindy, la cual había rodeado el mostrador para estar a tu lado."
    C "¿Viste que ese tipo ha estado aquí mucho tiempo?"
    "Miraste hacia donde ella estaba apuntando disimuladamente, y por supuesto, estaba hablando del mismo tipo."
    pov "Seh, lo vi."
    "Te encoges de hombros. Una reacción muy lógica, ¿No?"
    pov "Tal vez está decidiendo qué comprar."
    "Seguramente era un tipo raro que vas a ver una vez, no era para tanto."
    "De todas formas, Cindy, por más que fuera insufrible, no se alteraba fácil."
    pov "Es sólo un rarito, vemos de esos a diario."
    C "Pero este se siente diferente…"
    "Estabas empezando a creer que Cindy había visto muchas películas, pero luego recordaste que ella no le gustaba el séptimo arte y sólo trabaja en la tienda de su padre."
    pov "Cuando hablé con él, no parecía ser peligroso."
    show cindy1 incomoda
    "Cindy se giró a ti con sorpresa."
    C "¿Hablaste con él?, ¿Te dijo algo extraño?"

    menu:
        "Si":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Me pidió que dijera mi nombre."
            C "¿Eh?, ¿Por qué?"
            pov "Él recogió mi credencial, supongo que para corroborar que era mía."
            "Cindy se sujetó la barbilla, pensativa."
            pov "Fue… un poco raro, supongo."
            jump ruta_normal_2

        "No":
            pov "Solo devolvió mi credencial."
            C "¿Por qué la tenía él?"
            pov "O sea, él la agarró primero- mira, no fue la gran cosa."
            jump ruta_normal_2

    label ruta_normal_2:

    "Cindy te miró en silencio por unos segundos, para después suspirar."
    pov "Si te incomoda, puedo pedirle que se vaya."
    "Cindy negó con la cabeza, mirando de reojo al sujeto."
    C "Probablemente tengas razón…"
    C "Bueno, te dejo, seguiré viendo el inventario."
    pov "Claro."
    "Te acomodaste en tu silla designada, y antes de fingir ver los recibos, Cindy volvió a hablar."
    C "Pero si hace algo sospechoso, me avisas, ¿Sí?"
    hide cindy1 with dissolve
    "Asentiste con un leve gesto. Cindy no esperó respuesta verbal; sólo volvió a su tarea."
    "Te quedaste un momento con los ojos fijos en la pantalla del monitor. Por el rabillo del ojo miraste los pasillos."
    "El tipo seguía ahí."
    "Sólo parado."
    "Miraba una estantería que no tenía nada particularmente interesante."
    "Y entonces, te miró."
    "No fue una mirada rápida o distraída."
    "Fue directa."

    menu: 
        "Desviar la mirada":
            "Ese tipo te estaba empezando a espantar."
            "No pudiste enfrentarlo, estaba siendo demasiado."
            jump ruta_normal_3
        "Corresponder la mirada":
            $ show_affection("J", 1)
            $afecto += 1
            "Le devolviste la mirada con la misma intensidad."
            "No sabías si lo hacías por valentía, terquedad… o simple curiosidad."
            "Pero él no pestañeó."
            "Y entonces, hizo un leve gesto."
            "Un movimiento casi imperceptible con la cabeza."
            "Como si estuviera saludando."
            jump ruta_normal_3

    label ruta_normal_3:

    "Decidiste ignorarlo, volviendo tu atención al monitor para quitar el cd del reproductor."
    "Mientras guardas el cd en su respectiva caja, observas tus opciones."

    menu: 
        "Fantasía":
            "Te apetecía salir de la realidad, con mundos mágicos y criaturas extraordinarias."
            "Así que escoges una película y la ves el resto de tu turno."
            jump ruta_normal_10
        "Romance":
            "Te apetece ver cómo se desenvuelven las relaciones ajenas, tal vez una parte de ti desearía vivir una historia de amor."
            "Así que escoges una película y la ves el resto de tu turno."
            jump ruta_normal_10
        "Terror":
            $ show_affection("J", 1)
            $afecto += 1
            "Disfrutas los sustos y la atmósfera que generan las películas de terror."
            jump ruta_normal_4
        "Comedia":
            "Te apetece reír y disfrutar de buenos chistes y situaciones."
            "Así que escoges una película y la ves el resto de tu turno."
            jump ruta_normal_10
        "Musical":
            "Disfrutas de un buen musical, grandes canciones y coreografías."
            "Así que escoges una película y la ves el resto de tu turno."
            jump ruta_normal_10
        "Ciencia Ficción":
            "Te interesa la tecnología y cómo es que la gente se imagina cómo sería el futuro."
            "Así que escoges una película y la ves el resto de tu turno."
            jump ruta_normal_10

    label ruta_normal_4:

    "Estás por escoger una película, hasta que el repentino sonido de alguien apoyándose en el mostrador frente a ti te desconcentra."
    play sound "audio/sfx/cloth.mp3"
    window hide
    show cg1 with dissolve
    pause 2.0
    window show
    "Nuevamente, el sujeto desconocido se hace presente, esta vez frente a ti, mirando con atención el cd en tus manos."
    Stranger "¿Qué película vas a poner?"
    pov "¿Disculpa?"
    Stranger "Quiero saber qué película vas a poner, ¿Eso es un crimen?"
    pov "No, claro que no, pero-"
    Stranger "Vamos, estoy indeciso, tal vez puedas inspirarme."
    "Lo miraste en silencio por un momento, para después suspirar con cansancio."

    menu: 
        "Black Swan (2010)":
            Stranger "Ah, psicológico."
            Stranger "¿Te gusta analizar a las personas?"
            Stranger "¿Qué conclusiones sacas de mí?"
            pov "Que te parece que mis gustos son patéticos."
            Stranger "….."
            Stranger "Vaya, diste en el clavo."
            pov "¿Ahora quien tiene gustos patéticos?"
            "El tipo se cruza de brazos con irritación."
            Stranger "Tch…"
            $ pelicula = None
            jump ruta_normal_5
        "The Exorcist (1973)":
            Stranger "¡Hahaha!"
            Stranger "¿En serio te gusta eso?"
            pov "Hey, es un clásico."
            Stranger "Admito que tuvo su impacto, pero es sólo propaganda religiosa."
            pov "Ok, tal vez tengas un punto, pero no quita que sea buena."
            Stranger "Lo que digas."
            $ pelicula = None
            jump ruta_normal_5
        "Scream (1996)":
            $ show_affection("J", 1)
            $afecto += 1
            Stranger "Oh~"
            Stranger "Un clásico slasher~"
            Stranger "Interesante."
            $ pelicula = "A"
            jump ruta_normal_5
        "Tremors (1990)":
            Stranger "……."
            Stranger "¿En serio?"
            pov "¿Qué?"
            $ pelicula = None
            jump ruta_normal_5
        "Paranormal Activity (2007)":
            Stranger "Oh, si, a mi también me gusta esa."
            Stranger "Me ayuda a dormir."
            $ pelicula = None
            jump ruta_normal_5
        "Pulse (2001)":
            $ show_affection("J", 1)
            $afecto += 1
            Stranger "Oh~"
            Stranger "Es de esas películas sin sustos fáciles y que se mete en la piel."
            Stranger "Me gusta~"
            $ pelicula = "A"
            jump ruta_normal_5
        "The Thing (1982)":
            Stranger "Mmh, los efectos especiales son geniales, supongo…"
            $ pelicula = None
            jump ruta_normal_5

    label ruta_normal_5:

    pov "Bueno, ¿Eso te ayudó a decidir?"
    show cg2 with dissolve
    hide cg1
    "El sujeto ladeó la cabeza, ahora sabías con seguridad  que esa era su manera de mostrar burla."
    Stranger "Un poco."
    Stranger "Aunque lo que más me llamó la atención fue el género que elegiste."
    "Alzaste una ceja."
    pov "¿Sí? ¿Y qué tiene?"
    Stranger "Terror."
    "El tono de él baja."
    Stranger "Interesante elección. Siempre dice algo de quien lo prefiere."
    pov "¿Como qué?"
    Stranger "Que buscas sentir algo real."
    Stranger "O quieres que el miedo tenga un rostro." 
    Stranger "Algo que puedas entender, incluso si significa peligro."
    "Sus palabras eran suaves, pero se clavaban como agujas bajo la piel."
    pov "O tal vez me gustan las emociones fuertes sin ponerme en riesgo. Como todos los demás."
    Stranger "Pero tú no eres como todos los demás."
    "Vaya, hay que quitar esa frase del bingo de la novela visual."
    "Él se acercó un poco más al mostrador. No invadía tu espacio… pero era como si lo acariciara."
    Stranger "No pareces tener miedo."
    pov "¿Debería tenerlo?"
    Stranger "Depende. ¿Prefieres ver el horror desde afuera… o que te mire de vuelta?"

    menu: 
        "Seguirle la corriente":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Supongo que eso depende de qué tan bonita sea la cara del horror."
            "Él ladea un poco la cabeza, como si le hubieras dicho algo que no esperaba del todo, pero tampoco parece sorprendido."
            Stranger "…Vaya."
            Stranger "Ten en cuenta que a veces lo bonito también muerde."
            "Mira un segundo hacia los estantes como si buscara algo, pero es obvio que no lo hace."
            Stranger "O quizás te gusta que te muerdan. Quién sabe."
            "Se encoge de hombros, como restándole importancia a sus propias palabras."
            jump ruta_normal_6
        "Ignorarlo":
            pov "Voy a revisar el sistema un momento. Si decides algo, me avisas."
            "No se mueve. Apoya el codo en el mostrador, observándote."
            "El silencio es pesado."
            jump ruta_normal_6
    
    label ruta_normal_6:

    "Él extendió un dedo e hizo círculos sobre la superficie del mostrador."
    "Estaba fingiendo pensar, ignorándote, pero consciente de tu presencia."
    "Por el bien de tu sanidad mental, debías apresurarlo."

    menu:
        "Ser sutil":
            "Carraspeas contra tu mano hecha un puño."
            pov "Ehm, ¿Vas a escoger algo?"
            Stranger "Eres algo impaciente, ¿Eh?"
            pov "Oh, disculpa, no quise-"
            Stranger "Relájate, sólo estoy jugando."
            jump ruta_normal_7
        "Ir al grano":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Hey, amigo, ¿Podrías apresurarte?"
            Stranger "¿Cuál es la prisa?, no hay muchos clientes además de mí."
            pov "¿Siquiera quieres comprar algo?"
            "El tipo se rió entre dientes."
            Stranger "Sólo soy indeciso, no le hago daño a nadie."
            jump ruta_normal_7

    label ruta_normal_7:

    "Desviaste la mirada hacia atrás, en búsqueda de Cindy, sólo para sentir algo de seguridad de que no estabas por tu cuenta."
    "Pero lamentablemente, no la veías por ningún lado."
    play sound "audio/sfx/cloth.mp3"
    "Entonces, sin que se lo pidieras, él estiró una mano por encima del mostrador."
    J "Soy Jeff, creo que es momento de presentarnos formalmente, ¿No crees, [povname]?"
    "Tu mirada bajó a su mano."

    menu:
        "Chocar su mano":
            play sound "audio/sfx/391898__edinaldoapsantos__high_five.mp3"
            $ show_affection("J", 1)
            $afecto += 1
            J "……"
            pov "……"
            J "¡Hahahaha!"
            "Jeff se rió fuertemente, llamando la atención de los pocos clientes que seguían en la tienda."
            "No pudiste evitarlo, pero tu también te reíste por tu acción."
            pov "Hey, no exageres… nos están viendo."
            J "¿Por qué? ¿Te avergüenza de que te vean?"
            pov "No es eso, estás molestando a los clientes."
            J "Heh, cierto, no te tomaba como alguien que se avergüence fácilmente."
            jump ruta_normal_8
        "Tomar su mano":
            "Jeff sujetó tu mano con suavidad, como si quisiera hacer ver su contacto como algo inofensivo."
            J "Mmh, lindo…"
            "Sus dedos no apretaron, pero tampoco se retiraron enseguida." 
            "La frialdad del gesto no parecía molestarle, al contrario, le hacía gracia."
            "Finalmente soltó tu mano, como quien deja caer algo que ya inspeccionó suficiente."
            jump ruta_normal_8

    label ruta_normal_8:

    "Como alguien que trabaja en una tienda, deberías convencer al cliente de llevar lo más que pueda, pero algo te decía que Jeff se tomaría su buen tiempo."
    "Lo miraste unos segundos en silencio, observando su postura pensativa."
    "Si él estaba insistiendo en alargar la interacción, tenías permitido incomodar también, ¿No?"

    menu:
        "¿Qué hay con la bandana?":
            J "…."
            J "¿Por qué quieres saber?"
            menu:
                "Curiosidad":
                    J "…."
                    J "Tengo cicatrices, no son agradables de ver."
                    "Parece que tocaste una fibra sensible."
                    jump ruta_normal_9
                "¿Duele?":
                    $ show_affection("J", 2)
                    $afecto += 2
                    J "…"
                    J "Ya no lo hace, eso es lo que importa."
                    "No eras de meterte en asuntos ajenos, pero ya estableciste una conversación con él."
                    "No podía simplemente no importarte."
                    jump ruta_normal_9
        "¿En qué trabajas?":
            J "¿Huh?"
            J "¿Qué tiene que ver eso?"
            pov "Oh, ¿Eres freelancer?"
            J "¿Qué mierd…? ¡No!"
            pov "¿Entonces estás desempleado?"
            J "¡Yo-!"
            J "…. Bueno, técnicamente sí."
            pov "Hey, no hay de qué avergonzarse, ya te llegará la oportunidad."
            J "No quiero escuchar eso de ti."
            pov "¿Qué quieres decir con eso?"
            J "Descúbrelo tú."
            jump ruta_normal_9
        "¿Tienes pareja?":
            "Jeff se trastabilló en su lugar, dirigiendo su mirada hacia ti."
            "Se quedó en silencio unos segundos, recuperándose de la sorpresa inicial, para después ladear la cabeza, con un toque burlón."
            J "¿Y si lo hago?"
            menu:
                "Coquetear":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "No me molestaría compartir."
                    "Apoyas tu barbilla sobre tu mano, alzando las cejas juguetonamente."
                    "Jeff carraspea contra su bandana, ocultando lo que tu sospechas que es una carcajada."
                    "Al menos lo hiciste reír."
                    jump ruta_normal_9
                "Encogerte de hombros":
                    pov "Bien por ti si es el caso."
                    "Preguntaste por preguntar, no porque realmente tuvieras interés en él."
                    "Los hombros de él cayeron y te pareció escuchar un suspiro de su parte."
                    jump ruta_normal_9

    label ruta_normal_9:

    pov "Bueno, ¿Decidiste que llevar?"
    "Jeff depositó su atención nuevamente en ti."
    J "Vaya, pareciera que de verdad quisieras deshacerte de mí."

    menu:
        "Responder con amabilidad":
            pov "No es eso… si necesitas ayuda, estoy para atender."
            "Él ladeó la cabeza ligeramente, pero esta vez no con burla, sino más bien con aburrimiento."
            "Sus dedos dejaron de tamborilear, ahora quietos sobre la superficie del mostrador."
            J "Ah… claro. El protocolo de servicio."
            "La burla seguía ahí, pero sus ojos ya no brillaban con la misma chispa de antes."
            "Por un segundo, casi parecía que iba a decir algo más, pero se limitó a un suspiro discreto."
            hide cg2 with dissolve
            show jeff2 neutral bandana at center
            with dissolve
            J "En fin, creo que no llevaré nada."
            "Genial, todo fue para nada."
            J "Ojalá hubiera sido un gusto conocerte, [povname], pero… no estoy tan seguro."
            "Jeff se enderezó del mostrador, dándole palmadas al mostrador."
            pov "Seh, opino igual, Jeff."
            "No te quedas atrás y correspondes a la poca energía."
            hide jeff2 with dissolve
            "Jeff resta importancia con un gesto de mano y se retira."
            "Por fin."
            "Este tipo te estaba poniendo de los nervios, con todas sus preguntas y comentarios."
            "Todo parecía una invitación a un juego, pero no tenías por qué aceptarlo."
            jump ruta_normal_10
        "Responder con sarcasmo":
            $ show_affection("J", 1)
            $afecto += 1
            pov "No, para nada. Amo perder el tiempo con raritos que caminan en círculos como si estuvieran perdidos en el supermercado."
            "Jeff abrió mucho los ojos, fingiendo ofensa."
            J "¡Oye! Eso fue cruel. Me vas a hacer llorar."
            "Se llevó una mano al pecho, exagerando, y luego volvió a reírse entre dientes. Esta vez su risa fue más baja, más real."
            J "No sé si esto fue divertido porque hablé contigo o porque te arruiné el día."
            "La declaración salió con una franqueza inquietante."
            "No sabías como reaccionar, pero sí sabías que al final Jeff había hecho las cosas adrede"
            pov "Bueno… al menos reconoces que no fuiste exactamente un deleite."
            J "Claro, no soy idiota, me doy cuenta de lo que provoco en la gente."
            "Jeff se encogió de hombros, para después ladear la cabeza, interrogante y burlesco."
            J "¿Tratas a todos los clientes así o soy especial?"
            "No pudiste evitar soltar una pequeña carcajada ante sus palabras."
            pov "¿Sabes qué?, no suelo gastar tanta energía en desconocidos. Pero tú te lo ganaste."
            hide cg2 with dissolve
            show jeff2 happy bandana at center
            with dissolve
            "Jeff se enderezó repentinamente, contento, como si le hubieran dicho que consiguió un gran logro."
            J "¡Lo tomo!"
            "Por un momento pensaste que Jeff se refería a que tomaba tus palabras con gusto, hasta que te fijaste que los ojos de él estaban dirigidos a la película que habías escogido para colocar en el reproductor."
            if pelicula == "A":
                pov "Oh, genial."
                "Hablaste con alivio. Por fin Jeff se llevaría algo."
                "Además de que era algo que sabías que le gustaba."
                "Sentiste que hacer bien tu trabajo no se sintió tan mal."
            else:
                pov "Oh, de acuerdo."
                "No creías que le vaya a gustar, pero aprecias que al final se haya llevado algo."
                "A pesar de haber hecho bien tu trabajo, no sientes mucha satisfacción"
            pov "Gracias por comprar con nosotros."
            "Jeff asintió, recibiendo la película en su respectiva bolsa y se dirigió a la salida."
            J "Fue un placer, [povname]."
            hide jeff2 with dissolve
            "Él sacudió su mano a modo de despedida, y tú correspondiste con tu propia mano, aunque no tan entusiasta como la de él."
            "Bueno, lograste venderle al rarito del día."
            "Fue un logro, después de todo."
            jump ruta_normal_10

    label ruta_normal_10:

    scene store2 with dissolve
    "Tu día laboral ha terminado."
    "Dentro de todo, fue tranquilo."
    "La noche ha caído, pero no es razón para preocuparte porque vives a unas calles."
    "Algunas cosas son así de convenientes."
    "Esta semana le tocaba a Cindy quedarse para cerrar la tienda."
    "Como ustedes dos tienen casi el mismo cargo, decidieron que la tarea de cerrar sería por turnos."
    "Así que tu estabas con tus cosas listas para irte a tu hogar."
    show cindy1 incomoda at center
    with dissolve
    C "¿Vas a estar bien?"
    pov "Claro, ¿Por qué no lo estaría?"
    C "Ese tipo, parecía estar algo fijado en ti."
    "Resoplas con ironía."
    pov "Vamos, ¿En mi?"
    show cindy1 neutral at center
    C "Si, tampoco lo entiendo."
    "Ok, ouch."
    show cindy1 incomoda at center
    C "Pero, ¿Y si te sigue?"
    pov "Eso no va a pasar. Se fue hace horas, es imposible que se haya quedado rondando por aquí."
    C "No lo sé… tu sensor de peligro no es muy acertado que digamos."
    pov "El peligro es subjetivo."
    show cindy1 angry
    C "Eso no es así."
    pov "¿Por qué te importa tanto?, creí que me odiabas."
    show cindy1 incomoda at center
    "Cindy se sorprende ante tus palabras. Desvía la mirada hacia un lado, jugando con la vara de la mopa que tenía en manos, para limpiar antes de cerrar."
    C "No te odio… Sólo pienso que estar contigo es aburrido."
    pov "Sí, bueno, tú no eres exactamente el alma de la fiesta."
    show cindy1 neutral at center
    C "No lo digo como algo malo, en realidad… siento paz contigo."
    pov "Oh."
    C "Tu despreocupación por todo puede llegar a ser tedioso, pero también es reconfortante… de alguna manera."
    "Rascas tu cabeza, sin saber cómo reaccionar ante las palabras de Cindy. En realidad nunca te había dicho algo lindo hasta ahora."
    show cindy1 shy at center
    "Cindy se aclara la garganta, desviando la mirada con una mueca avergonzada."
    C "Lo que quiero decir… es que no quiero que te pase nada."
    "Das un paso a ella y posas tu mano en su hombro, sonriéndole con calma."
    pov "Estaré bien. Que algo raro pase no significa que el universo haya decidido girar en mi contra."
    "Ustedes compartieron un último gesto de despedida antes de que tú cerraras la puerta detrás de ti."
    scene closed with dissolve
    "El letrero de la tienda indicaba que estaba cerrado, y tú suspiraste, sintiendo que el peso de vivir una vida adulta en un mundo capitalista se levantaba un poco de tus hombros."
    "Sólo un poco."
    scene streetnight with dissolve
    "Es parte de la rutina, despedirte de Cindy e irte finalmente a tu hogar."
    "Vives por tu cuenta desde que empezaste a trabajar, por lo que no tienes responsabilidades extra por las que preocuparte, eso te daba espacio para concentrarte en tus propias necesidades."
    "No es una vida extraordinaria, pero es funcional."
    "Trabajas durante la semana, ganas dinero suficiente para el alquiler y las cuentas, y descansas los fines de semana." 
    "A pesar de que la calle está bien iluminada, el ambiente no deja de ser lúgubre mientras caminas en dirección a tu departamento."
    "Siempre ha sido así. Nada por lo que temer. ¿Cierto?"

    if afecto > 5:
        jump historia_continua_1
    else: 
        jump ruta_mala_1

    #ruta mala 1 / 0 a 9 puntos
    label ruta_mala_1:
    stop music fadeout 3.0
    play music "audio/music/suspenseful-dark-atmosphere-303538.mp3"
    play sound "audio/sfx/running-on-concrete.mp3"
    "Repentinamente, sientes el sonido de pasos acelerados desde atrás."
    play sound "audio/sfx/cloth.mp3"
    "Te giras para poder reaccionar, pero sientes que unos brazos te rodean fuertemente por el cuello, lo que te inmoviliza."
    play sound "audio/sfx/gore3.mp3"
    "Forcejeas para liberarte, pero es entonces que sientes la presión en tu estómago."
    show red with fade
    play sound "audio/sfx/gore2.mp3"
    "El frío se ramifica desde tu estómago hasta el resto de tu cuerpo, y puedes jurar que sientes tus entrañas al aire libre."
    "Tu cuerpo se estremece tras ser perforado, y es entonces que el dolor llega."
    "Duele, duele mucho."
    "Es tan intenso que no puedes sentir tus extremidades."
    "¿Así es cómo ibas a morir?"
    "Sabías que iba a pasar eventualmente, pero no sabías que iba a doler tanto."
    "¿Quién pudo hacerte esto?"
    "Algo tan cruel…"
    "¿Si quiera te lo merecías?"
    "No eras una santidad, pero no te considerabas una mala persona."
    scene black with fade
    "El último pensamiento que cruzó por tu mente, es que Cindy tendrá que cubrir tu turno mientras buscan un reemplazo."
    window hide
    show Death with fade
    pause 2.0
    "{b}Final I: No Llamaste Su Atención{/b}"
    return

    #historia continua 10 puntos
    label historia_continua_1:

    stop music fadeout 3.0
    play music "audio/music/tension-and-fear-108408.mp3"
    "Es entonces que sientes que tiran de tu brazo hacia un lado, con una gran fuerza."
    "Tal vez sí debiste estar más alerta."
    play sound "audio/sfx/cloth.mp3"
    scene alley with dissolve
    "Tiran de ti hasta un callejón al lado de la calle, es ligeramente más oscuro, pero por un farol al costado puedes distinguir lo que está frente a ti."
    "Como la repentina acción te desorientó, te demoras en reaccionar."
    pov "¿Que mierd-?"
    play sound "audio/sfx/push.mp3"
    "El sonido de un golpe leve a un lado de tu cabeza te interrumpe, y te das cuenta que la persona te acorraló contra la pared de ladrillos detrás de ti."
    "Miras de reojo el brazo de la persona, una familiar manga blanca cubre un brazo que se alarga desde tu punto ciego hacia delante."
    "Te cansas de la intriga y finalmente alzas la mirada hacia la persona que te acorraló, tienes un idea de quien podría ser."
    window hide
    show cg3 with dissolve
    pause 2.0
    window show
    J "[povname], nos encontramos de nuevo."
    "La incertidumbre te invade ante la vista de un rostro blanco, lleno de cicatrices."
    "Jeff se había quitado la capucha y la bandana, revelando su rostro."
    "La piel variaba de colores y texturas, su nariz estaba hundida, sus ojos azules lechosos estaban sumidos en párpados negros, y tenías la seguridad de que no lo has visto parpadear ni una sóla vez."
    "Pero lo que llamó más tu atención, fue la cicatriz que atravesaba su boca."
    "No parecía ser un corte limpio, y el cómo deformaba la expresión de él te causó un escalofrío desagradable."
    "Suponías que su rostro tendría imperfecciones que él querría esconder para no recibir miradas de desconocidos, pero considerando la bizarra situación, no fue sorprendente."
    pov "¿Jeff?"
    "Ciertamente, estabas en desventaja aquí, por lo que intentas pensar maneras para dar vuelta la mesa."
    pov "Wow, quién lo hubiera imaginado, de noche, alguien solo, callejón lúgubre, un clásico."
    "Jeff se rió entre dientes ante tu sarcasmo."
    J "No dejas la actitud, ¿Eh?"
    play sound "audio/sfx/blade-scrape.mp3"
    show cg6 with dissolve
    hide cg3
    "Para luego sacar del bolsillo de su capucha un… cuchillo."
    J "Ahora… aseguráte de darme un buen espectáculo."
    "La voz de él era rasposa, acelerada en un tono ansioso. Daba la impresión de que él estaba impaciente."
    pov "¿... Espectáculo?"
    J "El miedo es exquisito…"
    "Él susurró, casi (e innecesariamente) poético, inclinándose hacia ti, su respiración rozando tu rostro."
    pov "Hey, no es por nada… pero todo tu acercamiento se siente muy cliché."
    "Jeff ladeó la cabeza hacia un lado, hubieras jurado que eso era el equivalente de él alzando una ceja."
    "Si él tuviera cejas."
    J "No es un momento adecuado para bromear, ¿No crees?"
    pov "Si, bueno, realmente no sé qué te motivó a atacarme, pensé que nos estábamos llevando bien."
    "Jeff presionó el ancho de la hoja contra tu mejilla, el metal frío contra tu piel tibia."
    J "¿Estás preguntando qué te hace especial?"
    pov "¿Ser especial es que me lleves a un callejón oscuro?, Vaya, no debes ser muy popular."
    "Jeff resopló con molestia."
    play sound "audio/sfx/person-knocked-down.mp3"
    "Te sujetó el hombro con la mano con la que te acorraló, y te estrelló contra el muro detrás de ti."
    "Sentiste tu cabeza golpear contra la textura áspera de la superficie dura, lo que te hizo sisear."

    menu:
        "Disculparte":
            stop music fadeout 3.0
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            pov "Lo siento, ¿Si?"
            pov "No quise hacerte enojar."
            "Jeff estiró su ya de por sí gran sonrisa, y bajó el cuchillo."
            "Pero en el momento en que sentiste alivio por no ver el arma blanca, una punzada en el estómago te invadió."
            play sound "audio/sfx/stab.mp3"
            show cg7 with dissolve
            "Instintivamente, tu voz salió en un grito, pero tu boca fue cubierta por una mano que ahogó tu voz en tu garganta."
            J "Así que sí sientes miedo, después de todo…"
            play music "audio/ambience/submerged.mp3"
            scene black with fade
            "¿De eso se trataba?"
            "De verdad había mucha gente rara en el mundo."
            "Bueno, estabas por dejar de dejar de existir de todas maneras, ya no tendrías que lidiar con eso."
            show Death with fade
            pause 2.0
            "Fuiste alguien más del montón para Jeff."
            return
        "Provocarlo":
            $ show_live ("YouLive")
            pov "Más fuerte~"
            "Jeff te soltó y retrocedió un par de pasos, como si quemaras."
            play sound "audio/sfx/cloth.mp3"
            scene wall with dissolve
            show jeffknife1 angry at center
            with dissolve
            "Su expresión reflejaba sorpresa, y fue una reacción más grande de lo que esperabas."
            pov "Relájate, sólo bromeo."
            J "…No fue gracioso."
            pov "Para mi lo fue."
            J "¡Cállate, esto no debería ser divertido!"
            J "¡Deberías tener miedo!"
            jump supervivencia_1

    label supervivencia_1:

    "Jeff se acercó nuevamente, alzando el cuchillo hasta tu cuello."
    "Por reflejo, te alejaste de la hoja, sintiendo la punta perforar tu barbilla."
    J "Estás en un callejón, de noche, con un cuchillo en tu cuello…"
    J  "Así que te preguntaré de nuevo."
    J "¿Tienes miedo?"

    menu:
        "Si":
            $ show_live ("YouLive")
            "Jeff no ha provocado mucha impresión en ti."
            "Eres consciente que tu situación es peligrosa, pero… realmente no te podría importar menos."
            "Pero de todas formas, parecía ser divertido ver lo que sucede si te metes con él."
            "Por el momento, decidiste seguirle la corriente."
            pov "¿Sabes qué?, si, tengo miedo."
            jump supervivencia_2
        "No":
            stop music fadeout 3.0
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            "Que Jeff se joda."
            "No tienes ganas de lidiar con un loco sádico."
            pov "Siga participando."
            "La sonrisa de Jeff cae, sutilmente."
            J "¿Oh? ¿Así que así son las cosas?"
            play sound "audio/sfx/stab.mp3"
            show cg7 with dissolve
            "Un dolor intenso, agudo, que se ramifica desde tu estómago hasta las puntas de tus dedos te invade, quitándote el aliento."
            "Tu voz se atora en la base de tu garganta."
            J "¡¡Hahahahaha!!"
            "La risa descontrolada de Jeff es lo único que escuchas."
            "Realmente suena como si se estuviera divirtiendo."
            play sound "audio/sfx/character-falling-on-ground-250069.mp3"
            "Él te mantiene de pie con su mano en tu hombro, pero sientes que te suelta."
            show floor with fade
            "Inevitablemente caes al suelo, sintiendo frío, mucho frío. Las extremidades te pesan y no puedes abrir los ojos por más que lo intentes."
            show Death with fade
            pause 2.0
            "No contuviste a Jeff."
            return

    label supervivencia_2:

    show jeffknife1 smile
    "Jeff recuperó su ánimo, extendiendo su gran sonrisa."
    "Él bajó el cuchillo, pero lo mantuvo en su mano."
    "No te estaba amenazando, quizás quería seguir divirtiéndose contigo."
    J "Bien, bien, eso quería oír."
    "Típico."
    J "Ahora, ¿Qué te da miedo de mi?"
    "Evidentemente, Jeff disfrutaba de ver el miedo en sus víctimas."
    "Por el momento lograste mantenerlo lo suficientemente contento como para mantener una conversación contigo, pero quizás él buscaba escarbar más."
    "Tal vez le gustaba saber lo que él provocaba en sus víctimas con detalle."
    "Eso es gracioso."
    "¿Puedes aceptar el desafío de mimarlo?"

    menu:
        "Cara":
            J "¿Mi cara? No eres la única persona en decir eso."
            pov "Sí bueno, es un look... Único."
            show jeffknife1 happy
            "La sonrisa de Jeff se extendió."
            J "¿Dices que soy hermoso?"
            "Bueno, parece ser vanidoso respecto a su apariencia."
            pov "Claro, tus cicatrices son encantadoras."
            jump supervivencia_3
        "Voz":
            J "Huh, nadie había dicho antes eso, haha."
            pov "Suenas joven, ¿Cuántos años tienes?"
            "Jeff se sobresaltó de la emoción."
            show jeffknife1 happy
            J "¿Te parece?"
            "Y él ignoró por completo tu pregunta."
            "Tal vez era de esos que no le gustaba decir su edad."
            jump supervivencia_3
        "Está loco":
            show jeffknife1 happy
            J "¡Qué grosero!"
            "Su voz sonó más divertida que ofendida."
            J "Me gustan los desafíos…"
            "La forma en que dijo eso fue aún más aterradora."
            jump supervivencia_3
        "Te va a matar":
            J "¡Ding! ¡Ding! ¡Tenemos un ganador!"
            pov "¿Cuál es el premio?"
            show jeffknife1 neutral
            J "…"
            "Jeff no parece apreciar tu sarcasmo, pero se lo toma a bien."
            J "Podría pensar en algunos…"
            jump supervivencia_3

    label supervivencia_3:

    show jeffknife1 smile
    J "Esto es más divertido de lo que creía."
    pov "De todas maneras… ¿Por qué me atacas?"
    "Jeff te queda mirando unos segundos en silencio, su sonrisa estática."
    "Te daban ganas de exigirle que parpadee."
    J "Siento que matarte va a ser divertido."
    "Genial."
    "Tenías la esperanza de que era un simple ladrón que seguía en su fase de adolescente angsty y sólo quería asustarte, pero resulta que es un loco que genuinamente piensa en asesinarte."
    "Sacaste la lotería."
    pov "Y yo creí que me había ganado tu corazón."
    J "Oh~ hace falta mucho más que sólo un día para eso."
    "Eso parecía ser información útil."
    "Pero para el futuro, ahora deberías concentrarte en sobrevivir."
    J  "Ya sé. Juguemos a algo."
    pov "¿Jugar a qué?"
    J "Un simple las traes."
    pov "¿Qué pasa si gano?"
    J "..."
    J "Te dejaré ir."
    "……………….."
    show jeffknife1 happy
    J "¡Es lo que te gustaría que dijera! ¡Hahahaha!"
    "Era un idiota. Un idiota muy peligroso."
    "Tenías que escoger con cuidado."

    menu:
        "Está bien":
            stop music fadeout 3.0
            play music "audio/music/horror-background-atmosphere-2-289424.mp3"
            J "¡Estupendo!"
            play sound "audio/sfx/cloth.mp3"
            "Jeff te suelta y retrocede un par de pasos."
            show jeffknife1 smile
            J "Te daré una ventaja de 10 segundos."
            J "1….."
            play sound "audio/sfx/running-on-concrete.mp3"
            scene alley with dissolve
            "No dudas y sales corriendo hacia la salida del callejón. Las piernas te temblaban, pero las obligaste a seguir."
            "No querías ser precisamente víctima de asesinato después de todo."
            "Si de morir se trata, preferirías morir de manera indolora."
            J "¡{size=30}...2,4, 6….{/size}!"
            "¡¡!!"
            "¡El desgraciado está contando mal!"
            "Pero era tu culpa por confiar en lo que él dice."
            "¿Qué podías esperar de un demente?"
            scene streetnight with dissolve
            "Sales del callejón, , casi te caes, pero la adrenalina te hace continuar."
            menu:
                "Ir a la derecha":
                    play sound "audio/sfx/running-on-concrete.mp3"
                    "Estarás yendo de vuelta hacia la tienda."
                    "Cindy debería seguir ahí, podías pedir su ayuda y refugiarte."
                    scene closed with dissolve
                    "Llegas a la puerta, intentas abrir, pero está cerrada."
                    play sound "audio/sfx/knock-on-glass.ogg"
                    "Golpeas la puerta con fuerza, sin importarte si rompes el vidrio."
                    pov "¡Cindy!, ¡Abre!, ¡Rápido!"
                    play sound "audio/sfx/heart beat.mp3"
                    "Tu corazón acelerado rebota con esperanza al ver a Cindy entre las repisas de películas."
                    "Pero tu esperanza cae cuando la ves audífonos mientras trapea el piso."
                    pov "¡Cindy!, ¡Tu… perra, abre la puerta!"
                    "Tus gritos no parecen ser escuchados, por la manera en la que la ves contonearse con el trapero en manos."
                    "No es la primera vez que Cindy te decepciona, pero esta vez se siente más doloroso."
                    "Y eso que pensaste que las cosas podían mejorar entre ustedes dos."
                    stop sound fadeout 1.0
                    J "{size=30}Las traes….{/size}"
                    play sound "audio/sfx/gore3.mp3"
                    scene closed2 with dissolve
                    "Escuchas ese susurro burlón en tu oído, pero no tienes momento para girarte cuando te empujan contra el vidrio de la puerta y sientes una presión dolorosa en tu costado derecho."
                    play sound "audio/sfx/person-knocked-down.mp3"
                    pov "¡Cough!"
                    "Te ahogas con tu propia sangre, el líquido salpica el vidrio."
                    J "Pensé que sería más divertido… Bueno, qué más da."
                    "No puedes formular ningún pensamiento en el momento que la presión de tu costado es liberada."
                    "Sientes algo se derrama de tu costado, mojando tu pierna." 
                    "Instintivamente diriges una mano a la herida, con el impulso de detener la hemorragia."
                    "Pero es imposible."
                    "Sientes que te sueltan, pero tus piernas pierden la fuerza."
                    play sound "audio/sfx/character-falling-on-ground-250069.mp3"
                    "Te deslizas contra la puerta hasta llegar al suelo, sintiendo que debajo de ti se forma un charco de sangre drenada del lugar donde te apuñalaron."
                    scene black with fade
                    "Tu consciencia se va, tus ojos pesan."
                    C "¿Qué está-? ¡¡[povname]!!"
                    "Al menos Cindy se dio cuenta al final."
                    "Ella era todo un caso, pero esperabas que ella lo hiciera mejor a futuro."
                    show Death with fade
                    pause 2.0
                    "Perdiste el juego de Jeff."
                    return
                "Ir a la izquierda":
                    play sound "audio/sfx/running-on-concrete.mp3"
                    "¡Si puedes llegar a tu hogar estarás a salvo!"
                    play sound "audio/sfx/heart beat.mp3"
                    "Corres hacia adelante sin mirar atrás, el aire frío perforando tus pulmones mientras escuchas los latidos de tu corazón en los oídos."
                    "¡Falta poco….! ¡Sólo un poco más…!"
                    play sound "audio/sfx/push.mp3"
                    pause 1.0
                    play sound "audio/sfx/falling.mp3"
                    scene fall with dissolve
                    "Un peso demasiado pesado cae encima tuyo te inmoviliza contra el suelo."
                    J "¡Haaaa…. Eso fue divertido!"
                    "Te congelas al escuchar la voz de Jeff, para después sacudirte con la esperanza de quitártelo de encima."
                    J "Tsk, tsk… Aprende a perder, [povname]."
                    pov "E-espera, hiciste trampa, no contaste bien…"
                    J "…"
                    J "Seh, eso no importa realmente."
                    "Él sujeta tu cabeza con fuerza, lo que te saca un quejido de dolor."
                    play sound "audio/sfx/rush__blade.mp3"
                    "El frío y duro filo de la hoja del cuchillo presiona tu cuello expuesto."
                    pov "P-pero jugamos como querías."
                    J "..."
                    J "Heh….heh…"
                    J "¡¡HAHAHAHAHA!!"
                    J "Hah…. haha….."
                    J "Esto fue refrescante."
                    J "Pero ya me aburrí."
                    play sound "audio/sfx/gore2.mp3"
                    "La hoja se deslizó de un extremo a otro de tu cuello."
                    scene fall2 with dissolve
                    play sound "audio/sfx/blood dripping.mp3"
                    "La sangre brotó de tu garganta en un gran chorro." 
                    "Tus ojos se nublaron y los músculos de tu cuello perdieron la fuerza."
                    "El agarre en tu cabello fue soltado y tu cabeza cayó sobre el charco de sangre que seguía creciendo lentamente." 
                    "No podías ver nada, pero percibiste el sonido de los pasos de él alejarse."
                    scene black with fade
                    "¿Ibas a terminar así?"
                    "Era injusto."
                    "Ser desechado."
                    "Hubieras preferido morir de otra manera."
                    show Death with fade
                    pause 2.0
                    "Aburriste a Jeff."
                    return
        "No":
            stop music fadeout 3.0
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            show jeffknife1 mad
            J "...."
            "Los ojos de él se inyectan en sangre, sus dientes chocan y generan un chirrido que te provoca un escalofrío."
            J "¿Desprecias mi amabilidad?"
            "La voz de él se vuelve grave y temblorosa por la rabia."
            "Estás a punto de retractarte y tranquilizarlo."
            play sound "audio/sfx/stab.mp3"
            show cg5 with dissolve
            "Pero es tarde cuando sientes una repentina presión en tu barbilla, atravesando tu piel y músculos hasta atravesar tu lengua."
            play sound "audio/sfx/gore1.mp3"
            "Te ahogas con la sangre que brota de tu boca, el dolor agudo nublando tu mente y visión."
            J "¡Te doy la elección y tú la desperdicias!"
            "Él grita estridente, empujando más la hoja de su cuchillo en ti, hasta sentir que el metal llega a tu paladar."
            scene black with fade
            "Tus sentidos se apagan lentamente, hasta que ya no sientes nada…"
            "Que manera tan horrible de morir…"
            show Death with fade
            pause 2.0
            "Despreciaste a Jeff."
            return
        "Yo te persigo a ti":
            $ show_live ("YouLive")
            jump supervivencia_4

    label supervivencia_4:

    stop music fadeout 3.0
    play music "audio/music/dedpression-339994.mp3"
    show jeffknife1 sorpresa
    "Jeff se trastabilla con sus palabras, sin haberse esperado esa respuesta."
    J "............."
    "Jeff se enderezó sobre ti, analizándote en silencio." 
    play sound "audio/sfx/cloth.mp3"
    show cg3 with dissolve
    "El rostro de él era extrañamente inexpresivo, supones porque con la boca rota como la tiene él, es una condena a tener la misma expresión permanentemente."
    play sound "audio/sfx/hang.mp3"
    show cg4 with dissolve
    hide cg3
    "Repentinamente, sientes que tu cuello es apretado con fuerza, siendo difícil para ti respirar."
    "Instintivamente, alzas las manos y tiras del brazo de Jeff, un impulso de tu cuerpo para tratar de luchar."
    J "Témeme…"
    "El reclamo sonó casi infantil, a pesar de provenir de un hombre amenazante."
    "Intentas responder algo, cualquier cosa, pero tus cuerdas vocales están siendo apretadas demasiado fuerte."
    "Alcanzaste a escuchar el murmullo de él antes de sentir que la presión en tu cuello era liberada."
    "La mano de él seguía sobre tu cuello, pero sólo presionaba lo suficiente como para inmovilizarte."
    "Tosiste y respiraste aceleradamente, tratando de recuperar el aire que te faltaba."
    play sound "audio/sfx/blade-scrape.mp3"
    show cg6 with dissolve
    hide cg4
    "Pero entonces te diste cuenta que Jeff nuevamente estaba casi sobre ti, con cuchillo en mano."
    "Sentiste una punzada de dolor en tu mejilla, pero fue por un instante."
    "Jeff le hizo un corte limpio a la piel de tu mejilla izquierda, sentiste el cosquilleo de una delgada línea de sangre caer hasta tu mandíbula."
    J "¿Por qué no tienes miedo?"
    "Jeff te examinaba en silencio, como si al mirar tu reacción podría sacar una respuesta que lo satisfaga."
    play sound "audio/sfx/heart beat.mp3"
    "No era como si realmente no sintieras nada."
    "Reconocías que la situación era peligrosa, tu cuerpo lo sabía por el fuerte latir de tu corazón."
    "Pero como ha sido desde el inicio, no te importaba."
    "Él pedía que te le temas, pero como él amenaza tu vida, y no te importa realmente morir, en consecuencia, no le temes."
    
    menu:
        "Rendirte":
            $ show_live ("YouLive")
            "Bajas la mirada, pero no por miedo."
            "Sino que por cansancio."
            "¿Qué dejarías atrás si morías?"
            "No mucho, así que ya no te importaba."
            pov "Lo siento Jeff, pero no tengo miedo para darte."
            jump supervivencia_5
        "Desafiarlo":
            stop music fadeout 3.0
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            "Lo miras directamente a los ojos."
            pov "Tanto drama… ¿Para esto?"
            "La boca de Jeff se tuerce."
            pov "Sólo eres un asesino genérico, acosando a la víctima y llevándola a un callejón."
            pov "Si querías causar una mejor impresión, podrías ser más original."
            "De repente, la comisura extendida de Jeff se alza, extrañándote."
            J "Fue algo difícil de ver, pero…"
            play sound "audio/sfx/stab.mp3"
            show cg7 with dissolve
            "Jeff clavó el cuchillo debajo de tus costillas, quitándote el aire."
            "Él se inclinó sobre tu oído"
            J "Eres de luchar, ¿No?"
            "La sangre sube por tu garganta, ahogándote."
            scene black with fade
            "Vaya, parece que desafiarlo lo interpretó como una manera de luchar por tu vida."
            "Realmente ese no era el caso, pero te resignaste."
            show Death with fade
            pause 2.0
            "Alargaste lo inevitable."
            return

    label supervivencia_5:
    
    hide cg6 with dissolve
    show jeffknife1 neutral
    J "..."
    show jeffknife1 smirk
    "Jeff se mantuvo en silencio por un segundo, hasta que lograste notar cómo su sonrisa se extendía sutilmente."
    "Él lentamente se inclinó hacia a ti {w=0.5}y lamió tu mejilla herida, limpiando la línea de sangre."
    "Su respiración chocaba contra tu piel, tibia y húmeda."
    "El toque de su lengua te ardió en la herida, haciéndote sisear."
    "Podías aceptar que él te lamiera, sólo era él siendo raro."
    "Pero no podías quitarte de encima lo que él quería decirte con esa acción."

    menu:
        "Provocarlo":
            $ show_live ("YouLive")
            pov "¿Lamerme? Qué romántico. Me derrito."
            "¿Quizás si le tomas el pelo lo suficiente te deje en paz?"
            "Tenías que intentar."
            jump supervivencia_6
        "Suplicarle":
            stop music fadeout 3.0
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            "Una cosa es que no te importe que te atacan en la noche por un maníaco, pero otra cosa distinta es que te… ataquen de otra forma."
            "No quieres ni pensarlo."
            pov "Por favor… no me hagas daño…."
            "Quizás si pedías clemencia te deje ir."
            show jeffknife1 smile
            J ".......Heh."
            "Jeff rió entre dientes, bajando el cuchillo hasta tu abdomen."
            J "Sabía que me temerías…."
            "Buenop, parece que Jeff lo tomó como tu queriendo complacerlo para que no te haga daño."
            "No estaba del todo equivocado, pero ciertamente tu intención era algo distinta…"
            play sound "audio/sfx/stab.mp3"
            show cg7 with dissolve
            "Jeff hundió la hoja en tus entrañas, la punzada quitándote el aire."
            play sound "audio/sfx/stab.mp3"
            "Pero eso no lo detuvo."
            play sound "audio/sfx/stab.mp3"
            "Te apuñaló una y otra vez, hasta que se sintiera satisfecho."
            scene black with fade
            "El cansancio y el dolor era tan intensos que no podías mantener los ojos abiertos, pero aún podías escuchar."
            J "Eso fue un dolor…."
            show Death with fade
            pause 2.0
            "Alargaste lo inevitable."
            return

    label supervivencia_6:

    stop music fadeout 3.0
    play music "audio/music/suspenseful-dark-atmosphere-303538.mp3"
    show jeffknife1 angry
    play sound "audio/sfx/person-knocked-down.mp3"
    "Jeff gruñó entre dientes, volviendo a estrellarte contra la pared de ladrillos."
    "Soltaste un quejido de dolor ante el impacto."
    J "¿Por qué… no me temes?"
    pov "No sé qué quieres que te diga, Jeff."
    show jeffknife1 neutral
    "Jeff bajó la cabeza, aparentemente decepcionado."
    "Desviaste la mirada hacia los lados con duda, sin saber qué hacer."
    show jeffknife1 smile
    "Pero entonces él se enderezó nuevamente, con su sonrisa tan extendida que sus labios estaban tensos."
    J "No hay nada que pueda hacer si no temes a la muerte."
    J "Pero puedo hacer que me temas."
    play sound "audio/sfx/blade-scrape.mp3"
    show cg6 with dissolve
    "Alzó el cuchillo nuevamente, pero no a la altura para apuñalarte en un punto vital, sino que acercó la punta lentamente a tu rostro, a la altura de tu ojo izquierdo."
    J "Así que haremos esto, [povname]."
    "Tragaste duro ante la visión distorsionada de la punta del cuchillo a milímetros de tu pupila."
    J "Voy a perseguirte. Cada vez que te atrape, te haré daño, y cada vez que me evites, me alejaré un poco."
    "Los ojos de Jeff temblaban, casi blancos, como dos focos en medio de la oscuridad."
    pov "E-espera…"
    J "Perdiste el primer turno."
    "Dictó Jeff, empujando su mano."
    play sound "audio/sfx/gore1.mp3"
    show cg8 with dissolve
    play sound "audio/sfx/blood dripping.mp3"
    "La hoja se enterró en la esquina de tu ojo, casi rozando el borde del párpado."
    "Gritaste con todas tus fuerzas, hasta que sentiste que tu garganta se desgarraba."
    play sound "audio/sfx/gore4.mp3"
    "La sangre brotó como una pequeña cascada, y con la repentina sacudida de tu cuerpo, la sangre salpicó."
    "Jeff rió satisfecho con la reacción y enterró más la hoja, hundiéndola en la blanda carne de tu globo ocular."
    pov "¡A-ACK!"
    "Te atragantántaste con tu saliva, a punto de vomitar por el insoportable dolor."
    "Tus manos dieron manotazos hacia el pecho de Jeff, pero no lo movieron ni un centímetro."
    show red with dissolve
    hide cg8
    "Jeff sacudió el mango del cuchillo violentamente, moviéndolo aún enterrado en el ojo."
    play sound "audio/sfx/gore3.mp3"
    "Él sacudió un poco más el cuchillo y tiró, logrando sacar el globo ocular aún conectado a las venas."
    Stranger "¿Qué está pasando?"
    Stranger "¿Hay alguien ahí?"
    "Como campanas celestiales, lograste escuchar las voces de otras personas proviniendo de un costado, pero ya no tenías fuerzas para mantenerte de pie."
    play sound "audio/sfx/falling.mp3"
    scene floor2 with dissolve
    "Te desplomas en el suelo, con la cuenca izquierda sangrando por el arranque."
    "Tu visión estaba borrosa y dañada, no había manera de confiar en lo que veías."
    "Sólo podías centrarte en lo que escuchabas."
    J "Recuerda nuestro juego, [povname]."
    "Jeff murmuró suavemente, su voz escuchándose desde atrás."
    stop music fadeout 5.0
    scene black with fade
    "Lograste sentir los pasos de varias personas dirigiéndose a tu dirección, por lo que te rendiste ante el cansancio y el dolor."

    #dia 2

    show Day2 with fade

    pause 2.0

    scene black with fade
    hide Day2

    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"

    window show

    "Nunca habías sentido tanto dolor antes."
    "Claro, alguna vez te habías tropezado, raspado las rodillas, o quemado los dedos con agua hirviendo, cosas normales."
    "Pero esto…"
    "Esto era otro nivel."
    "No era el dolor físico lo que más molestaba, sino el tipo de dolor que te hace consciente de que todo lo que está pasando importa más de lo que quisieras."
    "El tipo de dolor que te despierta, te obliga a existir, te arranca de la comodidad de no sentir nada."
    "Para colmo, querías dormir. Dormir siempre ha sido tu mejor plan en cualquier situación."
    "Pero, por supuesto, a la vida le encanta arruinarte los planes."
    Stranger "¿Despertaste?"
    "La voz era masculina, suave, con ese tono educado que inspiraba confianza."
    "No despertaste de inmediato. Sentías tu cuerpo pesado por el cansancio."
    "Pero después de un par de respiraciones incómodas, lograste forzarte a ver."
    scene hospitalroom with whitefade
    play sound "audio/sfx/ekg-normal.wav"
    "El blanco te rodeaba. Te tomó unos segundos entender que estabas en una camilla de hospital."
    "Sábanas ásperas, olor a desinfectante y esa luz fluorescente de las ampolletas led."
    "Lo bueno, si es que había algo bueno, es que estabas con cuidados médicos."
    "Con suerte no te iban a dejar morir de forma estúpida después de todo lo que pasaste anoche."
    "Finalmente te enfocas en el responsable de la voz."
    show salazar1 neutral lentes at center
    with dissolve
    "Frente a ti había un hombre de bata blanca. Joven, bien peinado, de rostro amable."
    Stranger "¿Sabes dónde estás?"

    menu:
        "Hospital":
            $ show_affection("J", 1)
            $afecto += 1
            "El doctor asintió y anotó algo en unos papeles que llevaba consigo."
            Stranger "Bien. Eso es un buen signo."
            pov "¿Anotas por profesionalismo o porque necesitas llenar espacio?"
            "El doctor alzó una ceja a tu dirección, como si no se hubiera esperado un comentario tan seco, pero lejos de verse ofendido, se veía intrigado."
            Stranger "Ambas."
            jump ruta_normal_11
        "Cielo":
            pov "Creo que tengo un ángel ante mí."
            show salazar1 smile lentes
            "El doctor resopló divertido."
            Stranger "Veo que tienes sentido del humor, eso es buena señal."
            pov "Hubiera dicho algo más original, pero no tengo tantas energías…"
            Stranger "Me conformo. No todos los días me dicen ángel mientras trabajo."
            show salazar1 neutral lentes
            "Anotó un par de cosas en los papeles que llevaba. Parecía estar más entretenido que preocupado."
            jump ruta_normal_11

    label ruta_normal_11:

    "Tu voz estaba ronca y te dolía la garganta."
    "Tragaste con fuerza, tratando de aplacar el dolor."
    "El doctor te dedicó una mirada seria, como si te dijera que te lo tomaras con calma."
    Stranger "¿Recuerdas tu nombre?"

    menu: 
        "Como él quiera llamarte":
            show salazar1 smile lentes
            "El doctor soltó una leve carcajada, negando con la cabeza."
            Stranger "Responde seriamente."
            show salazar1 neutral lentes
            jump ruta_normal_12
        "Di tu nombre":
            $ show_affection("J", 1)
            $afecto += 1
            jump ruta_normal_12

    label ruta_normal_12:

    pov "Es… [povname]."
    "Tu voz salió ronca y entrecortada, pero lo suficientemente clara para que él te entienda."
    "El doctor asintió, concentrado." 
    "Evidentemente te estaba haciendo esas preguntas para saber que tan desorientada estaba tu cabeza."
    Stranger "De acuerdo. ¿Sabes por qué estás aquí?"
    "No respondiste de inmediato."
    "La imagen apareció sola. Una cara con cicatrices. Ojos hundidos. Una sonrisa deformada."
    "Y la risa. Esa maldita risa."
    "Por supuesto que sabías por qué estabas ahí."
    pov "Me atacó… alguien."
    show salazar1 incomodo lentes
    "El doctor se acercó y tomó tu mano con firmeza."
    "No te preguntó si querías ese gesto. Solo lo hizo."
    Stranger "Este lugar es seguro."
    Stranger "Él no puede hacerte daño ahora."
    "Te quedaste mirando su mano sobre la tuya." 
    "No sabías qué era peor: el dolor, o lo raro que se sentía que alguien te consolara de forma tan… correcta."
    "{i}Buen servicio{/i}, pensaste."
    "Tal vez te traigan café gratis después."
    "Él notó tu silencio y retiró la mano enseguida."
    show salazar1 shy blush lentes
    "Se aclaró la garganta, avergonzado."
    Stranger "Perdón… No me he presentado."
    show salazar1 smile none lentes
    DR "Soy tu doctor, Paul Salazar."
    "Te tomó un segundo procesarlo."
    pov "Un gusto… Dr. Salazar."
    pov "Diría que me habría gustado conocerte… en otra situación… pero ya sabes."
    "Él esbozó una sonrisa breve, sin saber si reír o disculparse otra vez."
    show salazar1 neutral lentes
    DR "Te explicaré un poco tu situación."
    "Se puso más recto y serio."
    DR "Tienes golpes en la cabeza. Hay que vigilarte por si presentas vómito, mareos o pérdida de conciencia."
    DR "También tienes algunos cortes menores. No necesitas puntos, pero… nada de rascarse ni tocarlos. ¿De acuerdo?"
    "En el instante exacto que lo dijo, la picazón te atacó. Maldita sugestión."
    DR "Lo más importante ahora: Sufriste asfixia. No hagas esfuerzos, no hables mucho. Si te mareas o te cuesta respirar, avisa."
    play sound "audio/sfx/cloth.mp3"
    "Asentiste en silencio, acomodándote lentamente en la camilla."
    "La tela de la bata raspaba un poco contra tu piel. El colchón olía a desinfectante. Todo olía a desinfectante."
    show salazar1 incomodo lentes
    DR "Y… respecto a tu ojo…"
    "Su tono cambió. Como si estuviera por dar muy malas noticias."
    DR "Lo siento. No pudimos salvarlo."
    "Frío. Como si alguien hubiera abierto una ventana en mitad del invierno."
    "Por reflejo, llevaste una mano temblorosa al costado izquierdo de tu rostro."
    "Sólo vendajes. Sólo vacío."
    "Habías imaginado perder cosas. Objetos, relaciones, tiempo."
    "Pero esto era distinto. Perder pedazos."
    show salazar1 neutral lentes
    DR "Podrás tener una vida normal."
    "Él dijo rápidamente, como si quisiera remediar tu situación."
    DR "Perderás algo de percepción de profundidad, pero no te impedirá hacer tu vida. Más adelante puedes optar por una prótesis, si lo deseas."
    DR "Ahora… Lo importante es que cicatrice bien."
    show salazar1 incomodo lentes
    "Él notó tu silencio. Tu falta de reacción lo incomodaba."
    "Se inclinó levemente hacia ti."
    DR "¿Estás bien, [povname]?"

    menu:
        "No estás bien":
            "Tu voz bajó, al igual que tu mirada."
            pov "No… no estoy bien."
            "No lo dijiste con drama, ni con lágrimas."
            "Solo lo dijiste porque era cierto."
            "Por una vez, no tenías energía para fingir."
            "El Dr. Salazar asintió despacio."
            DR "No tienes por qué estarlo."
            "El silencio se sintió pesado, pero no incómodo."
            "Era raro que alguien no tratara de llenar el espacio con frases vacías."
            pov "Creía que los doctores eran más… metódicos."
            show salazar1 smile lentes
            "El Dr. Salazar sonrió apenas, como si entendiera más de lo que decía."
            DR "No todos los doctores somos un cliché."
            "Por primera vez en mucho tiempo… sentiste menos soledad."
            "Solo un poco. Pero algo era algo."
            jump ruta_normal_13
        "Estarás bien":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Estaré bien. Es sólo un ojo, tengo otro."
            "No sabías si era cierto, pero tampoco importaba."
            "No lo dijiste para él. Lo dijiste para cortar la conversación."
            "Hablar dolía. Escuchar también."
            show salazar1 neutral lentes
            "Salazar te miró, como queriendo leer algo más en tu cara, pero solo encontró lo de siempre: apatía."
            DR "No tienes que fingir ser fuerte."
            DR "Tenemos profesionales con los que puedes hablar-"
            pov "No estoy fingiendo. Solo… no me importa."
            "Ahí estaba: la barrera. Sutil, pero sólida."
            "No querías consuelo. No querías compañía. Solo querías que te dejaran en paz."
            "Por un segundo, el silencio en la sala pesó más que el dolor en el cuerpo."
            jump ruta_normal_13

    label ruta_normal_13:

    DR "¿Hay alguien a quien llamar?"
    DR "¿Algún familiar, un amigo, pareja?"
    pov "…."
    "No querías admitir que tu vida era solitaria, pero no podías simplemente mentirle a tu doctor."

    menu: 
        "No tienes familia":
            show salazar1 incomodo lentes
            DR "Oh, lo lamento mucho…"
            jump character_2
        "No hablas con tu familia":
            show salazar1 incomodo lentes
            DR "Entiendo…"
            jump character_2
        "Tu familia vive en otra ciudad":
            show salazar1 incomodo lentes
            DR "Eso va hacer las cosas algo complicadas…."
            jump character_2

    label character_2:

    "El Dr. Salazar se rascó la cabeza con incomodidad."
    "Precisamente por eso no querías decir nada en primer lugar."
    DR "Debe haber alguien en esta ciudad con la que tengas contacto, ¿Algún compañero de trabajo?"
    "Hablar de trabajo te hizo recordar a cierta persona."
    show salazar1 neutral lentes
    pov "¿Qué hora es, doctor?"
    "El Dr. Salazar se sacude la muñeca y ojea su reloj de muñeca."
    DR "Son las 4 am."
    DR "¿Por qué?"
    pov "… Hay alguien a quien puedo llamar, pero es muy temprano…"
    DR "Alguien te atacó, lo entenderá."
    "Apretaste los labios en una línea, con duda."
    "No tenías tanta cercanía con ella… pero no podías pensar en nadie más."
    pov "Está bien… le daré su número."
    "Anotas en un papel un número de teléfono y se lo entregas."
    DR "Van a estar viniendo miembros del personal, para monitorear."
    DR "Puedes pedirles lo que necesites."
    pov "De acuerdo."
    "El Dr. Salazar asiente levemente ante tu afirmativa, y se dirige a la puerta de la habitación."
    "Pero antes de retirarse, se gira hacia ti."
    DR "Cuando te sientas mejor, podrás hablar con la policía."
    DR "Por ahora, descansa."
    hide salazar1 with dissolve
    "Y con eso, el doctor abandonó la habitación, dejándote con tus pensamientos."
    "Recuerdas vagamente que escuchaste personas acercarse a ti cuando te desmayaste en el callejón, seguramente ahuyentaron a Jeff."
    "Lo importante es que estás bien y con vigilancia, no hay manera de que Jeff te alcance, ¿Cierto?"
    "No era extraño que te preocupara eso, ya que lo último que te dijo fue que te perseguiría hasta encontrarte."
    "Pero nuevamente, estás en un hospital, se supone que es seguro."
    "Tanto pensar te agotó nuevamente, por lo que te acomodaste en la camilla para poder descansar."
    "Unos minutos… querías dormir aunque sea unos minutos."
    stop music fadeout 3.0
    scene black with fade
    play sound "audio/sfx/submerged.mp3"
    "………."
    "Mientras dormías, habrías jurado haber sentido una caricia en tu mejilla."
    "Era suave y delicada, unos dedos recorrieron la piel de tu pómulo derecho, bajando por tu mandíbula hasta rozar tus labios."
    scene hospitalroom with whitefade
    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 
    "Abriendo tu único ojo, miraste la habitación, buscando quien quiera que sea que te haya tocado mientras dormías."
    show cindy2 sad at center
    with dissolve
    "Pero sólo viste a Cindy."
    C "¡[povname]!"
    play sound "audio/sfx/Equip2.ogg"
    "Repentinamente, y para gran sorpresa tuya, Cindy rodeó tus hombros entre sus brazos, inclinándose sobre ti para estrecharse en un ligero abrazo."
    "Te quedaste de piedra."
    C "¡Pensé que no despertarías!, oh, que susto…"
    play sound "audio/sfx/cloth.mp3"
    "Cindy se separó de ti, tratándote con una delicadeza a la que no terminas de acostumbrarte."
    "¿Es tu idea, o es como si Cindy… tuviera el papel de tu mejor amiga?"
    "Ella era por lejos tu mejor amiga, sólo la conoces por un tiempo."
    "Está bien, tú fuiste quien le dio su contacto a Salazar, pero sólo porque es la persona más cercana que tienes a mano."
    pov "Ehm… ¿A qué viene tanto cariño?"
    show cindy2 incomoda
    "Un rayo pareció partir a Cindy, haciéndola retroceder con una expresión consternada."
    C "No… lo sé, pero es como… si tu de repente fueras muy importante."
    "¿O sea que antes no lo eras?"
    "Ok, una cosa es que tu pienses eso de ti personalmente, pero que otra persona lo diga te dolía un poco."
    show cindy2 sad
    C "Cuando supe lo que te pasó, vine de inmediato."
    C "No quería que estuvieras por tu cuenta en estos momentos."
    show cindy2 incomoda
    C "¿Cómo te sientes?"
    "Cindy tomó asiento en la silla a tu derecha, esta vez conservando una distancia más cordial."
    "Entendible, sólo trabajan en la misma tienda."
    pov "Con algo de dolor… pero creo que dentro de todo estoy bien."
    "Cindy bajó la mirada con preocupación, para después elevarla hacia ti."
    "Ella suspiró pesado, llevando los dedos hacia su frente."
    show cindy2 angry
    C "Te dije que tuvieras cuidado…"
    "Ese comentario… estaba demás."
    "¿Acaso ella quería echar la culpa hacia ti?"
    "¿Cómo si lo que te pasó fue por tus acciones y no las del desgraciado que te arrancó un ojo?"
    pov "Te recuerdo que me atacaron, no es mi culpa."
    C "No me refiero a eso, yo-"
    pov "¿Ahora se supone que eres una compañera de trabajo atenta?, que mal chiste."
    C "¡[povname]!"
    "No fue el volumen de su voz, ni tampoco el hecho de que te llamó por tu nombre."
    "Fue su tono desgarrador lo que te hizo detenerte."
    show cindy2 incomoda
    C "Yo… tampoco me entiendo."
    C "No creí que me importaras tanto."
    pov "Oye-"
    show cindy2 sad
    C "Estuviste a punto de morir, y me sentí aterrada."
    pov "…"
    "Es cómo… si hubieras empezado a desarrollar un campo gravitacional, y ahora varias personas giraban alrededor de ti. Jeff, Salazar, Cindy."
    "Sólo bastó que un loco te acosara y te arrancara un ojo, ¿No?"
    C "No tengo cómo explicarlo, pero me preocupo por ti, ¿Podrías dejar de ser idiota al respecto y aceptarlo?"
    "No pudiste evitar callarte ante la declaración de ella."
    "Estarías mintiendo si decías que tu corazón no latió fuerte."
        
    menu:
        "Agradecerle":
            pov "Yo… gracias, Cindy."
            show cindy2 neutral
            "Cindy te miró en silencio, uno reconfortante."
            pov "No soy… de decir estas cosas, pero gracias, por preocuparte por mi."
            show cindy2 smile
            "Cindy bajó la mirada, para después sonreír levemente."
            C "No estás haciendo un buen trabajo en solitario… así que no me importa hacerlo por ti."
            pov "Heh, si."
            "Cindy te sonrió levemente, pero de repente su expresión cambió."
            jump ruta_normal_14
        "Cuestionarla":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿De casualidad…. me acariciaste mientras dormía?"
            show cindy2 neutral
            "Cindy te quedó viendo inexpresiva."
            C "Ew, no."
            "Si, esa es la Cindy que conocías."
            pov "Bueno, ¿entonces quién fue?"
            C "¿Qué sé yo?, no es cómo si-"
            "Cindy detuvo sus palabras como si un pensamiento le hubiera llegado a la cabeza."
            jump ruta_normal_14
    
    label ruta_normal_14:

    show cindy2 angry
    C "El que te atacó, ¿Fue el mismo rarito de la tienda?"
    pov "Yo-"
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "Tras un leve toque en la puerta de tu habitación, aparecieron dos personas."
    "Perfecta entrada para interrumpir la conversación que estabas teniendo."
    show cindy2 angry at right
    with move
    show tw neutral at left
    with dissolve
    show ds neutral at center
    with dissolve
    TW "Buenas, [povname]. Somos el teniente Wes y la detective Sean, ¿Podemos hacerte unas preguntas?"
    "Miraste con tu único ojo a los policías."
    "Un hombre y una mujer, vestidos con ropa formal. El hombre fue el que habló, mostrando su placa, y la mujer, la detective Sean, lo imitó."
    "Te miraban con seriedad, pero a la vez no se veían muy preocupados por ti."
    "Más bien, pareciera que estaban más interesados en lo que tenías que decir."
    TW "Tu doctor nos dijo que tenías visita, si te es más cómodo, podemos hacer la entrevista con ella presente."
    C "[povname] recién despertó, debe descansar."
    "Cindy les habló por encima del hombro, desinteresada en la presencia de ellos."
    DS "Mientras más pronto hablemos, más pronto atraparemos al que te hizo esto."
    "El calor subió de tu pecho a tu cabeza, a tu cuenca."
    "No sabías si era una respuesta de tu cuerpo o sólo enojo hacia Jeff, pero pudiste ocultarlo."
    pov "Está bien, Cindy, responderé lo que pueda."
    "Los detectives parecieron relajarse un poco ante tus palabras."
    "Ellos se pusieron al otro lado de tu camilla, Wes se mantuvo de pie junto a ti, haciendo contacto visual contigo para transmitir más confianza, mientras Sean sacaba una libreta para tomar notas."
    "Clásico, policía bueno y malo."
    TW "Empecemos con lo más importante, ¿Viste a tu atacante?"
    pov "Oh, si, no fue bonito."
    DS "¿Podrías dar más detalles?"
    pov "¿Cómo su número social?"
    "Estabas jugando, obviamente."
    "Ya estabas en camilla, sin un ojo y bajo analgésicos, tenías permitido divertirte."
    show cindy2 neutral
    C "Te preguntan si era hombre o mujer, estatura, complexión, ropa-"
    pov "Lo sé, cielos, nadie acepta un chiste…"
    pov "Era un hombre, blanco. Alto, no sé… ¿de un metro noventa?, quizás más. Llevaba una sudadera blanca, pésima ropa para un criminal si me preguntan a mí."
    "Miraste a Cindy de reojo, fácil porque estaba en tu lado derecho." 
    "Ella tenía una expresión pensativa, lo más probable es que ya haya concluído que estabas hablando de Jeff, o como ella lo conocía, “el rarito de la tienda”."
    TW "¿… Alguna característica en especial?"
    pov "Tenía la cara destrozada, si saben a lo que me refiero."
    "Los tres presentes te miraron en silencio por unos segundos, y te sentiste bajo presión para dar más detalles."
    pov "… Tenía muchas cicatrices, la boca… la tenía rasgada."
    show cindy2 angry
    "Cindy parecía tan asqueada con la descripción que parecía a punto de vomitar."
    "Wes y Sean se dedicaron una mirada silenciosa, para después volver a mirarte."
    TW "De acuerdo… ¿Pasó algo inusual el día de tu ataque?"
    pov "Creo que la cantidad normal de “raro” que todos podemos tener en un día-"
    C "¡Deja de joder!"
    "Cindy te regañó, no gritó pero si usó un tono elevado de voz que te hizo hacer un puchero."
    C "Fue un tipo raro que apareció en la tienda."
    DS "¿Qué definirías como raro?"
    "Cindy rodó los ojos." 
    "Vaya, no tomabas a Cindy como alguien que se rebele ante la autoridad."
    C "Dió vueltas por más de una hora. Estaba muy interesado en [povname]."
    "Wes dirigió su atención a ti, alzando una ceja."
    TW "¿Tuviste interacción con él?"

    menu:
        "Di la verdad":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Bueno… la verdad es que coquetee un poco con él."
            show cindy2 incomoda
            "......."
            "Sentiste que todos en la habitación te estaban juzgando."
            pov "¿Qué?"
            pov "Sí, era extraño, pero fue casi… lindo."
            "El aire se tornó incómodo."
            jump ruta_normal_15
        "Exagera":
            pov "Oh, fue muy incómodo."
            pov "No paraba de mirarme, y fingió buscar algo para comprar por una eternidad."
            pov "Quería creer que era otro tipo de acosador."
            show cindy2 incomoda
            "Esperaste una reacción de los detectives, pero te miraron con la misma seriedad de antes."
            "Te giraste a Cindy, y ella estaba negando suavemente con la cabeza."
            "Público difícil, ¿Eh?"
            jump ruta_normal_15

    label ruta_normal_15:

    DS "¿Dijo algo sobre él, algún motivo o dijo por qué te dejó con vida?"
    "La pregunta te extrañó un poco. Era cómo si les extrañara el que hayas sobrevivido."
    "Bueno, no estaba del todo equivocada al preguntar eso, ya que precisamente por la amenaza de Jeff es que sigues con vida."
    show cindy2 angry
    "Quizás hubieras revelado esa parte de la información por un desliz de lengua, pero Cindy interrumpió antes de que dijeras algo."
    C "¿Qué clase de pregunta es esa?"
    DS "Estamos haciendo un perfil del sospechoso, cualquier detalle nos puede ayudar-"
    C "¡El tipo literalmente anda con la cara tapada!, ¡Está lleno de cicatrices!, ¿Qué más quieren? ¿Cómo no pueden encontrar a alguien así?"
    TW "Señorita, debes calmarte."
    C "¡No!, para un caso como este, con la descripción física ya deberían empezar a buscarlo."
    C "Mientras más pase el tiempo, puede que esté más lejos."
    "La habitación quedó en silencio por unos momentos, y sentiste incomodidad ante la discusión."
    TW "… Tienes razón, pararemos por ahora."
    DS "Pero teniente-"
    TW "[povname] necesita descansar."
    "Wes guió a Sean hacia la salida de la habitación, girándose por última vez hacia ti."
    TW "Que te mejores."
    hide tw with dissolve
    hide ds with dissolve
    show cindy2 angry at center
    with move
    "Asentiste en silencio, observando que se retiran."
    "Nuevamente, quedaste a solas con Cindy."
    "Esta vez, el silencio pesaba con muchas preguntas, que seguramente hubieran sido útiles para atrapar a Jeff."
    "Cindy murmuró para sí misma, pero después se dio cuenta de tu mirada sobre ella, por lo que se enderezó en su asiento como si nada hubiera pasado."
    C "No te preocupes, [povname], lo encontrarán."
    pov "…"
    "¿Deberías mencionar  la promesa de Jeff?"
    "Probablemente sería lo más inteligente de hacer, pero por el momento, te permitiste preguntar una sola cosa."
    pov "Hey, Cindy."
    pov "¿... No te gustan los policías?"
    show cindy2 incomoda
    "Cindy se sobresaltó en su asiento, y su tez palideció."
    "Ella desvió la mirada, frotó sus dedos indecisa."
    "Era evidente que no quería responder."
    pov "No importa, ignora eso último."
    "Restaste importancia con una sonrisa y un gesto de tu mano."
    show cindy2 neutral
    "Afortunadamente, Cindy pareció tranquilizarse."
    C "Yo… iré a desayunar, vuelvo en un rato."
    pov "De acuerdo. ¿Me traes algo?"
    show cindy2 neutral
    C "Claro, ¿Qué prefieres?"

    menu: 
        "Algo dulce":
            $ sabor = "D"
            jump character_3
        "Algo salado":
            $ sabor = "S"
            jump character_3

    label character_3:

    "Cindy asintió y se puso de pie."
    "Ella se dirigió a la puerta de la habitación, pero antes de que ella tomara la manilla, alguien más la abrió."
    "Cindy se movió a un lado, dejando entrar a un doctor."
    "Ella dio un saludo breve, mirándolo de reojo antes de salir de la habitación."
    hide cindy2 with dissolve
    window hide
    show cg9 with dissolve
    pause 1.0
    window show
    "Miraste cómo el doctor se adentraba en la habitación en silencio, cargando consigo una bandeja metálica."
    "Recordaste que el Dr. Salazar te advirtió que te vendrían periódicamente a monitorear."
    play sound "audio/sfx/metal-clink.wav"
    "Él empezó a mover sus manos, preparando lo que fuera que tuviera en la bandeja."

    menu:
        "Ser amigable":
            pov "Hola."
            "El doctor no respondió, te ignoró descaradamente mientras hacía lo que fuera que estaba haciendo."
            jump ruta_normal_16
        "Ser cortante":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Hey, ¿Vienes a monitorearme o algo así?"
            "No obtuviste respuesta."
            "Suspiraste y apartaste la mirada."
            "No sabías si era respuesta a un trauma u otra cosa, pero sentías cierto rechazo a ese hombre, alto, vestido de blanco con cabello negro y largo."
            "……."
            "Es sospechoso, ¿No?"
            jump ruta_normal_16

    label ruta_normal_16:

    "De todas formas, sentías tu garganta seca."
    pov "Disculpa, ¿Podrías darme agua?"
    "El doctor se quedó quieto de repente y se mantuvo así unos segundos."
    "Entonces, él volvió a moverse."
    "Sólo podías ver desde tu lugar la espalda del doctor."
    play sound "audio/sfx/pouring-water.wav"
    "Escuchaste el inconfundible sonido de agua siendo servida."
    "El simple sonido te dio más sed, lo más probable porque tu garganta adolorida suplicaba ser refrescada."
    "El doctor dio unos pasos y se acercó a ti."
    play sound "audio/sfx/cloth.mp3"
    show cg10 with dissolve
    hide cg9
    "Intentaste sentarte, pero tu cuerpo pesaba mucho."
    play sound "audio/sfx/Equip2.ogg"
    "Sentiste cómo una mano se posaba en tu espalda y te ayudaba a enderezarte."
    "El toque era suave y atento, te hizo consciente de lo vulnerable que estabas."
    "Entonces sentiste el borde de un vaso en tus labios."
    play sound "audio/sfx/drinking-water.wav"
    "Bebiste agua lentamente, tu garganta ardiendo pero aliviada por la frescura."
    "No te limitaste a un sorbo."
    "Al terminar, suspiraste con alivio, mirando de reojo al doctor que te estaba atendiendo."
    "Su fleco cubría sus rasgos y llevaba una mascarilla desechable."
    "……"
    "Bueno, bueno, ¿Dónde habías visto eso antes?"

    menu:
        "Agradecer":
            pov "Muchas gracias, {b}doctor{/b}."
            "Decidiste fingir ignorancia, tal vez eso te da algo de tiempo para que alguien aparezca."
            "Quizás un doctor real o Cindy."
            jump ruta_normal_17
        "Burlarte":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Cuantos años de medicina te costaron para saber que un paciente inconsciente debe mantenerse hidratado, {b}doc{/b}?"
            "Estabas jugando con fuego, pero la situación era tan bizarra que no podías tomártelo en serio."
            jump ruta_normal_17

    label ruta_normal_17:

    play sound "audio/sfx/cloth.mp3"
    show cg9 with dissolve
    hide cg10
    "El doctor no respondió y volvió a su lugar anterior, a hacer lo que sea que estaba haciendo."
    "Tras beber agua, te sentías mejor para hablar."
    "Según las indicaciones del Dr. Salazar, no debías hablar mucho, pero tenías la confianza de que te sentías lo suficientemente bien como para mantener una conversación, aunque sea unilateral."

    menu:
        "Desconfiar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Realmente eres doctor?"
            Stranger "…"
            jump ruta_normal_18
        "Coquetear":
            pov "Si hubiera sabido que atienden tan bien, habría venido más seguido."
            Stranger "…"
            jump ruta_normal_18

    label ruta_normal_18:

    "Estaba siendo bastante obvio que este doctor no tenía interés en congeniar contigo."
    "No sabías si tomártelo personal o no."
    "Esperarías que te trataran con cuidado en el hospital. Pero todo apuntaba que no sería así."

    menu:
        "Negociar":
            pov "Ah, ya veo."
            pov "No me presenté primero."
            pov "Soy [povname], ¿con quién tengo el gusto?"
            Stranger "…"
            jump ruta_normal_19
        "Quejarte":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Hey, si no tienes ánimos de congeniar con gente, creo que deberías reevaluar tu carrera."
            Stranger "…"
            pov "¿Me escuchaste?"
            jump ruta_normal_19

    label ruta_normal_19:

    "El doctor siguió guardando silencio."
    "Te estaba empezando a molestar."
    "Un intento más, tal vez podrías sacarle unas palabras si insistías por última vez."

    menu:
        "Decirle lo que te pasó":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Sabes, alguien me atacó."
            "El doctor se quedó inmóvil en su lugar."
            pov "Fue alguien con el que hablé en mi trabajo."
            pov "Creo que no le gusté, haha."
            Stranger "Oh, yo no diría eso."
            "El “doctor” murmuró de repente, su voz demasiado familiar."
            jump ruta_normal_20
        "Mostrar interés":
            pov "Ya conozco al Dr. Salazar, ¿eres su estudiante, quizás su colega?"
            Stranger "…"
            Stranger "Oh, soy algo mucho mejor que eso."
            jump ruta_normal_20
        
    label ruta_normal_20:

    if afecto > 15:
        jump historia_continua_2
    else: 
        jump ruta_mala_2

    #ruta mala 2 / 10 a 19 puntos
    label ruta_mala_2:

    stop music fadeout 3.0
    "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    play music "audio/music/suspenseful-dark-atmosphere-303538.mp3"
    play sound "audio/sfx/cloth.mp3"
    show cg11 with dissolve
    J "Hola, [povname]."
    J "¿Disfrutando tu estancia en el hospital?"
    J "Qué pena… no soy fan de este lugar."
    J "¡Pero parece que tú lo eres!"
    play sound "audio/sfx/bisturi.mp3"
    show cg12 with dissolve
    "No tuviste tiempo para hablar cuando Jeff sacó un bisturí."
    pov "Espera, Jeff, escúchame…"
    J "No, no, no hay nada que decir."
    J "Prefieres a los doctores, no tienes que dar más explicaciones."
    play sound "audio/sfx/gore4.mp3"
    show cg13 with dissolve
    "Jeff impulsó su brazo hacia ti, perforando tu garganta con la punta del bisturí."
    "Te ahogaste con tu sangre, gorgojeaste sin poder gritar ni hablar."
    J "No soy tan bueno como un cirujano…"
    "Jeff susurró contra tu oído, tu inhalas con dificultad, tosiendo sangre."
    J "¡Pero pasión no me falta!"
    play sound "audio/sfx/blood dripping.mp3"
    "La hoja del bisturí bajó desde tu cuello hasta tu clavícula, abriendo tu piel como un cierre, la hoja tan hundida en ti que sentías el choque del metal contra tus huesos."
    "Él rió con entusiasmo, divertido con la vista de ti estremeciéndote del dolor mientras la sangre brotaba de tu cuello y se derramaba hacia los lados, empapando la ropa de hospital y las sábanas debajo de ti."
    "Dolía, pero por alguna razón no tanto."
    "Sentías un cosquilleo en el lugar de tus heridas, lo más probable es que estabas con analgésicos."
    scene black with fade
    "Menos mal."
    "Claro, que te hayan degollado con un bisturí no es la manera con la que hubieras preferido morir."
    "Pero ciertamente, el hecho de no experimentar el dolor verdadero lo hacía mejor."
    "Tal vez consigan atrapar a Jeff una vez que alguien aparezca, por la forma en que seguía a tu lado, riéndose como el loco que es."
    "Al final, ¿Te mató porque fuiste amable con los doctores?"
    "No será que él… ¿Estaba celoso?"
    "Nah, no puede ser eso."
    "Tal vez simplemente odiaba los hospitales, como él había dicho."
    show Death with fade
    pause 2.0
    "{b}Final II: Ningún Doctor Pudo Salvarte{/b}"
    return

    #historia_continúa_2 / 20 puntos
    label historia_continua_2:

    stop music fadeout 3.0
    "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    play music "audio/music/tension-and-fear-108408.mp3"
    play sound "audio/sfx/cloth.mp3"
    show cg11 with dissolve
    hide cg9
    pov "Jeff, qué sorpresa, no sabía que eras tú."
    J "…"
    J "No aprecio tu sarcasmo."
    play sound "audio/sfx/heart beat.mp3"
    "Tu corazón latía con fuerza, respuesta a la cercanía de la persona que te arrancó el ojo izquierdo."
    "Tu cuerpo tenía miedo, pero tu mente no."
    pov "Así que… ¿Viniste a darme cuidados especiales?"
    "Jeff rió entre dientes, sacando una jeringa de su bolsillo."
    J "Algo así."
    pov "Espera, ¿Qué haces?"
    "Él llevó la jeringa a tu intravenosa y la inyectó en la manguera."
    J "Relájate, no te matará."
    J "Te hará sentir… algo de agitación."
    play sound "audio/sfx/ekg-fast.wav" volume 0.1
    "En el momento en que él dijo eso, sentiste que tu corazón empezó a latir más rápido."
    "Empezaste a respirar aceleradamente, como si hubieras corrido una maratón."
    "Por reflejo, te llevaste una mano al pecho, apretando la tela de la bata de hospital."
    pov "Tu…ah…. desgraciado…"
    "Jeff chasqueó la lengua, negando con la cabeza"
    J "Ten algo de respeto por tu doctor."
    "Jeff dirigió su mano hacia ti y sujetó entre sus dedos tu barbilla, alzando tu cabeza para verlo."
    "Sintiéndote débil y con cansancio, te dejaste ser, sin fuerzas para gritar por auxilio ni para soltarte de su agarre."
    J "Recuerda, estamos jugando."
    pov "Estoy…. en el hospital…. ¿Cómo…. esperas que…. huya de ti?"
    pov "Eres… un tramposo…"
    "Jadeaste con frustración, ya que no tenías energías ni para hablar bien."
    J "Tómalo como una advertencia."
    "Jeff se encogió de hombros despreocupado."
    stop sound fadeout 5.0
    "De repente, una alarma empezó a sonar, y el ruido de pasos rápidos llegaron de afuera de la habitación."
    J "Esa es mi señal."
    "Jeff se colocó la mascarilla nuevamente y se puso de pie."
    hide cg11 with dissolve
    J "Espero que mejores tu estrategia, sería una lástima que termines aburriendome."
    "Dijo Jeff, antes de desaparecer entre la pequeña multitud de enfermeras y doctores que entraron y se dirigieron hacia ti."
    DR "¡Tenemos una hiperpotasemia grave!"
    DR  "Administra gluconato de calcio intravenoso, 10 ml al 10 por ciento en bolo lento. ¡Ahora!"
    "Entre instrucciones y palabras de lenguaje médico que no entendías del todo, miraste con recelo a Jeff, que se retiró como si nada, oculto a plena vista."
    "¿De verdad fue tan fácil para él infiltrarse?"
    "O Jeff tenía una habilidad sobrehumana para pasar desapercibido, o la gente de este hospital era inepta."
    "Querías creer que fuera la primera opción."
    stop music fadeout 5.0
    "De todas formas, pudieron tratarte con rapidez, por lo que te sentías considerablemente mejor."
    show salazar1 neutral lentes at center
    with dissolve
    DR "Si notas la función renal comprometida, pide diálisis urgente."
    "El Dr. Salazar le estaba dando unas instrucciones a otro doctor, uno que ahora tenías la seguridad de que se trataba de un residente."
    "El residente asintió ante las órdenes del Dr. Salazar y se retiró, dejándolos solos a ustedes dos."
    show salazar1 incomodo lentes
    "El Dr. Salazar se masajeó las sienes y se dirigió a tu camilla."
    "Su mirada reflejaba preocupación, por lo que no pudiste evitar desviar la mirada con culpabilidad."
    DR "[povname], sufriste una hiperpotasemia severa, ¿Tienes alguna idea de lo que lo pudo haber provocado?"
    "Te mordiste el labio inferior ante la pregunta."
    "Estabas teniendo un momento difícil, tratando de convencerte de confiar todo el tema de Jeff con alguien más."

    menu:
        "Confiar en el Dr. Salazar":
            play music "audio/music/lofi-relax-music-lofium-123264.mp3" 
            "Pero las acciones rápidas y el cuidado atento que él te dirigía te convenció de que era digno de confianza."
            pov "La verdad es que… Mi atacante vino."
            pov "Él… me hizo algo, le puso algo a mi intravenosa."
            "El Dr. Salazar abrió los ojos con sorpresa, para después bajar la mirada con lástima."
            show salazar1 sad lentes
            DR "Lo siento tanto, [povname], este se supone que debería ser un lugar seguro, y te falló."
            DR "Yo te fallé."
            play sound "audio/sfx/cloth.mp3"
            "Tomaste la mano del doctor con la tuya, y trataste de sonreír reconfortante."
            pov "No es tu culpa, sé que haces lo mejor que puedes."
            "El Dr. Salazar miró en silencio sus manos entrelazadas, y acarició tu dorso con su pulgar."
            "No evitaste sentir tus mejillas encenderse ligeramente."
            DR "No es una idea muy convencional… pero puedo sacarte de aquí, ir a un lugar seguro."
            "Eso… no sonaba muy profesional." 
            "Era casi como si no se estuviera comportando seriamente como un doctor, más bien parecía… estar engatusado."
            "Pero ya no confiabas en el hospital." 
            "Cualquier otra cosa sonaba mejor para ti."
            pov "Hagámoslo."
            scene hospitalhall with dissolve
            "El Dr. Salazar hizo un rápido papeleo en el que te dio de alta, te entregó tu ropa y te transportó en silla de ruedas por los pasillos del hospital."
            pov "¿A dónde vamos?"
            show salazar1 neutral lentes at center
            with dissolve
            DR "A mi casa."
            pov "Wow, invítame a cenar primero."
            show salazar1 smile lentes
            "El Dr. Salazar rió entre dientes detrás de ti, empujando la silla de ruedas."
            DR "Te realicé cirugía, ya nos saltamos unos cuantos pasos."
            "Al menos podían tomarse las cosas con humor."
            scene elevator with dissolve
            "Ustedes llegaron al ascensor. El Dr. Salazar te entró primero, dejándote de espaldas a las puertas."
            pov "¿Viste a Cindy?"
            show salazar1 neutral lentes at center
            with dissolve
            DR "Si, linda chica, aunque un poco…"
            pov "¿Criticona?"
            DR "… Son tus palabras, no las mías."
            play sound "audio/sfx/elevator_open.wav"
            scene elevator2 with dissolve
            stop music fadeout 5.0
            "Ustedes quedan en silencio cuando escucharon las puertas del ascensor abrirse."
            "Esperaste en silencio para que alguien subiera y apretara un botón, pero en cambio escuchaste un sonido ahogado y un forcejeo detrás de ti."
            play music "audio/music/horror-background-atmosphere-2-289424.mp3"
            "Miraste el espejo frente a ti, y te sorprendiste al ver que el Dr. Salazar ya no estaba detrás de ti."
            "Las puertas del ascensor estaban abiertas, dejando ver a un pasillo del hospital que estaba a oscuras."
            pov "¿Doctor?"
            "Llamaste, en un intento de recibir respuesta, pero no nada."
            J "Qué pena…"
            "Esa voz te hizo estremecer."
            pov "¿Jeff…?"
            J "¿Quién hace trampa ahora?"
            window hide
            show cg14 with dissolve
            pause 1.0
            window show
            "Tras la burla, Jeff da un paso adelante, dejándose ver en el umbral del ascensor."
            pov "Yo…"
            J "Nuestro juego es entre tu y yo, nadie más."
            J "Pero ya no importa, el juego terminó."
            play sound "audio/sfx/cloth.mp3"
            show cg15 with dissolve
            "Jeff se adentra en el ascensor, mirándote desde el espejo."
            "Su tono era burlesco, pero sus ojos estaban inyectados en sangre."
            "Con lentitud, él sacó su cuchillo y lo dirigió con la misma lentitud hacia tu estómago."
            "Jadeaste ante la expectación."
            "Sabías lo que venía, sin embargo la ansiedad te abrumaba."
            play sound "audio/sfx/gore1.mp3"
            "De la misma manera lenta y calma, Jeff enterró la hoja del cuchillo en tu estómago, atravesando tu ropa hasta tu interior."
            "Te doblaste del dolor, pero Jeff te forzó a enderezarte tras rodear tu cuello con su brazo."
            "Sentiste su respiración a través de la mascarilla contra tu oreja."
            "Apretaste los dientes con fuerza, hasta el punto de lastimar tu boca."
            J "Ssh… Ve a dormir…"
            "Él susurró, enterrando más la hoja en tu interior."
            scene black with fade
            "Era tanto el dolor, que no podías gritar."
            "Pero el trato de él, sujetándote con un abrazo mientras te consolaba con susurros te daba la impresión de que estaba tomando cierta consideración."
            "Pudo haber sido mucho más cruel, tal vez estaba siendo un poco considerado porque fuiste un breve acompañante de juegos."
            show Death with fade
            pause 2.0
            "{b}Final III: No Seguiste El Juego{/b}"
            return
        "Guardatelo para ti":
            jump supervivencia_7

    label supervivencia_7:

    play music "audio/music/dedpression-339994.mp3"
    "Decidiste que era mejor lidiar con eso por tu propia cuenta."
    "Que Jeff tuviese la facilidad de entrar a un hospital e inyectarte algo bajo vigilancia te decía que la protección en ese lugar no era segura."
    pov "No lo sé, estuve inconsciente todo el tiempo."
    "El Dr. Salazar se inclinó a ti, apoyando una mano a un costado de tu cabeza."
    DR "Lo que sea que haya pasado, puedes confiar en mí."
    "….."
    "Si…"
    "No."
    "Te las has arreglado para sobrevivir hasta ahora, puedes seguir haciéndolo sin ayuda de nadie."
    "Llámalo presentimiento, pero algo te decía que Jeff no te atacaría por el momento, así que tenías tiempo para formar un plan."
    "Jeff no te hizo tanto daño como antes, así que lo más seguro es que hablaba en serio cuando decía que era una advertencia."
    "Una advertencia de que podía hacerte algo peor, y depende de ti evitarlo."
    "Así que no, no tenías por qué confiar en un doctor que acabas de conocer."
    pov "Doctor, digo la verdad."
    show salazar1 neutral lentes
    "El Dr. Salazar te miró unos segundos, no convencido, para después suspirar y tomar distancia."
    DR "De acuerdo… trata de descansar."
    "Asentiste en silencio, pero a diferencia de antes, el doctor llamó a alguien de afuera de la habitación."
    "Con rapidez, llegó una enfermera."
    DR "Estate alerta del monitor. Ante cualquier alteración, da aviso."
    "La enfermera asintió ante la instrucción y se quedó en la habitación, cerca del monitor cardiaco que tenías conectado."
    "Claramente, el Dr. Salazar no confiaba en dejarte a solas."
    DR "Vendré periódicamente."
    play sound "audio/sfx/cloth.mp3"
    hide salazar1 with dissolve
    "No sabías si se lo dijo a la enfermera o a ti, pero de todas formas asentiste y te recostaste en la camilla con un suspiro de cansancio."
    "Sobrevivir a un sádico asesino era exhausto."
    scene sky1 with dissolve
    "Cuando Cindy llegó y el Dr. Salazar le comentó que tuviste una pequeña crisis, ella se preocupó mucho, hasta el punto de considerar quedarse el resto del día contigo."
    "Aunque apreciaras el gesto, no estabas del todo bien con eso. Así que la convenciste de que fuera a trabajar, pidiéndole que te cubra."
    "De todas formas, el Dr. Salazar te dio una semana de reposo."
    scene sky2 with dissolve
    "Como te dejaron en observación, tuviste que pasar el resto del día y la noche en el hospital, pero cuando llegara la mañana del día siguiente, todo estaba listo para darte de alta."
    stop music fadeout 5.0

    #dia 3

    window hide

    show Day3 with fade

    pause 2.0


    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 

    scene hospitalexit with dissolve
    window show
    "Al día siguiente, te dieron de alta."
    "Y por suerte, tenías el asunto del transporte cubierto."
    show tw neutral at center
    with dissolve
    TW "Adelante, [povname]."
    "El Teniente Wes abrió la puerta del auto para ti, mientras la detective Sean tomaba asiento en el puesto del conductor."
    "Te levantas de tu lugar en la silla de ruedas en la que te llevaron a la entrada del hospital."
    play sound "audio/sfx/running-on-concrete.mp3"
    show tw neutral at left
    with move
    show salazar1 neutral lentes at center
    with dissolve
    DR "¡[povname]!"
    "Te giras ante el llamado de tu nombre."
    pov "¿Dr. Salazar, qué sucede?"
    "El Dr. Salazar se toma un momento para tomar aire, para después extenderte una tarjeta de presentación."
    play sound "audio/sfx/Equip2.ogg"
    window hide 
    show s_card at truecenter
    with dissolve
    window show
    DR "Mi tarjeta, puedes llamarme cuando quieras… o si necesitas algo."
    hide s_card with dissolve
    "Recibiste el pedazo de papel y lo agitaste juguetonamente."
    pov "¿Quién diría que podría conseguir el número de alguien si me lastimaba un poco?"
    show salazar1 incomodo blush lentes
    "El Dr. Salazar abre la boca con impresión, para después carraspear con las mejillas encendidas."
    DR "Esto… es preocupación profesional."
    "Wes alzó una ceja al doctor, el cual se rascó la cabeza con incomodidad y se retiró."
    hide salazar1 with dissolve
    show tw at center
    with move
    TW "¿Ese doctor no se ha sobrepasado contigo?"
    pov "Para nada, ha sido bastante atento."
    "Wes se encogió de hombros y volvió a apuntar al interior del auto."
    play sound "audio/sfx/515007__jusebago__cerrando-puerta-de-carro-closing-car-door.mp3"
    scene car with dissolve
    "Esta vez, sin interrupciones, te sentaste en los asientos traseros."
    "Cuando Wes tomó asiento en el lado del copiloto, el auto encendió y avanzó."
    "La mayoría del tiempo, hubo silencio, hasta que viste disimuladamente cómo Wes le daba un leve codazo a Sean."
    show tw neutral at left 
    with dissolve
    show ds neutral at right
    with dissolve
    DS "Ehem."
    "Ella carraspeó, mirándote por el espejo retrovisor."
    DS "Así que… [povname], ¿Cómo te sientes hasta el momento?"
    "Te extrañó el que la policía más distante esté intentando conversar contigo, pero no tenías por qué ser idiota y rechazar sus esfuerzos."
    pov "Bien, aunque en su mayoría es por los analgésicos."
    "No pudiste evitar acariciar con la punta de tus dedos el parche clínico que cubría tu cuenca izquierda."
    "Sean dio una pausa, para después responder."
    DS "… Tal vez tengas cicatrices, pero son la evidencia de que sobreviviste."
    "No pudiste evitar sorprenderte por un momento ante el comentario alentador, pero debes admitir que te hizo el día."
    pov "Gracias."
    "Sean miró al frente, concentrada en el camino, pero algo te hace pensar que se siente más tranquila."
    TW "¿Tu novia irá a verte a tu hogar?"
    "Tu mente se congela por instantes ante la pregunta de Wes."
    pov "¿Disculpa?"
    TW "La señorita Cindy."
    pov "Ah."
    "No sabías si ofenderte o avergonzarte."
    pov "Es sólo una compañera de trabajo, ni siquiera es mi amiga."
    TW "Oh, yo pensé…"
    "Él se giró a Sean, con una mirada que pedía ayuda, pero fue completamente ignorado."
    TW "La vi muy atenta y protectora de ti, lo siento, no quise…"
    pov "Está bien, también me llama la atención que sea así."
    pov "Pero… es agradable ver que alguien se preocupa de mí en esta ciudad."
    TW "Estás por tu cuenta tengo entendido."
    pov "Si, pero lidio con eso."
    DS "Podemos pedir protección para ti."
    pov "Oh, ¿Como vigilar donde vivo?"
    DS "Si, ahora asumimos que tu atacante está en la fuga, pero no podemos suponer que no volverá para terminar el trabajo."
    "Wes se removió incómodo en su lugar."
    TW "Elise…"
    pov "Está bien, no me importa."
    "En realidad, que te estén protegiendo te da cierta seguridad, considerando que Jeff irá a buscarte."
    "Eres consciente de que estás entorpeciendo la investigación al ocultar información clave, como el nombre de Jeff y el juego que él instauró."
    "Pero tras presenciar cómo él se salía con la suya muy fácilmente en el hospital, algo te decía que el universo estaba a favor de él."
    pov "La verdad, me hace sentir mejor."
    "Un escalofrío de peligro se enraíza desde tu nuca, como si tu cuerpo sintiera la presencia de Jeff cerca."
    play sound "audio/sfx/cloth.mp3"
    "El recuerdo del dolor punzante de tu ojo siendo arrancado te hace acomodarte en tu asiento."
    "Tal vez, sólo tal vez, te estaba afectando más de lo que te gustaría."
    DS "Llegamos."
    "Ves por la ventana del auto la entrada a tu edificio, lo que te hace suspirar de alivio."
    "Por fin puedes volver a tu cama."
    TW "Vamos a estar al pendiente, cualquier actualización te avisaremos."
    play sound "audio/sfx/Equip2.ogg"
    window hide
    show w_card at truecenter
    with dissolve
    window show
    TW "Este es mi número, llama si necesitas algo, y te aseguro que mi preocupación es estrictamente profesional."
    "Recibes la tarjeta de presentación con la punta de tus dedos, viendo el nombre impreso, “W. Wes”."

    menu: 
        "Coquetear con Wes":
            hide w_card with dissolve
            pov "Oh, W, ¿será de William?"
            show tw smile
            "Wes se ríe entre dientes, su voz grave vibrante es un dulce para los oídos."
            TW "No, pero buen intento."
            pov "¿Al menos puedo saber si hay señora Wes esperando en casa?"
            "Wes se sorprende por unos segundos, para después soltar una carcajada ligera."
            show ds incomoda
            "Escuchas a un lado que Sean suelta un quejido lastimero."
            DS "La W es de Wallace, ¿Feliz?"
            "Alzas las manos en rendición, con una pequeña sonrisa traviesa."
            "Abres la puerta del auto y te tomas un momento para despedirte."
            pov "De acuerdo, geez. Fue un gusto, detective."
            "Sean hace un ademán de despedida con la mano, como si te estuviera apresurando."
            pov "Wallace, ¿Puedo llamarte Wallace?"
            "Wes alzó una ceja con una sonrisa sarcástica."
            TW "Ya lo hiciste."
            pov "Fue un placer, Wallace."
            "Él vuelve a reír levemente, despidiéndote con la mano."
            TW "Ya nos veremos, player."
            jump charla_1
        "Coquetear con Sean":
            hide w_card with dissolve
            pov "¿Puedo tener su número, detective?"
            show ds incomoda
            "Ves por el espejo retrovisor que los ojos de Sean se abren con sorpresa."
            DS "¿Disculpa?"
            pov "El teniente me dió el de él, ¿Puedo tener el suyo?"
            "Sean mira de reojo a Wes, el cual se encoge de hombros."
            show ds incomoda blush
            DS "Bueno… yo…"
            TW "Discúlpala, no tiene muchas habilidades sociales."
            "Sean le da un codazo a Wes, quién se ríe levemente con burla."
            DS "¡Wallace!"
            pov "Eso es lindo."
            "Sean se queda en silencio por un momento, para después sacar a regañadientes su billetera."
            play sound "audio/sfx/Equip2.ogg"
            window hide
            show ds_card at truecenter
            with dissolve
            window show
            show ds neutral
            DS "Este… es mi número, llama cuando quieras- digo, cuando necesites."
            "Ves por el rabillo de tu ojo restante cómo Wes alza una ceja ante los murmullos de Sean, quien desvía la mirada de ti."
            pov "Entendido."
            "Asientes firmemente."
            jump charla_1
        "Preguntar sobre el caso":
            hide w_card with dissolve
            pov "¿Puedo… preguntarles algo?"
            "Ellos te miran desde sus lugares, expectantes a tus próximas palabras."
            pov "No pude evitar darme cuenta… que les sorprendió ver que sobreviví."
            "Wes mira un momento a Sean, con seriedad. Ella asiente firmemente."
            DS "Hay que decirle, Wallace."
            "Wes hace una pausa, para después suspirar pesado."
            TW "… Sospechamos de alguien que puede ser el hombre que te atacó."
            "Tragas fuertemente."
            pov "¿... Quién creen que es?"
            DS "Creemos que es alguien llamado Jeff, su apellido no lo sabemos con exactitud. Es un hombre muy peligroso, lleva escapando de la ley por más de una década."
            "Wes se acomoda en su asiento para enfrentarte."
            TW "[povname]... Es un asesino demente, y si tenemos razón respecto a esto… Serías la primera víctima de la que sabemos que él deja viva."
            pov "…"
            "Bueno, eso fue un gran volcado de información, presuntamente valiosa."
            pov "De acuerdo, entiendo."
            TW "¿Vas a estar bien por tu cuenta?, ¿No quieres que te consigamos un hotel?"
            pov "No, gracias… estaré bien."
            "Wes te miró indeciso por un momento, pero cedió al verte que bajas del auto."
            jump charla_1

    label charla_1:

    play sound "audio/sfx/515007__jusebago__cerrando-puerta-de-carro-closing-car-door.mp3"
    scene streetday with dissolve

    "Cierras la puerta y te quedas un momento sobre la acera, observando cómo el auto se mezcla en el tráfico."
    "Suspiras con alivio, girándote al vestíbulo de tu edificio."
    scene living with dissolve
    "Cuando llegas a tu departamento, está igual a cómo lo dejaste hace dos días."
    "Te entregaron el departamento amueblado y tenías pocas cosas propias, así que no había desorden, pero definitivamente haber dejado el lugar por dos días hizo que se acumulara algo de polvo."
    play sound "audio/sfx/441588__danielajq__18-barriendo.wav"
    "Así que lo primero que haces es ponerte a barrer y sacudir."
    "Abres las ventanas mientras agitas los cojines del sofá, y después sacudes el polvo de la tv."
    show kitchen with dissolve
    play sound "audio/sfx/609139__nataliafranco__nevera.mp3"
    "Deshechas todo de la nevera que está en mal estado y limpias el interior."
    show bathroom with dissolve
    "Pasas al baño, donde limpias las superficies hasta que no puedes ver ni un rastro de suciedad."
    show room with dissolve
    stop sound fadeout 3.0
    "Por último, llegas a tu habitación. Está más vacía de lo que te gustaría."
    "Te gustaría tener…"

    menu:
        "Posters":
            "Lo que sea para cubrir las paredes blancas."
            jump character_4
        "Luces":
            "Iluminación extra y estética le vendría bien."
            jump character_4
        "Muebles":
            "Más que adornos, preferirías tener muebles para guardar tus cosas."
            jump character_4

    label character_4:

    "De todas formas, ahora no tienes tiempo para preocuparte por eso."
    "Tienes que lidiar con lo más importante…"
    scene living with dissolve
    play sound "audio/sfx/609727__theplax__door-lock-1.wav"
    "Cierras todas las ventanas a tu alcance con seguro, luego vas a la entrada y pones doble llave a la cerradura."
    "Te asomas por una ventana, y ves que en la calle de enfrente hay una patrulla estacionada."
    play sound "audio/sfx/cloth.mp3"
    "Suspiras, sentándote en el sofá, recuperando el aire y la sensación de seguridad que habías perdido hace tiempo."
    "Técnicamente, Jeff no podría alcanzarte. No debería."
    "Pero uno nunca puede estar seguro, para conveniencias del guión."
    play sound "audio/sfx/735844__milcahrawr__muffled-news-program.wav"
    "Para distraerte, enciendes la tv y cambias de canal hasta alguno que te interese, hasta que llegas a un noticiario mostrando un escenario muy familiar."
    "Esa es… ¿La calle donde está la tienda de películas?"
    "Subes el volúmen, con mayor interés."
    Peri "… Una persona fue atacada a las 9 horas de la noche el día jueves, con heridas graves. Fuentes médicas informaron que la víctima se encuentra en recuperación."
    Peri "Descripciones del atacante indican que es un hombre alto, blanco, entre 20 y 30 años con cicatrices en el rostro. Lleva ropa blanca y negra, y frecuenta cubrirse el rostro."
    Peri "Al sospechoso se le atribuyen 27 víctimas de asesinato, pero los investigadores estiman que el número real podría superar al centenar."
    "Era bastante obvio que estaban hablando de tu ataque."
    "Sientes que pierdes fuerzas en las manos mientras más escuchas a la periodista, mientras más sabes de Jeff." 
    "¿Tantas personas había matado?"
    "¿Realmente te había dejado con vida?"
    "Recuerdas vagamente que Wes había discutido con unas personas fuera de tu habitación en el hospital, seguramente estaba ahuyentando a periodistas que querían hablar contigo."
    "Mejor, así hubieras tenido menos chance de meter la pata."
    "Si te hubieran puesto ante las cámaras, con micrófonos en la boca y periodistas viéndote con hambre de información, hubieras revelado información que no te convendría por el acecho de Jeff."
    "Ya que todo indicaba que no importaba a donde fueras, Jeff te encontraría."
    scene bathroom with dissolve
    play sound "audio/sfx/740313__fossarts__bathroom-faucet-turned-on-1.mp3"
    "Sintiendo que el sudor baja por tu frente, vas a al baño y te lavas la cara, suspirando frente al lavabo."
    "Te miras en el espejo, y por primera vez presencias tu apariencia actual."
    "Tu expresión se ve cansada, no llegaba a ser demacrada, pero estaba a punto."
    "Marcas moradas en forma de dedos rodeaban la piel de tu cuello, lo que te hizo tragar."
    "Pero entonces caes en cuenta del parche sobre tu ojo izquierdo."
    play sound "audio/sfx/cloth.mp3"
    "Con dedos temblorosos, desenganchas los elásticos del parche de tu cabeza, dejando a la vista un parche adhesivo. Remueves esa pieza, y sólo queda una gasa."
    "Pacientemente, quitas la gasa, para finalmente ver lo que había hecho Jeff de ti."
    "Tras quitar el pedazo de tela, ves tu párpado caído, y cuando intentas pestañear, tu párpado tiembla, dejando ver el interior de tu cuenca, recubierto con piel rosada y brillante."
    "Sientes curiosidad y extiendes tu párpado inferior para ver mejor el interior de tu cuenca."
    "Es curioso, porque de alguna forma, sientes que tu ojo sigue ahí."
    "¿Cómo se llamaba?, ¿Sensación fantasma?"
    "Si giras tu ojo derecho a algún lado, sientes que tu ojo izquierdo hace lo mismo, aunque claramente ya no se encuentra ahí."
    J "Es uno de mis mejores trabajos."
    stop music
    play music "audio/music/tension-and-fear-108408.mp3"
    "Te congelas ante la voz."
    show jeff1 smile at right:
        alpha 0.0
        linear 2 alpha 0.5
        linear 2 alpha 0.0
    play sound "audio/sfx/heart beat.mp3"
    "Tu visión se aclara, y en el reflejo del espejo, detrás de ti, puedes ver la silueta de Jeff."
    "Te giras repentinamente, con el corazón acelerado."
    "Pero no hay nadie."
    "Te tomas un momento para recuperar la respiración, para luego llevarte una mano a la cara."
    "¿Realmente estabas empezando a alucinar?"
    "Parece que Jeff había causado una gran impresión en ti."
    "¿Puede que realmente…. tengas miedo?"
    stop sound

    menu:
        "Si":
            $ miedo = "Si"
            "No querías admitirlo… pero parece que es el caso."
            "Pero tu miedo no es el de morir precisamente, es… de recibir más daño."
            jump character_5
        "No":
            $ miedo = None
            "Nah, no era para tanto."
            "Ese era tu cuerpo reaccionando al trauma, nada más."
            jump character_5

    label character_5:

    stop music fadeout 5.0
    
    "Tanto pensar en ese desquiciado te estaba cansando."
    scene kitchen2 with dissolve
    "Vas a la cocina a comer algo."
    if sabor == "D":
        "Tenías un par de donas en buen estado guardadas en la alacena."
        "Bebes un poco de jugo y te tomas los analgésicos que te corresponden, y te vas a la cama."
    else:
        "Decides hacerte un ramen instantáneo."
        "Lo acompañas con soda y te tomas los analgésicos que te corresponden, y te vas a la cama."

    play sound "audio/sfx/Equip2.ogg"
    scene black with fade
    "Quieres ir a dormir sintiendo que estás a salvo, pensando que estarás bien."
    "Pero como alguien está leyendo esto, eso no pasa."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    scene room2 with fade
    "Escuchas un crujido, lo que te despierta de inmediato."
    "No sabes si es por tener el sueño ligero o porque estás alerta, pero agradeces que sea así."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "Te quedas un momento en tu lugar, esperando que se trate de tu imaginación nuevamente, pero vuelves a escuchar un crujido, esta vez sabes que es por que hay alguien en la casa."
    play music "audio/music/horror-background-atmosphere-2-289424.mp3"
    "¡Tienes que esconderte!"

    window hide

    call screen mapa_home(time=10, timeout="game_over")

    label game_over:

    show jeffknife1 happy at jumpscare_top
    J "¡Te encontré!"
    play sound "audio/sfx/stab.mp3"
    show red with dissolve
    pause 1.0
    show Death with fade
    pause 2.0
    return

    label muerte_cama:
    scene bed with dissolve
    play sound "audio/sfx/cloth.mp3"
    "Es un buen escondite."
    "Aunque un poco predecible."
    "...."
    window hide
    show cg16 with dissolve
    pause 1.0
    window show
    J "¡Boo!"
    "Tal vez demasiado."
    play sound "audio/sfx/Equip2.ogg"
    scene black with fade
    "Te arrastras hasta el fondo, y Jeff te sigue a gatas, mientras se ríe."
    J "¡[povname]!, ¡Qué movimiento tan travieso!"
    "El espacio es tan reducido que pronto sientes la respiración de Jeff en tu oído."
    J "Pierdes de nuevo…"
    play sound "audio/sfx/rush__blade.mp3"
    "Sientes la fría hoja del cuchillo en tu cuello, y con un chirrido, sientes que el ardor te atraviesa."
    show red with dissolve
    pause 1.0
    show Death with fade
    pause 2.0
    return

    label muerte_closet:
    play sound "audio/sfx/cloth.mp3"
    scene closet with dissolve
    "Esperas unos segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    play sound "audio/sfx/403355__corpocracy__door_slam01.mp3"
    "Pero tus esperanzas de haber escogido un buen escondite se van cuando escuchas que la puerta del closet se abre."
    show living2 with dissolve
    show jeffknife1 happy at center
    with dissolve
    J "¡[povname]!"
    "Jeff suena encantado por verte, pero el gran cuchillo en su mano no inspira nada bueno."
    J "Volviste a perder, jeje."
    play sound "audio/sfx/gore3.mp3"
    show jeffknife2 happy at center
    hide jeffknife1
    "No tienes momento para pensar cuando Jeff te apuñala en el estómago."
    play sound "audio/sfx/falling.mp3"
    "Caes en el suelo, por el dolor intenso y la pérdida de sangre."
    scene black with fade
    J "No sabes jugar muy bien, [povname]."
    "Sintiendo la luz de la luna fría filtrándose por las ventanas, caes en el inconsciente."
    show Death with fade
    pause 2.0
    return

    label muerte_baño:
    play sound "audio/sfx/cloth.mp3"
    scene bathroom2 with dissolve
    "Te sientes a salvo."
    play sound "audio/sfx/471602__wifisfuneral__move_knob-02.mp3"
    "Pero entonces, escuchas como el pomo se agita."
    J "¡[povname]!, ¡Te atrapé!"
    "No respondes."
    play sound "audio/sfx/587930__robotortoise__knocking-and-banging-on-my-apartment-door-no-reverb.mp3"
    "La puerta es golpeada y se escuchan golpes estruendosos."
    J "¡Déjame entrar!, ¡Ya gané!"
    "Te quedas en silencio."
    "Quizás se canse y se vaya."
    J "…"
    play sound "audio/sfx/587930__robotortoise__knocking-and-banging-on-my-apartment-door-no-reverb.mp3"
    J "¡Ábreme!"
    "La puerta se sacude y te encoges ante la sorpresa."
    "Un golpe contundente choca contra la puerta, luego otro, y otro."
    play sound "audio/sfx/403355__corpocracy__door_slam01.mp3"
    "Hasta que la madera cede."
    show jeffknife1 mad at center
    with dissolve
    J "¡[povname]!"
    "El modo en que dice tu nombre es tenebroso, con los dientes apretados y en un gruñido."
    show jeffknife1 mad at jumpscare_top
    "No alcanzas a hacer nada cuando Jeff se abalanza sobre ti con cuchillo en mano."
    play sound "audio/sfx/stab.mp3"
    show red with fade
    pause 1.0
    show Death with fade
    pause 2.0
    return

    label muerte_sala:
    play sound "audio/sfx/cloth.mp3"
    scene living2 with dissolve
    "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "Pero un crujido frente a ti te pretrifica."
    show jeffknife1 neutral at center
    with dissolve
    J "…"
    pov "…"
    J "¿Si sabes que tienes que esconderte?"
    pov "…"
    J "Oh bueno, será."
    play sound "audio/sfx/hang.mp3"
    "Jeff te sujeta del cuello, ahorcándote."
    play sound "audio/sfx/gore3.mp3"
    show jeffknife2 neutral at center
    hide jeffknife1
    "Y entonces sientes que te perforan en el costado."
    scene black with fade
    J "Esto fue… demasiado fácil."
    show Death with fade
    pause 2.0
    return

    label supervivencia_8:
    $ show_live ("YouLive")
    play sound "audio/sfx/Equip2.ogg"
    scene bed with dissolve 
    "Te arrastras lo más silenciosamente posible debajo de la cama, y esperas."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "Escuchas crujidos suaves y continuos."
    "De repente ves unos pies atravesando la puerta de tu habitación, y tu respiración se detiene."
    "Los zapatos negros de combate avanzan con lentitud, rodeando tu cama."
    "Tu observas, rezando porque se vaya pronto."
    "La persona se queda unos momentos más, para después retirarse con la misma lentitud."
    "Sientes que puedes respirar."
    "Te quedas unos momentos, para después volver a pensar en qué hacer."
    call screen supervivencia_9

    label supervivencia_9:
    $ show_live ("YouLive")
    play sound "audio/sfx/Equip2.ogg"
    scene bathroom2 with dissolve 
    "Corres de puntillas al baño y cierras la puerta con seguro."
    "Te metes en la tina, tomando resguardo detrás de la cortina."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "Esperas pacientemente, escuchando el sonido de alguien abriendo puertas y moviendo cosas."
    "De repente, silencio."
    call screen supervivencia_10

    label supervivencia_10:
    $ show_live ("YouLive")
    play sound "audio/sfx/Equip2.ogg"
    scene living2 with dissolve
    "Disimuladamente, vas a la sala y te escondes detrás del sofá."
    "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    "…"
    "Aunque… estás en un lugar demasiado expuesto."
    call screen supervivencia_11

    label supervivencia_11:
    $ show_live ("YouLive")
    play sound "audio/sfx/Equip2.ogg"
    scene closet with dissolve
    play sound "audio/sfx/heart beat.mp3"
    "Entras al closet y te quedas en silencio, escuchando el latido de tu corazón en tus oídos."
    "Esperas segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    "Tus esperanzas se están agotando."
    "No puedes ir de un lugar a otro durante toda la noche."
    "¿Cómo puede ser tan insistente?"
    "El cansancio te está invadiendo, pierdes fuerzas en tus piernas."
    "Caes lentamente sobre tus rodillas, y te apoyas contra la pared."
    "Ya no te importa si Jeff te atrapa."
    "Que se joda él y su estúpido juego."
    "De repente, escuchas un suspiro pesado desde algún lugar de tu departamento."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "Lentamente y con sigilo, te asomas por la abertura del closet."
    window hide
    show cg17 with dissolve
    pause 2.0
    window show
    "Jeff está en tu sala, iluminado sutilmente por la luz de la luna que se filtra por la ventana."
    "Tiene el cuchillo a la mano, lo que te hace pensar que tuviste suerte de poder evitarlo."
    J "¡Sé que me escuchas [povname]!"
    J "¡Tu ganas esta ronda!"
    "El cansancio te abandona por un instante, reemplazado por euforia."
    J "Pero no olvides que te estaré vigilando."
    "Eso era un hecho que ya tenías claro."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    scene closet with dissolve
    "Ya te visitó al hospital y te siguió a tu casa."
    "No está de más decir que ya no te sientes a salvo en ninguna parte."
    play sound "audio/sfx/652346__weak_hero__door-closed_1.wav"
    stop music fadeout 5.0
    "Escuchas que la puerta principal se abre y se cierra, y eso te llena de un alivio que te hizo caer inconsciente en tu lugar."
    "De todas maneras, ¿Cómo pudo burlar a los policías ese maniaco?"
    "Una de tres."
    "Uno, mató a los policías. Es el escenario más latoso, ya que eso involucraría muchos más policías."
    "Dos, los policías no lo vieron. Lo que te causa una decepción inmensa."
    "Y tres, Jeff es muy bueno escabulléndose."
    scene black with fade
    "Aún no sabías cómo lo hacía."
    "Quizás lo sepas en un futuro, o quizás no."
    "El tiempo lo dirá."

    #dia 4

    window hide

    show Day4 with fade

    pause 2.0

    scene black with fade
    hide Day4

    window show

    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"

    "El día siguiente estaba… extrañamente calmo."
    "La noche anterior apenas pudiste dormir decentemente, dentro del closet cabe decir."
    "El alivio de sentir que el acecho hacia ti terminó, aunque sea un día, agotó las fuerzas de tu cuerpo."
    "Por lo que despertaste en el espacio reducido del closet, con un cuerpo adolorido."
    scene living with dissolve
    "Lo primero que haces al despertar es asomarte por la ventana, y no sabes si reír o llorar cuando ves la misma patrulla de ayer en el mismo lugar."
    "¿En serio Jeff se coló a tu departamento tan fácilmente?"
    "Revisas las cerraduras, y no están rotas."
    "Eso quiere decir que Jeff, además de burlar a los policías, no forzó la entrada."
    "¿Qué mierda?"
    "Todo se estaba volviendo demasiado conveniente, sobre todo para una historia de suspenso."
    "Antes, sabías con seguridad que Jeff se trataba de un humano, pero ahora… estabas empezando a considerar otras opciones."
    "Aseguras nuevamente la puerta de entrada, y consideras comprar un nuevo pestillo."
    "Pero primero lo primero, tienes que desayunar."
    show kitchen with dissolve
    play sound "audio/sfx/609139__nataliafranco__nevera.mp3"
    "Abres tu nevera, y la decepción te invade al ver que está prácticamente vacía."
    "Hay dos tomates arrugados, una caja de jugo que tras agitarla ves que está media vacía y la mitad de un limón."
    "Recuerdas que desechaste lo que estaba en mal estado el día anterior, pero también que no fuiste de compras."
    show hall with dissolve
    play sound "audio/sfx/keys.mp3"
    "Te preparas para salir, tomas tu billetera y te diriges al recibidor de tu departamento, jugando con tus llaves."
    "Miras por última vez el interior de tu departamento y te retiras, colocando llave a todas las cerraduras."
    "Un momento de duda te detiene, y revisas la ampolleta que está en la esquina superior de tu puerta."
    "Excelente, ahí estaba la habilidad superhumana de Jeff para meterse en tu departamento, se llamaba llaves de repuesto."
    "No puedes creer que realmente te hayas olvidado de eso."
    window hide
    pause 1.0
    show minimarket with fade
    pause 1.0
    window show
    "El minimarket que visitas es uno que está a dos calles de tu departamento, al lado contrario donde se encuentra la tienda de películas."
    "No tiene tantas cosas, pero sirve para momentos desesperados como el de ahora."
    "Buscas los esenciales entre los pasillos y las neveras."

    menu: 
        "Opción vegana":
            $ dieta = "V"
            jump character_6
        "Opción normal":
            $ dieta = "N"
            jump character_6

    label character_6:
    stop music fadeout 5.0
    play sound "audio/sfx/cloth.mp3"
    "Yendo a la caja, sientes un movimiento por el rabillo del ojo derecho. Un movimiento de color blanco."
    play sound "audio/sfx/heart beat.mp3"
    play music "audio/music/tension-and-fear-108408.mp3"
    "Tu corazón se agita, pero la presencia de muchas personas te regresa algo de confianza, por lo que disimuladamente sigues el movimiento."
    "Te acercas a un estante de bocadillos."
    show jeff2 bandana at center:
        alpha 0.0
        linear 2 alpha 0.5
    "Entre las etiquetas de los precios, bolsas coloridas y envases brillantes, puedes percibir un destello blanco, oculto del otro lado de la estantería."
    "Te inclinas en la esquina, asomándote lentamente por el costado."
    "Puedes percibir la postura de alguien agachado, usando ropa blanca."
    hide jeff2 with dissolve
    Stranger "¡[povname]!"
    scene minimarket with hpunch
    play sound "audio/sfx/cloth.mp3"
    play sound "audio/sfx/falling.mp3"
    "El llamado de tu nombre te sobresalta, lo que te hace caer tus compras."
    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 
    show salazar2 incomodo at center
    with dissolve
    DR "Oh, lo siento mucho."
    play sound "audio/sfx/cloth.mp3"
    "Ves con asombro al Dr. Salazar apoyándose en una rodilla, empezando a recoger tus compras."
    pov "¿Dr. Salazar?"
    show salazar2 smile
    DR "Puedes llamarme Paul."
    pov "… Ok, Paul, ¿Qué haces aquí?"
    "No sabes si es que el acoso de Jeff te estaba empezando a afectar más de lo que te gustaría, pero te convenciste de que sólo estabas tomando precauciones."
    "No necesitabas otro acosador en la lista."
    DR "Terminé mi turno hace unas horas. Me gusta venir a un café que está por aquí y no pude evitar verte por la ventana, ¿Espero no te moleste?"
    "Salazar se ríe levemente, incómodo, como si quisiera sacarse de encima una mala imagen."
    pov "Oh, ok."
    play sound "audio/sfx/cloth.mp3"
    "Te agachas también, terminando de recoger tus cosas."
    show salazar2 incomodo
    DR "¿Cómo te sientes?, ¿Cómo está tu… eh, ojo?"
    "Te llevas instintivamente una mano a tu párpado izquierdo, cubierto por el parche."
    pov "Ya no duele."
    show salazar2 smile
    DR "Eso es bueno. ¿Vas a querer una prótesis?"
    pov "Depende, ¿Puedo escoger el color?"
    DR "Por supuesto, puedes escoger el color y tamaño de la iris, de la pupila e incluso de la esclerótica."
    pov "Eso es genial, lo pensaré."
    "El Dr. Salazar asiente con una leve sonrisa."
    DR "¿Te ayudo con tus compras?"
    pov "Gracias, eres muy amable."
    DR "Lo que sea por mi paciente."
    play sound "audio/sfx/Equip2.ogg"
    "Salazar te ayuda a llevar tus cosas a la caja, y tú pagas."
    scene streetday with dissolve
    "Ustedes salen de la tienda, y se quedan un momento en la acera. Llevas una de las bolsas en tu mano, mientras él lleva la otra."
    show salazar2 neutral at center
    with dissolve
    DR "¿Haces las compras?"
    pov "Es para mi desayuno."
    show salazar2 incomodo
    "Salazar te mira con ojos sorprendidos, para después negar con la cabeza."
    DR "Ya es mediodía, [povname]."
    "Te encoges ante el regaño. El te lo diga un doctor te hace sentir más culpable."
    pov "Lo sé… Hubo circunstancias, pero ahora estoy en eso."
    "Él te mira en silencio unos segundos, para después carraspear contra su puño."
    show salazar2 shy blush
    DR "Puedo… Invitarte a desayunar."
    pov "¿Cómo dices?"
    DR "Ehem, dije que quisiera invitarte a desayunar."
    "Ves la postura nerviosa de Salazar y el evidente color en sus mejillas."
    "Ladeas la cabeza, con curiosidad."
    pov "¿Cómo en una cita?"
    show salazar2 incomodo
    "Salazar tose contra su mano, pero se recupera rápidamente."
    DR "No quisiera que me malinterpretaras, pero… "
    show salazar2 smile
    DR "Sí, supongo que sí, te estoy invitando a una cita."
    "Te quedas un momento en silencio, considerando la propuesta."
    "Siempre tienes la opción de coquetear con las personas que te encuentres, pero eso no quiere decir que vayas en serio."
    "Es divertido ver la reacción de los demás con tus provocaciones, y quizás había un poco de esperanza en ti de que eso te llevara a algún lado."
    "Y ahora, tienes la opción, de ir más allá."

    menu:
        "Aceptar":
            pov "Me encantaría."
            "La expresión de Salazar se iluminó ante tu respuesta."
            "Con timidez, él alzó su mano libre hacia ti."
            play sound "audio/sfx/cloth.mp3"
            "Tomas la mano de él con la tuya, entrelazando tus dedos con los de él."
            scene walk with dissolve
            "Caminan en silencio por la calle, y dejas que él te guíe, ya que era él el que te estaba invitando."
            play sound "audio/sfx/character-falling-on-ground-250069.mp3"
            "De repente, ante ustedes, un niño se cae sobre el asfalto y pega un grito desgarrador."
            "Los padres se acercan con rapidez, levantándolo sobre el suelo y dejando ver que su rodilla tenía una herida sangrante."
            show salazar2 neutral at center
            with dissolve
            DR "Déjenme ver, soy doctor."
            "Observas que Salazar se acerca con rapidez y seriedad, sacando de uno de sus bolsillos desinfectante para manos."
            "Sonríes levemente ante la atención de Salazar."
            "Tal vez… Necesitabas un hombre atento después de todo, que respetara la vida."
            "Incomparable con…"
            "Bueno, ya no tenías por qué pensar en él."
            hide salazar2 with dissolve
            stop music fadeout 3.0
            play sound "audio/sfx/person-knocked-down.mp3"
            scene walk with hpunch
            pause 1.0
            play sound "audio/sfx/falling.mp3"
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            "De repente, un gran peso te derrumba sobre el suelo, y te inmoviliza."
            "Sientes que algo húmedo cae sobre tus mejillas, es tibio."
            window hide
            show cg18 with dissolve
            pause 1.0
            window show
            "Miras arriba, y presencias una expresión que no esperabas ver nunca."
            "Jeff lloraba inconsolablemente sobre ti."
            J "¿Cómo pudiste [povname]...?"
            J "¿No soy suficiente para ti…?"
            "Sientes que tu voz se quiebra ante el desconcierto."
            "Por suerte, aparentemente las personas presenciaron todo, lo que indicaba que todo acabaría."
            "Jeff sería atrapado, y tú podrías volver a tu vida."
            J "¡¿No soy suficiente para ti?!"
            play sound "audio/sfx/stab.mp3"
            show cg19 with hpunch
            hide cg18
            "El estruendoso alarido de Jeff te saca de tus pensamientos, y es tarde cuando ves que él alza un cuchillo, y lo entierra en tu pecho."
            play sound "audio/sfx/stab.mp3"
            J "¡[povname]! ¡[povname]!"
            play sound "audio/sfx/stab.mp3"
            "Con cada pronunciación de tu nombre, te ganabas una nueva a apuñalada, que agitaba tu cuerpo y derramaba más sangre."
            play sound "audio/sfx/stab.mp3"
            "Y la expresión de él no cambió, estaba llena de dolor."
            play sound "audio/sfx/push.mp3"
            pause 1.0
            play sound "audio/sfx/character-falling-on-ground-250069.mp3"
            scene walk2 with dissolve
            "Con tu visión borrosa, alcanzas a ver que Jeff es sujetado e inmovilizado al suelo, mientras sigue gritando."
            "Tu párpado pesa, y lo cierras."
            scene black with fade
            "Suspiras por última vez, con el alivio de que Jeff pudo ser atrapado."
            "A costa tuya, claro."
            DR "¡[povname]!"
            "Sientes que tus mejillas son sujetadas por manos mojadas y pegajosas."
            play sound "audio/sfx/cloth.mp3"
            "Escuchas la voz desgarradora de Salazar, quien te sujeta desesperado."
            DR "¡Quédate conmigo!, ¡T-te ayudaré!"
            DR "¡[povname]!"
            "Sonríes levemente, sintiendo la calidez del abrazo de Salazar."
            "Eso era lo que querías, ¿No?"
            show Death with fade
            pause 2.0
            "{b}Final IV: Ninguno De Ustedes Ganó{/b}"
            return
        "Rechazar":
            jump historia_continua_3
        
    label historia_continua_3:

    pov "Lo siento, pero no puedo."
    show salazar2 incomodo none
    "La decepción se refleja en la expresión de Salazar."
    DR "O-oh, ¿Tienes a alguien más…?"
    pov "No es eso. Hoy tengo cosas que hacer, pero otro día podríamos salir, ¿Si?"
    "La mueca de Salazar no parece cambiar ante tus palabras, pero con tu silencio expectante, Salazar sonríe levemente."
    show salazar2 smile
    DR "Entiendo, otro día será."
    DR "Al menos déjame acompañarte a dejar tus compras."
    "Reflexionas sus palabras por un momento."
    "Definitivamente, no estaría demás que te acompañe."
    "Se sentiría seguro, de hecho."
    pov "Claro."
    "Guías el camino, y ustedes caminan en silencio durante todo el trayecto."
    scene hall with dissolve
    "Ustedes llegan a la entrada de tu edificio, y al ver que Salazar no tenía intenciones de dejarte ahí, seguiste guiando el camino hasta detenerte en la puerta de tu departamento."
    pov "Aquí es."
    show salazar2 neutral at center
    with dissolve
    play sound "audio/sfx/Equip2.ogg"
    "Salazar se queda mirando la puerta por unos segundos, para después sonreír levemente, mientras extendía la bolsa que él cargaba hacia ti."
    show salazar2 smile
    DR "Fue un placer verte, [povname]."
    pov "Igualmente, Dr- digo, Paul."
    "La sonrisa de Salazar se extiende, recuperando un poco de la energía que había perdido desde tu rechazo."
    DR "Puedes llamarme cuando quieras."
    pov "Lo tengo en cuenta."
    "Salazar se dirige a la salida, no sin antes voltearse por un momento hacia ti para despedirse con la mano."
    hide salazar2 with dissolve
    "Tu le correspondiste la despedida, y te quedaste en el pasillo hasta que ya no lo viste."
    "Suspiras levemente, volviendo a la realidad de tu situación."
    "Cierto, debes tener cuidado."
    play sound "audio/sfx/609727__theplax__door-lock-1.wav"
    "Desbloqueas cada cerradura y entras a tu departamento, volviendo a cerrar con llave. También te cercioras de ocultar las llaves de repuesto dentro de tu departamento."
    play sound "audio/sfx/cloth.mp3"
    scene kitchen with dissolve
    "Dejas tus compras en la cocina y guardas todo donde corresponde y te quedas con lo que harás el desayuno."
    "Enciendes la cafetera, con el nuevo café que compraste, y pones dos rebanadas de pan en la tostadora."
    "No te habías dado cuenta lo tarde que era cuando Salazar te lo señaló." 
    "Debiste tener mucho cansancio como para haber dormido casi 10 horas después de que Jeff entrara a tu departamento en la madrugada."
    "Te asomas en la ventana nuevamente, y la patrulla sigue ahí. No sabes si es la misma o es otra diferente, pero al menos tienes protección, ¿No?"
    "Que chiste."
    "Con tu café listo y tus tostadas, tomas asiento en la pequeña mesa que tú llamas comedor."
    stop music fadeout 3.0
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "Estás a media mordida, cuando escuchas un toque en la puerta."
    "Miras con sigilo la puerta, en silencio."
    C "¡[povname]!, ¡Soy yo!"
    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"
    "Te relajas cuando te das cuenta de que se trata de Cindy."
    "Vaya, estás siendo bastante popular hoy."
    show living with dissolve
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    pause 1.0
    show cindy2 neutral at center
    with dissolve
    "Vas y abres la puerta, dejando espacio para que ella entre. Cindy pasa con rapidez."
    pov "¿Qué te trae por aquí?"
    "No era sorpresa que ella supiera donde vivías, ya que no es la primera vez que viene."
    "Al ser ella y su padre, tu jefe, las únicas dos personas que conoces en la ciudad, cuando sucedía un imprevisto como un cheque rebotado o algún percance en la tienda, te iban a avisar personalmente a tu departamento."
    C "¿Han atrapado al tipo?"
    "Te encoges de hombros."
    pov "Nop."
    show cindy2 angry
    C "Tienes que tomarte en serio esto, aunque hayan pedido protección para ti, no es seguro confiar 100 por ciento en eso."
    pov "Así que viste la patrulla de afuera."
    "Cindy se lleva una mano a la frente."
    C "Si... también fueron muchos periodistas a la tienda. Se filtró que trabajas ahí, así que tuve que cerrar temporalmente."
    pov "Oh, lo siento…"
    show cindy2 neutral
    play sound "audio/sfx/cloth.mp3"
    "Cindy suspira, tomando asiento en el sofá."
    C "Nada de esto es tu culpa, [povname]. Debí haberte acompañado ese día."
    play sound "audio/sfx/cloth.mp3"
    "Tu la acompañas, tomando asiento junto a ella."
    pov "No digas eso. No tenías cómo saberlo."
    C "…"
    "Cindy carraspea, cambiando de tema."
    C "Así que… ¿Sabes detalles de tu caso?"
    pov "Oh, bueno, parece que saben quién es."
    "El interés de Cindy fue picado."
    C "¿En serio, quién?"
    pov "Un tipo que tiene un body count de 27… De víctimas me refiero."
    "Cindy te miró expectante, ignorando tu broma. Parece que ella no ha visto las noticias." 
    "Claro, en qué momento si tenía que lidiar con ahuyentar a los periodistas invasivos."
    pov "Parece que soy la primera víctima que dejó con vida."
    C "…"
    show cindy2 angry
    "Cindy deja escapar un quejido."
    C "Lo que faltaba, un asesino serial se fijó en ti."
    "Ella no está equivocada."
    pov "No dijeron que fuera un asesino serial."
    C "Si asesinó a más de tres personas y lleva haciéndolo desde hace años, cae en la categoría de asesino serial."
    pov "¿... De acuerdo?"
    C "¿Viste si sentía placer al atacarte?"
    pov "Oh, si, definitivamente."
    "Recordabas cómo él insistía que admitieras que tenías miedo, incluso querer saber los detalles."
    "Ups, ¿quizás debiste guardarte eso para ti?"
    "Cindy se llevó unos dedos a la barbilla, pensativa mientras murmuraba para sí misma."
    C "Entonces caería en la categoría dos…"
    pov "…"
    pov "¿Cindy?"
    show cindy2 neutral
    C "¿Si?"
    pov "¿Puedo preguntarte algo, sin que te enojes?"
    C "..."
    C "¿De acuerdo?"
    pov "Tu… ¿cómo sabes tanto término policial?"
    show cindy2 incomoda
    C "…"
    "Cindy se quedó congelada, mirándote con sorpresa."
    C "… Yo…"
    "Entonces, ella suspiró pesadamente."
    C "Yo… nunca quise ser una clerk en la tienda de mi padre."
    pov "Si, nadie quiere serlo."
    show cindy2 angry
    "Cindy te dedicó una mirada reprochadora ante tu comentario sarcástico, pero continuó."
    show cindy2 neutral
    C "… Estudié criminología por 4 años, y luego entré a la academia de policía."
    pov "…"
    "Vaya, eso no te lo esperabas."
    "Cindy… no daba la imagen de querer ser algo en la vida, mucho menos policía."
    C "Desde que tengo memoria, quise ser detective, y me esforcé mucho para graduarme con honores."
    show cindy2 angry
    C "Pero cuando entré a la academia, la tienda de mi papá fue robada."
    C "Atraparon a los culpables, pero como uno de ellos era el sobrino de un teniente, los dejaron libres."
    C "El sistema se jacta de ser una red justa, pero tiene demasiados agujeros."
    C "Abandoné la academia y trabajo para papá desde entonces."
    pov "…"
    pov "Vaya, quién lo diría."
    "Cindy farfulló entre dientes."
    C "No seas condescendiente conmigo."
    pov "¡No, no!, para nada. Me llama la atención, eso es todo."
    pov "Eso explica porque fuiste tan… hosca con el teniente Wes y la detective Sean."
    "Cindy resopló, desviando la mirada."
    C "… ¿Tú crees que ellos están haciendo un buen trabajo?"
    pov "Bueno, no sé en qué estarán ahora, pero tengo el presentimiento de que están esforzándose."
    show cindy2 neutral
    "Cindy bajó la mirada, desganada."
    C "Espero que el sistema no te falle como me falló a mí, [povname]."
    pov "…"
    pov "Creo que eso es lo segundo más lindo que me has dicho."
    "Cindy alza una ceja."
    C "¿Qué fue lo primero?"
    pov "Que sientes paz conmigo."
    C "…"
    C "Si, bueno, sigo pensando eso."
    "Ustedes se quedan un momento en silencio, hasta que tu lo rompes."
    pov "Me alegra que nos estemos llevando bien, Cin."
    C "…"
    show cindy2 smile blush
    "Ella sonríe levemente."
    C "Yo también."
    show cindy2 neutral none
    C "Bueno, ya es hora de irme."
    pov "¿Tan pronto?"
    C "Sólo vine a ver cómo estabas. Por lo que veo, estás bien."
    pov "Pero…"
    "Cindy se gira hacia ti, interrogante."
    C "¿Sucede algo?"
    pov "…"
    "No, no podías decirle sobre el juego de Jeff."
    pov "No, nada, regresa segura."
    "Cindy te miró un par de segundos en silencio, para después marcharse."
    hide cindy2 with dissolve
    "Viendo que estabas por tu cuenta, suspiras pesadamente."
    scene sky1 with dissolve
    "Pasas el resto del día en tu departamento. Sentías que iba a ser una noche tranquila."
    show sky2 with dissolve
    "Pero cuando llegó la noche, cambiaste de parecer."
    "Jeff dijo que cada vez que lo evadieras, él se alejaría. Así que técnicamente, deberías estar a salvo esta noche." 
    "Pero por otro lado, era Jeff de quien se estaba hablando."
    "El tipo es un demente cobarde tramposo, no puedes confiar en las palabras de él."
    "Así que decides salir."
    "¿A dónde?, No importa, sólo te vas a donde haya una gran multitud de gente, donde sea imposible atacarte."
    stop music fadeout 3.0
    scene barstreet with dissolve
    play music "audio/music/sexy-lounge-music-131701.mp3" fadein 3.0
    "Entonces llegas a una calle llena de bares."
    "Las luces pintan de colores las calles y la música se escapa suavemente de los lugares."
    "Te encoges de hombros y escoges un bar para entrar."
    scene bar with dissolve
    "El lugar es tranquilo y una cantidad considerable de gente, perfecto."
    "No querías ir a un lugar medio vacío, era como ser un ciervo e ir a la pradera."
    "Pero tampoco a un lugar concurrido, es lo que menos necesitas en tu estado paranóico."
    "Así que te sientas en la barra y te preparas para pedir."

    menu:
        "Vino":
            jump character_7
        "Cerveza":
            jump character_7

    label character_7:

    "Te sientas a esperar pacientemente por tu pedido."
    play sound "audio/sfx/cloth.mp3"
    "Y es entonces que sientes que alguien toma el lugar junto a ti."
    window hide
    show cg20 with dissolve
    pause 2.0
    window show
    pov "…"
    pov "¿En serio?"
    J "¿Qué?"
    J "Puedo ir a donde quiera, este es un lugar público."
    pov "¿Y no crees que con sólo gritar puedo hacer que te arresten?"
    "Jeff te mira por encima del hombro, con desinterés ante tu amenaza."
    J "Claro, puedes hacer eso, y en lo que se tarda en venir un policía, puedo arrancarte el otro ojo y huir de nuevo."
    pov "…"
    pov "Eres un cobarde."
    J "Heh."
    J "Soy muchas cosas."
    "El bartender se acerca y Jeff le hace una seña para hacer un pedido."
    J "Un whisky, seco."
    pov "¿Oh?, ¿A la vieja escuela?, ¿O sólo te estás luciendo?"
    J "¿Ante quién me voy a lucir?, ¿Tú?"

    menu:
        "Provocar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Parece que te esfuerzas mucho en llamar mi atención."
            J "Yo no…"
            J "Cállate…"
            jump ruta_normal_21
        "Desafiar":
            pov "No fuiste tan sutil al dejarme vivir."
            "Escuchas como él chasquea la lengua con molestia bajo la bandana."
            jump ruta_normal_21
    
    label ruta_normal_21:

    pov "Soy la primera persona que dejas con vida."
    pov "Creo que eso me hace al menos relevante para ti."
    "Tus palabras parecen llamar la atención de él."
    J "No te creas tan especial, no eres la primera."
    pov "…"
    pov "¿Oh?"
    "El bartender llega con tu pedido y el de él."
    play sound "audio/sfx/649345__isaacburkevideo__glass-clink.mp3"
    show cg21 with dissolve
    hide cg20
    "Jeff envuelve con sus dedos el vaso de vidrio, y baja un poco la bandana de su boca. Puedes ver un poco de su perfil."
    "Es raro verlo… tan tranquilo."
    J "Fue un error de principiante… La chica era linda conmigo, y sufrió lo mismo que yo, así que me compadecí."
    "Jeff bebió un sorbo, para después dar vueltas el vaso, revolviendo la bebida en su interior."
    J "No sé si sigue viva, pero la última vez que la vi quería matarme, así que ya no me importa."
    pov "Wow, tú siendo compasivo, eso es nuevo."
    pov "¿Y qué fue lo que ustedes sufrieron, sí se puede saber?"
    "Él señaló con la punta de su índice su propio rostro."
    J "Las quemaduras."
    pov "Ah."
    pov "¿Puedo… preguntar cómo pasó?"
    J "…"
    J "En un accidente… me vertí ácido encima."
    pov "…"

    menu: 
        "Tener empatía":
            pov "Yo… lamento que te pasó eso."
            J "… Seh. "
            "Jeff bebió otro sorbo de su whisky."
            jump ruta_normal_22
        "Burlarte":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Con accidentalmente… ¿Te refieres a que lo derramaste o te lo echaste?"
            J "…"
            J "¿Un poco las dos?"
            pov "Wow, simplemente… Wow."
            "Jeff resopla. Aparenta molestarse, pero percibes la diversión en su voz."
            J "Oh, cállate, no eres quien juzgarme."
            pov "¿Eso qué quiere decir?"
            J "Averígualo tú."
            "Jeff bebió otro sorbo de su whisky."
            jump ruta_normal_22

    label ruta_normal_22:

    pov "De todas formas, ¿A qué viniste aquí?"
    pov "Pensé que querías mantener… “esto” entre nosotros, sin público."
    J "Relájate, no te haré nada. Cumpliré con mi promesa."
    pov "…"
    pov "“Por ahora”, ¿No?"
    J "…"
    play sound "audio/sfx/649345__isaacburkevideo__glass-clink.mp3"
    "Pones los ojos en blanco y bebes tu propia bebida."
    "Ustedes se mantienen en silencio por un rato, escuchando la música del bar y el ruido de las demás personas conversando entre sí."

    menu:
        "Comentar de tu día":
            pov "Así que… hoy fui de compras."
            J "…"
            pov "Me encontré con mi doctor. No fue tan impactante como encontrarte a ti, pero fue… algo."
            "Jeff resopla, con el borde del vaso contra sus labios."
            J "Llevar tus comestibles por ti, clásico."
            J "No tienes que fingir que te agrada frente a él, ¿Sabes?"
            pov "Yo no- espera, ¿Cómo sabes eso?"
            "Jeff ladeó la cabeza burlonamente."
            jump ruta_normal_23
        "Preguntar sobre el día de él":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Qué hiciste hoy?"
            "Jeff se gira a ti con sorpresa."
            J "Yo… no hice mucho."
            "Él regresó su mirada al frente."
            J "Fui de compras…"
            J "Recorrí las calles…"
            J "Descansé un poco…"
            J "Y vine a este bar."
            "Mientras escuchas atentamente, miras que la comisura de Jeff se alarga en una sonrisa burlona, a la vez que te das cuenta."
            jump ruta_normal_23

    label ruta_normal_23:

    pov "¡Si eras tú el me estaba siguiendo!"
    show cg22 with dissolve
    J "¡Hahaha!"
    "Lo miras con enojo, pero lejos de estar molesto, a Jeff parecía agradarle causar esa reacción en ti."
    "Tomas un sorbo de tu bebida, y él hace lo mismo."
    "Cada vez que él termina de beber, se sube la bandana de nuevo, cubriendo su rostro."
    "Tienen una pausa, un momento para tranquilizar la emoción anterior."
    pov "¿De… verdad no me harás nada esta noche?"
    hide cg22 with dissolve
    "Jeff apoya su mejilla en su mano con aburrimiento."
    J "¿Por qué, ahora me tienes miedo?"
    pov "No es por eso… Apreciaría no ir de nuevo al hospital tan pronto después de haber salido."
    "Jeff chasquea la lengua."
    J "No te preocupes, mejor disfruta que no te estoy destripando donde estás."
    pov "Ok, eso no es tranquilizador."
    "Jeff suspira, girándose hacia ti."
    "Sus ojos, azules como el cielo, lechosos como un día nublado, te miran fijamente."
    J "Prometo que no haré nada."

    menu:
        "Coquetear":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿No podrías ser así de lindo la mayoría del tiempo?"
            pov "Es una pérdida de tiempo que actúes como un loco todo el tiempo."
            "Crees que Jeff hizo el ademán de alzar una ceja, porque… él no tiene cejas, duh."
            J "¿Y que sea un asesino?"
            pov "Sí, eso también."
            J "Huh."
            "Jeff regresa a su lugar en silencio, como si no se esperara tu respuesta."
            "No lo puedes ver con claridad, pero jurarías que debajo de sus párpados negros, puedes ver un tono de rosa distinto al de las llagas de su piel."
            jump ruta_normal_24
        "Sospechar":
            "Entrecierras los ojos con sospecha, y bebes un sorbo de tu bebida."
            pov "Eso veremos."
            "Jeff pone los ojos en blanco."
            jump ruta_normal_24

    label ruta_normal_24:

    "Ustedes guardan silencio nuevamente, esta vez se sienten más tranquilos, como si se hubieran sacudido la incomodidad anterior."
    pov "¿Por qué haces esto, de todos modos?"
    "Jeff te mira interrogativamente."
    pov "No sé… lo que piensas. No sé si me odias o te agrado, no sé si me quieres matar u observar."
    J "…"
    J "Yo tampoco lo sé con claridad."
    J "Pierdo el control cuando se trata de ti."
    "Jeff suelta una carcajada seca."
    show cg22 with dissolve
    J "Siempre fui bueno improvisando, pero desde que te conocí, no sé qué mierda estoy haciendo."

    menu:
        "Indagar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Siempre fuiste bueno en esto de… matar personas."
            pov "¿Qué es diferente ahora?"
            jump ruta_normal_25
        "Comprender":
            pov "Supongo que es cómo encontrar un obstáculo nuevo."
            "Jeff niega levemente con la cabeza." 
            jump ruta_normal_25

    label ruta_normal_25:

    hide cg22 with dissolve
    J "Tú… eres un enigma. Creí entender a toda la humanidad, por eso la odiaba, pero contigo… es como si quisiera averiguar más."
    J "Me llamas la atención, en eso estoy seguro."
    play sound "audio/sfx/cloth.mp3"
    "Él lentamente dirigió su mano hacia ti."
    "No te mueves, no sabes si es por temor a que haga algo, o si quieres que te alcance."
    "Los dedos de Jeff rodean tu cuello, y aprietan suavemente. No llega a ahorcarte, pero su agarre es firme."
    J "Aún estoy pensando qué hacer contigo una vez me aburra de nuestro juego."
    "Él te acerca a él, su respiración rozando con tu rostro mientras él habla suavemente."
    J "Ya que me aburro fácilmente."

    menu:
        "Liberarte":
            "Tomas la mano de Jeff entre la tuya, y afortunadamente, él no se resiste a tu toque."
            play sound "audio/sfx/Equip2.ogg"
            "Liberas tu cuello de la mano de él, alejándola de ti mientras te acaricias el cuello."
            pov "Geez, ok, ya entendí."
            J "Más te vale."
            "Él volvió a su lugar, y siguió bebiendo su whisky."
            jump ruta_normal_26
        "Gemir":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Ngh~"
            "Jeff abrió en grande los ojos, soltándote, como si contagiaras."
            "Él te miró con asombro un par de segundos, para después farfullar."
            J "De nuevo caí en eso…"
            "Él gruñó por lo bajo, y siguió bebiendo su whisky."
            jump ruta_normal_26
        
    label ruta_normal_26:

    pov "Hey, así que… ¿Cuál es el plan?"
    J "¿Huh?"
    pov "¿Vamos a charlar como si fuéramos amigos, a pesar de que me arrancaste un ojo y me estás acosando?"
    "Jeff resopla una carcajada, alzando su vaso."
    show cg22 with dissolve
    J "¡Brindo por eso!"

    menu:
        "Brindar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Lo que tú digas."
            play sound "audio/sfx/629997__trexlasso__glass-clink.mp3"
            "Alzas el contenedor de tu bebida y chocas el vaso de él en un pequeño brindis."
            "Él te queda mirando en silencio, pensativo."
            J "… Eres una persona muy rara, [povname]."
            pov "¿Eso te gusta? " 
            "Jeff ríe levemente."
            J "Ya veremos."
            jump ruta_normal_27
        "Regañar":
            pov "Estás loco."
            J "Ese es mi encanto, por si no lo has notado."
            "Pones los ojos en blanco, ignorándolo."
            jump ruta_normal_27

    label ruta_normal_27:

    pov "…"
    pov "Gracias, por dejarme en paz esta noche."
    hide cg22 with dissolve
    J "…"
    J "Tus estándares son muy bajos, ¿No?"
    pov "Hey, dije gracias, no que te volviste mágicamente decente porque hiciste una sola cosa buena por mí."
    "Esto no es un dark romance."
    "…"
    "Quizás."
    "Jeff alzó sus manos en rendición, su postura despreocupada."
    J "Estoy de buen humor, sólo puedo decir eso."
    pov "¿Tiene algo que ver a que rechacé la cita con Paul?"
    J "…"
    J "Piensa lo que quieras."
    "Sonríes levemente, y bebes de tu bebida."
    "Ustedes se quedan en silencio, escuchando la música del bar."
    "El jazz es relajante, y extrañamente, no te sientes mal."
    "Era increíble cómo podías pasar de un momento temiendo que te encontrara en tu escondite, y en otro parece que ustedes están teniendo una…"
    "¿Oh?"
    "¿Era tu idea o esto parecía una cita?"
    "Saliendo con el tipo que te arrancó el ojo y amenaza con matarte, ¿Tal vez sí es un dark romance después de todo?"

    menu:
        "¿Eres celoso?":
            J "…"
            J "¿A qué viene eso?"
            pov "No pude evitar notar que realmente odias cuando alguien es… amable conmigo."
            pov "¿Eres del tipo celoso, Jeff?"
            J "…"
            J "Estás jugando con fuego, [povname]."
            menu:
                "Burlarte":
                    $ show_affection("J", 2)
                    $afecto += 2
                    pov "¿Por qué?"
                    pov "¿Porque es insensato provocar a un asesino serial que me tiene en la mira?"
                    "Tal vez no estabas tan bien mentalmente por meterte con alguien tan peligroso, pero definitivamente tienes sentido común como para reconocer lo jodida que es la situación."
                    J "Ha, veo que entiendes a lo que me refiero."
                    jump ruta_normal_28
                "Coquetear":
                    pov "Quizás quiera quemarme."
                    J "…" 
                    J "No lo recomiendo."
                    J "Una vez que el fuego te alcanza, no hay vuelta atrás."
                    "Para tu sorpresa, su tono de voz se marchita."
                    jump ruta_normal_28
        "¿De donde sacas el dinero?":
            pov "Para pagar lo que estás bebiendo, digo."
            J "…"
            J "Normalmente mataría al bartender."
            "Sientes una sonrisa burlona en su voz."
            J "Pero prometí que me comportaría, así que tendrás que invitarme."
            menu:
                "Aceptar":
                    pov "…"
                    "Supsiras en rendición."
                    pov "De acuerdo, sólo porque no quiero que me asocien contigo si te arrancas."
                    "Jeff resopló una risa corta y ligera, victorioso."
                    jump ruta_normal_28
                "Quejarte":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "¿Qué-?, ¡Nah-ah!"
                    J "Si-ih."
                    "Él tocó la punta de tu nariz con su dedo, juguetonamente."
                    J "Si no lo haces, me iré corriendo y tendrás que pagar igual."
                    J "¿No sería mejor evitar el mal rato y que te miren mal por juntarte con alguien que no paga la cuenta?"
                    pov "…"
                    pov "Te odio."
                    J "Heh."
                    "Lejos de sentirse molesto, Jeff se ríe entre dientes."
                    jump ruta_normal_28
        "¿Qué te pasó en la boca?":
            J "…"
            J "Muy personal, ¿No crees?"
            pov "Me fuiste a matar a mi casa, creo que tengo derecho a saber un poco más de ti."
            J "…"
            J "No te atrevas a juzgarme."
            pov "Lo intentaré."
            "Jeff gruñó por lo bajo."
            J "… Me la corté yo."
            pov "¿En serio?"
            pov "¿Por qué?"
            "Jeff deja salir un quejido frustrado."
            J "Era un angsty teen, era otra época, estaba pasando por algo…"
            menu:
                "Juzgarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Increíble, ¿A quién tratabas de emular?"
                    "Él te enfrenta, con molestia."
                    "No se veía enojado, por lo que estabas a salvo por ahora."
                    J "¡A nadie!"
                    J "Este es mi estilo original."
                    J "Y no me arrepiento."
                    J "Me gusta cómo soy."
                    "Asientes en silencio, con una falsa expresión de comprensión."
                    jump ruta_normal_28
                "Calmarlo":
                    pov "Hey, está bien."
                    pov "Yo también pasé por fases en la adolescencia."
                    pov "Es normal."
                    J "…"
                    "Jeff se rasca la cabeza."
                    jump ruta_normal_28

    label ruta_normal_28:

    J "No te acomodes tanto, mañana volveré a buscarte."
    pov "Oh, si, cierto."
    pov "Me estás acosando."
    pov "Por un momento lo olvidé. Pasar el tiempo contigo como alguien normal no es tan malo."
    pov "Podría llamarlo una cita, incluso."
    "Estás hablando por hablar, pero puedes presenciar que tus palabras crearon una reacción en Jeff."
    J "…"
    J "¿Crees que alguien como yo puede experimentar cosas normales?"
    J "¿Cómo una cita?"

    menu:
        "Sí":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Si, claro."
            jump ruta_normal_29
        "No":
            pov "Nah, para nada."
            jump ruta_normal_29

    label ruta_normal_29:
    play sound "audio/sfx/649345__isaacburkevideo__glass-clink.mp3"
    scene bar with dissolve
    play sound "audio/sfx/cloth.mp3"
    show jeff2 neutral bandana at center
    with dissolve
    
    "Él se queda un segundo en silencio, para después depositar el vaso vacío sobre la barra y levantarse de su asiento."
    "Seguiste el movimiento de él, girándote desde el taburete."
    J "Buenas noches, [povname], suerte para mañana."
    play sound "audio/sfx/cloth.mp3"
    "Jeff hace el ademán de acercarse, alzando su mano hacia ti."
    "Ves que no saca el cuchillo, por lo que te inclinas a él."

    menu:
        "Tomar su mano":
            "Estrechas tu mano con la de él, en un apretón suave y cordial."
            "Ojalá lo hubieras conocido en este contexto mundano."
            pov "Me esforzaré."
            "Jeff asiente silenciosamente y se retira."
            jump ruta_normal_30
        "Besar su mejilla":
            $ show_affection("J", 1)
            $afecto += 1
            play sound "audio/sfx/Equip2.ogg"
            "Sujetas la mano de él con la tuya, pero lo atraes hacia ti y apoyas tu mejilla contra el costado de su rostro cubierto por la bandana."
            pov "Nos vemos luego, Jeff."
            "Susurras suavemente, cerca del oído de él."
            "Él no responde, de hecho sientes un espasmo en la mano de él."
            "Jeff se retira lentamente, ocultando sus ojos tras el fleco y la capucha."
            jump ruta_normal_30

    label ruta_normal_30:

    hide jeff2 with dissolve
    "Observas cómo él desaparece por la puerta del bar, y entonces te das cuenta que hay algo en tu mano."
    play sound "audio/sfx/186114__carlosramon__16-paper-arrugat.wav" volume 0.5
    "Es un papel arrugado, y cuando lo estiras ves que es un billete."
    show money at truecenter
    with dissolve
    "Manchado con sangre."
    "Así que sí tenía para pagar después de todo."
    hide money 
    with dissolve
    "De todas maneras, no podías usar ese billete, te verán con sospecha."
    "Decides quedarte un rato más, reflexionando sobre todo lo que acaba de pasar."
    "Ahora, sabes con seguridad que esta noche no va a pasar nada."
    "Pero debes tener cuidado, mañana se retoma el juego."
    stop music fadeout 5.0
    scene black with fade
    pause 1.0

    #dia 5

    window hide
    show Day5 with fade

    pause 2.0

    scene room with fade
    window show

    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"

    "Despiertas como siempre en la seguridad de tu habitación, con la diferencia de que no dejas de pensar lo que pasó la noche anterior."
    "Aún conservas el billete manchado con sangre que te dió Jeff."
    "Seguramente te lo dió sabiendo que no podías gastarlo, lo hizo a propósito."
    "Era… extraño."
    "Por experiencia propia, sabes que él se comporta erráticamente." 
    "Claro, de alguna forma te la has ingeniado para interactuar con él en momentos peligrosos donde tu vida está en juego."
    "Pero eso no quita que haya sido increíble que Jeff, tan impredecible como es, haya establecido cierta relación contigo."
    "Podías admitir que había momentos donde su compañía, cuando él no trataba de enterrar un cuchillo en tus entrañas, no era tan desagradable."
    "Era como si Jeff tuviera dos lados: Uno es el asesino desquiciado, y el otro es un tipo arrogante que no salía de su fase edgy."
    "Oh no."
    "¿Esto se trataba del síndrome de Estocolmo?"
    "Otra casilla del bingo de novela visual."
    scene living with dissolve
    "De todas formas, hoy tenías que estar más en guardia."
    "Jeff volvería, y él ya conoce el terreno de tu departamento, por lo que estabas en desventaja."
    "Tal vez tengas más chance si te vas a un hotel por esta noche."
    "Lo más probable es que te siga la pista, pero las oportunidades de que te ataque caerían enormemente."
    "Sonaba como una estrategia. Cambiar frecuentemente tu ubicación."
    stop music fadeout 3.0
    play sound "audio/sfx/275570__kwahmah_02__doorbell-d.mp3"
    "De repente, tu timbre suena en medio de tu reflexión."
    "…"
    "No puede tratarse de Jeff, ¿Cierto?"
    "Él no es de la clase que toca timbres."
    "¿Qué tan gracioso sería que fuera él?"
    play sound "audio/sfx/275570__kwahmah_02__doorbell-d.mp3"
    "…"
    menu:
        "Abrir":
            "Te diriges a la puerta aún con tu ropa para dormir y te asomas por la mirilla en silencio."
            "Reconoces de inmediato el cabello castaño del Dr. Salazar."
            jump lol
        "No abrir":
            "Si, no."
            "Es mejor no arriesgarte."
            DR "… ¿[povname]?"
            "Te sobresaltas al escuchar la voz apagada del Dr. Salazar del otro lado."
            "Bueno, sustos que dan gusto dice el dicho."
            jump lol

    label lol:

    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    "Desbloqueas las cerraduras de la puerta y la abres, dejándolo pasar."
    show salazar2 incomodo at center
    with dissolve
    pov "¿Qué haces aquí?"
    "Salazar juega con sus manos nerviosamente."
    DR "Lo siento… No pude evitar preocuparme."
    pov "¿Huh?"
    DR "Unos detectives me contactaron, preguntaron por tu ojo."
    pov "¿... Ok?"
    DR "[povname]... No lo tengo."
    pov "¿Disculpa?"
    DR "Según el informe, cuando te trasladaron al hospital, recuperaron tu ojo."
    pov "¿Para qué recogerían un ojo inservible?"
    "Salazar carraspea."
    DR "Es protocolo, tanto policial como médico. Todo lo encontrado en escena debe guardarse."
    pov "De acuerdo, entiendo eso, ¿Pero qué quieres decir con que no lo tienes?"
    DR "Eso es lo extraño. Tu ojo está registrado en el hospital, pero cuando fui a revisar, no estaba."
    pov "…"
    "Podías adivinar quién lo pudo haber tomado."
    DR "Creo que tu atacante está obsesionado contigo, ¿Has sentido que te siguen últimamente?"
    "Oh, el dulce e ingenuo doctor no tiene idea."
    "Te limitas a encogerte de hombros."
    pov "Supongo."
    DR "Yo… Tengo razones para pensar que vendrá por ti."
    "Vaya, este doctor hace mucho más que sólo operarte, aparentemente. Se ofrece para ser tu príncipe de brillante armadura."
    pov "¿Eso quiere decir que estás aquí por mí?"
    DR "Eh.. yo…"
    pov "¿Vienes a cuidarme, Paul?"
    pov "¿No crees que eso es favoritismo para un paciente entre muchos?"
    stop music fadeout 3.0
    show salazar2 sad
    "El labio inferior de Salazar empezó a temblar levemente, sorprendiéndote."
    pov "Wow, cálmate, no es para tanto."
    DR "Tampoco lo entiendo…"
    play music "audio/music/Nostalgic-Romance-Piano-and-Violin by Mircea Iancu.mp3"
    "Tienes la sensación de deja vu, ya que alguien más te había dicho algo igual."
    show salazar2 sad blush
    DR "Eres… Increíble."
    DR "Nunca tuve un paciente como tú. Desde que despertaste y hablamos, me produces taquicardia, sudoración, confusión…"
    "Pareciera que lo estás haciendo sentir enfermo con tanto término médico."
    "Pero entiendes la idea."
    DR "¿Esto es lo que… llamarían amor a primera vista?"
    pov "…"
    "Ok, estabas en una situación algo complicada."
    "No todos los días viene tu doctor a tu departamento y confiesa su amor por ti."
    "Pero ya te han pasado demasiadas cosas inusuales como para sorprenderte."
    pov "Paul, yo-"
    stop music fadeout 3.0
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "Antes de que puedas responder, se escucha un toque en la puerta."
    "¿Cuáles son las posibilidades?"
    C "¡Soy yo!"
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "Te volteas a Salazar con una sonrisa torcida."
    pov "Disculpa, tengo que atender-"
    play sound "audio/sfx/Equip2.ogg"
    DR "[povname]."
    "Repentinamente, él te sujeta la mano con firmeza, lo que te desconcierta."
    "Los ojos comúnmente calmos de él brillaban con desesperación."
    "No sabes qué pensar."
    play sound "audio/sfx/587930__robotortoise__knocking-and-banging-on-my-apartment-door-no-reverb.mp3"
    "Los golpes en la puerta se vuelven más insistentes."
    C "¡Llamaré a la policía si no obtengo respuesta en 1…!"
    play sound "audio/sfx/Equip2.ogg"
    "Te liberas del agarre de Salazar y te apresuras a abrir la puerta."
    pov "¡Ya voy, ya voy!, geez, estoy en algo aquí."
    play music "audio/music/dedpression-339994.mp3"
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    show salazar2 incomodo none at right
    with move
    show cindy2 angry at left
    with dissolve
    "Cindy te mira con seriedad desde el momento que abres la puerta. Ella entra, con un montón de papeles en sus brazos."
    C "Esto es urgente, tenemos- ¿Qué mierda?"
    "Cindy se detiene en medio de la sala, viendo con confusión a Salazar, el cual se mantiene de brazos cruzados apoyado en una pared."
    C "¿Qué hace él aquí?"
    pov "Oh, ehm… vino a verme."
    "Ella alza una ceja hacia ti."
    C "¿Para qué?"
    pov "Estaba preocupado por mí."
    "Salazar desvía la mirada incómodamente."
    C "…"
    C "¿Síndrome de Florence Nightingale?"
    show salazar2 incomodo blush
    "Salazar se ruboriza en su lugar."
    DR "¡Eso es-!"
    pov "¿Qué es eso?"
    show cindy2 neutral
    C "Cuando el cuidador se enamora del paciente."
    pov "Oh, entonces sí."
    DR "¡[povname]!"
    "Salazar protestó con las mejillas aún encendidas."
    "Te encoges de hombros despreocupadamente."
    pov "Tu viniste por tu cuenta."
    DR "Pensé que seríamos nosotros dos."
    scene kitchen with dissolve
    show cindy2 neutral at left
    with dissolve
    show salazar2 neutral at right
    with dissolve
    "Cindy pasa a la cocina y deja el montón de papeles sobre tu mesa, mirando de soslayo a Salazar."
    pov "Ah, si, ¿A qué viniste, Cin?"
    C "Averigüe cosas sobre el rarito de la tienda."
    "Tomas asiento, mirando con curiosidad los papeles."
    "Varían de noticias impresas de sitios web, hojas de peridódico con párrafos destacados, fotos de personas e informes."
    pov "¿De dónde sacaste todo esto?"
    C "Tengo mis medios."
    "Cindy tomó asiento contigo, apuntando las hojas de papel."
    C "Este tipo, Jeff, está involucrado en muchos asesinatos, y también incendios."
    C "Lleva fugitivo al menos 15 años. No tiene un perfil de víctimas en específico, son desde borrachos en la calle hasta familias de los suburbios."
    C" Sigue el mismo modus operandi, apuñala a sus víctimas en lugares vitales y les corta la boca, con un cuchillo de cocina."
    pov "…"
    DR "…"
    C "…"
    C "El peor arma, si me preguntas a mí."
    "Pones los ojos en blanco ante el comentario de ella."
    pov "Continúa, por favor."
    show cindy2 angry
    "Cindy frunce el ceño, esparciendo los papeles para verlos todos juntos."
    C "Lo extraño es que nunca lo han atrapado."
    C "El tipo es muy descuidado. Usa ropa blanca, fácil de manchar, lleva el pelo largo, sin importarle dejar ADN, no lleva guantes, deja sus huellas por todas partes."
    C "Lo buscan en varias regiones, y aún así nunca lo han arrestado."
    C "No tiene dirección ni familia, ni siquiera se sabe con exactitud su pasado ni quién era antes."
    C "Lo que me llama la atención… Es que para ser un simple tipo, su nivel de conveniencia supera lo normal."
    C "Logra escapar del fuego, evita las cámaras de seguridad, incluso sabe trepar muros. Es cómo… Si tuviera el guión de su lado."
    pov "Haha, ¿Guión?, ¿De qué hablas?"
    C "No lo digo literalmente. Es como si el universo estuviera de su lado."
    "Uf, eso estuvo cerca. No necesitamos otro personaje con autoconciencia narrativa."
    "Pero ahora que Cindy lo menciona, es verdad."
    "Se supone que dieron su descripción física por las noticias, y aún así, se las arregla para seguirte durante el día, o para ir a un bar por la noche."
    "Es como… Si fuera invisible para los demás."
    "No, no hay plot twist de que en realidad él es parte de tu imaginación, o que es un fantasma."
    "Jeff es solamente muy escurridizo."
    show salazar2 incomodo
    DR "Con mayor razón tienes que tener cuidado, [povname]."
    DR "Volverá por ti."
    "Ya lo hizo y lo volverá hacer, pero no puedes decir eso en voz alta."
    C "¿De qué hablas?"
    DR "Creo que está obsesionado con [povname]."
    "Cindy te mira con seriedad."
    C "Si ese es el caso, no puedes quedarte aquí, al menos no por tu cuenta."
    pov "¿Entonces cuál es la idea, piensan quedarse conmigo 24/7?"
    show cindy2 neutral
    show salazar2 neutral
    C "…"
    DR "…"
    pov "Oh no, lo es."
    C "No es la solución más elegante, pero me aseguraré de que estés bien."
    DR "Yo puedo protegerte."
    "De repente, Cindy y Salazar se miran en silencio."
    show cindy2 angry
    C "Yo me quedaré con [povname]. Soy su compañera de trabajo, nos conocemos desde hace más tiempo."
    DR "Soy su doctor, tengo el deber de velar por su bienestar."
    C "Lo que estás haciendo, y me refiero venir a su casa, no es para nada profesional para un doctor."
    C "Podría decir que estás acosando a [povname]. ¿Cómo supiste donde vivía?, ¿Lo viste en su expediente?"
    show salazar2 incomodo
    DR "¡Nos encontramos ayer!, fue pura casualidad- hasta me atrevería decir que fue el destino."
    "Cindy resopla una risa irónica."
    C "¿Vas a hablar de destino?, ¿En serio?"
    stop music fadeout 3.0
    pov "Chicos, ¿Podemos relajarnos un momento?"
    "Los dos se callan y te miran."
    "Los miras con aburrimiento."
    pov "¿Me dejan ir a bañarme?, Todavía estoy en mi ropa para dormir."
    show cindy2 shy blush
    show salazar2 shy blush
    "Repentinamente, ambos desvían la mirada, con las mejillas encendidas."
    C "Ah, claro, claro…"
    DR "Lo siento, adelante…"
    "Te retiras de la cocina y vas al baño."
    scene bathroom with dissolve
    "No esperabas recibir tanta visita, tampoco que vinieran a tu rescate."
    "Parecía casi como si te hubieras echado perfume de feromonas o algo así, ya que atraes a tanta gente."
    play music "audio/music/lofi-song-jinsei-by-lofium-236730.mp3"
    window hide
    scene sky1 with dissolve
    pause 1.0
    window show
    "Al final, ellos decidieron quedarse contigo durante el día."
    "El plan de ir a un hotel se había ido por la borda, ya que se podría decir que te atraparon dentro de tu departamento."
    "Si mostrabas interés en salir, Cindy y Salazar saltaban de sus lugares y te seguían como patitos bebés hacia su mamá pato."
    "Así que no podías costear ir a un hotel con dos personas más, además de que no querías estar en deuda con ellos si se ofrecían a pagar."
    "Se estaba tornando cansador la vigilancia sobre ti."
    scene sky2 with dissolve
    "Hasta que llegó la noche."
    "Con cada minuto, los nervios subían por tu cuerpo, ya que mientras más se oscurecía, más grande era la probabilidad de que Jeff llegara."
    scene living2 with dissolve
    show salazar2 neutral at right
    with dissolve
    show cindy2 neutral at left
    with dissolve
    DR "Se está volviendo tarde, Cindy, deberías volver a tu casa pronto."
    show cindy2 angry
    C "¿Yo?, ¿Qué me dices de ti?, ¿No tienes un trabajo que hacer en el hospital?"
    DR "Mi turno empieza mañana."
    C "Sí, bueno, conozco mejor a [povname]. Si alguien debería quedarse en la noche, debería ser yo."
    DR "¿Qué es más seguro que un doctor?"
    "Cindy y Salazar se fulminan con la mirada, mientras tú aguantas."
    pov "No quiero tener a los dos aquí esta noche, fue suficiente tenerlos todo el día."
    C "Entonces tu decide."
    pov "¿Qué?"
    DR "O nos quedamos ambos, o uno. Pero no ninguno."
    "Para acorralarte, saben trabajar en equipo, ¿no?"

    menu: 
        "Cindy":
            $ ruta = "C"
            jump cindy
        "Salazar":
            $ ruta = "S"
            jump salazar

    #ruta salazar

    label salazar:

    pov "Elijo al doctor."
    show salazar2 smile
    "Salazar sonríe, triunfante."
    C "¿En serio?"
    "Te encoges de hombros."
    "¿La oportunidad de pasar la noche con un doctor guapo?, No querías desperdiciarlo."
    DR "No te preocupes, cuidaré bien de [povname]."
    C "Más te vale."
    scene living2 with dissolve
    show cindy2 neutral at center
    with dissolve
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    "Cindy toma sus cosas y se dirige a la puerta, tu la sigues para abrirle y despedirla."
    pov "Gracias por venir, en serio."
    pov "Creo… Que me hacía falta sentir que me cuidan."
    show cindy2 smile
    "Cindy te mira de reojo, y sonríe levemente."
    C "Sí, cuando quieras."
    play sound "audio/sfx/cloth.mp3"
    "Ella rodea tu hombro con el brazo y te da un beso en la mejilla como despedida."
    "Cindy desaparece tras la puerta, y te quedas con Salazar."
    scene kitchen2 with dissolve
    show salazar2 smile at center
    with dissolve
    pov "¿Quieres cenar?"
    DR "Oh, puedo cocinar algo."
    pov "No señor, ya haces demasiado con quedarte aquí, déjame servirte."
    DR "Te ayudaré entonces."
    "Te ríes levemente ante la insistencia de él."
    "Es indiscutiblemente adorable."
    "Ustedes empiezan a moverse dentro de la cocina."

    menu:
        "Charlar":
            show salazar2 neutral
            pov "Así que, ¿Eres oculista o algo así?"
            DR "Soy cirujano."
            pov "¿Hace cuánto que ejerces?"
            DR "Completé mi residencia hace 4 años. Fue duro, sobre todo porque tengo TDAH."
            DR "Pero con ayuda de profesores pude sobrellevarlo."
            pov "Me alegro. Soy la prueba viviente de que haces un estupendo trabajo."
            jump salazar2
        "Coquetear":
            pov "Entonces, ¿El destino, amor a primera vista?"
            pov "Como hombre de ciencia, no pensé que creerías en esas cosas."
            show salazar2 shy blush
            "Ves como Salazar se sonroja."
            DR "No te burles de mí."
            pov "No, no, es lindo."
            DR "…"
            DR "¿Tu crees?"
            pov "Claro."
            jump salazar2

    label salazar2:

    show salazar2 smile none

    "Salazar sonríe ante tus palabras, observándote mientras sacas los ingredientes para cocinar."
    DR "¿Qué vamos a cenar?"

    if dieta == "V":
        pov "Risotto de champiñones."
        pov "¿Está bien?"
        DR "Por supuesto, no soy quisquilloso."
    else:
        pov "Espagueti con boloñesa."
        DR "Ah, que rico."
        pov "¿Te gusta?"
        DR "Diría que es mi platillo favorito."

    "Ustedes toman asiento en la mesa y comen."
    "La velada es bastante íntima, parece… como si tuvieran una cita."

    menu:
        "Mencionarlo":
            pov "Así que al final pudimos tener nuestra cita."
            show salazar2 neutral
            DR "¿Huh?"
            pov "Qué estrategia. Venir a protegerme para lograrlo."
            show salazar2 shy
            "Salazar carraspea y se limpia la boca."
            DR "Te aseguro que mis intenciones son genuinamente de preocupación."
            DR "…"
            show salazar2 smile
            DR "Que eso haya acabado en una cita fue un bonus."
            pov "¡Hey!"
            "Salazar se ríe ante tu reacción a su respuesta."
            "Parece que se está acostumbrando a ti."
            jump salazar3
        "No mencionarlo":
            pov "¿Se adapta a tu gusto?"
            DR "Sí, definitivamente."
            DR "Cocinas bien."
            pov "No exageres, es algo simple."
            "Salazar te sonríe levemente, murmurando para sí mismo."
            DR "Podría comerlo todos los días…"
            jump salazar3

    label salazar3:

    DR "Así que, dime [povname], ¿A qué te dedicas?"
    pov "Oh, no es la gran cosa, sólo soy dependiente en una tienda de películas."
    DR "Oh, ¿Como un blockbuster?"
    pov "Básicamente, pero es sólo una tienda local, no una cadena."
    pov "El dueño es un amante del séptimo arte, y también el padre de Cin."
    DR "Ah, ya veo."
    DR "¿No hay nepotismo?"
    pov "Para nada. De hecho, creo que a mi jefe le frustra que Cindy no comparta su pasión."
    DR "¿Qué me dices de ti?"
    pov "¿Qué?"
    DR "¿Te apasionan las películas?"
    if cine == "Si":
        pov "Claro, es lo que me hace disfrutar un poco más mi trabajo."
    elif cine == "No":
        pov "La verdad es que no mucho."
        pov "El trabajo me sirve porque está cerca de donde vivo y la paga es buena."
    pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "Todavía tenía los dos ojos."
    show salazar2 incomodo
    "Salazar se remueve incómodo ante tu comentario."
    DR "Me hubiera gustado poder recuperar tu ojo, pero…"
    pov "Lo entiendo, no te preocupes."
    pov "El cuerpo humano es frágil."
    show salazar2 neutral
    DR "Cierto. Es imposible para nosotros crear un órgano o extremidad a gusto, hay que proteger nuestro cuerpo."
    "La seriedad en la voz de Salazar te deja en silencio. Claro, siendo doctor, es parte de su trabajo velar por la seguridad del cuerpo humano."
    "Pero podías ver preocupación verdadera por la vida."
    show salazar2 smile
    "Viendo los platos vacíos, haces el ademán de levantarte, pero Salazar te detiene con un gesto de su mano."
    DR "Yo lavaré los platos."
    "Alzas las manos en derrota."
    pov "Lo que digas."
    play sound "audio/sfx/740313__fossarts__bathroom-faucet-turned-on-1.mp3"
    "Observas cómo él se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "Te quedas cerca, admirando la figura de su espalda ancha y sus brazos moviéndose."
    pov "Así que… Sólo tengo una cama."
    play sound "audio/sfx/478579__toklant__drop-mug-on-a-plate-in-a-kitchen.mp3"
    "Los platos se le caen de las manos a Salazar, pero afortunadamente dentro del lavadero."
    show salazar2 shy blush
    DR "N-no te preocupes, puedo dormir en el sofá."
    DR "No podría abusar de tu hospitalidad…"

    menu:
        "Calmarlo":
            pov "Hey, tranquilo."
            pov "No tenemos que hacer nada."
            pov "Pero no me gusta la idea de dejarte solo con un asesino suelto, mejor juntos que separados, ¿No?"
            jump salazar4
        "Restar importancia":
            pov "No te preocupes, no va a pasar nada."
            pov "Mi cama es lo suficientemente grande."
            pov "Me sentiré mal si te dejo durmiendo en mi duro sofá."
            jump salazar4

    label salazar4:

    show salazar2 incomodo

    DR "…"
    DR "De acuerdo."
    "Asientes levemente, retirándote de la cocina."
    pov "Iré a prepararme para dormir."
    scene bathroom2 with dissolve
    "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "Por un momento te detienes frente al espejo."
    "Tienes un poco de nervios por pasar la noche con Salazar, pero había algo más…"
    "Si Jeff venía…"
    "No, no debías pensar así."
    "Él era un cobarde, sólo te atacaba cuando estabas a solas."
    "Si, eso era seguro."
    "Técnicamente, tener a alguien contigo era evitarlo."
    "Él mismo lo había dicho, este juego era entre ustedes dos. Así que Jeff no debería involucrar a Salazar."
    scene kitchen2 with dissolve
    show salazar2 shy blush at center
    with dissolve
    "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Salazar."
    pov "El baño está libre, por si quieres usarlo. Es la puerta al fondo del pasillo, a la izquierda."
    DR "Oh, gracias."
    pov "Mi habitación es la puerta de enfrente."
    DR "…"
    DR "S-sí…"
    "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    stop music fadeout 5.0
    scene room2 with dissolve
    play sound "audio/sfx/Equip2.ogg"
    "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Salazar."
    "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "Unos instantes después, Salazar avanzaba hacia ti, lentamente, como si temiera sobresaltarte."
    pov "Adelante, no muerdo."
    window hide
    play sound "audio/sfx/Equip2.ogg"
    show cg23 with dissolve
    play music "audio/music/Nostalgic-Romance-Piano-and-Violin by Mircea Iancu.mp3"
    pause 2.0
    window show
    "Con la escasa luz, alcanzas a ver que él sonreía levemente ante tu broma, pero se mantuvo en silencio mientras se acomodaba bajo las sábanas junto a ti."
    "Él fue cuidadoso, pero no pudo evitar rozar su pierna con la tuya."
    DR "Lo siento, yo no-"
    pov "Está bien."
    pov "No soy tan frágil, ¿Sabes?"
    "Él te mira, sus ojos brillando con la escasa luz."
    DR "Temo que por pensar así, no vas a tener cuidado."
    "Bueno, no estaba del todo equivocado."
    "Al final, todo se remonta a lo que sucedió con Jeff."
    "Tal vez si no te hubiera atacado, nunca hubieras conocido a Salazar."
    pov "¿Por qué yo?"
    pov "¿Qué tengo de especial?"
    play sound "audio/sfx/cloth.mp3"
    "Inesperadamente, sientes que la mano de él roza tu mejilla, y acaricia con su pulgar delicadamente."
    DR "No lo sé, porque eres tú."
    "Él se ríe levemente."
    DR "Es extraño, siento que conozco tu rostro, pero no puedo describirlo con palabras."
    DR "Pero aún así, me gustas."
    play sound "audio/sfx/heart beat.mp3"
    "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    pov "B-buenas noches."
    DR "Descansa, [povname]."
    scene black with fade
    hide cg23
    "Cierras tu ojo, concentrándote en tu respiración y la de él para dormir."
    "Pronto, lo logras."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Salazar, te das cuenta de que no está en la cama."
    stop music fadeout 5.0
    scene room2 with fade
    "Te levantas y sigilosamente sales de tu habitación."
    "No escuchas nada, pero eso no te calma."
    scene living2 with dissolve
    "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    window hide
    play music "audio/music/horror-background-atmosphere-2-289424.mp3"
    show cg24 with dissolve
    pause 2.0
    window show
    "Jeff tiene a Salazar sujetado desde el cuello, apuntando la punta del cuchillo contra su garganta."
    "¿En qué momento entró Jeff, Salazar se levantó y se enfrentaron?"
    "Eso debió producir un ruido, pero no tenías idea."
    "Parece que Jeff es muy bueno en lo que hace."
    J "[povname]... Dije que volvería."
    pov "… Si, puedo darme cuenta."
    J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    "Jeff acercó más el cuchillo al cuello de Salazar."

    if miedo == "Si":
        pov "N-no le hagas daño."
        J "¿Oh?"
        J "¿Así que te preocupas por este bastardo?"
        pov "Hey, no le digas así."
        J "Sigues probando mi punto."
    else:
        pov "¿En serio?"
        pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
        pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
        J "…"

    J "Entonces… No te importará si hago esto, ¿O sí?"
    play sound "audio/sfx/blade-scrape.mp3"
    "Jeff hace un corte en la mejilla de Salazar, el cual suelta un quejido ahogado mientras la hoja corta su piel."
    pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "No hay por qué involucrarlo."
    J "…"

    if afecto > 25:
        jump hisotria_continua_salazar
    else:
        jump muerte_salazar

    label muerte_salazar:

    window hide
    play sound "audio/sfx/rush__blade.mp3"
    play sound "audio/sfx/gore2.mp3"
    show cg25
    pause 1.0
    window show
    "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por la garganta de Salazar."
    play sound "audio/sfx/blood dripping.mp3"
    "Él gorgotea y Jeff lo suelta."
    play sound "audio/sfx/falling.mp3"
    scene living2 with dissolve
    "Salazar se lleva las manos al cuello, tratando de parar la hemorragia, pero sus piernas ceden y él cae."
    "Te petrificas en tu lugar, viendo que debajo de Salazar crece un charco oscuro."
    show jeffknife3 neutral at center
    with dissolve
    J "Hah… Eres tan hipócrita."
    "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "Tú aún no puedes desviar tu mirada atónita del cadáver de Salazar en el suelo."
    J "Te advertí que me aburro fácilmente."
    "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    play sound "audio/sfx/gore3.mp3"
    scene black with fade
    pause 1.0
    show Death with fade
    pause 2.0
    "{b}Final V: Lo Decepcionaste{/b}"
    return

    label hisotria_continua_salazar:

    window hide
    play sound "audio/sfx/stab.mp3"
    show cg26 with dissolve
    pause 1.0
    window show
    "Jeff aleja el cuchillo del cuello de Salazar, y en cambio lo entierra en su hombro."
    "Salazar deja salir un alarido que es prontamente callado por la mano de Jeff."
    scene living2 with dissolve
    play sound "audio/sfx/falling.mp3"
    "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo y Salazar cae al suelo, su herida sangrando constantemente."
    DR "[povname]... Corre…"
    show jeffknife3 smile at center
    with dissolve
    J "No te molestes, guapo."
    "Jeff estiró una sonrisa burlona."
    J "Hay nueva jurisdicción."
    play sound "audio/sfx/cloth.mp3"
    "Jeff ignora el cuerpo de Salazar y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    play sound "audio/sfx/Equip2.ogg"
    "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    J "Es curioso… No quiero dañarte, no como antes al menos."
    J "¿Por qué será?"

    menu:
        "Le gustas":
            pov "T-tal vez es porque te gusto."
            show jeffknife3 neutral
            J "…"
            J "¿Cómo dices?"
            pov "Ya sabes, ¿Te intereso?"
            pov "¿Tienes un crush conmigo?"
            jump salazar5
        "Quiere dejarte en paz":
            pov "Quizás quieres dejarme en paz."
            show jeffknife3 neutral
            J "…"
            J "Nah, no es eso. Todo lo contrario."
            pov "Entonces… ¿Tienes una fijación conmigo?"
            J "¿Ah?"
            jump salazar5

    label salazar5:

    show jeffknife3 pensativo 
    J "…"
    "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    show jeffknife3 smile
    J "¡Oh, ya veo!"
    "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    show jeffknife3 happy
    J "¡Te deseo!"
    J "¡A ti!"
    "Jeff suelta una carcajada estridente."
    "No sabes si sonreír u horrorizarte."
    J "¡Eso explica muchas cosas!"
    play sound "audio/sfx/hang.mp3"
    "El agarre en tu mano se hace más fuerte, y él tira de ti."
    pov "Espera, ¿Qué haces?"
    J "Ya descubrí lo que quiero."
    J "No quiero seguir jugando contigo."
    "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    J "Quiero tenerte para mí."
    "Entonces te das cuenta que te está guiando a la salida."
    "En un instante, viste el cuerpo de Salazar aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    pov "¿Qué hay de-?"
    J "No pienses en él."
    play sound "audio/sfx/cloth.mp3"
    show jeffknife3 smile at jumpscare_top
    "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Por el olor, te das cuenta que es sangre."
    "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    J "Sólo céntrate en mí."
    "Has visto de lo que es capaz."
    "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "Eso te hizo considerar sus palabras, profundamente."

    scene black with fade
    pause 1.0

    jump day6

    #ruta cindy

    label cindy:

    pov "Elijo a Cindy."
    show cindy2 smile
    show salazar2 incomodo
    "Ella sonríe satisfecha, y él suspira decepcionado."
    DR "De acuerdo, comprendo."
    "Preferías pasar la noche con alguien a quien conoces mejor, además de que fue a la academia de policía. Eso inspira seguridad."
    scene living2 with dissolve
    show salazar2 neutral at center
    with dissolve
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    "Salazar se dirige a la puerta, tú lo sigues para abrirle y despedirlo."
    pov "Gracias por venir, en serio."
    pov "Creo… Que me hacía falta sentir que me cuidan."
    show salazar2 smile
    "Salazar te mira de reojo, y sonríe levemente."
    DR "Siempre estaré para ti."
    play sound "audio/sfx/cloth.mp3"
    "Él acaricia suavemente la parte superior de tu cabeza."
    "Salazar desaparece tras la puerta, y te quedas con Cindy."
    scene kitchen2 with dissolve
    show cindy2 neutral at center
    with dissolve
    pov "¿Quieres cenar?"
    C "Seguro."
    pov "¿Prefieres cocinar o pedir algo?"
    C "Conozco un buen restaurante chino a domicilio cerca de aquí."
    "Asientes con la cabeza."
    pov "De acuerdo."
    "Ella saca su teléfono, y los adornos colgados en el aparato tintinean con cada movimiento."
    C "¿Alguna alergia, algo que no comas?"
    if dieta == "V":
        pov "La opción vegana para mí, por favor."
    else:
        pov "Nada que reportar."
    "Cindy asiente y hace el pedido."
    scene living2 with dissolve
    show cindy2 neutral at center
    with dissolve
    "Mientras ustedes esperan en el sofá, se mantienen en silencio."

    menu:
        "Charlar":
            pov "Así que, ¿Policía?"
            pov "Honestamente, no me lo esperaba."
            C "Seh, lo sé." 
            C "En lo académico resaltaba, pero tenía desventaja en lo físico."
            C "Aún si las llaves funcionan por la gravedad, se requiere cierta cantidad de fuerza."
            C "Fuerza que no tengo"
            jump cindy2
        "Coquetear":
            pov "Entonces, ¿Hiciste toda una investigación policial sólo por mi?"
            "Cindy te mira de reojo"
            C "¿Cuál es tu punto?"
            pov "Oh, nada."
            pov "Sólo que aparentemente estás dispuesta a varias cosas por mí."
            pov "Como pasar la noche."
            show cindy2 shy blush
            "Cindy desvía la mirada, pero notas cómo sus mejillas se encienden levemente."
            C "No te hagas ilusiones."
            jump cindy2

    label cindy2:

    play sound "audio/sfx/275570__kwahmah_02__doorbell-d.mp3"
    "Ustedes pasan los siguientes minutos esperando por el pedido, y cuando llega, se sirven en la cocina."
    scene kitchen2 with dissolve
    show cindy2 neutral at center
    with dissolve
    "Cindy come lentamente, picoteando la comida."
    "Parece estar pensando en otra cosa."

    menu:
        "Preguntar":
            pov "¿En qué piensas tanto?"
            "Cindy regresa la mirada hacia ti, para después apoyar su mejilla en su mano."
            C "Quizás no sea tan buena idea quedarnos acá."
            pov "¿Por qué lo dices?"
            C "Ese loco puede saber dónde vives hasta este punto."
            C "Quedarnos puede ser demasiado peligroso."
            pov "…"
            jump cindy3
        "No preguntar":
            pov "Tienes razón, es bastante bueno."
            C "…"
            "Tu intento de charlar no funciona."
            "Lo más probable es que siga preocupada por el asunto de Jeff."
            jump cindy3

    label cindy3:

    "Cindy era realmente perspicaz, ¿No?"
    "Parece ser el personaje con más sentido común."
    "Pero ese no es el tema."
    "Jeff es un cobarde, sólo te ha atacado cuando no hay nadie."
    "Además, el juego que tienen es entre ustedes, él no tiene por qué involucrar a Cindy."
    "Así que todo va a estar bien."
    pov "Todo va a estar bien."
    "Lo dices en voz alta no sólo para asegurarte a ti, también a Cindy."
    show cindy2 smile
    "Ella te dedica una leve sonrisa desganada, pero termina por suspirar rendida."
    C "Tu ganas, tengamos algo de charla trivial."
    show cindy2 neutral
    C "¿Cómo te estabas sintiendo con el trabajo?"
    C "Antes de todo esto."
    pov "Yo creo que bien."
    pov "Lo siento, pero tendré que faltar durante un tiempo."
    C "No te culpo, de todas maneras cerramos temporalmente."
    C "No sé en tu caso, pero puedo vivir sin películas."
    if cine == "Si":
        pov "Yo no podría, me encantan."
    else:
        pov "Seh, yo también."
    pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "Todavía tenía los dos ojos."
    show cindy2 incomoda
    "Cindy hace una mueca de incomodidad, tratando de desviar la mirada de tu parche, fallando."
    show cindy2 neutral
    "Viendo los platos vacíos, haces el ademán de levantarte, pero Cindy te detiene con un gesto de su mano."
    C "No te esfuerces, ve a prepararte para dormir."
    "Alzas las manos en derrota."
    pov "Lo que digas."
    play sound "audio/sfx/740313__fossarts__bathroom-faucet-turned-on-1.mp3"
    "Observas cómo ella se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "Te quedas cerca, admirando la figura de su espalda pequeña y sus brazos moviéndose."
    pov "Así que… Sólo tengo una cama."
    show cindy2 neutral blush
    "Cindy se detiene un segundo, dejando el agua correr."
    C "¿...Ok?"

    menu:
        "Ser cool":
            pov "Parece que tendremos pijamada."
            jump cindy4
        "Ser indiferente":
            pov "Si quieres podemos hacer un muro de almohadas."
            jump cindy4

    label cindy4:

    "Cindy asiente con la cabeza y vuelve a lo suyo."
    scene bathroom2 with dissolve
    "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "Por un momento te detienes frente al espejo."
    "Tienes un poco de nervios por pasar la noche con Cindy."
    "Nunca la habías visto con otros ojos, pero ahora no podías evitar pensar que tienes algo de suerte por pasar la noche con una chica linda."
    "Claro, no va a pasar nada."
    "Ella ni siquiera es tu amiga, técnicamente."
    "¿O podría decirse que sí?"
    scene kitchen2 with dissolve
    show cindy2 neutral blush at center
    with dissolve
    "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Cindy."
    pov "El baño está libre, por si quieres usarlo."
    "Ella ya había estado aquí antes, por lo que sabía dónde estaba todo."
    C "De acuerdo."
    "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    stop music fadeout 5.0
    scene room2 with dissolve
    play sound "audio/sfx/Equip2.ogg"
    "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Cindy."
    "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "Unos instantes después, Cindy entra a la habitación."
    "En silencio, ella se adentra bajo las sábanas junto a ti."
    window hide
    play sound "audio/sfx/Equip2.ogg"
    show cg27 with dissolve
    play music "audio/music/Nostalgic-Romance-Piano-and-Violin by Mircea Iancu.mp3"
    pause 2.0
    window show
    "Sientes el aroma de su perfume, es dulce."
    "Alcanzas a ver que los ojos de ella brillan, aún con la escasa luz."
    pov "¿Por qué te preocupas tanto por mí?"
    pov "¿Qué cambió?"
    play sound "audio/sfx/cloth.mp3"
    "Inesperadamente, sientes que la mano de ella roza tu mejilla, y acaricia con su pulgar delicadamente."
    C "Me dí cuenta que eres importante para mí."
    "Ella se ríe levemente."
    C "Es extraño, siento que te conozco, pero no puedo pensar en algún momento que pasé contigo en específico."
    C "Pero aún así, me importas"
    play sound "audio/sfx/heart beat.mp3"
    "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    pov "B-buenas noches."
    C "Descansa bien."
    scene black with fade
    hide cg27
    "Cierras tu ojo, concentrándote en tu respiración y la de ella para dormir."
    "Pronto, lo logras."
    play sound "audio/sfx/429268__mateopkp8__21-rechineo.mp3"
    "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Cindy, te das cuenta de que no está en la cama."
    stop music fadeout 5.0
    scene room2 with fade
    "Te levantas y sigilosamente sales de tu habitación."
    "No escuchas nada, pero eso no te calma."
    "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    window hide
    play music "audio/music/horror-background-atmosphere-2-289424.mp3"
    show cg28 with dissolve
    pause 2.0
    window show
    "Jeff tiene sujetada a Cindy desde el cuello, tapando su boca, y apuntando la punta del cuchillo contra su cintura."
    "¿En qué momento entró Jeff, Cindy se levantó y se enfrentaron?"
    "Eso debió producir un ruido, pero no tenías idea."
    "Parece que Jeff es muy bueno en lo que hace."
    J "[povname]... Dije que volvería."
    pov "… Si, puedo darme cuenta."
    J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    "Jeff acercó más el cuchillo a la piel de Cindy."

    if miedo == "Si":
        pov "N-no le hagas daño."
        J "¿Oh?"
        J "¿Así que te preocupas por esta perra?"
        pov "Hey, no le digas así."
        J "Sigues probando mi punto."
    else:
        pov "¿En serio?"
        pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
        pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
        J "…"

    J "Entonces… No te importará si hago esto, ¿O sí?"
    play sound "audio/sfx/blade-scrape.mp3"
    "Jeff hace un corte en el costado de Cindy, la cual suelta un quejido ahogado contra la mano de él."
    pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "No hay por qué involucrarla."
    J "…"

    if afecto > 25:
        jump historia_continua_cindy
    else:
        jump muerte_cindy

    label muerte_cindy:
    window hide
    play sound "audio/sfx/rush__blade.mp3"
    show cg29 with dissolve
    play sound "audio/sfx/gore1.mp3"
    pause 1.0
    window show
    "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por el estómago de Cindy."
    "La sangre y entrañas se derramaron y Jeff la suelta."
    scene living2 with dissolve
    play sound "audio/sfx/falling.mp3"
    "Cindy se lleva las manos al estómago, tratando de parar la hemorragia, pero sus piernas ceden y ella cae."
    "Te petrificas en tu lugar, viendo que debajo de Cindy crece un charco oscuro."
    show jeffknife3 neutral at center
    with dissolve
    J "Hah… Eres tan hipócrita."
    "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "Tú aún no puedes desviar tu mirada atónita del cadáver de Cindy en el suelo."
    J "Te advertí que me aburro fácilmente."
    "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    play sound "audio/sfx/gore3.mp3"
    scene black with fade
    pause 1.0
    show Death with fade
    pause 2.0
    "{b}Final V: Lo Decepcionaste{/b}"
    return

    label historia_continua_cindy:

    window hide
    play sound "audio/sfx/stab.mp3"
    show cg30 with dissolve
    pause 1.0
    window show
    "Jeff entierra lentamente la punta del cuchillo en el costado de Cindy."
    "Ella deja salir un grito acallado contra la mano de él."
    scene living2 with dissolve
    play sound "audio/sfx/falling.mp3"
    "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo, y Cindy cae al suelo."
    C "[povname]... Vete…"
    show jeffknife3 smile at center
    with dissolve
    J "No te molestes, linda."
    "Jeff estiró una sonrisa burlona."
    J "Hay nueva jurisdicción."
    play sound "audio/sfx/cloth.mp3"
    "Jeff ignora el cuerpo de Cindy y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    play sound "audio/sfx/Equip2.ogg"
    "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    J "Es curioso… No quiero dañarte, no como antes al menos."
    J "¿Por qué será?"

    menu:
        "Le gustas":
            pov "T-tal vez es porque te gusto."
            show jeffknife3 neutral
            J "…"
            J "¿Cómo dices?"
            pov "Ya sabes, ¿Te intereso?"
            pov "¿Tienes un crush conmigo?"
            jump cindy5
        "Quiere dejarte en paz":
            pov "Quizás quieres dejarme en paz."
            show jeffknife3 neutral
            J "…"
            J "Nah, no es eso. Todo lo contrario."
            pov "Entonces… ¿Tienes una fijación conmigo?"
            J "¿Ah?"
            jump cindy5

    label cindy5:

    show jeffknife3 pensativo 
    J "…"
    "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    show jeffknife3 smile
    J "¡Oh, ya veo!"
    "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    show jeffknife3 happy
    J "¡Te deseo!"
    J "¡A tí!"
    "Jeff suelta una carcajada estridente."
    "No sabes si sonreír u horrorizarte."
    J "¡Eso explica muchas cosas!"
    play sound "audio/sfx/hang.mp3"
    "El agarre en tu mano se hace más fuerte, y él tira de ti."
    pov "Espera, ¿Qué haces?"
    J "Ya descubrí lo que quiero."
    J "No quiero seguir jugando contigo."
    "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    J "Quiero tenerte para mí."
    "Entonces te das cuenta que te está guiando a la salida."
    "En un instante, viste el cuerpo de Cindy aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    pov "¿Qué hay de-?"
    J "No pienses en ella."
    play sound "audio/sfx/cloth.mp3"
    show jeffknife3 smile at jumpscare_top
    "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Por el olor, te das cuenta que es sangre."
    "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    J "Sólo céntrate en mí."
    "Has visto de lo que es capaz."
    "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "Eso te hizo considerar sus palabras, profundamente."
    stop music fadeout 5.0
    scene black with fade
    pause 1.0

    jump day6

    #dia 6

    label day6:

    window hide
    show Day6 with fade

    pause 2.0

    scene black with fade
    window show

    play music "audio/music/dedpression-339994.mp3"
    "La sensación bajo tu cuerpo es dura y áspera."
    "El colchón evidentemente es muy viejo y de mala calidad."
    "Aunque hayas despertado, mantienes tu ojo cerrado, reflexionando sobre lo que sucedió para que te llevara a donde estás."
    play sound "audio/sfx/running-on-concrete.mp3" volume 0.5
    scene run1 with fade
    "Jeff tiró de ti, obligándote a correr con él." 
    "El frío de la madrugada entraba a tus pulmones, mientras las luces de los faroles alumbraban su camino."
    "Recorrieron muchas calles, no sabías que tan lejos te estaba llevando."
    play sound "audio/sfx/running-on-concrete.mp3" volume 0.5
    scene run2 with fade
    "A petición tuya, en ocasiones le pedías que se detuviera para descansar. Jeff aceptaba, y mientras tú recuperabas el aliento, él vigilaba los alrededores."
    "A penas te sentías mejor, él tomaba tu muñeca y nuevamente te arrastraba."
    "Finalmente habían llegado a un barrio de mala a muerte, lleno de basura, campamentos y casas en mal estado."
    "La casa de Jeff no fue la excepción."
    scene black with fade
    "Recuerdas que él dijo que era el lugar donde se quedaba por el momento, mientras te invitaba a pasar en una pequeña casa destartalada."
    "Como era de noche y él no quiso encender las luces, en el caso de que tuviera electricidad, no viste bien como era el interior."
    "Pero por el olor a humedad y polvo, además del crujido bajo tus pies, podías asumir que el lugar no estaba en buen estado."
    "Afortunadamente, Jeff ofreció la cama especialmente para ti, diciendo que tenía cosas que hacer."
    J "¿Vas a seguir fingiendo dormir?"
    "Maldices internamente ante la voz de Jeff."
    window hide
    show cg31 with fade
    pause 2.0
    window show
    "Abres tu ojo, y te encuentras con algo que no esperabas que sería lo primero que vieras en el día."
    J "Buenos días, [povname]."
    "Jeff está apoyado en el borde de la cama, a centímetros de ti."
    "Te mira fijamente, recorriendo cada centímetro de tu rostro."
    pov "Buenas…"
    "Era raro estar con Jeff y que no tenga la intención de herirte."
    "Claro, sucedió lo del bar, pero aún estabas en guardia por lo que hizo anoche."
    "También era… curioso verlo sin la sudadera blanca de siempre."
    "Ver los brazos desnudos y la silueta de la cintura de Jeff se sentía como ver los tobillos de una mujer victoriana."
    "Jeff asintió levemente ante tu saludo, manteniendo su sonrisa."
    J "No hay necesidad de tanta cautela."
    J "Ya no quiero matarte."
    "Bueno, eso sonaba tranquilizador."
    "Pero se trataba de Jeff."
    "El tipo era todo menos confiable."

    menu:
        "Ser optimista":
            pov "¿En serio?"
            jump ruta_normal_31
        "Sospechar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "No te creo."
            jump ruta_normal_31

    label ruta_normal_31:

    "Jeff ríe entre dientes, tocando la punta de tu nariz con su índice."
    J "Vayamos a desayunar."
    "…"
    "Él te evitó, ¿Cierto?"
    play sound "audio/sfx/cloth.mp3"
    "Él se levanta y se mantiene de pie junto a la cama, mirándote expectante."
    scene room_j with dissolve
    show jeff3 neutral at center
    with dissolve
    play sound "audio/sfx/Equip2.ogg"
    "Te levantas lentamente, y te ves en una habitación demasiado amplia, pero bastante destartalada."
    "No había muebles además de la cama, pero al menos la ventana no estaba rota."
    "Entonces te das cuenta que sólo estás en ropa para dormir y sin zapatos."
    "¿Realmente corriste por varias calles sin pisar un clavo o un pedazo de vidrio?, que suerte que no te haya dado tétanos."
    pov "No tengo zapatos…"
    show jeff3 pensativo
    "Jeff desvía la mirada pensativo."
    J "Espera un momento."
    hide jeff3 with dissolve
    "Jeff desaparece por la puerta, y escuchas movimiento desde el otro lado de la habitación."
    show jeff3 smile at center
    with dissolve
    "Pronto, Jeff reaparece, con dos pantuflas, de distinto tamaño cada una."
    J "Es lo que encontré a mano, luego buscaremos ropa para ti."
    "Aceptas con resignación las pantuflas."
    "No están rotas ni mugrosas, sólo con algo de polvo."
    "Son de distinta talla, una te queda bien y la otra te queda suelta, pero era mejor que andar pisando tétanos."
    pov "Gracias."
    show jeff3 happy blush
    "Jeff sonrió ampliamente ante tu agradecimiento, incluso pudiste ver como el color subía a su rostro."
    J "Ven."
    play sound "audio/sfx/cloth.mp3"
    "Jeff tomó tu muñeca, el agarre era firme, pero no te hacía daño. Él tiró de ti, pero a diferencia de otras veces, fue suave y calmo."
    scene dinningroom_j with dissolve
    "Te guió por el interior de la casa, hasta llegar a lo que sería un comedor, por la mesa y dos sillas. Había un minirefri y una cocina en la habitación contigua, pero dudabas de que funcionaran."
    show jeff3 smile at center
    with dissolve
    J "Traje el desayuno."
    play sound "audio/sfx/Equip2.ogg"
    show coffee at truecenter
    with dissolve
    if dieta == "V":
        J "Un latte con leche de soya."
    else:
        J "Un latte con leche descremada."
    "Él te extiende un vaso de cartón, y tu lo recibes entre tus manos, está tibio."
    hide coffee with dissolve
    pov "¿Cómo-?"
    J "¿Supe tu preferencia?"
    show jeff3 happy blush
    "La sonrisa de él se tornó burlona."
    J "Vamos, [povname], eres inteligente."
    pov "…"
    "Por supuesto, es porque te siguió durante días."
    "Seguramente averiguó esas cosas tras vigilarte."
    J "No creas que olvidé lo comestible."
    play sound "audio/sfx/Equip2.ogg"
    if sabor == "D":
        show muffin at truecenter
        with dissolve
        J "También te traje un muffin."
        hide muffin with dissolve
    else:
        show sandwich at truecenter
        with dissolve
        J "Te conseguí un sandwich."
        hide sandwich with dissolve
    pov "…"
    pov "Ok, iré al grano."
    pov "¿Estás intentando ser algo así como un novio atento?"
    show jeff3 pensativo none
    "Jeff ladeó la cabeza interrogativamente."
    J "¿De qué hablas?"
    pov "Me arrancaste un ojo, te colaste a mi habitación de hospital, te metiste en mi casa, ¿Quieres que olvide todo eso?"
    pov "¿Cómo se supone que yo crea que me amas si me has hecho pasar un infierno?"
    show jeff3 neutral
    play sound "audio/sfx/609139__nataliafranco__nevera.mp3"
    "Jeff te mira con curiosidad, para luego dirigirse al minirefri."
    J "No quiero que olvides lo que hice."
    "Él musitó suavemente, sacando un frasco del mini refri."
    J "Sólo que lo veas desde una perspectiva diferente."
    play sound "audio/sfx/85549__maj061785__glass-clinking.mp3"
    window hide
    show jar1 at truecenter
    with dissolve
    pause 1.0
    window show
    "Él puso el fresco frente a ti."
    "Dentro, había un líquido transparente espeso, que rozaba con el amarillo. En el interior, al fondo, ves una mancha de color rojo oscuro mezclado con negro."
    "Entonces, él lo gira."
    window hide
    hide jar1 with dissolve
    play sound "audio/sfx/629997__trexlasso__glass-clink.mp3"
    show jar2 at truecenter
    with dissolve
    pause 1.0
    window show
    "Es tu ojo."
    "Sientes frío."
    hide jar2 with dissolve
    show jeff3 smile blush
    J "Tu ojo es tan lindo… No pude evitar guardarlo."
    play sound "audio/sfx/cloth.mp3"
    show jeff3 smile blush at jumpscare_top
    with dissolve
    "Jeff se dirige a ti, sujetando tus mejillas entre sus manos."
    J "Pero ahora tengo algo mejor, a ti."
    "Él acaricia tu piel con sus pulgares, bajando los ojos hacia tus labios."
    J "Lo que tenemos es especial… Y me aseguraré de que también lo veas."
    "Sientes que un escalofrío te atraviesa. Llegas a la conclusión de que no tienes escapatoria."
    "Físicamente, es casi imposible escapar de Jeff. Incluso si lo intentas, por cómo él se expresa, no crees que dude en encadenarte a su lado o cortarte las piernas para que no huyas."
    "Tampoco puedes pedir ayuda, Jeff mataría a cualquiera que se acerque a ti. Lo sabes por experiencia."

    menu:
        "Está loco":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Estás demente…"
            show jeff3 happy none
            "Jeff suelta una carcajada estridente, bajando sus manos a tus hombros."
            J "Completamente."
            jump ruta_normal_32
        "Tiene sentido":
            pov "Seh, entiendo lo que dices."
            show jeff3 neutral none
            J "…"
            J "Me sorprende que lo aceptes tan fácilmente."
            jump ruta_normal_32

    label ruta_normal_32:

    pov "Ok, ok."
    pov "Tomaré tu tonto desayuno."
    play sound "audio/sfx/cloth.mp3"
    "Jeff sonrió ampliamente, inclinándose hacia ti."
    "En un momento pensaste que te iba a besar, por lo que cerraste tu ojo, pero entonces sentiste un toque ligero en tu frente."
    play sound "audio/sfx/346661__deleted_user_2104797__kiss_01.mp3"
    "Jeff besa tu frente por unos segundos, para después liberarte y tomar asiento en la mesa."
    show jeff3 neutral at jumpscare_reset
    with dissolve
    "Sigues su ejemplo y tomas asiento."
    "En silencio, bebes el latte y comes el bocadillo que te trajo."
    pov "¿De dónde sacaste esto?"
    J "¿Crees que no sé sobre las cadenas de comida?"
    J "A varias calles de aquí hay una sucursal de una cafetería."
    pov "¿Tú tomaste desayuno?"
    show jeff3 smile blush
    "Jeff se sonroja levemente, sonriendo afectuosamente."
    J "Si, hace horas."
    J "Lamento no acompañarte, pero nuestros horarios son diferentes."
    
    menu:
        "Preguntar":
            pov "¿Y eso por qué?"
            show jeff3 neutral none
            J "Al ser un fugitivo, suelo comprar y comer en la madrugada."
            J "Los empleados están cansados y malhumorados, así que no me prestan atención."
            jump ruta_normal_33
        "Proponer cenar juntos":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Y si en la cena te unes a mí?"
            show jeff3 happy none
            J "Oh, eso me encantaría."
            "Escuchas cómo él suspira levemente."
            jump ruta_normal_33

    label ruta_normal_33:

    pov "Espera, ¿Pagaste esto con dinero?"
    show jeff3 neutral none
    "Jeff ladea la cabeza, como si estuviera alzando una ceja que no tiene."
    J "¿De qué otra forma pude haberlo conseguido?"
    pov "No sé, robo a mano armada."
    show jeff3 pensativo
    J "Tch, no soy tan descuidado."
    J "Ya me buscan por asesinato e incendio provocado, no voy a agregar robo a esa lista."
    pov "¿Y de donde sacas el dinero?"
    show jeff3 neutral
    J "…"
    J "Bueno, sería un desperdicio no quedarse con el dinero de algunas de las personas que mato."
    "La manera en que él admite matar gente tan relajado es escalofriante."
    pov "Geez, eres patético. No te vale con matar gente, también le robas."
    J "Hey, al menos esos asesinatos no son atribuidos a mí. Se alejan de mi modus operandi, y pasan a considerarse robo."
    pov "Eso no es razón de estar orgulloso, Jeff."
    pov "Nada de lo que dices es razón para estarlo."
    J "…"
    show jeff3 smile blush
    J "Eres adorable cuando me juzgas."
    "Oh no, ha caído por completo."
    "Pero no puedes bajar la guardia, tampoco tomar ventaja de eso."
    "Por más tonto de amor que se vea, sigue siendo un desquiciado que, por lo que has aprendido recientemente, es más calculador de lo que aparenta."
    pov "¿Nunca te habías enamorado antes?"
    show jeff3 pensativo none
    J "…"
    J "Creo que una vez, si se le puede llamar así."
    pov "Oh, ¿De quién?"
    show jeff3 neutral
    J "Una mujer con la que pasé tres noches."
    pov "Asco."
    show jeff3 angry
    J "¡No de esa forma!, Fue íntimo de otra manera."
    show jeff3 pensativo
    J "Hablamos todo el tiempo. Sentí que ella me comprendía."
    show jeff3 neutral
    J "…"
    J "¿Qué me dices de ti?"
    J "¿Te has enamorado antes?"

    menu:
        "Si":
            J "…"
            J "Pero eso ya pasó, ¿No?"
            "Cierto, él es el tipo celoso."
            pov "Obviamente."
            jump character_8
        "No":
            show jeff3 smile
            "Jeff amplió su sonrisa"
            jump character_8
        
    label character_8:

    show jeff3 pensativo
    J "¿Entonces cuál es tu preferencia?"
    J "¿Hombre, mujer, ambos?"

    menu:
        "Hombres":
            show jeff3 smile
            J "Me aseguraré de que no pienses en ninguno más que yo."
            jump character_9
        "Mujeres":
            J "…"
            show jeff3 neutral
            J "No puedo evitar ser un hombre."
            show jeff3 smile
            J "Pero no te dejaré ir sólo por eso."
            jump character_9
        "Ambos":
            show jeff3 smile
            J "Ah, tengo doble competencia."
            J "Te aseguro que no suelo perder."
            jump character_9
        "No te importa":
            show jeff3 smile
            "Jef se ríe levemente, contento."
            J "Eres como yo."
            J "A mí tampoco me importa."
            J "A ti te amo porque eres tú."
            jump character_9
        "No lo has considerado":
            show jeff3 smile
            J "Huh."
            "La sonrisa de él se volvió traviesa."
            J "Haré que me consideres a mí, y sólo a mí."
            jump character_9

    label character_9:

    J "Mientras más sé cosas sobre ti, más me gustas."
    pov "¿Puedo saber cosas de ti también?"
    J "Por supuesto."

    menu:

        "¿Tienes familia?":
            show jeff3 neutral
            J "…"
            J "Obviamente la tuve al inicio."
            J "Una madre, un padre."
            J "… Un hermano."
            J "Pero los perdí."
            menu:
                "¿Los mataste?":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "…"
                    show jeff3 smile
                    "Jeff suelta una carcajada desganada."
                    J "Me conoces mejor de lo que creí."
                    jump familia0
                "¿Cómo?":
                    J "…"
                    J "[povname], eres inteligente, de seguro que sabes la respuesta."
                    jump familia0
        "¿Tienes amigos?":
            show jeff3 pensativo
            J "Hubo un tiempo en que viví con unos tipos."
            J "Era una casa grande, éramos varios."
            J "Cada uno tenía… Sus peculiaridades."
            show jeff3 neutral
            J "Pero son lo más cercano a lo que puedo llamar amigos."
            menu:
                "Suenan cool":
                    J "No lo eran, créeme."
                    J "¿Por qué crees que vivían con un asesino como yo?"
                    pov "…"
                    J "Así es, mataban gente también."
                    jump amigos0
                "Suenan raros":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "Hah, lo eran."
                    show jeff3 pensativo
                    J "El dueño de la casa era… inexpresivo."
                    J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
                    J "Otro se la pasaba jugando videojuegos."
                    J "Uno se vestía de payaso, y un par se la pasaban grabando."
                    J "Así que sí, son raros."
                    jump amigos0
        "¿Qué edad tienes?":
            show jeff3 neutral
            J "…"
            J "No te diré."
            pov "¡Oh, vamos!"
            pov "¿Al menos me das un rango?"
            J "…"
            J "¿Qué edad tienes tú?"
            menu:
                "Menos de 20":
                    J "…"
                    J "Pero eres mayor de edad, ¿Cierto?"
                    pov "Por supuesto."
                    J "Menos mal, no salgo con menores."
                    pov "Eso es… ¿bueno, supongo?"
                    "¿Qué tantas cosas positivas pueden haber en un asesino?"
                    J "… Pero, soy considerablemente mayor."
                    pov "No te preocupes, puedo lidiar con hombres maduros."
        
                "En tus 20's":
                    J "De acuerdo, soy mayor que tú."
                    pov "¿En serio no me vas a decir qué tanto?"
                    "Jeff refunfuñó."
                    pov "Así que mayor, ¿Eh?"
                    
                "En tus 30's":
                    J "Estamos iguales, ¿Feliz?"
                    pov "Así que treintañero, ¿Eh?"
            show jeff3 angry
            J "Cállate."
            menu:
                "Halagarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Estás en buena forma."
                    show jeff3 neutral
                    pov "Incluso si no eres tan joven, te ves bien."
                    show jeff3 shy blush
                    "Ignorando lo destrozada que estaba su cara, claro."
                    "Jeff no dice nada, pero notas que sus mejillas se encienden."
                    jump edad0
                "Burlarte":
                    pov "Para ser tan viejo, te ves bien."
                    "Jeff resopla."
                    jump edad0
        "Eso es todo":
            jump ruta_normal_36

#after1

    label familia0:

    menu: 
        "¿Tienes amigos?":
            show jeff3 pensativo
            J "Hubo un tiempo en que viví con unos tipos."
            J "Era una casa grande, éramos varios."
            J "Cada uno tenía… Sus peculiaridades."
            show jeff3 neutral
            J "Pero son lo más cercano a lo que puedo llamar amigos."
            menu:
                "Suenan cool":
                    J "No lo eran, créeme."
                    J "¿Por qué crees que vivían con un asesino como yo?"
                    pov "…"
                    J "Así es, mataban gente también."
                    jump amigos1_1
                "Suenan raros":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "Hah, lo eran."
                    show jeff3 pensativo
                    J "El dueño de la casa era… inexpresivo."
                    J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
                    J "Otro se la pasaba jugando videojuegos."
                    J "Uno se vestía de payaso, y un par se la pasaban grabando."
                    J "Así que sí, son raros."
                    jump amigos1_1
        "¿Qué edad tienes?":
            show jeff3 neutral
            J "…"
            J "No te diré."
            pov "¡Oh, vamos!"
            pov "¿Al menos me das un rango?"
            J "…"
            J "¿Qué edad tienes tú?"
            menu:
                "Menos de 20":
                    J "…"
                    J "Pero eres mayor de edad, ¿Cierto?"
                    pov "Por supuesto."
                    J "Menos mal, no salgo con menores."
                    pov "Eso es… ¿bueno, supongo?"
                    "¿Qué tantas cosas positivas pueden haber en un asesino?"
                    J "… Pero, soy considerablemente mayor."
                    pov "No te preocupes, puedo lidiar con hombres maduros."
                "En tus 20's":
                    J "De acuerdo, soy mayor que tú."
                    pov "¿En serio no me vas a decir qué tanto?"
                    "Jeff refunfuñó."
                    pov "Así que mayor, ¿Eh?"
                "En tus 30's":
                    J "Estamos iguales, ¿Feliz?"
                    pov "Así que treintañero, ¿Eh?"
            show jeff3 angry
            J "Cállate."
            menu:
                "Halagarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Estás en buena forma."
                    show jeff3 neutral
                    pov "Incluso si no eres tan joven, te ves bien."
                    show jeff3 shy blush
                    "Ignorando lo destrozada que estaba su cara, claro."
                    "Jeff no dice nada, pero notas que sus mejillas se encienden."
                    jump edad1_1
                "Burlarte":
                    pov "Para ser tan viejo, te ves bien."
                    "Jeff resopla."
                    jump edad1_1
        "Eso es todo":
            jump ruta_normal_36

    label amigos0:
    
    menu:
        "¿Tienes familia?":
            show jeff3 neutral
            J "…"
            J "Obviamente la tuve al inicio."
            J "Una madre, un padre."
            J "… Un hermano."
            J "Pero los perdí."
            menu:
                "¿Los mataste?":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "…"
                    show jeff3 smile
                    "Jeff suelta una carcajada desganada."
                    J "Me conoces mejor de lo que creí."
                    jump familia1_1
                "¿Cómo?":
                    J "…"
                    J "[povname], eres inteligente, de seguro que sabes la respuesta."
                    jump familia1_1
        "¿Qué edad tienes?":
            show jeff3 neutral
            J "…"
            J "No te diré."
            pov "¡Oh, vamos!"
            pov "¿Al menos me das un rango?"
            J "…"
            J "¿Qué edad tienes tú?"
            menu:
                "Menos de 20":
                    J "…"
                    J "Pero eres mayor de edad, ¿Cierto?"
                    pov "Por supuesto."
                    J "Menos mal, no salgo con menores."
                    pov "Eso es… ¿bueno, supongo?"
                    "¿Qué tantas cosas positivas pueden haber en un asesino?"
                    J "… Pero, soy considerablemente mayor."
                    pov "No te preocupes, puedo lidiar con hombres maduros."
        
                "En tus 20's":
                    J "De acuerdo, soy mayor que tú."
                    pov "¿En serio no me vas a decir qué tanto?"
                    "Jeff refunfuñó."
                    pov "Así que mayor, ¿Eh?"
                    
                "En tus 30's":
                    J "Estamos iguales, ¿Feliz?"
                    pov "Así que treintañero, ¿Eh?"
            show jeff3 angry
            J "Cállate."
            menu:
                "Halagarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Estás en buena forma."
                    show jeff3 neutral
                    pov "Incluso si no eres tan joven, te ves bien."
                    show jeff3 shy blush
                    "Ignorando lo destrozada que estaba su cara, claro."
                    "Jeff no dice nada, pero notas que sus mejillas se encienden."
                    jump edad1_2
                "Burlarte":
                    pov "Para ser tan viejo, te ves bien."
                    "Jeff resopla."
                    jump edad1_2
        "Eso es todo":
            jump ruta_normal_36

    label edad0:

    menu:
        "¿Tienes familia?":
            show jeff3 neutral none
            J "…"
            J "Obviamente la tuve al inicio."
            J "Una madre, un padre."
            J "… Un hermano."
            J "Pero los perdí."
            menu:
                "¿Los mataste?":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "…"
                    show jeff3 smile
                    "Jeff suelta una carcajada desganada."
                    J "Me conoces mejor de lo que creí."
                    jump familia1_2
                "¿Cómo?":
                    J "…"
                    J "[povname], eres inteligente, de seguro que sabes la respuesta."
                    jump familia1_2
            
        "¿Tienes amigos?":
            show jeff3 pensativo none
            J "Hubo un tiempo en que viví con unos tipos."
            J "Era una casa grande, éramos varios."
            J "Cada uno tenía… Sus peculiaridades."
            show jeff3 neutral
            J "Pero son lo más cercano a lo que puedo llamar amigos."
            menu:
                "Suenan cool":
                    J "No lo eran, créeme."
                    J "¿Por qué crees que vivían con un asesino como yo?"
                    pov "…"
                    J "Así es, mataban gente también."
                    jump amigos1_2
                "Suenan raros":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "Hah, lo eran."
                    show jeff3 pensativo
                    J "El dueño de la casa era… inexpresivo."
                    J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
                    J "Otro se la pasaba jugando videojuegos."
                    J "Uno se vestía de payaso, y un par se la pasaban grabando."
                    J "Así que sí, son raros."
                    jump amigos1_2
        "Eso es todo":
            jump ruta_normal_36

    #familia after2

    label familia1_1:

    menu: 
        "¿Qué edad tienes?":
            show jeff3 neutral
            J "…"
            J "No te diré."
            pov "¡Oh, vamos!"
            pov "¿Al menos me das un rango?"
            J "…"
            J "¿Qué edad tienes tú?"
            menu:
                "Menos de 20":
                    J "…"
                    J "Pero eres mayor de edad, ¿Cierto?"
                    pov "Por supuesto."
                    J "Menos mal, no salgo con menores."
                    pov "Eso es… ¿bueno, supongo?"
                    "¿Qué tantas cosas positivas pueden haber en un asesino?"
                    J "… Pero, soy considerablemente mayor."
                    pov "No te preocupes, puedo lidiar con hombres maduros."
        
                "En tus 20's":
                    J "De acuerdo, soy mayor que tú."
                    pov "¿En serio no me vas a decir qué tanto?"
                    "Jeff refunfuñó."
                    pov "Así que mayor, ¿Eh?"
                    
                "En tus 30's":
                    J "Estamos iguales, ¿Feliz?"
                    pov "Así que treintañero, ¿Eh?"
            show jeff3 angry
            J "Cállate."
            menu:
                "Halagarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Estás en buena forma."
                    show jeff3 neutral
                    pov "Incluso si no eres tan joven, te ves bien."
                    show jeff3 shy blush
                    "Ignorando lo destrozada que estaba su cara, claro."
                    "Jeff no dice nada, pero notas que sus mejillas se encienden."
                    jump ruta_normal_36
                "Burlarte":
                    pov "Para ser tan viejo, te ves bien."
                    "Jeff resopla."
                    jump ruta_normal_36
        "Eso es todo":
            jump ruta_normal_36

    label familia1_2:

    menu: 
        "¿Tienes amigos?":
            show jeff3 pensativo none
            J "Hubo un tiempo en que viví con unos tipos."
            J "Era una casa grande, éramos varios."
            J "Cada uno tenía… Sus peculiaridades."
            show jeff3 neutral
            J "Pero son lo más cercano a lo que puedo llamar amigos."
            menu:
                "Suenan cool":
                    J "No lo eran, créeme."
                    J "¿Por qué crees que vivían con un asesino como yo?"
                    pov "…"
                    J "Así es, mataban gente también."
                    jump ruta_normal_36
                "Suenan raros":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "Hah, lo eran."
                    show jeff3 pensativo
                    J "El dueño de la casa era… inexpresivo."
                    J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
                    J "Otro se la pasaba jugando videojuegos."
                    J "Uno se vestía de payaso, y un par se la pasaban grabando."
                    J "Así que sí, son raros."
                    jump ruta_normal_36
                
        "Eso es todo":
            jump ruta_normal_36

    #amigos after2

    label amigos1_1:

    menu:
        "¿Qué edad tienes?":
            show jeff3 neutral
            J "…"
            J "No te diré."
            pov "¡Oh, vamos!"
            pov "¿Al menos me das un rango?"
            J "…"
            J "¿Qué edad tienes tú?"
            menu:
                "Menos de 20":
                    J "…"
                    J "Pero eres mayor de edad, ¿Cierto?"
                    pov "Por supuesto."
                    J "Menos mal, no salgo con menores."
                    pov "Eso es… ¿bueno, supongo?"
                    "¿Qué tantas cosas positivas pueden haber en un asesino?"
                    J "… Pero, soy considerablemente mayor."
                    pov "No te preocupes, puedo lidiar con hombres maduros."
        
                "En tus 20's":
                    J "De acuerdo, soy mayor que tú."
                    pov "¿En serio no me vas a decir qué tanto?"
                    "Jeff refunfuñó."
                    pov "Así que mayor, ¿Eh?"
                    
                "En tus 30's":
                    J "Estamos iguales, ¿Feliz?"
                    pov "Así que treintañero, ¿Eh?"
            show jeff3 angry
            J "Cállate."
            menu:
                "Halagarlo":
                    $ show_affection("J", 1)
                    $afecto += 1
                    pov "Estás en buena forma."
                    show jeff3 neutral
                    pov "Incluso si no eres tan joven, te ves bien."
                    show jeff3 shy blush
                    "Ignorando lo destrozada que estaba su cara, claro."
                    "Jeff no dice nada, pero notas que sus mejillas se encienden."
                    jump ruta_normal_36
                "Burlarte":
                    pov "Para ser tan viejo, te ves bien."
                    "Jeff resopla."
                    jump ruta_normal_36
        "Eso es todo":
            jump ruta_normal_36

    label amigos1_2:

    menu:
        "¿Tienes familia?":
            show jeff3 neutral none
            J "…"
            J "Obviamente la tuve al inicio."
            J "Una madre, un padre."
            J "… Un hermano."
            J "Pero los perdí."
            menu:
                "¿Los mataste?":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "…"
                    show jeff3 smile
                    "Jeff suelta una carcajada desganada."
                    J "Me conoces mejor de lo que creí."
                    jump ruta_normal_36
                "¿Cómo?":
                    J "…"
                    J "[povname], eres inteligente, de seguro que sabes la respuesta."
                    jump ruta_normal_36
            
        "Eso es todo":
            jump ruta_normal_36

    #edad after2

    label edad1_1:

    menu:
        "¿Tienes amigos?":
            show jeff3 pensativo none
            J "Hubo un tiempo en que viví con unos tipos."
            J "Era una casa grande, éramos varios."
            J "Cada uno tenía… Sus peculiaridades."
            show jeff3 neutral
            J "Pero son lo más cercano a lo que puedo llamar amigos."
            menu:
                "Suenan cool":
                    J "No lo eran, créeme."
                    J "¿Por qué crees que vivían con un asesino como yo?"
                    pov "…"
                    J "Así es, mataban gente también."
                    jump ruta_normal_36
                "Suenan raros":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "Hah, lo eran."
                    show jeff3 pensativo
                    J "El dueño de la casa era… inexpresivo."
                    J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
                    J "Otro se la pasaba jugando videojuegos."
                    J "Uno se vestía de payaso, y un par se la pasaban grabando."
                    J "Así que sí, son raros."
                    jump ruta_normal_36
        
        "Eso es todo":
            jump ruta_normal_36
    
    label edad1_2:

    menu:
        "¿Tienes familia?":
            show jeff3 neutral none
            J "…"
            J "Obviamente la tuve al inicio."
            J "Una madre, un padre."
            J "… Un hermano."
            J "Pero los perdí."
            menu:
                "¿Los mataste?":
                    $ show_affection("J", 1)
                    $afecto += 1
                    J "…"
                    show jeff3 smile
                    "Jeff suelta una carcajada desganada."
                    J "Me conoces mejor de lo que creí."
                    jump ruta_normal_36
                "¿Cómo?":
                    J "…"
                    J "[povname], eres inteligente, de seguro que sabes la respuesta."
                    jump ruta_normal_36
        "Eso es todo":
            jump ruta_normal_36

    label ruta_normal_36:

    show jeff3 smile none
    J "¿Estás feliz con todo lo que preguntaste?"
    pov "Depende, tengo una pregunta más."
    pov "¿Por qué matas?"
    show jeff3 neutral
    J "…"
    show jeff3 pensativo
    "Jeff desvía la mirada, pensativo."
    J "A este punto… Es como preguntarle a un pájaro por qué vuela."
    show jeff3 neutral
    J "Es lo que soy."
    pov "Pero empezó por algo, ¿No?, ¿Qué pasó?"
    "Jeff se encoge de hombros."
    J "Era un niño cuando empezó."
    J "El mundo era un lugar sin sentido, y los humanos me parecen desagradables, en general."
    J "Quería hacer del mundo un lugar hermoso."
    J "Y fue así durante años."

    menu:
        "Es raro":
            pov "Que rara razón para matar."
            pov "Yo pensaba que tenías una vida trágica."
            show jeff3 smile
            J "Heh, lamento decepcionarte, amor."
            jump ruta_normal_37
        "Es jodido":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Vaya, eso es jodido."
            show jeff3 smile
            J "Ni me lo digas."
            pov "Con razón estás tan mal de la cabeza."
            J "Heh, que halago, amor."
            jump ruta_normal_37

    label ruta_normal_37:

    show jeff3 neutral
    J "Pero cuando te conocí… Empecé a sentir cosas que pensé que había olvidado."
    "Las palabras querían escapar de tu boca."
    pov "¿Considerarías dejar de matar?"
    pov "¿Por mí?"
    "Era tarde, lo dijiste."
    "Nuevamente, no eres una santidad que quiere dar una lección moral a una persona evidentemente inmoral, pero era una pregunta hecha por genuina curiosidad."
    "No era una petición, sólo querías saber."
    "Y afortunadamente, parece que Jeff no se lo tomó mal."
    show jeff3 smile
    J "Podría llegar a un consenso… Sólo en caso de."
    play sound "audio/sfx/heart beat.mp3"
    "No puedes evitar sentir que tu corazón se acelera."
    "De acuerdo, debías admitir que hasta el momento, dudabas que realmente Jeff estuviera enamorado de ti."
    "Pero si este tipo demente dice que podría considerar cambiar sólo por ti, era imposible no conmoverte, aunque sea un poco."
    pov "Eso es muy dulce, gracias."
    "Era mejor estar en su lado bueno de todas maneras." 
    "Quien sabría lo que pasaría si lo tratabas mal o le rompías el corazón."
    "Algo te dice que él es muy rencoroso."
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "De repente, se escucha un golpe en la puerta."
    scene living_j with dissolve
    show jeff3 neutral at center
    with dissolve
    "Jeff se torna serio y va a la ventana, asomándose levemente."
    J "Es un policía."
    pov "¿Se te olvidó pagar la renta?"
    "Jeff se mordió la punta de los dedos, pensativo."
    J "No pago renta."
    pov "Ah, eres un ocupa."
    show jeff3 angry
    J "Ya- deja de bromear."
    play sound "audio/sfx/244325__philip_daniels__knock_on_door.mp3"
    "El llamado a la puerta se torna insistente."
    show jeff3 neutral
    J "Responde tú."
    pov "¿Qué?"
    J "Estoy siendo buscado, no pueden verme."
    J "Tendrás que hablar con él."
    pov "Pero yo-"
    J "Confiaré en ti."
    play sound "audio/sfx/cloth.mp3"
    hide jeff3 with dissolve
    "Sin esperar una respuesta, Jeff desapareció tras adentrarse en la casa."
    "Te removiste en tu lugar con nervios, dirigiéndote a la puerta."
    "Todo va a estar bien, [povname], ya le has mentido a la policía antes. Será pan comido."
    play sound "audio/sfx/15419__pagancow__dorm-door-opening.mp3"
    "Abres la puerta y frente a ti está un policía uniformado."
    P "Buenos días, siento molestar tan temprano."
    pov "No importa…"
    P "Estamos monitoreando la zona, es sólo rutina. ¿Has presenciado actividad inusual últimamente?"
    
    menu:
        "Decir la verdad":
            stop music fadeout 5.9
            pov "…"
            pov "La verdad… "
            "Bajas el volumen de tu voz."
            pov "Me secuestraron."
            pov "Él… está dentro de la casa."
            "El policía te miró en silencio por unos segundos, analizando si estabas diciendo la verdad."
            "Entonces, él desenfundó su arma y abrió la puerta."
            P "Espera aquí."
            "Él entra sigilosamente, apoyando su hombro contra las superficies a medida que entraba a la casa."
            "Esperaste en la puerta principal, el silencio pesado en el aire."
            play sound "audio/sfx/Gun1.ogg"
            "De repente escuchas el primer disparo."
            play sound "audio/sfx/Gun1.ogg"
            pause 1.0
            play sound "audio/sfx/Gun1.ogg"
            "Luego el segundo y el tercero."
            play music "audio/music/dark-and-scary-wind-9658.mp3"
            "Por la sopresa e incertidumbre, te congelas en tu lugar."
            J "¡[povname]!"
            "El alarido de Jeff te hace temblar."
            show jeff4 hurt at center
            with dissolve
            "Él aparece por el pasillo, apoyado contra la pared y con una herida en el costado."
            show jeff4 mad at jumpscare_top
            with dissolve
            "Jeff se abalanza hacia ti, aplastandote con su cuerpo."
            J "¡Te vas a ir conmigo!"
            "Sonaba molesto, pero más que eso, se veía dolido, seguramente por haberlo delatado."
            scene red with dissolve
            play sound "audio/sfx/gore3.mp3"
            "Él sujetó tu cabeza con fuerza, y enterró su pulgar en tu ojo restante."
            "Soltaste un alarido de agonía, sintiendo que la punzada de dolor te invadía de la cabeza a los pies."
            "Tus brazos se sacudieron contra él, pero eso no evitó nada."
            "Sientes que el dedo de él se entierra más, atravesando tu cuenca."
            "No te queda fuerza para seguir luchando, tu voz se ahoga ante el dolor."
            scene black with fade
            "Lo último que escuchas es un último disparo."
            pause 1.0
            show Death with fade
            pause 2.0
            "{b}Final VI: Lo Traicionaste{/b}"
            return
        "Mentir":
            $ show_affection("J", 1)
            $afecto += 1
            pov "No he visto nada."
            P "…"
            P "De acuerdo."
            P "Intenta tener cuidado, este barrio es peligroso."
            "Quizás notó que no eres precisamente de ahí."
            P "Cierra bien todas las ventanas y puertas."
            "El policía hace un ademán con su gorra."
            P "Siento de nuevo la molestia."
            jump historia_continúa_3_38

    label historia_continúa_3_38:

    play sound "audio/sfx/609727__theplax__door-lock-1.wav"
    "Ves que el policía se retira, y cuando no lo ves más, cierras la puerta."
    stop music fadeout 8.0
    "Suspiras pesadamente, y te giras hacia la dirección en la que se fue Jeff."
    pov "¿Jeff?, Ya puedes salir."
    "No obtienes respuesta, por lo que das unos pasos adelante."
    show jeff3 happy blush at center
    with dissolve
    "De la oscuridad, Jeff se acerca a ti corriendo, y te estrecha contra sus brazos."
    J "¡[povname]!"
    play sound "audio/sfx/Equip2.ogg"
    show jeff3 happy blush at jumpscare_top
    with dissolve
    play music "audio/music/romantic-pianobittersweet-romance-324562.mp3"
    "Él te envuelve en un fuerte abrazo, incluso se inclina a un lado para elevarte del suelo unos centímetros."
    J "¡Eres genial!"
    pov "Oh, eh, si, intento serlo."
    "No sabes si tomarte bien los elogios, ya que acabas de romper la ley."
    J "¡Tuviste la oportunidad de delatarme, pero me encubriste!"

    menu:
        "Ser indiferente":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Sí, sí, estuve ahí."
            J "No me importa que me trates fríamente, ¡Igual te adoro!"
            pov "Yo no estaba- Espera, ¿Qué?"
            jump ruta_normal_39
        "Ser complaciente":
            pov "No soy capaz de entregarte."
            J "¡Te lo compensaré por completo!"
            pov "… ¿Cómo, precisamente?"
            J "Lo que sea."
            jump ruta_normal_39

    label ruta_normal_39:

    play sound "audio/sfx/cloth.mp3"
    "Jeff te deposita en el suelo y se distancia de ti, pero sus manos se mantienen sobre ti."
    pov "No te tomaba por un arrastrado."
    J "Lameré tus pies si quieres."
    pov "¡Asco!, entiendo la idea, eso no fue necesario."
    play sound "audio/sfx/cloth.mp3"
    show jeff3 smile
    "Jeff ríe entre dientes, subiendo sus manos hacia tu cuello."
    #
    "Su tono burlesco te fastidiaba, sólo quería molestarte."
    #
    "Él ladea la cabeza, mirando con atención las marcas de sus dedos en tu cuello, que se habían estado borrado con el pasar de los días."
    "Te abstienes de decir algo, pues sientes que el aire cambia a uno… más íntimo."
    "Tus ojos se encuentran por un instante con los de Jeff, sus pupilas normalmente pequeñas estaban ligeramente dilatadas."
    "Él se acerca y agacha la cabeza a la altura de tu cuello."
    "Lo único que ves es el cabello negro de él sobre tu frente."

    menu:
        "Alejarte":
            "Retrocedes levemente, pero él te sujeta firmemente."
            "Incluso si no quieres, él lo hará de todas maneras."
            jump ruta_normal_40
        "Dejarlo":
            $ show_affection("J", 1)
            $afecto += 1
            jump ruta_normal_40

    label ruta_normal_40:

    play sound "audio/sfx/658348__dversexxxstudio__kiss.mp3"
    "Sientes que el primer beso sobre tu cuello te produce un escalofrío, y el segundo lo hace peor."
    play sound "audio/sfx/346661__deleted_user_2104797__kiss_01.mp3"
    "Jeff se toma su tiempo, lentamente y con calma, besa tu cuello de un extremo a otro, acariciando la piel de tu garganta con sus labios suavemente."
    "Aprietas los labios, para no emitir ni un sonido."
    "Tal vez toda la situación está jugando con tu mente, porque una casa destartalada no te parece el peor lugar para hacer esto."
    play sound "audio/sfx/cloth.mp3"
    window hide
    show cg32 with dissolve
    pause 2.0
    window show
    "Sientes cómo él se separa pausadamente y se inclina sobre tu rostro."
    "Su cabello largo y desordenado impide tu visión, pero por la cercanía, puedes ver los ojos brillantes y el corte de su boca cerca de ti."
    play sound "audio/sfx/352345__noahpardo__npx-male-wet-kiss-3.wav"
    "Ves cómo los ojos de él están fijos en tus labios, por lo que no te sorprendes cuando él finalmente te besa."
    "El toque era suave, pero podías sentir que los labios estaban secos y fríos." 
    "Aún así, no era tan malo."
    "Las manos de él subieron a tu mandíbula, sujetándote firmemente, como si quisiera evitar darte oportunidad para escapar."
    "Sentías la posesividad en su toque, pero no era agresivo."
    "Más bien, parecía tener cuidado."
    "Tomando valentía, alzas tus manos y envuelves los hombros de él."
    show cg33 with dissolve
    hide cg32
    play sound "audio/sfx/658348__dversexxxstudio__kiss.mp3"
    "Jeff gime suavemente contra tus labios al sentir que tus dedos se enredan en su cabello, separándose un instante sólo para volver a besarte, necesitado."
    play sound "audio/sfx/cloth.mp3"
    "Él baja sus manos a tu cintura y te sujeta firmemente."

    menu:
        "Incluir lengua (sugestivo)":
            "Sacas la lengua y lames ligeramente el labio inferior de Jeff."
            "Él suspira y abre los labios, dándote camino."
            play sound "audio/sfx/352345__noahpardo__npx-male-wet-kiss-3.wav"
            "Profundizas el beso, y sientes que Jeff se derrite contra ti."
            "Sus dedos en tu cintura y sus labios contra los tuyos tiemblan."
            play sound "audio/sfx/658348__dversexxxstudio__kiss.mp3"
            "Acaricias su lengua con la tuya, el toque es suave y tibio, húmedo."
            "Sientes que tu respiración se entrelaza con la de él."
            "Él te acerca más, el roce de sus manos sintiéndose caliente sobre tu cuerpo."
            "Hasta que sientes que él sube la mano a tu pecho."
            "No te importaría normalmente, ustedes estaban besándose, no era raro que él se entusiasmara."
            "Pero cuando sentiste una punzada en tu muslo, decidiste parar."
            "Una casa en ruinas no es el mejor lugar para… eso."
            "Incluso si tu estado de ánimo es cachondo, tienes estándares."
            window hide
            show cg34 with dissolve
            hide cg33
            pause 1.0
            window show
            "Te separas lentamente, tu boca y la de él siendo unidas por un hilo de saliva."
            "Los ojos de él se ven nublados, y su respiración está agitada."
            hide cg34 with dissolve
            jump beso_1
        "Con eso basta":
            "Te separas lentamente, creando distancia entre él y tú."
            hide cg33 with dissolve
            jump beso_1

    label beso_1:

    pov "De acuerdo, suficiente por hoy."
    show jeff3 sad
    "Jeff deja escapar un quejido lastimero, sin querer soltarte."
    J "¿Qué?, ¿Por qué?"
    pov "No pienso llegar más lejos contigo en este lugar."
    pov "Pueden haber cucarachas, ratas… o tétanos."
    show jeff3 pensativo
    J "Tch, ok."
    show jeff3 neutral none at jumpscare_reset
    with dissolve
    "Jeff te libera de su abrazo, pero se mantiene cerca."
    J "Quería demostrarte lo agradecido que estoy."
    pov "Puedes agradecerme de otra forma."
    show jeff3 smile blush
    "El rostro de Jeff se ilumina."
    J "¿Puedo lamer tu-?"
    pov "¡No!, ¡Consígueme ropa!"
    J "Oh, cierto."
    "Niegas con la cabeza, en desaprobación por las ocurrencias de él."
    #
    "Esa broma era más molesta que graciosa."
    #
    show jeff3 neutral none
    play sound "audio/sfx/cloth.mp3"
    "Jeff se dirige a un rincón de la sala y recoge algo."
    J "Ten, mientras consigo ropa para ti."
    "Él te ofrece su sudadera blanca… demasiado blanca."
    pov "¿Cómo haces para mantenerla tan limpia si te la pasas matando?"
    pov "¿No debería mancharse con la sangre?"
    "Si resulta que también tiene la habilidad sobrehumana de no mancharse, esta historia se va a catalogar como fantasía."
    J "Tengo varias de esas."
    J "No soy estúpido, sé que no puedo andar con la misma sudadera ensangrentada a todas partes."
    pov "¿Pero porqué blancas?"
    pov "¿No sería mejor ropa roja, o negra?"
    J "Tengo una marca."
    pov "¿Una marca?"
    show jeff3 smile
    J "Claro, ¿Cómo la gente va a saber que se trata de mi si uso ropa diferente?"
    pov "…"
    pov "Dejemos el tema, que me va a dar una embolia."
    show jeff3 smile blush
    J "Haha, eres adorable."
    play sound "audio/sfx/Equip2.ogg"
    "Te pones la sudadera encima de tu ropa de pijama, y es una fortuna que no te queda ajustada."
    "Jeff se ve delgado, pero sus hombros y pecho son más anchos de lo que parecen."
    J "…"
    J "¿Te gusta lo que ves?"
    "Ah, te quedaste mirándolo fijamente por un momento."

    menu:
        "Si":
            pov "Claro."
            pov "Un tipo con la cara quemada y la boca cortada es sexy."
            show jeff3 neutral none
            J "…"
            J "Incluso si lo dices para burlarte, no me afecta."
            J "Me gusta cómo me veo."
            pov "Un hombre con confianza, eso si es atractivo."
            show jeff3 shy blush
            "Jeff se queda en silencio, pero alcanzas a ver que sus mejillas se sonrojan."
            jump character_10
        "No es tu tipo":
            pov "Nah, no realmente."
            show jeff3 angry none
            J "¡¿Qué?!, ¡¿Por qué no?!"
            pov "Eres muy flacucho para mi gusto."
            J "¡¿Acaso te gustan más musculosos?!"
            J "…"
            J "¿O más rellenos?"
            pov "Ok, creo que deberíamos dejarlo hasta ahí."
            jump character_10

    label character_10:

    hide jeff3 with dissolve
    play sound "audio/sfx/Equip2.ogg"
    show jeff2 neutral bandana at center
    with dissolve
    "El saca una sudadera idéntica a la que ya tienes y se cubre el rostro con la bandana y la capucha."
    pov "¿Vamos a una tienda?"
    J "Mejor."
    pov "¿Un mall?"
    "Estabas jodiendo, sabías que ustedes no podían salir así como así."
    J "Un tipo que recolecta objetos tiene mucha ropa. Va a dar lo que sea por un poco de brandy."
    pov "Asco."
    J "Relájate, la vamos a lavar… no sé, 5 veces, para que estés en paz."
    "Que estilo de vida tan precario…"
    "¿Qué esperabas de un criminal?"

    scene black with fade

    stop music fadeout 5.0
    pause 1.0

    #dia 7

    window hide
    show Day7 with fade

    pause 2.0

    scene black with fade
    window show
    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 

    "Como lo prometió, Jeff lavó varias veces toda la ropa que se consiguió con un alcohólico de la calle."
    "Así que ahora contabas con una camiseta, una sudadera propia, pantalones de chándal y zapatillas, que a pesar de ser de tu talla, eran de diferente par."
    "¿Quién pensaría que irías en picada en una trama de romance-terror?"
    "Pero al menos, pasar el tiempo con Jeff se volvió algo ameno."
    "Ustedes se la pasaban hablando, reflexionando sobre cosas, aprendiendo uno del otro."
    "Incluso se quedaron dormidos mientras hablaban."
    window hide
    show cg35 with fade
    pause 2.0
    window show
    "Así que no fue raro que él sea lo primero que ves apenas despiertas."
    J "…"
    pov "…"
    pov "¿Hace cuánto que me estás mirando?"
    J "Desde que desperté."
    "Lo miras expectante."
    J "Hace 5 horas."
    "Ok, esto se estaba saliendo de control."
    "No esperabas llamar la atención de un asesino que se volvería en tu acosador de un día para otro." 
    "De hecho, eso te abrumaba."
    pov "… ¿De verdad te tomó una semana amarme?"
    J "¿Es tan difícil de creer?"
    J "No sé mucho de romance, pero eres la primera persona que me produce esto."
    J "Quiero estar a tu lado siempre, odio a cualquiera que se te acerque, no soporto la idea que alguien más te haga daño-"
    pov "¿Sigues queriendo hacerme daño, Jeff?"
    "La sonrisa de Jeff se tensa ante tus palabras, y el aire se vuelve pesado."
    "Esa era una pregunta que necesitaba ser respondida."
    "La idea de estar con Jeff y que él quiera dañarte… Te da mal sabor de boca."
    J "Ahora que estamos bien, no tengo porqué."
    "¿Eso quería decir que si estuvieran mal, te lastimaría?"
    "Jeff alza una mano a tu mejilla y la acaricia con la punta de sus dedos, recorriendo con sus ojos cada rincón de tu rostro."
    pov "¿Y qué hay de lo que le hiciste a mi ojo?"
    "Jeff se ríe entre dientes, y sientes frustración al sentir que no te toma en serio."
    J "¿De qué serviría una disculpa cuando el daño ya está hecho?"
    "Eso… Tenía cierta lógica, pero eso no significaba que no sientas rencor."
    play sound "audio/sfx/cloth.mp3"
    "Él deslizó sus dedos por debajo de los elásticos del parche, tirando sutilmente hasta desengancharlo de tu cabeza."
    "Te habías quitado el parche adhesivo y la gasa, por lo que cuando él retiró tu parche, dejó al descubierto tu cuenca vacía."
    J "Además, creo que te ves mejor así."
    "No sabías si sentir que te elogia o que te está manipulando."
    "De cualquier forma, su toque era suave y delicado, rozando con la yema de sus dedos la zona alrededor de tu párpado izquierdo."
    J "Es uno de mis mejores trabajos."
    "Sus palabras te producen un escalofrío."
    "Sientes que tu mente está confusa."
    "No sabes lo que está bien o que está mal a este punto."

    menu:
        "Contarle a Jeff":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Estoy… perdiendo la cabeza, Jeff?"
            "Jeff sonríe afectuosamente, acariciando con su pulgar tu labio inferior."
            J "¿Qué mejor que enloquecer juntos, [povname]?"
            jump ruta_normal_41
        "Guardarlo para ti":
            "Él no tiene por qué saberlo."
            "Puede que alimente más la locura de él."
            jump ruta_normal_41

    label ruta_normal_41:

    "Te mantienes en silencio, bajo la mirada fija de Jeff."
    "Te estabas acostumbrando a que él se la pase observándote y que no parpadee."
    "De hecho, te preguntas si siquiera tiene párpados."

    menu:
        "Ser sutil":
            $ show_affection("J", 1)
            $afecto += 1
            pov "De casualidad… ¿Tienes insomnio?"
            "Jeff parece contentarse con tu pregunta."
            J "¿Lo notaste?"
            jump ruta_normal_42
        "Ir al grano":
            pov "¿Qué onda con tus ojos?"
            J "¿Qué hay con ellos?"
            pov "Eso negro alrededor."
            J "…"
            jump ruta_normal_42

    label ruta_normal_42: 

    J "Hace años que tengo insomnio."
    J "Por lo que se me formaron estas ojeras."
    pov "… Oh."
    pov "Entonces, ¿Tienes párpados?"
    "Jeff resopla, sarcástico."
    J "¿Por qué todos piensan que no tengo párpados?"
    pov "Bueno, por mi parte es porque nunca te he visto parpadear."
    J "…"
    show cg36 with dissolve
    pause 1.0
    hide cg36 with dissolve
    J "¿Feliz?"
    pov "Sip, definitivamente ya no tengo dudas."
    "Claro, verlo parpadear lo hacía parecer más… normal."
    pov "Mírate, tan obediente."
    pov "Pensé que te gustaba dar órdenes más que recibirlas."
    J "No tengo preferencia."
    J "Sé lo que quiero, y hago lo que sea por conseguirlo."
    J "Pero estoy dispuesto a recibir lo que me des."

    menu:
        "Coquetear":
            $ show_affection("J", 1)
            $afecto += 1
            pov "¿Estamos hablando de otra cosa?"
            show cg37 with dissolve
            "Las mejillas de Jeff se encienden, y su mirada baja."
            J "Tómalo como quieras."
            hide cg37 with dissolve
            jump ruta_normal_43
        "Bromear":
            pov "¿Si te digo que ladres como perro, lo harás?"
            J "…"
            J "Hay límites."
            jump ruta_normal_43

    label ruta_normal_43:

    "Te ríes entre dientes ante la respuesta de él, y al menos Jeff parece satisfecho con tu reacción."
    "Alzas tu mano y recorres con suavidad el brazo izquierdo de él, acariciando las marcas y cicatrices a través de la tela."
    pov "¿Qué te sucedió?"
    "Jeff suspira despreocupado."
    J "Una mezcla de ocasiones. Algunas son quemaduras por el fuego y ácido, otras son cortes por peleas."
    pov "¿Peleas?, Jeff, no te tomé como uno de esos."
    J "¿Qué esperabas que hiciera?, ¿Dejarme apuñalar?, No gracias."
    pov "¿Y con quién pelearías tú?"
    J "…"
    J "Muchos enemigos."
    pov "¿Así que has dejado con vida a aún más personas?"
    J "Solo te dejé a ti y la chica que mencioné antes."
    J "Los demás lograron escapar o simplemente buscan venganza."
    pov "Vaya, eres todo un chico malo."
    "Jeff se ríe levemente, su voz es vibrante."
    "Que bueno que se lo tome con humor."
    "Ya que técnicamente, él es todo lo que está mal en el mundo."
    J "Hey, [povname]."
    pov "¿Sí?"
    J "¿Te gusto?"
    pov "…"
    pov "Jeff, no me ando besando con cualquiera."
    "Él suspira, aliviado."
    "Jeff hace círculos con su dedo sobre las sábanas, mientras formaba un puchero."
    J "¿Te seguiría gustando si fuera un gusano?"
    pov "…"
    "Vaya, parece que él es el tipo de alto mantenimiento."

    menu:
        "Si":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Por supuesto, adoro los gusanos."
            J "…"
            J "No-"
            pov "No aprecias mi sarcasmo, lo sé."
            pov "Nunca lo haces, y aún así me amas."
            jump ruta_normal_44
        "No":
            pov "Ew."
            J" … Oh."
            pov "Me gustas porque eres humano, no me aprovecharé de un gusano."
            J "… No era literal."
            pov "¿Qué dices?"
            J "Nada."
            jump ruta_normal_44

    label ruta_normal_44:

    "Jeff se endereza de la cama y estira la espalda. Él suelta un quejido satisfecho, y se pone de pie."
    J "Voy a bañarme."
    play sound "audio/sfx/Equip2.ogg"
    scene room_j with dissolve
    show jeff1 neutral at center
    with dissolve
    "Una de las cosas buenas de esa casa, es que tenía agua, aunque de manera algo ilegal."
    "Jeff mencionó algo sobre bypass al contador."
    "Con que ustedes tuvieran agua, te bastaba."

    menu:
        "Unirte a él":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Voy contigo."
            play sound "audio/sfx/cloth.mp3"
            "Te pones de pie también, pero pronto unas manos sobre tus hombros te detienen."
            show jeff1 angry blush 
            J "Si vas conmigo, será un infierno para mí."
            pov "Pero pensé-"
            J "¡Un infierno!"
            pov "¡Ok, geez!"
            "Él te suelta, y notas cómo sus manos tiemblan levemente y su respiración está agitada."
            "Ah, esa clase de infierno."
            jump ruta_normal_45
        "Dejarlo":
            jump ruta_normal_45

    label ruta_normal_45:

    "Te quedas donde estás, en la habitación."
    hide jeff1 with dissolve
    "Jeff te da una última mirada antes de salir."
    "Miras el alrededor, buscando alguna forma de detenerte."
    "No tenías tu teléfono contigo, y la casa no tenía wifi."
    "Con suerte tenía luz."
    "Así que decides recorrer el lugar."
    jump casa

    label casa:
    window hide
    scene house_j with dissolve
    pause 1.0
    call screen mapa_house

    label habitacion_j:
    scene room_j with dissolve
    "Paseas por el lugar, evitando los escombros."
    "No hay nada además de la cama."
    jump casa

    label sala_j:
    show living_j with dissolve
    "Vas a la sala, e inspeccionas los muebles."
    "El sofá es duro, y el cable de la TV está rota."
    "No tienes mucho qué hacer aquí."
    jump casa

    label cocina_j:
    show kitchen_j with dissolve
    play sound "audio/sfx/609139__nataliafranco__nevera.mp3"
    "Revisas el minirefri."
    "Hay muchas bebidas energéticas."
    "…"
    "Eso explica el insomnio."
    jump casa

    label baño_j:
    scene bathroom_j with dissolve
    "Te quedas junto a la puerta, escuchando el sonido de la ducha."
    "Hay un leve tarareo del otro lado de la puerta."
    "Sólo tienes tu imaginación contigo, por lo que te resignas."
    jump casa

    label sotano:

    stop music fadeout 8.0
    "Hay una puerta de la que no sabes a dónde va."
    "Considerando que esta es una casa prácticamente abandonada, algo te decía que entrar no sería lindo."
    "Pero la curiosidad era más grande."
    play sound "audio/sfx/637493__kyles__door-wood-old-open-hall-echo.mp3"
    "Abres la puerta y el crujido retumba entre las paredes."
    scene black with dissolve
    "Está oscuro, pero por suerte hay un interruptor al costado, por lo que lo apretas y el lugar se alumbra."
    play sound "audio/sfx/348223__tbrook__switch-light-07.mp3"
    scene basementdoor with dissolve 
    "Frente a ti, se extienden hacia abajo unas escaleras."
    "Por supuesto, no faltaba el sótano escalofriante."
    "Tenías la fortuna que Jeff no era de esos que encadenaba en el sótano a prueba de ruido."
    "…"
    "Por ahora."
    "Bajas en silencio, apoyándote en el barandal ante los escalones desgastados."
    "El silencio abunda en el lugar, tus pasos resuenan en el cemento."
    scene basement with dissolve
    "La luz también se encendió abajo, por lo que puedes ver con claridad el lugar."
    "Es espacioso y frío."
    "Las paredes son de piedra y hay algunas tuberías descubiertas, lo que explica el olor a humedad."
    "Pero hay otro olor en el aire."
    "No lo reconoces al inicio, pero te diriges a un rincón donde hay un mueble destartalado."
    "Te asomas para ver mejor."
    play music "audio/music/horror-background-atmosphere-2-289424.mp3"
    window hide
    play sound "audio/sfx/442334__liongrill__jumpscare-sound.mp3"
    show cg38:
        xalign 0.5
        yalign 0.5
        zoom 2.0
        linear 0.1 zoom 1.0
    pause 2.0
    window show

    pov "¡Mierda!"
    "Retrocedes con horror, presenciando un cadáver."
    "Con valentía, lo miras a una distancia prudente, porque la escena es demasiado horrible como para verlo de cerca."
    "Reconoces por el cabello corto y el tamaño que es un hombre, pero su rostro es totalmente irreconocible. Está hinchado y con la piel verdosa."
    "Notas el polvo blanco que tiene encima, y no te cuesta entender que se trata de cal."
    "Si no fuera por la cal, hubieras notado el olor desde el principio."
    "Sientes que la bilis sube por tu garganta, pero tapas la boca como reflejo para evitarlo."
    "Te alejas de la escena para tomar aire."
    "¿Qué mierda?"
    "Jeff… ¿Hizo eso?"
    "Sería lo ideal que él no tuviera nada que ver, pero siendo realistas, lo más probable es que fuera Jeff."
    "Ese… ¿Era el dueño original de la casa?"
    "Jeff había admitido que consigue dinero en sus asesinatos, por lo que no sería raro que hiciera lo mismo con el alojamiento."
    "Él escogió ese barrio peligroso a propósito, porque si la policía aparecía, estarían más ocupados en otras actividades sospechosas típicas del lugar."
    "Era un claro escondite a plena vista."
    "¿Pero qué hay con el tema de que Jeff mató al dueño de la casa y lo puso en el sótano?"
    "Era horrible, lo miraras donde lo miraras."
    "Jeff mató a mucha gente, entre ellos… gente inocente."
    "Nunca viste un ápice de remordimiento de su parte y tú…"
    "Te volviste su cómplice."
    "Sabías que no eras responsable por las acciones de Jeff."
    "Pero si tú no las cuestionabas, ¿No eras igual de horrible que él?"
    "Deberías sentir un rechazo absoluto hacia alguien así."
    "Deberías ser incapaz de charlar amenamente con alguién así."
    "Pero… "
    stop music fadeout 8.0
    "¿Por qué… No puedes odiarlo?"

    menu:
        "Lo amas":
            $ amor = "Si"
            "No puede ser…"
            "De verdad caíste tan bajo como para enamorarte de un asesino despiadado."
            "Habías perdido realmente la cabeza."
            jump charcater_11
        "Sólo te agrada":
            $ amor = "No"
            "Él… Es algo así como un amigo."
            "Si, ustedes se besaron, pero fue sólo eso."
            "No tenías fuertes sentimientos por él."
            jump charcater_11

    label charcater_11:

    play music "audio/music/dedpression-339994.mp3"
    "De cualquier forma, no podías quedarte en el sótano."
    "Seguramente Jeff se pregunte dónde estás si no te ve, y quizás se moleste por tu descubrimiento."
    scene basementdoor with dissolve
    "Subes las escaleras con rapidez, pero conservando precaución ante el deterioro de los escalones."
    scene house_j with dissolve
    "Llegas al pasillo en el momento en que Jeff sale del baño."
    show jeff3 smile at center
    with dissolve
    "Su cabello sigue húmedo, por lo que se lo seca con una toalla."
    J "Ahí estabas, te estaba buscando."
    pov "Seh…"
    "Él frota un extremo de la toalla contra su cabeza y su cabello largo se sacude."
    J "¿Ya te aburriste de mí?"
    "La sonrisa de él es divertida, acentuando su sarcasmo."

    menu:
        "Nunca":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Nunca me aburriría de ti, Jeff."
            show jeff3 smile blush
            "No lo dices precisamente por sus aspectos buenos."
            "Que son muy pocos, o inexistentes."
            "Pero al menos Jeff parece feliz con tu respuesta."
            jump ruta_normal_46
        "Exactamente":
            pov "Bueno, tenía que entretenerme de alguna forma."
            show jeff3 neutral
            J "…"
            "Jeff te mira atentamente, como si quisiera comprenderte."
            jump ruta_normal_46

    label ruta_normal_46:

    stop music fadeout 5.0
    play music "audio/music/romantic-pianobittersweet-romance-324562.mp3"
    "Él siguió frotándose el cabello mojado, que no parecía estar cerca de estar seco."
    pov "… ¿Es muy optimista pensar que podría haber una secadora de pelo aquí?"
    show jeff3 pensativo none
    "Jeff te mira con sarcasmo."
    J "¿En este chiquero?, Obvio que no."
    pov "Entonces déjamelo a mí."
    show jeff3 neutral
    "Extiendes tus manos hacia él, apuntando la toalla."
    "Él te miró en silencio por unos segundos, interrogativo."
    show jeff3 smile blush
    "Pero después pareció entender y su expresión se iluminó."
    J "¡Por supuesto!"
    play sound "audio/sfx/cloth.mp3"
    scene living_j with dissolve
    show jeff3 smile at center
    with dissolve
    "Jeff te extiende la toalla y se apresura a tomar asiento en la sala, mirándote expectante."
    "Te acercas y te colocas detrás de él. Él se gira, para darte la espalda."
    "El cabello de él se extiende frente a ti, brillante y lacio."
    "Empiezas a frotar las puntas suavemente, algunas veces apretando la toalla para quitar el exceso de agua."
    pov "Tienes el pelo muy liso."
    show jeff3 neutral
    J "Antes lo tenía un poco ondulado, pero desde el accidente, quedó así."
    "Ah, claro. No tenías en claro cómo fue exactamente lo que pasó, pero te haces una idea general."
    show jeff3 pensativo
    J "También era castaño."
    pov "…"
    pov "¿Tienes fotos?"
    show jeff3 smile
    "Jeff resopla divertido."
    J "¿De esa época?, Para nada."
    J "…"
    J "Quizás en mi vieja cuenta de tumblr."
    pov "Eres tan emo."
    show jeff3 angry blush
    J "¡No lo-!, ugh."
    "Te ríes ante la protesta de Jeff."
    play sound "audio/sfx/cloth.mp3"
    show jeff3 neutral none
    "Él alza la cabeza, y te mira desde su lugar."
    "Su mirada, comúnmente ida, te mira con suavidad. Una humanidad que ves por primera vez en él. "
    "Continuas frotando su cabello, esta vez en la parte superior de su cabeza."
    J "De todas formas, me veo mejor ahora."
    pov "¿En serio?"
    J "Si, en ese entonces era muy soso. Me comparaban mucho con mi hermano, decían que nos parecíamos mucho."
    pov "Tiene sentido, si son hermanos."
    pov "… ¿Ustedes eran cercanos?"
    J "Si, lo éramos."
    show jeff3 pensativo
    J "…"
    show jeff3 neutral
    J "La verdad, es que ni siquiera sé si está vivo."
    pov "¿Pensé que tu familia estaba muerta?"
    J "Mis padres lo están, estoy seguro de eso."
    J "Pero de Liu… No tanto."
    pov "¿Cómo lo sabes?"
    show jeff3 pensativo
    J "Es… complicado."
    pov "Entiendo, ¿Es otra de tus aventuras?"
    J "Se podría decir."
    pov "Hay tanto sobre ti que me está costando seguir el hilo."
    show jeff3 smile
    "Jeff ríe entre dientes."
    J "No es necesario que sepas cada detalle de mí."
    J "Mejor enfócate en disfrutarme."
    play sound "audio/sfx/Equip2.ogg"
    "Él se endereza y se gira para enfrentarte."
    J "¿Qué parte de mí te gusta más?"

    menu:
        "Ojos":
            show jeff3 smile blush
            J "¿Mis ojos?"
            J "Sí que sabes halagar."
            jump favorito
        "Sonrisa":
            show jeff3 smile blush
            J "¿De verdad te gusta?"
            show jeff3 happy
            J "¡Eso me hace tan feliz!"
            jump favorito
        "Cuerpo":
            show jeff3 neutral blush
            J "…"
            J "Ten cuidado, [povname]."
            jump favorito
        "Calva":
            show jeff3 mad blush
            J "¡Yo no tengo-!"
            "Él se lleva una mano a la cabeza, sintiendo la parte que no tiene cabello."
            show jeff3 angry
            J "Eso no es calva."
            pov "De acuerdo, entradas."
            J "¡Tampoco!; ¡Es parte de mis cicatrices!"
            "Jeff refunfuña, con un puchero."
            jump favorito

    label favorito:

    show jeff3 neutral none
    pov "Eres alguien muy vanidoso, ¿No?"
    "Jeff se encoge de hombros."
    play sound "audio/sfx/cloth.mp3"
    show jeff3 sorpresa blush at jumpscare_top
    with dissolve
    "Rodeas la cabeza de él con la toalla, y tiras suavemente, haciendo que él se incline levemente hacia ti."
    show jeff3 shy
    "Lo miras en silencio, y ves que causa una reacción en él."
    "Sus mejillas se encienden y él desvía la mirada brevemente con timidez."
    "Él… realmente está rendido a ti."
    "Puedes… casi confiar en él."

    menu:
        "Preguntar por el antiguo dueño":
            show jeff3 neutral none
            J "…"
            J "Así que te diste cuenta."
            J "Ya te lo dije, no tienes que actuar con tanta cautela conmigo."
            jump ruta_normal_47
        "Preguntar por el cadáver del sótano":
            $ show_affection("J", 1)
            $afecto += 1
            show jeff3 neutral none
            J "…"
            J "¿Bajaste?"
            "No sabes si suena molesto o no."
            "Pero su tono se había endurecido, lo que te traía malos recuerdos de tus encuentros anteriores con él."
            jump ruta_normal_47

    label ruta_normal_47:

    stop music fadeout 5.0
    pov "Así que lo mataste."
    J "…"
    J "¿Realmente te extraña?"
    pov "No me extraña… Es sólo que…"
    pov "Me sorprendió, eso es todo."
    "Jeff te mira en silencio, pensativo."
    "Su expresión, comúnmente sonriente y maníaca, es extrañamente calma."
    "De hecho, él daba un poco más de miedo cuando era serio."
    pov "Jeff… ¿Has pensado realmente en la situación?"
    J "¿De qué hablas?"
    pov "Hablo de esto."
    "Señalas todo el lugar, las paredes rotas, el suelo lleno de escombros y polvo, los muebles rotos. Ustedes."
    pov "También lo de ayer, con el policía."
    pov "Si me quedo contigo, ¿Vamos a vivir así?"
    play music "audio/music/tension-and-fear-108408.mp3"
    show jeff3 angry
    "Los ojos de Jeff se inyectan en sangre, y su boca forma una mueca."
    play sound "audio/sfx/cloth.mp3"
    "Antes de que te des cuenta, él atrapa tus mejillas entre sus dedos y aprieta, atrayéndote hacia él bruscamente."
    "… Duele."
    J "No hay ninguna condicional en esto, no hay ningún “Si”. Vas a estar conmigo, y punto."
    pov "…"
    "Jeff entierra sus uñas en tu piel, lo que te hace sisear."
    "Él realmente seguía siendo el mismo."
    J "¿Debería arrancarte el otro ojo para que entiendas?"

    menu:
        "Disculparte":
            pov "T-tienes razón."
            pov "Me equivoqué."
            pov "Sólo quería saber cómo viviríamos, eso es todo."
            jump ruta_normal_48
        "Negociar":
            $ show_affection("J", 1)
            $afecto += 1
            pov "No pretendía nada con lo que dije, sólo quería visualizar nuestra vida juntos."
            jump ruta_normal_48

    label ruta_normal_48:

    J "…"
    play sound "audio/sfx/cloth.mp3"
    show jeff3 neutral at jumpscare_reset
    with dissolve
    "Jeff te suelta y guarda distancia."
    "Sientes que vuelves a respirar y que tu corazón se calma."
    J "Vamos a tener que movernos constantemente, para evitar a la policía."
    J "Supongo que podría mejorar los lugares en los que nos quedemos."
    "Él se llevó un dedo a la barbilla, pensativamente."
    J "Quizás intercalar entre casas y hoteles."
    J "Pero no te puedo prometer lujos."
    stop music fadeout 5.0
    pov "Entiendo completamente."
    show jeff3 smile
    play sound "audio/sfx/Equip2.ogg"
    "Jeff sonríe satisfecho con tu respuesta, levantándose del sofá."
    play music "audio/music/romantic-pianobittersweet-romance-324562.mp3"
    J "¿Qué te parece desayunar?"
    pov "Seguro, ¿Pero qué?"
    if dieta == "V":
        J "Conseguí algo de avena y fruta para ti."
    else:
        J "Conseguí unos huevos. Ya cocí algunos."
    pov "Ah, gracias. ¿Vas a comer conmigo?"
    play sound "audio/sfx/Equip2.ogg"
    "Jeff ríe entre dientes, rodeando tus hombros con su brazo y te guió a la cocina."
    scene kitchen_j with dissolve
    show jeff3 smile at center
    with dissolve
    J "Has alterado por completo mi horario, por lo que sí, me uniré a ti."
    "Ustedes llegan a la cocina, y él se dirige al minirefri."
    "Él se agacha, en consecuencia, su camiseta se levanta ligeramente, dejando ver la piel de su espalda baja."
    "A diferencia del resto de su piel pálida, está libre de cicatrices, o por lo que puedes ver."
    "Alzas tu mano y tiras del borde de la camiseta, tratando de regresarla a su lugar."
    show jeff3 sorpresa blush
    "El cuerpo de Jeff se tensa, y se levanta lentamente."
    J "…"
    pov "¿Qué?"
    "Jeff está con las manos vacías, y te mira expectante."
    show jeff3 pensativo
    J "… ¿Tienes hambre de otra cosa, [povname]?"
    "Te alarmas en tu lugar."
    pov "¡Estaba arreglando tu ropa!"
    show jeff3 neutral
    "Jeff te mira en silencio, para después desviar la mirada a un lado."
    "Es tu idea… ¿O está decepcionado?"

    menu:
        "Burlarte":
            pov "¿En serio?"
            pov "¿Estás tan ansioso de contacto físico?"
            show jeff3 pensativo
            "Jeff se remueve en su lugar, con incomodidad."
            jump ruta_normal_49
        "Coquetear":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Vaya, no me lo esperaba."
            pov "¿Tanto quieres que te toque?"
            show jeff3 shy
            "Jeff se remueve en su lugar, con timidez."
            jump ruta_normal_49

    label ruta_normal_49:

    "Niegas levemente con la cabeza, acercándote a él."
    "Jeff se apoya en el borde de la encimera, mirándote con atención, esperando algo."
    play sound "audio/sfx/cloth.mp3"
    "Apoyas ambas manos a ambos lados del cuerpo de él, mirándolo desde tu lugar con una sonrisa ladina."
    pov "¿Estás siendo tímido?"
    show jeff3 neutral
    J "…"
    J "No, sólo quiero recibir lo que me des."
    window hide
    show cg39 with dissolve
    pause 2.0
    window show
    "Tu sonrisa se suaviza, acercándote a él, la distancia entre ustedes es demasiado pequeña como para mantenerla así."
    "Él te mira por unos segundos, para después inclinarse sobre ti."
    play sound "audio/sfx/658348__dversexxxstudio__kiss.mp3"
    "Recibes el beso con calma, habiéndolo esperado."
    "Los labios de Jeff se sienten un poco más suaves contra los tuyos, pero siguen siendo fríos."
    "La mano de él sube y sujeta tu mandíbula con delicadeza, rozando la yema de sus dedos con la piel de tu mejilla."
    play sound "audio/sfx/352345__noahpardo__npx-male-wet-kiss-3.wav"
    "Sientes que la respiración se agita levemente, y él te muerde ligeramente el labio inferior, profundizando el beso."

    menu:
        "Acariciarlo (Sugestivo)":
            play sound "audio/sfx/cloth.mp3"
            window hide
            show cg40 with dissolve
            hide cg39
            pause 1.0
            window show
            "Deslizas lentamente tu mano bajo la camiseta de Jeff, sintiendo la tibia piel de él bajo tus dedos."
            "Acaricias suavemente, sintiendo leves relieves."
            play sound "audio/sfx/457738__magnumdafolf__sensual-breathing.wav" volume 0.5
            J "!!"
            J "[povname]..."
            "Él se separa unos centímetros de ti, mirándote con necesidad."
            pov "Sólo estoy tanteando el terreno."
            "Acompañado de tus palabras, deslizas tu mano hacia la espalda de él, apretando suavemente la piel, acariciando el hundimiento de su zona lumbar."
            J "Ngh… "
            pov "¿Te gustan los simples toques?"
            pov "No puedo imaginar cómo te pondrías haciendo otras cosas."
            J "Ah~... [povname]..."
            "Su voz, generalmente rasposa, se suaviza ante tu toque."
            stop sound
            hide cg40 with dissolve
            jump beso_2
        "Con eso basta":
            jump beso_2

    label beso_2:

    hide cg39 with dissolve
    show jeff3 smile
    "Considerando que con eso tuvo suficiente, recoges tus manos y retrocedes un par de pasos."
    "Miras la condición en la que él está, y te sorprende ver que está ligeramente agitado."
    pov "…"
    pov "¿Tienes experiencia en esto, Jeff?"
    show jeff3 neutral
    J "…"
    show jeff3 shy
    J "Muy poca."
    pov "Ya veo…"
    show jeff3 neutral none
    J "¿Qué hay de ti?"

    menu:
        "Tienes experiencia":
            pov "Claro, si tengo."
            jump character_11
        "No tienes experiencia":
            pov "Nop, pero la imaginación me ayuda."
            jump character_11

    label character_11:

    J "…"
    "Jeff suspira, enderezándose."
    play sound "audio/sfx/346661__deleted_user_2104797__kiss_01.mp3"
    "Se acerca a ti y besa suavemente tu frente."
    J "Desayunemos de una vez."
    scene dinningroom_j with dissolve
    "Tomas asiento en el comedor, esperando a que él vuelva."
    "En realidad, ves que te estás acostumbrando de a poco a la compañía de Jeff."
    "Cuando él estaba de buen humor, te trataba bien, pero… Cuando se enojaba, realmente sacaba lo peor."
    "Eso… Era una razón para preocuparte."
    show jeff3 smile at center
    with dissolve
    "Jeff se acerca y deja frente a ti un plato con tu desayuno."
    "La mesa sigue estando algo sucia, pero los platos y utensilios estaban limpios."
    "Miras cómo él comía en silencio."
    "… Podías ver como un poco de comida se asomaba desde la herida de su boca."
    stop music fadeout 5.0
    show jeff3 neutral
    pov "Tienes algo de comida ahí."
    play music "audio/music/dedpression-339994.mp3"
    "Llamas su atención y apuntas a tu propia boca, para darle la señal."
    "Jeff se lleva una mano a la cara, y nota el pequeño desastre que tiene."
    show jeff3 smile
    J "Oh, esto pasa."
    "…"
    "Si, esto no estaba funcionando del todo para ti."
    "No sólo Jeff no era digno de confianza, era violento, volátil e impredecible."
    "Si en sólo 7 días se enamoró de ti, ¿Cómo sabes si en otros 7 días te va a odiar?"
    pov "…"
    pov "Jeff, tengo algo que preguntarte."
    J "¿Qué es?"
    pov "… ¿Te sigue importando si te temo o no?"
    "Antes parecía muy fijado en que le temas, pero ahora… No sabes lo que realmente quiere."
    show jeff3 neutral
    J "…"
    J "¿Me temes?"

    menu:
        "Si":
            jump miedo
        "No":
            jump miedo

    label miedo:

    J "…"
    show jeff3 smile
    J "Heh…"
    show jeff3 happy
    J "¡Hahaha!"
    "Él ríe estruendosamente, sorprendiéndote."
    "No sabes si preocuparte por esa reacción o no."
    show jeff3 smile
    J "… Hah."
    J "No importaba cuál fuera tu respuesta, no cambia lo que siento por ti."
    J "Tampoco cambiaría nuestra situación."
    show jeff3 neutral
    J "…"
    J "Lo que sí me preocuparía, sería que te aburrieras de mí."
    show jeff3 sad
    J "Tú… ¿Me dirías si empiezas a aburrirte de mí?"

    menu:
        "Desviar el tema":
            pov "Pfft, eso no va a pasar."
            show jeff3 neutral
            "Jeff suspira, resignado."
            jump ruta_normal_50
        "Sí":
            $ show_affection("J", 1)
            $afecto += 1
            pov "Claro."
            "Sabías por experiencia que él prefería la honestidad."
            show jeff3 smile
            "Jeff sonríe satisfecho."
            jump ruta_normal_50

    label ruta_normal_50:

    "Ustedes dejan el tema, y terminan su desayuno."
    scene sky1 with dissolve
    "El resto del día es tranquilo, incluso puedes presenciar a Jeff durmiendo. Cosa que nunca habías visto antes."
    "La realidad parecía estar estableciéndose, y llegó el atardecer."
    "Jeff había mencionado que tenía algunos billetes y que podría comprar una cena para llevar de un restaurante a unas calles."
    stop music fadeout 5.0
    play sound "audio/sfx/765250__damiana79__police-siren.mp3"
    scene living_j with dissolve
    "Pero de repente, se escuchan sirenas de policía."
    "Cada vez se escuchan más fuerte, y parecen ser de varios autos."
    pov "… ¿Jeff?"
    show jeff3 neutral at center
    with dissolve
    play music "audio/music/suspenseful-dark-atmosphere-303538.mp3" 
    "Él se pone de pie y va a la sala, asomándose ligeramente por la ventana."
    "Las luces se asoman por las ventanas, y aunque esperas que pasen de largo, se quedan ahí."
    "Las sirenas se apagan, y puedes ver por la cantidad de luces que al menos hay tres patrullas."
    "Se escucha el chasquido de un megáfono y la voz de alguien resuena."
    Stranger "¡Te tenemos rodeado!"
    Stranger "¡Entrega al rehén!"
    show jeff3 angry
    J "¡Mierda!"
    J "¡Ese hijo de puta alcohólico no sabe quedarse callado!"
    "Claro, era bastante obvio que un tipo que colecciona basura y da lo que sea por brandy no era confiable."
    play sound "audio/sfx/Equip2.ogg"
    show jeff1 angry at center
    with dissolve
    "Jeff se apresura a un rincón de la sala y se coloca su sudadera blanca."
    pov "¿Qué vas hacer?"
    J "¿Entregarme?, ni loco."
    J "Ven."
    play sound "audio/sfx/cloth.mp3"
    "Él toma tu mano fuertemente y tira de ti."
    scene house_j with dissolve
    pov "Pero estamos rodeados, no podemos salir."
    J "Por adelante y atrás no, pero por debajo…"
    "Entiendes lo que él está diciendo cuando se dirige al sótano."
    play sound "audio/sfx/403355__corpocracy__door_slam01.mp3"
    "Escuchas que la puerta de la entrada es azotada."
    DS "¡[povname]!"
    scene basement with dissolve
    show jeff1 angry at center
    with dissolve
    "Reconoces esa voz, pero cuando llegas al sótano, Jeff te suelta y va a un extremo del lugar."
    pov "¿A dónde vamos ahora?"
    "Jeff forcejea con algo en el suelo, y ves que levanta un pedazo de cemento que lleva a un lugar abajo."
    "Vaya, que conveniente."
    J "Por las alcantarillas."
    pov "Ew…"
    show jeff1 mad
    J "¡[povname]!"
    pov "¡Ok, ok!"
    "Obedeces y bajas por la abertura."
    scene sewer with dissolve
    "Caes en el interior de una alcantarilla, el agua bajo tus pies chapotea por tus movimientos."
    play sound "audio/sfx/cloth.mp3"
    show jeff1 angry at center
    with dissolve
    "Jeff salta después de ti y tira de tu brazo."
    J "¡Vamos!, ¡Nos siguen de cerca!"
    play sound "audio/sfx/528595__robinhood76__09358-running-into-lake-water.mp3"
    "Ustedes corren, escuchando como varias personas los siguen por detrás."
    "Entre la prisa, logras avistar el final del túnel."
    pov "¿A donde vamos después?"
    J "…"
    pov "¿Jeff?"
    J "¡Cállate!, ¡Estoy pensando!"
    play sound "audio/sfx/hang.mp3"
    scene sewerexit with dissolve
    show jeff1 angry at center
    with dissolve
    "El agarre en tu brazo se vuelve más fuerte, lo que te lastima."
    "Ustedes salen a un arroyo en medio del bosque, y Jeff apresura el paso."
    pov "¿No nos vamos a perder?"
    J "…"
    "Jeff permanecía en silencio, respirando agitadamente."
    "Parecía… Realmente un criminal buscado."
    "Te has metido en un problema muy grande."
    scene woods with dissolve
    play sound "audio/sfx/508142__headwalker__running-in-the-woods.wav"
    show jeff1 angry at center
    with dissolve
    "Ustedes se adentran en el bosque, pero tras encontrarse luces provenientes de linternas, toman un desvío."
    "Sucede lo mismo por el otro camino, ustedes están arrinconados."
    "No tienen de otra que seguir recto, pero adelante sólo hay…"
    scene cliff with dissolve
    show jeff1 sorpresa at center
    with dissolve
    "Ustedes llegan al borde del barranco, y Jeff finalmente te suelta."
    "A lo lejos, a la entrada del bosque, se reúnen las luces y avanzan hacia ustedes a gran velocidad."
    pov "Jeff…"
    show jeff1 angry
    J "Mierda, mierda, ¡Mierda!"
    "Las personas se acercan más."
    "La multitud es una sombra, pero puedes decir que son muchos."
    "Ustedes no tienen salida."

    if afecto < 45:
        jump e_final_malo
    elif 45 <= afecto < 50:
        jump e_final_neutral
    elif afecto >= 50:
        jump e_final_verdadero


    label e_final_malo:

    menu:
        "Quedarse con él":
            jump final_muerte

    label e_final_neutral:

    menu:
        "Quedarse con él":
            jump final_muerte
        "Tienes miedo...":
            jump final_neutral

    label e_final_verdadero:

    menu:
        "Quedarse con él":
            jump final_muerte
        "Tienes miedo...":
            jump final_neutral
        "...":
            jump final_verdadero

    label final_muerte:
    stop music fadeout 3.0
    pov "Jeff…"
    play music "audio/music/dark-and-scary-wind-9658.mp3"
    "Suavemente, alcanzas la mano de él, y entrelazas sus dedos."
    show jeff1 sad
    "Jeff te mira desesperado, pero al encontrarse con tus ojos, se tranquiliza."
    J "[povname]... Te amo."
    "Tu le sonríes afectuosamente."
    "El sonido de los pasos de las personas se acercan, acompañados por voces desesperadas, gritando que se detengan."
    "Ustedes se enfrentan al acantilado, sintiendo la brisa del mar golpearlos, como si les estuviera advirtiendo de lo que los esperaba."
    "Apretaste la mano de él, con decisión."
    "Ustedes dan un paso al frente, y el suelo desaparece de sus pies."
    scene black with fade
    "Lo último que sientes, es el viento chocando con tu rostro, y el agarre en tu mano que nunca se soltó."
    show Death with fade
    pause 2.0
    "{b}Final VII: Juntos Para Siempre{/b}"
    return

    label final_neutral:

    stop music fadeout 3.0
    pov "Jeff… Tengo miedo."
    play music "audio/music/dedpression-339994.mp3"
    play sound "audio/sfx/cloth.mp3"
    "Jeff sujeta tus mejillas entre sus manos, y te mira sin saber qué hacer."
    show jeff1 smile
    "Sintiendo que los demás se acercan, los hombros de él caen con resignación, y él te sonríe con tristeza."
    J "Hah, logré que temieras por tu vida."
    play sound "audio/sfx/Gun1.ogg"
    "Tienes las palabras en la boca, escuchas el sonido de un disparo demasiado cerca como para alarmarte."
    show jeff1 hurt shot
    "El pecho de Jeff se tiñe de rojo, y una fuerza lo empuja hacia el acantilado."
    hide jeff1 with dissolve
    pov "¡NO!"
    play sound "audio/sfx/Equip2.ogg"
    "Tratas de alcanzar la mano de él, y seguramente hubieras caído también si la alcanzabas, pero un agarre en tu cintura te lo impide."
    DS "¡[povname]!, ¡Ya acabó!"
    "Tratas de liberarte, sintiendo que las lágrimas corren por tus mejillas."
    pov "¡Jeff, Jeff!"
    "Llamas su nombre, pues aún recuerdas a unos instantes atrás, estaba a tu lado."
    play sound "audio/sfx/falling.mp3"
    "Sean te obliga a caer sobre tus rodillas, y te rompes por completo."
    play sound "audio/sfx/cloth.mp3"
    "Ella te envuelve en tus brazos, pero no se siente del todo bien."
    DS "Ssh, ya acabó…"
    "Su voz es tranquilizante, pero no te consuela por completo."
    scene black with fade
    stop music fadeout 5.0
    pause 2.0
    "…"
    scene office with dissolve
    play music "audio/music/lofi-relax-music-lofium-123264.mp3" 
    pov "Así que eso pasó."
    T "…"
    T "Por como lo veo yo, [povname], lograste lo que muchos no han podido."
    T "Pudiste sobrevivir."
    pov "… ¿Entonces porque siento que algo está mal?"
    T "Construiste una relación socio-afectiva con Jeff. Él se volvió el monstruo y tu salvador a la vez, es difícil desligarse de alguien que significó tanto para ti."
    pov "…"
    T "Con el tiempo, podrás llenar el vacío que él dejó. Es parte del proceso de sanar."
    "Te mantienes en silencio, tratando de encontrar un lugar en tu mente que acepte lo que el terapeuta está diciendo."
    T "Nuestro tiempo se acabó, ¿Alguien viene por ti?"
    if ruta == "S":
        pov "Sí, Paul me está esperando afuera."
        "Resulta que él pudo ser llevado al hospital a tiempo."
        "Fue la primera persona a la que viste cuando te recuperaron."
    else:
        pov "Cindy no tarda nada en llegar."
        "Resulta que ella pudo ser llevada al hospital a tiempo."
        "Fue la primera persona a la que viste cuando te recuperaron."
    T "Ah, veo que ustedes siguen en contacto."

    menu:
        "Estamos saliendo":
            "No te costó mucho entender que era mucho mejor salir con alguien que estaba bien de la cabeza."
            jump final_n
        "Nuestra amistad creció":
            if ruta == "S":
                "Él fue el que te convenció de ir a terapia, por más que te negaras."
            else:
                "Gracias a su compañía, lograste muchas cosas, incluso volver al trabajo."
            jump final_n

    label final_n:

    T "Me alegro por ti."
    "Asientes por la simple cortesía."
    scene streetday with dissolve
    "Sales de la consulta, y respiras profundamente, sintiendo que un gran peso se liberaba de tus hombros."
    if ruta == "S":
        show salazar2 smile at center
        with dissolve
        DR "¿Cómo te fue?"
        pov "Bien, hablé mucho."
        "Salazar sonríe cálidamente."
        "Su brazo ya había sanado."
    else:
        show cindy3 neutral at center
        with dissolve
        C "¿Todo bien?"
        "Sientes el toque en tu hombro, y asientes con una pequeña sonrisa."
        "Lejos de ocultar la cicatriz que le ocasionó el incidente, lo portaba con orgullo."

    scene sky1 with dissolve
    "Ustedes caminan por la calle, bajo la luz del sol y con un silencio cómodo."
    "No sabes lo que te depara de ahora en adelante."
    "Nunca olvidarás lo que sucedió esa semana."
    "Nunca olvidarás a Jeff, lo que te hizo sentir y cuestionar."
    "Pero sabes con seguridad, que todo acabó. Tu vida volvió a la normalidad."
    "{b}Final Normal: Vivirá En Tu Memoria{/b}"
    jump credits_fear_me

    label final_verdadero:

    pov "Jeff… Ven aquí."
    play sound "audio/sfx/cloth.mp3"
    show jeff1 neutral at jumpscare_top
    with dissolve
    "Jeff te mira con duda, pero obedece."
    "Sujetas su cabeza entre tus manos, y lo atraes hacia ti."
    "Rozas tus labios contra la oreja de él, y susurras algo en voz baja."
    show jeff1 sorpresa
    "Él se sobresalta, y cuando se endereza, te mira con desconcierto."
    "Tú le sonríes."
    DS "¡Quieto!"
    "Escuchas cómo los policías llegaron a ustedes, por lo que actúas con rapidez."
    play sound "audio/sfx/Equip2.ogg"
    "Pones tus manos sobre el pecho de Jeff, y empujas con todas tus fuerzas."
    show jeff1 sorpresa at jumpscare_reset
    with dissolve
    "Jeff no puso resistencia, y mientras caía hacia el vacío, pudiste ver sus ojos desorbitados, observándote."
    hide jeff1 with dissolve
    "Miras abajo desde el borde del acantilado, y sientes que alguien se pone a tu lado."
    "Por el rabillo del ojo, sabes que se trata de Sean."
    pov "Ya todo acabó."
    scene black with fade
    stop music fadeout 5.0
    pause 2.0
    "…"
    scene office with dissolve
    play music "audio/music/creepy-ambient-soundscape-360808.mp3"
    pov "Y eso pasó."
    T "…"
    "El terapeuta mira el suelo pensativamente."
    T "Bueno, definitivamente… El mérito es tuyo."
    T "Lograste vencer el mal que te acechaba, no tienes que sentirte culpable."
    T "Fue en defensa propia, eras tú o él."
    pov "Claro."
    T "…"
    T "¿Cómo te sientes al respecto?"
    pov "…"

    menu:
        "Diferente":
            pov "Bueno, definitivamente me siento diferente."
            pov "Maté a alguien."
            jump final_v
        "Normal":
            pov "Como siempre."
            "… Como si siempre hubiera algo dentro de ti que estaba mal."
            jump final_v

    label final_v:

    T "…"
    T "¿Sigues viviendo por tu cuenta?"
    pov "Sip, pero me cambié a otro departamento."
    T "Entonces, ¿No vives con nadie?"
    pov "No, es un departamento pequeño."
    T "… De acuerdo, por lo que veo, no sientes tanto apego hacia él."
    T "Eso… Supongo que es porque tienes una mente fuerte."
    pov "Gracias."
    T "Pero… Me gustaría que siguieras viniendo, para ver cómo te sientes en tu vida normal."
    play sound "audio/sfx/cloth.mp3"
    "Te encoges de hombros, poniéndote de pie al ver que tu hora ya terminó."
    pov "De acuerdo, ¿El próximo mes?"
    T "… Que sea la próxima semana."
    pov "Ok."
    scene streetday with dissolve
    "Sales de la consulta, y viéndote en la calle concurrida de día, sientes que tus hombros se relajan."
    "Tu vida había vuelto casi a la normalidad, con la excepción de que te mudaste y cambiaste de trabajo."
    "Muchos dirían que lo que pasaste fue un infierno, pero para ti, fue algo especial."
    "Tu… Extrañabas a Jeff. Y no eras tan idiota como para admitirlo con el terapeuta."
    if amor == "Si":
        "Lo amabas, después de todo."
    else:
        "Fue tu amigo, después de todo."
    "Su risa estruendosa, su cabello largo revuelto, sus manos blancas sujetando tu rostro."
    "Extrañabas todo."
    "Así que te aferrabas a la promesa que hiciste ese día."
    window hide
    scene cliff with dissolve
    pause 1.0
    window show
    pov "… Te estaré esperando."
    scene black with fade
    "No explicaste mucho, y aún así, Jeff pareció comprenderlo."
    "Porque él siempre logra escapar."
    "Así que aprovechaste la conveniencia de la que él goza, sabiendo que él sobreviviría."
    "..."
    scene newroom with dissolve
    "Ya habían pasado semanas de lo ocurrido, pero él aún no aparecía…"
    "Se estaba tomando su tiempo, eso es seguro."
    "Pero volvería, lo sabías."
    window hide
    scene newroom2 with dissolve
    pause 2.0
    scene black with fade
    pause 1.0
    "{b}Final Verdadero: Viene Por Ti{/b}"
    jump credits_fear_me

    label credits_fear_me:
    $ quick_menu = False
    scene black with fade
    window hide
    pause 2.0

    show text _("{size=70}{color=#27BBF5}Guión, Arte y Programación{/color} by Neesa Complex")
    with dissolve

    pause 2.0

    hide text
    with fade


    show text _("{size=70}{color=#EC96FF}Traducción al Ruso{/color} by regisvinex")
    with dissolve

    pause 2.0

    hide text
    with fade

    show screen credits_music
    with dissolve

    pause 6.0

    hide screen credits_music
    with fade

    show text _("{size=70}{color=#D90000}Jeff The Killer{/color} by Jeff 'Sesseur' Case and 'GameFuelTV'{/size}")
    with dissolve
    pause 2.0

    hide text
    with fade

    show text _("{size=70}Muchas gracias por jugar{/size}")
    with dissolve
    pause 2.0

    hide text
    with fade

    show text _("{size=70}Si quieres seguir viendo mis proyectos, no dudes en apoyarme *{/size}")
    with dissolve
    stop music fadeout 3.0
    pause 4.0

    hide text
    with fade

    return
