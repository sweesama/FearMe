﻿# TODO: Translation updated at 2025-10-24 16:08

# game/script.rpy:84
translate english start_253e915d:

    # "La habitación está en silencio, iluminada por la cálida luz del mediodía que se filtra por la ventana."
    "The room was silent, illuminated by the warm midday light filtering through the window."

# game/script.rpy:85
translate english start_5bd4202f:

    # "Miras a cualquier parte que no sea tu terapeuta. Aún no tenías la confianza de hablar con familiaridad."
    "You looked anywhere but at your therapist. You didn't yet feel comfortable enough to speak freely."

# game/script.rpy:86
translate english start_6c536a08:

    # "Asistir a esas sesiones se sentía como tarea. Más que por tu bien, parecía ser una manera de vigilarte."
    "Attending these sessions felt like a chore. More than for your own good, it seemed like a way to keep an eye on you."

# game/script.rpy:87
translate english start_d3cf8ed6:

    # T "Sabes que no tienes obligación de hablar de él."
    T "You know you have no obligation to talk about him."

# game/script.rpy:88
translate english start_9a1d3ee0:

    # "El terapeuta te miraba con paciencia, apoyando su espalda en el respaldo de su sillón con calma."
    "The therapist watched you patiently, leaning calmly against the back of his armchair."

# game/script.rpy:89
translate english start_317bbe28:

    # T "Puedes hablar de lo que quieras."
    T "You can talk about whatever you want."

# game/script.rpy:90
translate english start_e427c5c8:

    # "Tú resoplas con ironía, sin dar respuesta."
    "You scoffed ironically, offering no reply."

# game/script.rpy:91
translate english start_03a479b0:

    # T "Fueron 7 días. Suficiente para que alguien cambie, ¿No crees?"
    T "It had been 7 days. Enough time for someone to change, don't you think?"

# game/script.rpy:92
translate english start_ce4635fc:

    # "Instintivamente, alzas la mano al lado izquierdo de tu rostro, donde tienes un parche cubriendo el lugar de tu ojo izquierdo."
    "Instinctively, you raised your hand to the left side of your face, where a patch covered your left eye."

# game/script.rpy:93
translate english start_a6f596a2:

    # T "Te hizo daño, no hay duda de eso. La policía, el hospital... todos tienen su versión. Pero yo quiero la tuya."
    T "He hurt you, there's no doubt about it. The police, the hospital... everyone has their version. But I want yours."

# game/script.rpy:94
translate english start_c191c049:

    # "Te encoges de hombros."
    "You shrugged."

# game/script.rpy:95
translate english start_01299a9d:

    # T "Está bien. El silencio es una respuesta."
    T "That's fine. Silence is an answer."

# game/script.rpy:96
translate english start_05c4662d:

    # "Miras hacia la ventana, en el vidrio se distinguía la silueta de tu reflejo."
    "You looked towards the window; your reflection's silhouette was visible in the glass."

# game/script.rpy:97
translate english start_4e6749f3:

    # "A pesar de que no te veías con tanta claridad, tu postura y expresión eran notablemente diferentes a una semana atrás."
    "Even though you couldn't see yourself clearly, your posture and expression were noticeably different from a week ago."

# game/script.rpy:115
translate english start_81875c7e:

    # "El inicio de tu turno es como el botón “Comenzar” de tu vida."
    "The start of your shift is like your life's 'Start' button."

# game/script.rpy:116
translate english start_7956f306:

    # "Tienes una rutina clara, despertar, trabajar y dormir."
    "You have a clear routine: wake up, work, and sleep."

# game/script.rpy:117
translate english start_f9519c9e:

    # "No tienes un legado, no tienes ambiciones, no tienes asuntos pendientes."
    "You have no legacy, no ambitions, no pending matters."

# game/script.rpy:118
translate english start_27975d0e:

    # "Cumpliste con tus deberes como estudiante y terminaste la escuela."
    "You fulfilled your duties as a student and finished school."

# game/script.rpy:119
translate english start_06baf93d:

    # "Pero no tienes motivaciones para perseguir un sueño o una meta más allá de donde estás ahora."
    "But you lack the motivation to pursue a dream or a goal beyond where you are now."

# game/script.rpy:120
translate english start_eb9e088b:

    # "Sientes como si no tuvieras el un rol protagónico en el mundo, porque nada en especial te ha sucedido (todavía)."
    "You feel as if you don't have a starring role in the world, because nothing special has happened to you (yet)."

# game/script.rpy:121
translate english start_d36386ed:

    # "De hecho, se podría decir que te dejas llevar por la apatía."
    "In fact, one could say you let apathy guide you."

# game/script.rpy:122
translate english start_b6d0f08b:

    # "Una apatía que te hace sentir las emociones fuertes entumecidas."
    "An apathy that numbs your strong emotions."

# game/script.rpy:123
translate english start_08a745d8:

    # "¿Una vuelta en una montaña rusa?, Agradable, ¿Te tropiezas y caes de bruces en el suelo en público?, No es el fin del mundo."
    "A roller coaster ride? Pleasant. You trip and fall face-first in public? Not the end of the world."

# game/script.rpy:124
translate english start_da9d8111:

    # "Positivo o negativo, tu rango de emociones era muy bajo."
    "Positive or negative, your emotional range was very low."

# game/script.rpy:125
translate english start_a208fb7d:

    # "Como un perfecto papel en blanco."
    "Like a perfect blank canvas."

# game/script.rpy:126
translate english start_b6582220:

    # "De todas maneras, intentas hacer tu vida lo más cómoda posible."
    "Anyway, you try to make your life as comfortable as possible."

# game/script.rpy:127
translate english start_ff063798:

    # "Por más raro que suene, trabajas en una tienda de películas que sólo atrae a nostálgicos y a cinéfilos."
    "As strange as it sounds, you work at a video store that only attracts nostalgics and cinephiles."

# game/script.rpy:132
translate english start_93385125:

    # "La principal razón por la que tomaste el empleo es porque es algo que te gusta."
    "The main reason you took the job is because you like it."

# game/script.rpy:133
translate english start_7603bb79:

    # "Puedes pasar horas viendo películas y nunca aburrirte."
    "You can spend hours watching movies and never get bored."

# game/script.rpy:139
translate english start_b19502e2:

    # "No te entusiasman mucho."
    "They don't excite you much."

# game/script.rpy:140
translate english start_3fae0c89:

    # "El hecho de que para hacer bien tu trabajo debes saber al menos una película decente de cada género, lo hace más conveniente."
    "The fact that to do your job well you need to know at least one decent movie from every genre makes it more convenient."

# game/script.rpy:141
translate english start_4916808c:

    # "Ni siquiera tienes que verlas, con sólo tomar la opinión de personas a las que si les gustan las películas puedes arreglártelas."
    "You don't even have to watch them; you can just get by with opinions from people who do like movies."

# game/script.rpy:147
translate english character_1_a887f9b8:

    # "El lugar es lo suficientemente colorido como para no deprimirte con sólo estar ahí, y si tienes suerte, puedes encontrarte uno que otro personaje."
    "The place is colorful enough not to depress you just by being there, and if you're lucky, you might run into an interesting character or two."

# game/script.rpy:148
translate english character_1_d8769169:

    # "Claro, aparte de los personajes que ya existen."
    "Of course, besides the characters that already exist."

# game/script.rpy:151
translate english character_1_a8a411d2:

    # C "¿Recuperando el tiempo perdido?"
    C "Catching up on lost time?"

# game/script.rpy:152
translate english character_1_a129665b:

    # C "Por un momento pensé que no vendrías."
    C "For a moment I thought you wouldn't come."

# game/script.rpy:153
translate english character_1_8c90e6ad:

    # "Cindy, tu compañera de trabajo."
    "Cindy, your coworker."

# game/script.rpy:154
translate english character_1_2b3eedb2:

    # "No es muy buena en lo que hace, lo cual es decir mucho ya que ser dependiente de una tienda perdida en el tiempo no requiere mucho esfuerzo, pero es la hija del dueño."
    "She's not very good at her job, which is saying a lot since being an attendant at a time-lost store doesn't require much effort, but she's the owner's daughter."

# game/script.rpy:155
translate english character_1_3c709925:

    # "Tú eres la otra persona que trabaja full-time, y te desempeñas bien."
    "You're the other full-time employee, and you do well."

# game/script.rpy:156
translate english character_1_cfa5e664:

    # "Ustedes no se llevan ni muy bien ni muy mal, se soportan."
    "You two don't get along great, nor terribly; you tolerate each other."

# game/script.rpy:157
translate english character_1_fe42fed0:

    # C "¿Dónde está tu credencial?"
    C "Where's your badge?"

# game/script.rpy:158
translate english character_1_06dd4662:

    # "Instintivamente te llevaste la mano al cuello, y efectivamente, tu credencial de empleado no estaba."
    "Instinctively you reached for your neck, and indeed, your employee badge wasn't there."

# game/script.rpy:159
translate english character_1_5eb31b77:

    # C "Es raro, pero siento que no puedo decir tu nombre sin tu credencial."
    C "It's strange, but I feel like I can't say your name without your badge."

# game/script.rpy:160
translate english character_1_b4b58704:

    # "Cindy se encogió de hombros y se retiró a la trastienda con una caja llena de películas."
    "Cindy shrugged and retreated to the back room with a box full of movies."

# game/script.rpy:162
translate english character_1_a909a2a2:

    # "De alguna manera, lo que te dijo ella tenía algo de sentido."
    "Somehow, what she said made sense."

# game/script.rpy:163
translate english character_1_d77d6979:

    # "Es como si tampoco pudieras recordar tu nombre si no estaba escrito frente a ti."
    "It was as if you couldn't remember your own name unless it was written right in front of you."

# game/script.rpy:164
translate english character_1_0e463432:

    # "Como si los nombres solo existieran si alguien más los decía en voz alta."
    "As if names only existed if someone else spoke them aloud."

# game/script.rpy:165
translate english character_1_4c099ea6:

    # "Bueno, recordabas haberlo sacado entre tus cosas cuando llegaste, lo más seguro es que estaba en la tienda."
    "Well, you remembered taking it out of your things when you arrived, so it was most likely still in the store."

# game/script.rpy:177
translate english mostrador_8305cafb:

    # "Revisas detrás del mostrador, en el suelo no hay nada."
    "You checked behind the counter, nothing on the floor."

# game/script.rpy:186
translate english trastienda_b77e0aa2:

    # "Tal vez lo hayas dejado caer en la trastienda, pero sólo te encontraste a Cindy viendo su teléfono junto a las cajas que se había llevado."
    "Maybe you dropped it in the back room, but you only found Cindy looking at her phone next to the boxes she'd taken back."

# game/script.rpy:187
translate english trastienda_847d2c02:

    # "Cindy te dio una mirada rápida, para luego volver a ignorarte."
    "Cindy gave you a quick glance, then went back to ignoring you."

# game/script.rpy:188
translate english trastienda_e4c1a3b9:

    # "Tú seguiste su ejemplo y te enfocas en buscar tu credencial."
    "You followed her example and focused on finding your badge."

# game/script.rpy:190
translate english trastienda_da6cbd4e:

    # "Sip, no estaba ahí."
    "Nope, it wasn't there."

# game/script.rpy:197
translate english pasillo1_3e0a8a07:

    # "Entre los estantes llenos de películas de acción, tu credencial no está ahí."
    "Among the shelves full of action movies, your badge was nowhere to be found."

# game/script.rpy:203
translate english pasillo2_37ce519a:

    # "Te inclinas para intentar ver mejor el suelo, con esperanza de que tu credencial esté por ahí."
    "You leaned down to try and get a better look at the floor, hoping your badge was around somewhere."

# game/script.rpy:204
translate english pasillo2_cf1b11af:

    # "Avanzas por el pequeño pasillo, determinado por estanterías llenas de películas de terror y thriller."
    "You moved down the small aisle, determined, past shelves packed with horror and thriller movies."

# game/script.rpy:218
translate english movimiento_1_cec488aa:

    # "Hasta que visualizas el inconfundible pedazo de plástico, casi llegando al final del pasillo."
    "Until you spotted the unmistakable piece of plastic, almost at the end of the aisle."

# game/script.rpy:220
translate english movimiento_1_610313c8:

    # "Estás por alcanzar tu credencial, pero una mano blanca se te adelanta, recogiendo con lentitud el pedazo de plástico."
    "You were reaching for your badge, but a white hand got there first, slowly picking up the plastic piece."

# game/script.rpy:224
translate english movimiento_1_7eabdc81:

    # "Miras hacia arriba y te encuentras con un hombre alto, encapuchado y con la cara cubierta."
    "You looked up and found yourself facing a tall, hooded man with his face covered."

# game/script.rpy:225
translate english movimiento_1_6eb89af0:

    # "Parece un criminal en potencia, o alguien resfriado."
    "He looked like a potential criminal, or someone with a bad cold."

# game/script.rpy:226
translate english movimiento_1_483996b9:

    # "Pero no tienes energías de preocuparte."
    "But you didn't have the energy to worry."

# game/script.rpy:227
translate english movimiento_1_1227d9d5:

    # "Te enderezas en tu lugar, quedando frente a frente."
    "You straightened up, standing face to face."

# game/script.rpy:228
translate english movimiento_1_7e21fbc4:

    # "El hombre parece ignorarte, más interesado en tu credencial en su mano."
    "The man seemed to ignore you, more interested in your badge in his hand."

# game/script.rpy:229
translate english movimiento_1_2e8071c4:

    # Stranger "¿Es tuya?"
    Stranger "Is this yours?"

# game/script.rpy:230
translate english movimiento_1_10d2bb24:

    # "Su voz, suavizada por la tela, es grave y ligeramente rasposa."
    "His voice, muffled by the fabric, was deep and slightly raspy."

# game/script.rpy:231
translate english movimiento_1_67183082:

    # "Asientes en silencio, mirando con sospecha al hombre."
    "You nodded silently, looking at the man suspiciously."

# game/script.rpy:232
translate english movimiento_1_d0b58d2b:

    # "Por el cómo ladeó la cabeza."
    "By the way he cocked his head."

# game/script.rpy:233
translate english movimiento_1_c542e169:

    # Stranger "Pruébalo."
    Stranger "Prove it."

# game/script.rpy:234
translate english movimiento_1_e3c35191:

    # "Ahora, por fin puedes visualizar tu nombre."
    "Now, you could finally visualize your name."

# game/script.rpy:236
translate english movimiento_1_860c11db:

    # Stranger "…."
    Stranger "..."

# game/script.rpy:237
translate english movimiento_1_fe36de0d:

    # "El hombre mira en silencio la credencial, y por un momento de verdad pensaste que quizás te equivocaste después de todo, pero entonces él te ofreció el pedazo de plástico."
    "The man looked at the badge in silence, and for a moment you truly thought you might have been wrong after all, but then he offered you the piece of plastic."

# game/script.rpy:238
translate english movimiento_1_d372c5a4:

    # Stranger "De acuerdo, [povname]."
    Stranger "Alright, [povname]."

# game/script.rpy:239
translate english movimiento_1_39cf6bbb:

    # "Recibes la credencial en tus manos, dedicándole una mirada al tipo."
    "You took the badge in your hands, giving the guy a look."

# game/script.rpy:242
translate english movimiento_1_79558830:

    # pov "Gracias, señor."
    pov "Thanks, mister."

# game/script.rpy:243
translate english movimiento_1_f1124ab9:

    # Stranger "… No me digas así, no soy tan viejo."
    Stranger "Don't call me that, I'm not that old."

# game/script.rpy:244
translate english movimiento_1_2c3a1f62:

    # pov "Lo siento, pero no tengo manera de saberlo cuando no veo tu cara."
    pov "Sorry, but I have no way of knowing when I can't see your face."

# game/script.rpy:245
translate english movimiento_1_a60ecf05:

    # Stranger "Mmh, supongo que tienes un punto."
    Stranger "Hmm, I guess you have a point."

# game/script.rpy:246
translate english movimiento_1_101a4993:

    # pov "Además, por la piel de tus manos, puedo decir que no eres exactamente un jovencito-"
    pov "Besides, from the skin on your hands, I can tell you're not exactly a young fella—"

# game/script.rpy:247
translate english movimiento_1_8fe33072:

    # Stranger "Sí, ya entendí."
    Stranger "Yeah, I get it."

# game/script.rpy:248
translate english movimiento_1_8125bf81:

    # "La voz del sujeto se escuchaba irritada."
    "The guy's voice sounded irritated."

# game/script.rpy:249
translate english movimiento_1_a6b9f3b4:

    # "Una parte de ti te decía que debías ser más “dulce” con los clientes, pero si con tu palabrería lograste molestarlo, podrías considerarlo un logro."
    "A part of you said you should be more 'sweet' with customers, but if you managed to annoy him with your chatter, you could consider it an achievement."

# game/script.rpy:250
translate english movimiento_1_7ca2858d:

    # "Este tipo te daba mala espina."
    "This guy gave you bad vibes."

# game/script.rpy:256
translate english movimiento_1_5b5434cf:

    # pov "¿Quién eres?, ¿La seguridad de credenciales?"
    pov "Who are you? The badge security?"

# game/script.rpy:257
translate english movimiento_1_744cff50:

    # "El hombre se encoge de hombros, despreocupado."
    "The man shrugged, unconcerned."

# game/script.rpy:258
translate english movimiento_1_7c26673f:

    # Stranger "Sólo quería asegurarme de dárselo a la persona correcta."
    Stranger "I just wanted to make sure I gave it to the right person."

# game/script.rpy:259
translate english movimiento_1_c25af955:

    # pov "Evidentemente trabajo aquí."
    pov "I clearly work here."

# game/script.rpy:260
translate english movimiento_1_ad5c7e03:

    # "Él se ríe entre dientes."
    "He chuckled."

# game/script.rpy:261
translate english movimiento_1_9c70edbe:

    # Stranger "Sí~ pero podría haberle pertenecido a algún otro trabajador."
    Stranger "Yeah~ but it could've belonged to someone else."

# game/script.rpy:262
translate english movimiento_1_b459f57e:

    # pov "Literalmente tiene mi foto impresa."
    pov "It literally has my photo printed on it."

# game/script.rpy:263
translate english movimiento_1_58d49fe9:

    # "El sujeto restó importancia con un gesto de mano."
    "The man waved it off dismissively."

# game/script.rpy:264
translate english movimiento_1_9a7ea173:

    # Stranger "¿Hubieras preferido que le diera tu credencial a cualquiera con uniforme que la reclame como suya?"
    Stranger "Would you have preferred I gave your badge to just any uniformed person who claimed it was theirs?"

# game/script.rpy:265
translate english movimiento_1_e95c90d2:

    # "Su lógica era extrañamente convincente."
    "His logic was strangely convincing."

# game/script.rpy:266
translate english movimiento_1_8c85875e:

    # pov "… Supongo que no."
    pov "I guess not."

# game/script.rpy:267
translate english movimiento_1_5d017620:

    # "El hombre ladeó la cabeza con burla."
    "The man cocked his head with a smirk."

# game/script.rpy:268
translate english movimiento_1_948bcf69:

    # "No podías verlo por la bandana, pero sabías que estaba sonriendo."
    "You couldn't see it through the bandana, but you knew he was smiling."

# game/script.rpy:269
translate english movimiento_1_902577b0:

    # Stranger "¿Ves?, no soy tan malo."
    Stranger "See? I'm not so bad."

# game/script.rpy:270
translate english movimiento_1_6af11f3e:

    # "Que él dijera eso te hizo pensar lo contrario."
    "The fact that he said that made you think the opposite."

# game/script.rpy:276
translate english ruta_normal_1_14868465:

    # "Te colocas en silencio la credencial en tu cuello, mientras él seguía inmóvil en su lugar."
    "You silently put the badge around your neck, while he remained motionless in his spot."

# game/script.rpy:277
translate english ruta_normal_1_bd2ca35a:

    # "Te moviste lentamente en dirección al mostrador."
    "You slowly moved towards the counter."

# game/script.rpy:278
translate english ruta_normal_1_4e5bde80:

    # "El tipo te miró fijamente mientras te movías, lo que hizo empeorar tu incomodidad."
    "The guy stared at you as you moved, which only made your discomfort worse."

# game/script.rpy:280
translate english ruta_normal_1_8af99058:

    # "Decidiste ignorarlo, desviando tu atención a uno de los monitores junto a ti."
    "You decided to ignore him, shifting your attention to one of the monitors next to you."

# game/script.rpy:281
translate english ruta_normal_1_e5cd9c3c:

    # "Podrías, si el sujeto encapuchado de antes dejara de darse tantas vueltas por la tienda de manera sospechosa."
    "You could, if the hooded guy from before would stop wandering around the store so suspiciously."

# game/script.rpy:282
translate english ruta_normal_1_560c188e:

    # "Lo ignorabas con todas las ganas, pero era imposible no notarlo."
    "You tried your best to ignore him, but it was impossible not to notice him."

# game/script.rpy:283
translate english ruta_normal_1_f4fac144:

    # "Quizás lo estaba haciendo a propósito."
    "Maybe he was doing it on purpose."

# game/script.rpy:286
translate english ruta_normal_1_e90550e8:

    # C "Hey, [povname]."
    C "Hey, [povname]."

# game/script.rpy:287
translate english ruta_normal_1_4955c0ab:

    # "Ante el llamado de tu nombre, alzaste la mirada hacia Cindy, la cual había rodeado el mostrador para estar a tu lado."
    "At the sound of your name, you looked up at Cindy, who had come around the counter to stand next to you."

# game/script.rpy:288
translate english ruta_normal_1_071b72fb:

    # C "¿Viste que ese tipo ha estado aquí mucho tiempo?"
    C "Did you see that guy? He's been here for a long time."

# game/script.rpy:289
translate english ruta_normal_1_d4b2a28d:

    # "Miraste hacia donde ella estaba apuntando disimuladamente, y por supuesto, estaba hablando del mismo tipo."
    "You looked where she was subtly pointing, and of course, she was talking about the same guy."

# game/script.rpy:290
translate english ruta_normal_1_908ff5a8:

    # pov "Seh, lo vi."
    pov "Yeah, I saw him."

# game/script.rpy:291
translate english ruta_normal_1_66fd586d:

    # "Te encoges de hombros. Una reacción muy lógica, ¿No?"
    "You shrugged. A very logical reaction, right?"

# game/script.rpy:292
translate english ruta_normal_1_f87eaf8d:

    # pov "Tal vez está decidiendo qué comprar."
    pov "Maybe he's deciding what to buy."

# game/script.rpy:293
translate english ruta_normal_1_62771837:

    # "Seguramente era un tipo raro que vas a ver una vez, no era para tanto."
    "He was probably just a weirdo you'd see once, no big deal."

# game/script.rpy:294
translate english ruta_normal_1_03ec8c08:

    # "De todas formas, Cindy, por más que fuera insufrible, no se alteraba fácil."
    "Anyway, Cindy, as annoying as she was, wasn't easily flustered."

# game/script.rpy:295
translate english ruta_normal_1_34e679ad:

    # pov "Es sólo un rarito, vemos de esos a diario."
    pov "He's just a weirdo, we see those every day."

# game/script.rpy:296
translate english ruta_normal_1_ae284ab8:

    # C "Pero este se siente diferente…"
    C "But this one feels different..."

# game/script.rpy:297
translate english ruta_normal_1_733a3677:

    # "Estabas empezando a creer que Cindy había visto muchas películas, pero luego recordaste que ella no le gustaba el séptimo arte y sólo trabaja en la tienda de su padre."
    "You were starting to believe Cindy had watched many movies, but then you remembered she didn't like cinema and only worked in her dad's store."

# game/script.rpy:298
translate english ruta_normal_1_d780a543:

    # pov "Cuando hablé con él, no parecía ser peligroso."
    pov "When I talked to him, he didn't seem dangerous."

# game/script.rpy:300
translate english ruta_normal_1_ed362492:

    # "Cindy se giró a ti con sorpresa."
    "Cindy turned to you, surprised."

# game/script.rpy:301
translate english ruta_normal_1_7c0a489a:

    # C "¿Hablaste con él?, ¿Te dijo algo extraño?"
    C "You talked to him? Did he say anything strange?"

# game/script.rpy:307
translate english ruta_normal_1_87d69241:

    # pov "Me pidió que dijera mi nombre."
    pov "He asked for my name."

# game/script.rpy:308
translate english ruta_normal_1_79cfc7e8:

    # C "¿Eh?, ¿Por qué?"
    C "Huh? Why?"

# game/script.rpy:309
translate english ruta_normal_1_ffb9cba5:

    # pov "Él recogió mi credencial, supongo que para corroborar que era mía."
    pov "He picked up my badge, I guess to verify it was mine."

# game/script.rpy:310
translate english ruta_normal_1_68f5b046:

    # "Cindy se sujetó la barbilla, pensativa."
    "Cindy held her chin, thoughtfully."

# game/script.rpy:311
translate english ruta_normal_1_d729dd55:

    # pov "Fue… un poco raro, supongo."
    pov "It was... a little weird, I guess."

# game/script.rpy:315
translate english ruta_normal_1_ae362f25:

    # pov "Solo devolvió mi credencial."
    pov "He just gave me back my badge."

# game/script.rpy:316
translate english ruta_normal_1_5bae812b:

    # C "¿Por qué la tenía él?"
    C "Why did he have it?"

# game/script.rpy:317
translate english ruta_normal_1_7c90a249:

    # pov "O sea, él la agarró primero- mira, no fue la gran cosa."
    pov "I mean, he grabbed it first – look, it wasn't a big deal."

# game/script.rpy:322
translate english ruta_normal_2_acb62680:

    # "Cindy te miró en silencio por unos segundos, para después suspirar."
    "Cindy looked at you in silence for a few seconds, then sighed."

# game/script.rpy:323
translate english ruta_normal_2_31e940bc:

    # pov "Si te incomoda, puedo pedirle que se vaya."
    pov "If he makes you uncomfortable, I can ask him to leave."

# game/script.rpy:324
translate english ruta_normal_2_ae29e262:

    # "Cindy negó con la cabeza, mirando de reojo al sujeto."
    "Cindy shook her head, glancing at the guy."

# game/script.rpy:325
translate english ruta_normal_2_23bc24e0:

    # C "Probablemente tengas razón…"
    C "You're probably right..."

# game/script.rpy:326
translate english ruta_normal_2_3ad3c68b:

    # C "Bueno, te dejo, seguiré viendo el inventario."
    C "Okay, I'll leave you to it, I'll go check the inventory."

# game/script.rpy:327
translate english ruta_normal_2_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:328
translate english ruta_normal_2_4e517ebe:

    # "Te acomodaste en tu silla designada, y antes de fingir ver los recibos, Cindy volvió a hablar."
    "You settled into your designated chair, and before you could pretend to look at receipts, Cindy spoke again."

# game/script.rpy:329
translate english ruta_normal_2_92d91f0d:

    # C "Pero si hace algo sospechoso, me avisas, ¿Sí?"
    C "But if he does anything suspicious, let me know, okay?"

# game/script.rpy:331
translate english ruta_normal_2_419d7f0d:

    # "Asentiste con un leve gesto. Cindy no esperó respuesta verbal; sólo volvió a su tarea."
    "You nodded slightly. Cindy didn't wait for a verbal response; she just went back to her task."

# game/script.rpy:332
translate english ruta_normal_2_eb55ff67:

    # "Te quedaste un momento con los ojos fijos en la pantalla del monitor. Por el rabillo del ojo miraste los pasillos."
    "You kept your eyes fixed on the monitor screen for a moment. Out of the corner of your eye, you glanced at the aisles."

# game/script.rpy:333
translate english ruta_normal_2_776f35c1:

    # "El tipo seguía ahí."
    "The guy was still there."

# game/script.rpy:334
translate english ruta_normal_2_354be233:

    # "Sólo parado."
    "Just standing."

# game/script.rpy:335
translate english ruta_normal_2_2edd89ef:

    # "Miraba una estantería que no tenía nada particularmente interesante."
    "He was looking at a shelf that held nothing particularly interesting."

# game/script.rpy:336
translate english ruta_normal_2_172f0ed3:

    # "Y entonces, te miró."
    "And then, he looked at you."

# game/script.rpy:337
translate english ruta_normal_2_749a1b42:

    # "No fue una mirada rápida o distraída."
    "It wasn't a quick or distracted glance."

# game/script.rpy:338
translate english ruta_normal_2_f97e4ce2:

    # "Fue directa."
    "It was direct."

# game/script.rpy:342
translate english ruta_normal_2_5af008ef:

    # "Ese tipo te estaba empezando a espantar."
    "That guy was starting to freak you out."

# game/script.rpy:343
translate english ruta_normal_2_fe67954b:

    # "No pudiste enfrentarlo, estaba siendo demasiado."
    "You couldn't face him; it was getting to be too much."

# game/script.rpy:348
translate english ruta_normal_2_5fd684a7:

    # "Le devolviste la mirada con la misma intensidad."
    "You returned his gaze with the same intensity."

# game/script.rpy:349
translate english ruta_normal_2_44843b97:

    # "No sabías si lo hacías por valentía, terquedad… o simple curiosidad."
    "You didn't know if you were doing it out of bravery, stubbornness... or simple curiosity."

# game/script.rpy:350
translate english ruta_normal_2_74854c52:

    # "Pero él no pestañeó."
    "But he didn't blink."

# game/script.rpy:351
translate english ruta_normal_2_1bc05b4d:

    # "Y entonces, hizo un leve gesto."
    "And then, he made a slight gesture."

# game/script.rpy:352
translate english ruta_normal_2_343ef582:

    # "Un movimiento casi imperceptible con la cabeza."
    "An almost imperceptible nod of the head."

# game/script.rpy:353
translate english ruta_normal_2_a019b42d:

    # "Como si estuviera saludando."
    "As if he were greeting you."

# game/script.rpy:358
translate english ruta_normal_3_baa32eed:

    # "Decidiste ignorarlo, volviendo tu atención al monitor para quitar el cd del reproductor."
    "You decided to ignore him, turning your attention back to the monitor to remove the CD from the player."

# game/script.rpy:359
translate english ruta_normal_3_f74cc9e0:

    # "Mientras guardas el cd en su respectiva caja, observas tus opciones."
    "As you put the CD back in its case, you looked at your options."

# game/script.rpy:363
translate english ruta_normal_3_e2b3880d:

    # "Te apetecía salir de la realidad, con mundos mágicos y criaturas extraordinarias."
    "You felt like escaping reality, into magical worlds and extraordinary creatures."

# game/script.rpy:364
translate english ruta_normal_3_accd8364:

    # "Así que escoges una película y la ves el resto de tu turno."
    "So you pick a movie and watch it for the rest of your shift."

# game/script.rpy:367
translate english ruta_normal_3_bf33e6a9:

    # "Te apetece ver cómo se desenvuelven las relaciones ajenas, tal vez una parte de ti desearía vivir una historia de amor."
    "You feel like seeing how other people's relationships unfold; maybe a part of you wishes you could live a love story."

# game/script.rpy:368
translate english ruta_normal_3_accd8364_1:

    # "Así que escoges una película y la ves el resto de tu turno."
    "So you pick a movie and watch it for the rest of your shift."

# game/script.rpy:373
translate english ruta_normal_3_9ff14b94:

    # "Disfrutas los sustos y la atmósfera que generan las películas de terror."
    "You enjoy the scares and the atmosphere that horror movies create."

# game/script.rpy:376
translate english ruta_normal_3_76db4b4b:

    # "Te apetece reír y disfrutar de buenos chistes y situaciones."
    "You feel like laughing and enjoying good jokes and situations."

# game/script.rpy:377
translate english ruta_normal_3_accd8364_2:

    # "Así que escoges una película y la ves el resto de tu turno."
    "So you pick a movie and watch it for the rest of your shift."

# game/script.rpy:380
translate english ruta_normal_3_2ad13818:

    # "Disfrutas de un buen musical, grandes canciones y coreografías."
    "You enjoy a good musical, great songs, and choreographies."

# game/script.rpy:381
translate english ruta_normal_3_accd8364_3:

    # "Así que escoges una película y la ves el resto de tu turno."
    "So you pick a movie and watch it for the rest of your shift."

# game/script.rpy:384
translate english ruta_normal_3_ffa8e314:

    # "Te interesa la tecnología y cómo es que la gente se imagina cómo sería el futuro."
    "You're interested in technology and how people imagine the future would be."

# game/script.rpy:385
translate english ruta_normal_3_accd8364_4:

    # "Así que escoges una película y la ves el resto de tu turno."
    "So you pick a movie and watch it for the rest of your shift."

# game/script.rpy:390
translate english ruta_normal_4_0d22d6b3:

    # "Estás por escoger una película, hasta que el repentino sonido de alguien apoyándose en el mostrador frente a ti te desconcentra."
    "You were about to pick a movie, until the sudden sound of someone leaning on the counter in front of you distracted you."

# game/script.rpy:396
translate english ruta_normal_4_bc5ac81e:

    # "Nuevamente, el sujeto desconocido se hace presente, esta vez frente a ti, mirando con atención el cd en tus manos."
    "Again, the stranger was there, this time in front of you, looking intently at the CD in your hands."

# game/script.rpy:397
translate english ruta_normal_4_a3e745a4:

    # Stranger "¿Qué película vas a poner?"
    Stranger "What movie are you going to put on?"

# game/script.rpy:398
translate english ruta_normal_4_74267743:

    # pov "¿Disculpa?"
    pov "Excuse me?"

# game/script.rpy:399
translate english ruta_normal_4_f8f7158b:

    # Stranger "Quiero saber qué película vas a poner, ¿Eso es un crimen?"
    Stranger "I want to know what movie you're going to put on. Is that a crime?"

# game/script.rpy:400
translate english ruta_normal_4_58563c79:

    # pov "No, claro que no, pero-"
    pov "No, of course not, but—"

# game/script.rpy:401
translate english ruta_normal_4_7a0cebca:

    # Stranger "Vamos, estoy indeciso, tal vez puedas inspirarme."
    Stranger "Come on, I'm undecided, maybe you can inspire me."

# game/script.rpy:402
translate english ruta_normal_4_5e7421d8:

    # "Lo miraste en silencio por un momento, para después suspirar con cansancio."
    "You looked at him in silence for a moment, then sighed with weariness."

# game/script.rpy:406
translate english ruta_normal_4_8674d526:

    # Stranger "Ah, psicológico."
    Stranger "Ah, psychological."

# game/script.rpy:407
translate english ruta_normal_4_ee76db2c:

    # Stranger "¿Te gusta analizar a las personas?"
    Stranger "Do you like analyzing people?"

# game/script.rpy:408
translate english ruta_normal_4_b4be9333:

    # Stranger "¿Qué conclusiones sacas de mí?"
    Stranger "What conclusions do you draw about me?"

# game/script.rpy:409
translate english ruta_normal_4_749da67d:

    # pov "Que te parece que mis gustos son patéticos."
    pov "That you think my tastes are lame?"

# game/script.rpy:410
translate english ruta_normal_4_710f203b:

    # Stranger "….."
    Stranger "...."

# game/script.rpy:411
translate english ruta_normal_4_3d81733a:

    # Stranger "Vaya, diste en el clavo."
    Stranger "Wow, you hit the nail on the head."

# game/script.rpy:412
translate english ruta_normal_4_f302080a:

    # pov "¿Ahora quien tiene gustos patéticos?"
    pov "Now who has lame tastes?"

# game/script.rpy:413
translate english ruta_normal_4_85f633f9:

    # "El tipo se cruza de brazos con irritación."
    "The guy crossed his arms in irritation."

# game/script.rpy:414
translate english ruta_normal_4_3eafab4e:

    # Stranger "Tch…"
    Stranger "Tch..."

# game/script.rpy:418
translate english ruta_normal_4_d03d8729:

    # Stranger "¡Hahaha!"
    Stranger "Hahahaha!"

# game/script.rpy:419
translate english ruta_normal_4_311dd15f:

    # Stranger "¿En serio te gusta eso?"
    Stranger "Seriously, you like that?"

# game/script.rpy:420
translate english ruta_normal_4_7ca24f77:

    # pov "Hey, es un clásico."
    pov "Hey, it's a classic."

# game/script.rpy:421
translate english ruta_normal_4_46476a6d:

    # Stranger "Admito que tuvo su impacto, pero es sólo propaganda religiosa."
    Stranger "I admit it had an impact, but it's just religious propaganda."

# game/script.rpy:422
translate english ruta_normal_4_fedc5190:

    # pov "Ok, tal vez tengas un punto, pero no quita que sea buena."
    pov "Okay, maybe you have a point, but that doesn't make it any less good."

# game/script.rpy:423
translate english ruta_normal_4_d3a93014:

    # Stranger "Lo que digas."
    Stranger "Whatever you say."

# game/script.rpy:429
translate english ruta_normal_4_da3c9522:

    # Stranger "Oh~"
    Stranger "Oh~"

# game/script.rpy:430
translate english ruta_normal_4_2288b594:

    # Stranger "Un clásico slasher~"
    Stranger "A classic slasher~"

# game/script.rpy:431
translate english ruta_normal_4_644cb77a:

    # Stranger "Interesante."
    Stranger "Interesting."

# game/script.rpy:435
translate english ruta_normal_4_7acf4be8:

    # Stranger "……."
    Stranger "......"

# game/script.rpy:436
translate english ruta_normal_4_30f85677:

    # Stranger "¿En serio?"
    Stranger "Seriously?"

# game/script.rpy:437
translate english ruta_normal_4_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:441
translate english ruta_normal_4_b5b797cc:

    # Stranger "Oh, si, a mi también me gusta esa."
    Stranger "Oh, yeah, I like that one too."

# game/script.rpy:442
translate english ruta_normal_4_493e448f:

    # Stranger "Me ayuda a dormir."
    Stranger "It helps me sleep."

# game/script.rpy:448
translate english ruta_normal_4_da3c9522_1:

    # Stranger "Oh~"
    Stranger "Oh~"

# game/script.rpy:449
translate english ruta_normal_4_9a7fb7f4:

    # Stranger "Es de esas películas sin sustos fáciles y que se mete en la piel."
    Stranger "It's one of those movies that doesn't have cheap jump scares and really gets under your skin."

# game/script.rpy:450
translate english ruta_normal_4_578fbdc9:

    # Stranger "Me gusta~"
    Stranger "I like it~"

# game/script.rpy:454
translate english ruta_normal_4_ff1f770f:

    # Stranger "Mmh, los efectos especiales son geniales, supongo…"
    Stranger "Hmm, the special effects are cool, I guess..."

# game/script.rpy:460
translate english ruta_normal_5_b3a8649c:

    # pov "Bueno, ¿Eso te ayudó a decidir?"
    pov "Well, did that help you decide?"

# game/script.rpy:463
translate english ruta_normal_5_891ab733:

    # "El sujeto ladeó la cabeza, ahora sabías con seguridad que esa era su manera de mostrar burla."
    "The guy cocked his head; now you knew for sure that was his way of showing mockery."

# game/script.rpy:464
translate english ruta_normal_5_725c5e0d:

    # Stranger "Un poco."
    Stranger "A little."

# game/script.rpy:465
translate english ruta_normal_5_3c3da743:

    # Stranger "Aunque lo que más me llamó la atención fue el género que elegiste."
    Stranger "Though what caught my attention most was the genre you chose."

# game/script.rpy:466
translate english ruta_normal_5_45b264e1:

    # "Alzaste una ceja."
    "You raised an eyebrow."

# game/script.rpy:467
translate english ruta_normal_5_107e6b99:

    # pov "¿Sí? ¿Y qué tiene?"
    pov "Oh yeah? And what about it?"

# game/script.rpy:468
translate english ruta_normal_5_9ae72082:

    # Stranger "Terror."
    Stranger "Horror."

# game/script.rpy:469
translate english ruta_normal_5_888068ad:

    # "El tono de él baja."
    "His tone dropped."

# game/script.rpy:470
translate english ruta_normal_5_086864c3:

    # Stranger "Interesante elección. Siempre dice algo de quien lo prefiere."
    Stranger "Interesting choice. It always says something about the person who prefers it."

# game/script.rpy:471
translate english ruta_normal_5_6c41161b:

    # pov "¿Como qué?"
    pov "Like what?"

# game/script.rpy:472
translate english ruta_normal_5_4a41220d:

    # Stranger "Que buscas sentir algo real."
    Stranger "That you're looking to feel something real."

# game/script.rpy:473
translate english ruta_normal_5_edd25cab:

    # Stranger "O quieres que el miedo tenga un rostro."
    Stranger "Or you want fear to have a face."

# game/script.rpy:474
translate english ruta_normal_5_fc1d6905:

    # Stranger "Algo que puedas entender, incluso si significa peligro."
    Stranger "Something you can understand, even if it means danger."

# game/script.rpy:475
translate english ruta_normal_5_dff41859:

    # "Sus palabras eran suaves, pero se clavaban como agujas bajo la piel."
    "His words were soft, but they pricked like needles under your skin."

# game/script.rpy:476
translate english ruta_normal_5_be1a1dc2:

    # pov "O tal vez me gustan las emociones fuertes sin ponerme en riesgo. Como todos los demás."
    pov "Or maybe I like strong emotions without putting myself at risk. Like everyone else."

# game/script.rpy:477
translate english ruta_normal_5_ad98273a:

    # Stranger "Pero tú no eres como todos los demás."
    Stranger "But you're not like everyone else."

# game/script.rpy:478
translate english ruta_normal_5_14c2af34:

    # "Vaya, hay que quitar esa frase del bingo de la novela visual."
    "Well, that phrase needs to be removed from the visual novel bingo card."

# game/script.rpy:479
translate english ruta_normal_5_f872c175:

    # "Él se acercó un poco más al mostrador. No invadía tu espacio… pero era como si lo acariciara."
    "He moved a little closer to the counter. He didn't invade your space... but it was as if he caressed it."

# game/script.rpy:480
translate english ruta_normal_5_00157c57:

    # Stranger "No pareces tener miedo."
    Stranger "You don't seem to be afraid."

# game/script.rpy:481
translate english ruta_normal_5_a8bbecbb:

    # pov "¿Debería tenerlo?"
    pov "Should I be?"

# game/script.rpy:482
translate english ruta_normal_5_05b2a07f:

    # Stranger "Depende. ¿Prefieres ver el horror desde afuera… o que te mire de vuelta?"
    Stranger "Depends. Do you prefer to see horror from the outside... or have it stare back at you?"

# game/script.rpy:488
translate english ruta_normal_5_d0cab671:

    # pov "Supongo que eso depende de qué tan bonita sea la cara del horror."
    pov "I guess it depends on how pretty the face of horror is."

# game/script.rpy:489
translate english ruta_normal_5_dff2b092:

    # "Él ladea un poco la cabeza, como si le hubieras dicho algo que no esperaba del todo, pero tampoco parece sorprendido."
    "He tilted his head slightly, as if you had said something he didn't quite expect, but he didn't seem surprised either."

# game/script.rpy:490
translate english ruta_normal_5_05576f06:

    # Stranger "…Vaya."
    Stranger "...Wow."

# game/script.rpy:491
translate english ruta_normal_5_6da8515b:

    # Stranger "Ten en cuenta que a veces lo bonito también muerde."
    Stranger "Keep in mind that sometimes pretty things bite too."

# game/script.rpy:492
translate english ruta_normal_5_255e690a:

    # "Mira un segundo hacia los estantes como si buscara algo, pero es obvio que no lo hace."
    "He glanced at the shelves for a second as if looking for something, but it was obvious he wasn't."

# game/script.rpy:493
translate english ruta_normal_5_41c5b8b1:

    # Stranger "O quizás te gusta que te muerdan. Quién sabe."
    Stranger "Or maybe you like being bitten. Who knows."

# game/script.rpy:494
translate english ruta_normal_5_22c8cb22:

    # "Se encoge de hombros, como restándole importancia a sus propias palabras."
    "He shrugged, as if downplaying his own words."

# game/script.rpy:497
translate english ruta_normal_5_e1da323f:

    # pov "Voy a revisar el sistema un momento. Si decides algo, me avisas."
    pov "I'm going to check the system for a moment. If you decide anything, let me know."

# game/script.rpy:498
translate english ruta_normal_5_86e5cb94:

    # "No se mueve. Apoya el codo en el mostrador, observándote."
    "He didn't move. He leaned his elbow on the counter, watching you."

# game/script.rpy:499
translate english ruta_normal_5_f818d1ac:

    # "El silencio es pesado."
    "The silence was heavy."

# game/script.rpy:504
translate english ruta_normal_6_31e46d31:

    # "Él extendió un dedo e hizo círculos sobre la superficie del mostrador."
    "He extended a finger and drew circles on the counter surface."

# game/script.rpy:505
translate english ruta_normal_6_dd900e51:

    # "Estaba fingiendo pensar, ignorándote, pero consciente de tu presencia."
    "He was pretending to think, ignoring you, but aware of your presence."

# game/script.rpy:506
translate english ruta_normal_6_da57c29c:

    # "Por el bien de tu sanidad mental, debías apresurarlo."
    "For your mental sanity's sake, you needed to hurry him up."

# game/script.rpy:510
translate english ruta_normal_6_b84a99ac:

    # "Carraspeas contra tu mano hecha un puño."
    "You cleared your throat, your hand a clenched fist."

# game/script.rpy:511
translate english ruta_normal_6_03ad10c2:

    # pov "Ehm, ¿Vas a escoger algo?"
    pov "Um, are you going to pick something?"

# game/script.rpy:512
translate english ruta_normal_6_f340bcaf:

    # Stranger "Eres algo impaciente, ¿Eh?"
    Stranger "You're a bit impatient, huh?"

# game/script.rpy:513
translate english ruta_normal_6_b041e5a8:

    # pov "Oh, disculpa, no quise-"
    pov "Oh, excuse me, I didn't mean to—"

# game/script.rpy:514
translate english ruta_normal_6_55df15bf:

    # Stranger "Relájate, sólo estoy jugando."
    Stranger "Relax, I'm just playing."

# game/script.rpy:519
translate english ruta_normal_6_6b036851:

    # pov "Hey, amigo, ¿Podrías apresurarte?"
    pov "Hey, buddy, could you hurry up?"

# game/script.rpy:520
translate english ruta_normal_6_d45f46e4:

    # Stranger "¿Cuál es la prisa?, no hay muchos clientes además de mí."
    Stranger "What's the rush? There aren't many other customers besides me."

# game/script.rpy:521
translate english ruta_normal_6_862483a0:

    # pov "¿Siquiera quieres comprar algo?"
    pov "Do you even want to buy anything?"

# game/script.rpy:522
translate english ruta_normal_6_d7bc3471:

    # "El tipo se rió entre dientes."
    "The guy chuckled."

# game/script.rpy:523
translate english ruta_normal_6_9894db0c:

    # Stranger "Sólo soy indeciso, no le hago daño a nadie."
    Stranger "I'm just indecisive, I'm not bothering anyone."


# game/script.rpy:528
translate english ruta_normal_7_f4cd09be:

    # "Desviaste la mirada hacia atrás, en búsqueda de Cindy, sólo para sentir algo de seguridad de que no estabas por tu cuenta."
    "You glanced back, searching for Cindy, just to feel some security that you weren't on your own."

# game/script.rpy:529
translate english ruta_normal_7_3e402da3:

    # "Pero lamentablemente, no la veías por ningún lado."
    "But unfortunately, you didn't see her anywhere."

# game/script.rpy:531
translate english ruta_normal_7_03c6350e:

    # "Entonces, sin que se lo pidieras, él estiró una mano por encima del mostrador."
    "Then, without you asking, he reached a hand over the counter."

# game/script.rpy:532
translate english ruta_normal_7_dcabc9da:

    # J "Soy Jeff, creo que es momento de presentarnos formalmente, ¿No crees, [povname]?"
    J "I'm Jeff. I think it's time we formally introduce ourselves, don't you, [povname]?"

# game/script.rpy:533
translate english ruta_normal_7_465c3e77:

    # "Tu mirada bajó a su mano."
    "Your gaze dropped to his hand."

# game/script.rpy:540
translate english ruta_normal_7_9c908b85:

    # J "……"
    J "......"

# game/script.rpy:541
translate english ruta_normal_7_1cb9306f:

    # pov "……"
    pov "....."

# game/script.rpy:542
translate english ruta_normal_7_7b7d640d:

    # J "¡Hahahaha!"
    J "Hahahaha!"

# game/script.rpy:543
translate english ruta_normal_7_1527fe50:

    # "Jeff se rió fuertemente, llamando la atención de los pocos clientes que seguían en la tienda."
    "Jeff laughed loudly, drawing the attention of the few remaining customers in the store."

# game/script.rpy:544
translate english ruta_normal_7_e5ec76c2:

    # "No pudiste evitarlo, pero tu también te reíste por tu acción."
    "You couldn't help it, but you also laughed at your action."

# game/script.rpy:545
translate english ruta_normal_7_6a03cbae:

    # pov "Hey, no exageres… nos están viendo."
    pov "Hey, don't exaggerate... they're watching us."

# game/script.rpy:546
translate english ruta_normal_7_f2d3f19e:

    # J "¿Por qué? ¿Te avergüenza de que te vean?"
    J "Why? Are you embarrassed for them to see you?"

# game/script.rpy:547
translate english ruta_normal_7_5d03a9f5:

    # pov "No es eso, estás molestando a los clientes."
    pov "It's not that, you're bothering the customers."

# game/script.rpy:548
translate english ruta_normal_7_a005b756:

    # J "Heh, cierto, no te tomaba como alguien que se avergüence fácilmente."
    J "Heh, right, I didn't take you for someone who'd easily get embarrassed."

# game/script.rpy:551
translate english ruta_normal_7_a180aa46:

    # "Jeff sujetó tu mano con suavidad, como si quisiera hacer ver su contacto como algo inofensivo."
    "Jeff held your hand gently, as if wanting to make his touch seem harmless."

# game/script.rpy:552
translate english ruta_normal_7_ed4cfdae:

    # J "Mmh, lindo…"
    J "Mmm, cute..."

# game/script.rpy:553
translate english ruta_normal_7_af17a36a:

    # "Sus dedos no apretaron, pero tampoco se retiraron enseguida."
    "His fingers didn't squeeze, but they didn't pull away immediately either."

# game/script.rpy:554
translate english ruta_normal_7_0856e44d:

    # "La frialdad del gesto no parecía molestarle, al contrario, le hacía gracia."
    "The coldness of the gesture didn't seem to bother him; on the contrary, it amused him."

# game/script.rpy:555
translate english ruta_normal_7_f227e563:

    # "Finalmente soltó tu mano, como quien deja caer algo que ya inspeccionó suficiente."
    "He finally let go of your hand, like someone dropping something they'd inspected enough."

# game/script.rpy:560
translate english ruta_normal_8_3cf9f753:

    # "Como alguien que trabaja en una tienda, deberías convencer al cliente de llevar lo más que pueda, pero algo te decía que Jeff se tomaría su buen tiempo."
    "As someone who works in a store, you should convince the customer to buy as much as possible, but something told you Jeff would take his sweet time."

# game/script.rpy:561
translate english ruta_normal_8_ebe71245:

    # "Lo miraste unos segundos en silencio, observando su postura pensativa."
    "You watched him in silence for a few seconds, observing his thoughtful posture."

# game/script.rpy:562
translate english ruta_normal_8_ea413312:

    # "Si él estaba insistiendo en alargar la interacción, tenías permitido incomodar también, ¿No?"
    "If he was insistent on prolonging the interaction, you were allowed to make him uncomfortable too, right?"

# game/script.rpy:566
translate english ruta_normal_8_f2a658e9:

    # J "…."
    J "......"

# game/script.rpy:567
translate english ruta_normal_8_dd4773e1:

    # J "¿Por qué quieres saber?"
    J "Why do you want to know?"

# game/script.rpy:570
translate english ruta_normal_8_f2a658e9_1:

    # J "…."
    J "...."

# game/script.rpy:571
translate english ruta_normal_8_4a80f2ea:

    # J "Tengo cicatrices, no son agradables de ver."
    J "I have scars, they're not pleasant to see."

# game/script.rpy:572
translate english ruta_normal_8_9937ed6d:

    # "Parece que tocaste una fibra sensible."
    "Looks like you touched a nerve."

# game/script.rpy:577
translate english ruta_normal_8_14360a18:

    # J "…"
    J "..."

# game/script.rpy:578
translate english ruta_normal_8_8d2ed3a9:

    # J "Ya no lo hace, eso es lo que importa."
    J "It doesn't anymore, that's what matters."

# game/script.rpy:579
translate english ruta_normal_8_e2e8b803:

    # "No eras de meterte en asuntos ajenos, pero ya estableciste una conversación con él."
    "You weren't one to meddle in other people's affairs, but you had already established a conversation with him."

# game/script.rpy:580
translate english ruta_normal_8_f3611b6e:

    # "No podía simplemente no importarte."
    "You couldn't just not care."

# game/script.rpy:583
translate english ruta_normal_8_0eb96dcd:

    # J "¿Huh?"
    J "Huh?"

# game/script.rpy:584
translate english ruta_normal_8_564c8fc4:

    # J "¿Qué tiene que ver eso?"
    J "What does that have to do with anything?"

# game/script.rpy:585
translate english ruta_normal_8_88d2d51f:

    # pov "Oh, ¿Eres freelancer?"
    pov "Oh, are you a freelancer?"

# game/script.rpy:586
translate english ruta_normal_8_7ba8913d:

    # J "¿Qué mierd…? ¡No!"
    J "What the fu...? No!"

# game/script.rpy:587
translate english ruta_normal_8_4cdb1132:

    # pov "¿Entonces estás desempleado?"
    pov "So you're unemployed?"

# game/script.rpy:588
translate english ruta_normal_8_a4883f2f:

    # J "¡Yo-!"
    J "I-!"

# game/script.rpy:589
translate english ruta_normal_8_b5e56971:

    # J "…. Bueno, técnicamente sí."
    J "Well, technically, yes."

# game/script.rpy:590
translate english ruta_normal_8_55227dee:

    # pov "Hey, no hay de qué avergonzarse, ya te llegará la oportunidad."
    pov "Hey, nothing to be ashamed of, your opportunity will come."

# game/script.rpy:591
translate english ruta_normal_8_c64ac46b:

    # J "No quiero escuchar eso de ti."
    J "I don't want to hear that from you."

# game/script.rpy:592
translate english ruta_normal_8_bbe0c635:

    # pov "¿Qué quieres decir con eso?"
    pov "What's that supposed to mean??"

# game/script.rpy:593
translate english ruta_normal_8_a6a781f5:

    # J "Descúbrelo tú."
    J "You figure it out"

# game/script.rpy:596
translate english ruta_normal_8_a5784726:

    # "Jeff se trastabilló en su lugar, dirigiendo su mirada hacia ti."
    "Jeff stumbled in place, turning his gaze to you."

# game/script.rpy:597
translate english ruta_normal_8_ed91d6c2:

    # "Se quedó en silencio unos segundos, recuperándose de la sorpresa inicial, para después ladear la cabeza, con un toque burlón."
    "He remained silent for a few seconds, recovering from the initial surprise, then tilted his head with a teasing touch."

# game/script.rpy:598
translate english ruta_normal_8_1d975fe1:

    # J "¿Y si lo hago?"
    J "What if I'm not?"

# game/script.rpy:603
translate english ruta_normal_8_1ba220be:

    # pov "No me molestaría compartir."
    pov "I wouldn't mind sharing."

# game/script.rpy:604
translate english ruta_normal_8_4d129c8f:

    # "Apoyas tu barbilla sobre tu mano, alzando las cejas juguetonamente."
    "You rested your chin on your hand, raising your eyebrows playfully."

# game/script.rpy:605
translate english ruta_normal_8_fd0fa39f:

    # "Jeff carraspea contra su bandana, ocultando lo que tu sospechas que es una carcajada."
    "Jeff cleared his throat against his bandana, hiding what you suspected was a chuckle."

# game/script.rpy:606
translate english ruta_normal_8_44ccc4e5:

    # "Al menos lo hiciste reír."
    "At least you made him laugh."

# game/script.rpy:609
translate english ruta_normal_8_55d7389c:

    # pov "Bien por ti si es el caso."
    pov "Good for you, if that's the case."

# game/script.rpy:610
translate english ruta_normal_8_b7084154:

    # "Preguntaste por preguntar, no porque realmente tuvieras interés en él."
    "You asked to ask, not because you were genuinely interested in him."

# game/script.rpy:611
translate english ruta_normal_8_e8682974:

    # "Los hombros de él cayeron y te pareció escuchar un suspiro de su parte."
    "His shoulders slumped, and you thought you heard a sigh from him."

# game/script.rpy:616
translate english ruta_normal_9_5a9a98ab:

    # pov "Bueno, ¿Decidiste que llevar?"
    pov "Well, did you decide what to get?"

# game/script.rpy:617
translate english ruta_normal_9_b68673fd:

    # "Jeff depositó su atención nuevamente en ti."
    "Jeff refocused his attention on you."

# game/script.rpy:618
translate english ruta_normal_9_b47ab4ca:

    # J "Vaya, pareciera que de verdad quisieras deshacerte de mí."
    J "Wow, it seems like you really want to get rid of me."

# game/script.rpy:622
translate english ruta_normal_9_b4f2b9bc:

    # pov "No es eso… si necesitas ayuda, estoy para atender."
    pov "It's not that... if you need help, I'm here to assist."

# game/script.rpy:623
translate english ruta_normal_9_de096237:

    # "Él ladeó la cabeza ligeramente, pero esta vez no con burla, sino más bien con aburrimiento."
    "He tilted his head slightly, but this time not with mockery, but rather boredom."

# game/script.rpy:624
translate english ruta_normal_9_6e8e4c83:

    # "Sus dedos dejaron de tamborilear, ahora quietos sobre la superficie del mostrador."
    "His fingers stopped drumming, now still on the counter surface."

# game/script.rpy:625
translate english ruta_normal_9_3cdaa8f0:

    # J "Ah… claro. El protocolo de servicio."
    J "Ah... right. Customer service protocol."

# game/script.rpy:626
translate english ruta_normal_9_8e5b001a:

    # "La burla seguía ahí, pero sus ojos ya no brillaban con la misma chispa de antes."
    "The mockery was still there, but his eyes no longer sparkled with the same intensity."

# game/script.rpy:627
translate english ruta_normal_9_c6cec9a8:

    # "Por un segundo, casi parecía que iba a decir algo más, pero se limitó a un suspiro discreto."
    "For a second, it almost seemed like he was going to say something more, but he just let out a discreet sigh."

# game/script.rpy:631
translate english ruta_normal_9_d205df72:

    # J "En fin, creo que no llevaré nada."
    J "Anyway, I don't think I'll be taking anything."

# game/script.rpy:632
translate english ruta_normal_9_35671ebc:

    # "Genial, todo fue para nada."
    "Great, all that for nothing."

# game/script.rpy:633
translate english ruta_normal_9_9a59fcb3:

    # J "Ojalá hubiera sido un gusto conocerte, [povname], pero… no estoy tan seguro."
    J "I wish it had been a pleasure to meet you, [povname], but... I'm not so sure."

# game/script.rpy:634
translate english ruta_normal_9_ea99ece5:

    # "Jeff se enderezó del mostrador, dándole palmadas al mostrador."
    "Jeff straightened up from the counter, patting it"

# game/script.rpy:635
translate english ruta_normal_9_d9ead54c:

    # pov "Seh, opino igual, Jeff."
    pov "Yeah, I agree, Jeff."

# game/script.rpy:636
translate english ruta_normal_9_5a34650e:

    # "No te quedas atrás y correspondes a la poca energía."
    "You didn't hold back and matched his low energy."

# game/script.rpy:638
translate english ruta_normal_9_2c711a9d:

    # "Jeff resta importancia con un gesto de mano y se retira."
    "Jeff waved his hand dismissively and left."

# game/script.rpy:639
translate english ruta_normal_9_2f5a7aff:

    # "Por fin."
    "Finally."

# game/script.rpy:640
translate english ruta_normal_9_56da2df2:

    # "Este tipo te estaba poniendo de los nervios, con todas sus preguntas y comentarios."
    "This guy was getting on your nerves with all his questions and comments."

# game/script.rpy:641
translate english ruta_normal_9_6791b26a:

    # "Todo parecía una invitación a un juego, pero no tenías por qué aceptarlo."
    "Everything seemed like an invitation to a game, but you didn't have to accept it."

# game/script.rpy:646
translate english ruta_normal_9_937773fa:

    # pov "No, para nada. Amo perder el tiempo con raritos que caminan en círculos como si estuvieran perdidos en el supermercado."
    pov "No, not at all. I love wasting time with weirdos who walk in circles as if they're lost in the supermarket."

# game/script.rpy:647
translate english ruta_normal_9_e9c644c1:

    # "Jeff abrió mucho los ojos, fingiendo ofensa."
    "Jeff's eyes widened, feigning offense."

# game/script.rpy:648
translate english ruta_normal_9_62e317c1:

    # J "¡Oye! Eso fue cruel. Me vas a hacer llorar."
    J "Hey! That was mean. You're going to make me cry."

# game/script.rpy:649
translate english ruta_normal_9_90c16e08:

    # "Se llevó una mano al pecho, exagerando, y luego volvió a reírse entre dientes. Esta vez su risa fue más baja, más real."
    "He clutched his chest dramatically, then chuckled again. This time his laugh was softer, more genuine."

# game/script.rpy:650
translate english ruta_normal_9_2d4c2ce6:

    # J "No sé si esto fue divertido porque hablé contigo o porque te arruiné el día."
    J "I don't know if this was funny because I talked to you or because I ruined your day."

# game/script.rpy:651
translate english ruta_normal_9_d735a1aa:

    # "La declaración salió con una franqueza inquietante."
    "The statement came out with unsettling frankness."

# game/script.rpy:652
translate english ruta_normal_9_e3a146df:

    # "No sabías como reaccionar, pero sí sabías que al final Jeff había hecho las cosas adrede"
    "You didn't know how to react, but you knew that in the end, Jeff had done things on purpose."

# game/script.rpy:653
translate english ruta_normal_9_28cc16f3:

    # pov "Bueno… al menos reconoces que no fuiste exactamente un deleite."
    pov "Well... at least you admit you weren't exactly a delight."

# game/script.rpy:654
translate english ruta_normal_9_14db9991:

    # J "Claro, no soy idiota, me doy cuenta de lo que provoco en la gente."
    J "Sure, I'm not an idiot, I know what kind of reaction I get from people."

# game/script.rpy:655
translate english ruta_normal_9_90119485:

    # "Jeff se encogió de hombros, para después ladear la cabeza, interrogante y burlesco."
    "Jeff shrugged, then tilted his head, questioning and mocking."

# game/script.rpy:656
translate english ruta_normal_9_3731e46e:

    # J "¿Tratas a todos los clientes así o soy especial?"
    J "Do you treat all customers like this, or am I special?"

# game/script.rpy:657
translate english ruta_normal_9_4d226e02:

    # "No pudiste evitar soltar una pequeña carcajada ante sus palabras."
    "You couldn't help but let out a small laugh at his words."

# game/script.rpy:658
translate english ruta_normal_9_76f846b2:

    # pov "¿Sabes qué?, no suelo gastar tanta energía en desconocidos. Pero tú te lo ganaste."
    pov "You know what? I don't usually spend so much energy on strangers. But you earned it."

# game/script.rpy:662
translate english ruta_normal_9_01ac062d:

    # "Jeff se enderezó repentinamente, contento, como si le hubieran dicho que consiguió un gran logro."
    "Jeff straightened up suddenly, pleased, as if he'd been told he achieved a great feat."

# game/script.rpy:663
translate english ruta_normal_9_e59bf4a8:

    # J "¡Lo tomo!"
    J "I'll take it!"

# game/script.rpy:664
translate english ruta_normal_9_23e642f7:

    # "Por un momento pensaste que Jeff se refería a que tomaba tus palabras con gusto, hasta que te fijaste que los ojos de él estaban dirigidos a la película que habías escogido para colocar en el reproductor."
    "For a moment you thought Jeff meant he appreciated your words, until you noticed his eyes were fixed on the movie you had chosen to put in the player."

# game/script.rpy:666
translate english ruta_normal_9_e38d0662:

    # pov "Oh, genial."
    pov "Oh, great."

# game/script.rpy:667
translate english ruta_normal_9_bb4b41d0:

    # "Hablaste con alivio. Por fin Jeff se llevaría algo."
    "You said with relief. Finally, Jeff would take something."

# game/script.rpy:668
translate english ruta_normal_9_92344c5d:

    # "Además de que era algo que sabías que le gustaba."
    "And it was something you knew he liked."

# game/script.rpy:669
translate english ruta_normal_9_723cede3:

    # "Sentiste que hacer bien tu trabajo no se sintió tan mal."
    "You felt good about doing your job well, after all."

# game/script.rpy:671
translate english ruta_normal_9_65eb677e:

    # pov "Oh, de acuerdo."
    pov "Oh, okay."

# game/script.rpy:672
translate english ruta_normal_9_b02e9d0f:

    # "No creías que le vaya a gustar, pero aprecias que al final se haya llevado algo."
    "You didn't think he'd like it, but you appreciated that he ended up taking something."

# game/script.rpy:673
translate english ruta_normal_9_2d424167:

    # "A pesar de haber hecho bien tu trabajo, no sientes mucha satisfacción"
    "Despite doing your job well, you didn't feel much satisfaction."

# game/script.rpy:674
translate english ruta_normal_9_06f4dacf:

    # pov "Gracias por comprar con nosotros."
    pov "Thanks for shopping with us."

# game/script.rpy:675
translate english ruta_normal_9_bd9528a1:

    # "Jeff asintió, recibiendo la película en su respectiva bolsa y se dirigió a la salida."
    "Jeff nodded, taking the movie in its bag, and headed for the exit."

# game/script.rpy:676
translate english ruta_normal_9_3005fd63:

    # J "Fue un placer, [povname]."
    J "It was a pleasure, [povname]."

# game/script.rpy:678
translate english ruta_normal_9_b853bc69:

    # "Él sacudió su mano a modo de despedida, y tú correspondiste con tu propia mano, aunque no tan entusiasta como la de él."
    "He waved goodbye, and you reciprocated with your own hand, though not as enthusiastically as his."

# game/script.rpy:679
translate english ruta_normal_9_d5ce5829:

    # "Bueno, lograste venderle al rarito del día."
    "Well, you managed to sell something to the weirdo of the day."

# game/script.rpy:680
translate english ruta_normal_9_278c84ce:

    # "Fue un logro, después de todo."
    "It was an accomplishment, after all."

# game/script.rpy:686
translate english ruta_normal_10_f8fe4a1f:

    # "Tu día laboral ha terminado."
    "Your workday was over."

# game/script.rpy:687
translate english ruta_normal_10_69ecb368:

    # "Dentro de todo, fue tranquilo."
    "All in all, it was quiet."

# game/script.rpy:688
translate english ruta_normal_10_011b6360:

    # "La noche ha caído, pero no es razón para preocuparte porque vives a unas calles."
    "Night had fallen, but there was no reason to worry since you lived a few blocks away."

# game/script.rpy:689
translate english ruta_normal_10_7d1b8af5:

    # "Algunas cosas son así de convenientes."
    "Some things were just convenient like that."

# game/script.rpy:690
translate english ruta_normal_10_73825a29:

    # "Esta semana le tocaba a Cindy quedarse para cerrar la tienda."
    "This week it was Cindy's turn to close the store."

# game/script.rpy:691
translate english ruta_normal_10_7d132380:

    # "Como ustedes dos tienen casi el mismo cargo, decidieron que la tarea de cerrar sería por turnos."
    "Since you two had almost the same position, you decided that closing duties would be by turns."

# game/script.rpy:692
translate english ruta_normal_10_d3cebf8b:

    # "Así que tu estabas con tus cosas listas para irte a tu hogar."
    "So you had your things ready to go home."

# game/script.rpy:695
translate english ruta_normal_10_f690edb1:

    # C "¿Vas a estar bien?"
    C "Are you going to be okay?"

# game/script.rpy:696
translate english ruta_normal_10_a92e43d0:

    # pov "Claro, ¿Por qué no lo estaría?"
    pov "Sure, why wouldn't I be?"

# game/script.rpy:697
translate english ruta_normal_10_8df76e26:

    # C "Ese tipo, parecía estar algo fijado en ti."
    C "That guy seemed a bit fixated on you."

# game/script.rpy:698
translate english ruta_normal_10_5b6cbcc6:

    # "Resoplas con ironía."
    "You scoffed ironically."

# game/script.rpy:699
translate english ruta_normal_10_e926f3e7:

    # pov "Vamos, ¿En mi?"
    pov "Come on, on me?"

# game/script.rpy:701
translate english ruta_normal_10_1b2ad7d4:

    # C "Si, tampoco lo entiendo."
    C "Yeah, I don't get it either."

# game/script.rpy:702
translate english ruta_normal_10_9f9aa0ea:

    # "Ok, ouch."
    "Ok, ouch."

# game/script.rpy:704
translate english ruta_normal_10_36c496c7:

    # C "Pero, ¿Y si te sigue?"
    C "But what if he follows you?"

# game/script.rpy:705
translate english ruta_normal_10_3df52fa3:

    # pov "Eso no va a pasar. Se fue hace horas, es imposible que se haya quedado rondando por aquí."
    pov "That's not going to happen. He left hours ago, there's no way he stayed lurking around here."

# game/script.rpy:706
translate english ruta_normal_10_ac1aea29:

    # C "No lo sé… tu sensor de peligro no es muy acertado que digamos."
    C "I don't know... your danger sensor isn't very accurate, I'd say."

# game/script.rpy:707
translate english ruta_normal_10_7906ca35:

    # pov "El peligro es subjetivo."
    pov "Danger is subjective."

# game/script.rpy:709
translate english ruta_normal_10_4e645e54:

    # C "Eso no es así."
    C "That's not true."

# game/script.rpy:710
translate english ruta_normal_10_21a3cd41:

    # pov "¿Por qué te importa tanto?, creí que me odiabas."
    pov "Why do you care so much? I thought you hated me."

# game/script.rpy:712
translate english ruta_normal_10_4d72f6db:

    # "Cindy se sorprende ante tus palabras. Desvía la mirada hacia un lado, jugando con la vara de la mopa que tenía en manos, para limpiar antes de cerrar."
    "Cindy was surprised by your words. She averted her gaze, playing with the mop handle she had in her hands, to clean before closing."

# game/script.rpy:713
translate english ruta_normal_10_4da6f8f6:

    # C "No te odio… Sólo pienso que estar contigo es aburrido."
    C "I don't hate you... I just think being with you is boring."

# game/script.rpy:714
translate english ruta_normal_10_63b5d32e:

    # pov "Sí, bueno, tú no eres exactamente el alma de la fiesta."
    pov "Yeah, well, you're not exactly the life of the party."

# game/script.rpy:716
translate english ruta_normal_10_0ee3a25f:

    # C "No lo digo como algo malo, en realidad… siento paz contigo."
    C "I don't mean it in a bad way, really... I feel peaceful with you."

# game/script.rpy:717
translate english ruta_normal_10_b746947b:

    # pov "Oh."
    pov "Oh."

# game/script.rpy:718
translate english ruta_normal_10_18b6c29b:

    # C "Tu despreocupación por todo puede llegar a ser tedioso, pero también es reconfortante… de alguna manera."
    C "Your disregard for everything could be tiresome, but it was also comforting... in a way."

# game/script.rpy:719
translate english ruta_normal_10_a068fddf:

    # "Rascas tu cabeza, sin saber cómo reaccionar ante las palabras de Cindy. En realidad nunca te había dicho algo lindo hasta ahora."
    "You scratched your head, not knowing how to react to Cindy's words. She had never said anything nice to you until now."

# game/script.rpy:721
translate english ruta_normal_10_b5a34223:

    # "Cindy se aclara la garganta, desviando la mirada con una mueca avergonzada."
    "Cindy cleared her throat, looking away with an embarrassed grimace."

# game/script.rpy:722
translate english ruta_normal_10_16e04610:

    # C "Lo que quiero decir… es que no quiero que te pase nada."
    C "What I mean is... I don't want anything bad to happen to you."

# game/script.rpy:723
translate english ruta_normal_10_32448f1f:

    # "Das un paso a ella y posas tu mano en su hombro, sonriéndole con calma."
    "You took a step towards her and placed your hand on her shoulder, smiling calmly."

# game/script.rpy:724
translate english ruta_normal_10_60dad86e:

    # pov "Estaré bien. Que algo raro pase no significa que el universo haya decidido girar en mi contra."
    pov "I'll be fine. Just because something weird happened doesn't mean the universe has decided to turn against me."

# game/script.rpy:725
translate english ruta_normal_10_c3e697c9:

    # "Ustedes compartieron un último gesto de despedida antes de que tú cerraras la puerta detrás de ti."
    "You shared a final farewell gesture before you closed the door behind you."

# game/script.rpy:727
translate english ruta_normal_10_405fbc5b:

    # "El letrero de la tienda indicaba que estaba cerrado, y tú suspiraste, sintiendo que el peso de vivir una vida adulta en un mundo capitalista se levantaba un poco de tus hombros."
    "The store sign indicated it was closed, and you sighed, feeling the weight of adult life in a capitalist world lift a little from your shoulders."

# game/script.rpy:728
translate english ruta_normal_10_479fead5:

    # "Sólo un poco."
    "Just a little."

# game/script.rpy:730
translate english ruta_normal_10_29fc634a:

    # "Es parte de la rutina, despedirte de Cindy e irte finalmente a tu hogar."
    "It was part of the routine, saying goodbye to Cindy and finally going home."

# game/script.rpy:731
translate english ruta_normal_10_789485ef:

    # "Vives por tu cuenta desde que empezaste a trabajar, por lo que no tienes responsabilidades extra por las que preocuparte, eso te daba espacio para concentrarte en tus propias necesidades."
    "You'd lived on your own since you started working, so you had no extra responsibilities to worry about, which gave you space to focus on your own needs."

# game/script.rpy:732
translate english ruta_normal_10_fdc40514:

    # "No es una vida extraordinaria, pero es funcional."
    "It wasn't an extraordinary life, but it was functional."

# game/script.rpy:733
translate english ruta_normal_10_e865c2f2:

    # "Trabajas durante la semana, ganas dinero suficiente para el alquiler y las cuentas, y descansas los fines de semana."
    "You worked during the week, earned enough money for rent and bills, and rested on weekends."

# game/script.rpy:734
translate english ruta_normal_10_52d12e2c:

    # "A pesar de que la calle está bien iluminada, el ambiente no deja de ser lúgubre mientras caminas en dirección a tu departamento."
    "Even though the street was well lit, the atmosphere remained gloomy as you walked towards your apartment."

# game/script.rpy:735
translate english ruta_normal_10_05a725ca:

    # "Siempre ha sido así. Nada por lo que temer. ¿Cierto?"
    "It had always been like this. Nothing to fear. Right?"

# game/script.rpy:747
translate english ruta_mala_1_dcf6eb48:

    # "Repentinamente, sientes el sonido de pasos acelerados desde atrás."
    "Suddenly, you heard quick footsteps behind you."

# game/script.rpy:749
translate english ruta_mala_1_6ec1599f:

    # "Te giras para poder reaccionar, pero sientes que unos brazos te rodean fuertemente por el cuello, lo que te inmoviliza."
    "You turned to react, but felt arms wrap tightly around your neck, immobilizing you."

# game/script.rpy:751
translate english ruta_mala_1_a839a0ff:

    # "Forcejeas para liberarte, pero es entonces que sientes la presión en tu estómago."
    "You struggled to break free, but then you felt the pressure in your stomach."

# game/script.rpy:754
translate english ruta_mala_1_a32b7649:

    # "El frío se ramifica desde tu estómago hasta el resto de tu cuerpo, y puedes jurar que sientes tus entrañas al aire libre."
    "A cold sensation branched from your stomach to the rest of your body, and you could swear you felt your guts spilling out."

# game/script.rpy:755
translate english ruta_mala_1_369e00db:

    # "Tu cuerpo se estremece tras ser perforado, y es entonces que el dolor llega."
    "Your body convulsed after being pierced, and that's when the pain hit."

# game/script.rpy:756
translate english ruta_mala_1_624f73a6:

    # "Duele, duele mucho."
    "It hurt, it hurt a lot."

# game/script.rpy:757
translate english ruta_mala_1_dfbe77d5:

    # "Es tan intenso que no puedes sentir tus extremidades."
    "It was so intense you couldn't feel your limbs."

# game/script.rpy:758
translate english ruta_mala_1_d79a79c2:

    # "¿Así es cómo ibas a morir?"
    "Is this how you were going to die?"

# game/script.rpy:759
translate english ruta_mala_1_ec2dcadc:

    # "Sabías que iba a pasar eventualmente, pero no sabías que iba a doler tanto."
    "You knew it would happen eventually, but you didn't know it would hurt so much."

# game/script.rpy:760
translate english ruta_mala_1_58673d96:

    # "¿Quién pudo hacerte esto?"
    "Who could have done this to you?"

# game/script.rpy:761
translate english ruta_mala_1_a738b8a0:

    # "Algo tan cruel…"
    "Something so cruel..."

# game/script.rpy:762
translate english ruta_mala_1_12ae082c:

    # "¿Si quiera te lo merecías?"
    "Did you even deserve it?"

# game/script.rpy:763
translate english ruta_mala_1_958897ff:

    # "No eras una santidad, pero no te considerabas una mala persona."
    "You weren't a saint, but you didn't consider yourself a bad person."

# game/script.rpy:765
translate english ruta_mala_1_b8289e29:

    # "El último pensamiento que cruzó por tu mente, es que Cindy tendrá que cubrir tu turno mientras buscan un reemplazo."
    "The last thought that crossed your mind was that Cindy would have to cover your shift while they looked for a replacement."

# game/script.rpy:769
translate english ruta_mala_1_1fea95e6:

    # "{b}Final I: No Llamaste Su Atención{/b}"
    "{b}Ending I: You Didn't Get His Attention{/b}"

# game/script.rpy:777
translate english historia_continua_1_7780c235:

    # "Es entonces que sientes que tiran de tu brazo hacia un lado, con una gran fuerza."
    "It was then that you felt your arm being pulled violently to one side."

# game/script.rpy:778
translate english historia_continua_1_37b85890:

    # "Tal vez sí debiste estar más alerta."
    "Maybe you should have been more alert."

# game/script.rpy:781
translate english historia_continua_1_d076a17a:

    # "Tiran de ti hasta un callejón al lado de la calle, es ligeramente más oscuro, pero por un farol al costado puedes distinguir lo que está frente a ti."
    "You were dragged into an alley beside the street; it was slightly darker, but a streetlight nearby allowed you to distinguish what was in front of you."

# game/script.rpy:782
translate english historia_continua_1_b136983e:

    # "Como la repentina acción te desorientó, te demoras en reaccionar."
    "Since the sudden action disoriented you, you were slow to react."

# game/script.rpy:783
translate english historia_continua_1_c815043a:

    # pov "¿Que mierd-?"
    pov "What the f—?"

# game/script.rpy:785
translate english historia_continua_1_7298b65e:

    # "El sonido de un golpe leve a un lado de tu cabeza te interrumpe, y te das cuenta que la persona te acorraló contra la pared de ladrillos detrás de ti."
    "The sound of a slight blow to the side of your head interrupted you, and you realized the person had cornered you against the brick wall behind you."

# game/script.rpy:786
translate english historia_continua_1_4cf5d3d7:

    # "Miras de reojo el brazo de la persona, una familiar manga blanca cubre un brazo que se alarga desde tu punto ciego hacia delante."
    "You glanced at the person's arm, a familiar white sleeve covering an arm reaching from your blind spot."

# game/script.rpy:787
translate english historia_continua_1_a3f5837b:

    # "Te cansas de la intriga y finalmente alzas la mirada hacia la persona que te acorraló, tienes un idea de quien podría ser."
    "You grew tired of the suspense and finally looked up at the person who had cornered you. You had an idea who it might be."

# game/script.rpy:792
translate english historia_continua_1_d3542d80:

    # J "[povname], nos encontramos de nuevo."
    J "[povname], we meet again."

# game/script.rpy:793
translate english historia_continua_1_66f6a037:

    # "La incertidumbre te invade ante la vista de un rostro blanco, lleno de cicatrices."
    "Uncertainty filled you at the sight of a white, scarred face."

# game/script.rpy:794
translate english historia_continua_1_20aa010b:

    # "Jeff se había quitado la capucha y la bandana, revelando su rostro."
    "Jeff had removed his hood and bandana, revealing his face."

# game/script.rpy:795
translate english historia_continua_1_c546e882:

    # "La piel variaba de colores y texturas, su nariz estaba hundida, sus ojos azules lechosos estaban sumidos en párpados negros, y tenías la seguridad de que no lo has visto parpadear ni una sóla vez."
    "His skin varied in colors and textures, his nose was sunken, his milky blue eyes were deep-set in dark circles, and you were certain you hadn't seen him blink once."

# game/script.rpy:796
translate english historia_continua_1_ffe6c6c8:

    # "Pero lo que llamó más tu atención, fue la cicatriz que atravesaba su boca."
    "But what caught your attention most was the scar that ran across his mouth."

# game/script.rpy:797
translate english historia_continua_1_9eb6c8c7:

    # "No parecía ser un corte limpio, y el cómo deformaba la expresión de él te causó un escalofrío desagradable."
    "It didn't look like a clean cut, and the way it distorted his expression sent a shiver down your spine."

# game/script.rpy:798
translate english historia_continua_1_7bc7ae10:

    # "Suponías que su rostro tendría imperfecciones que él querría esconder para no recibir miradas de desconocidos, pero considerando la bizarra situación, no fue sorprendente."
    "You assumed his face would have imperfections he'd want to hide to avoid stares from strangers, but considering the bizarre situation, it wasn't surprising."

# game/script.rpy:799
translate english historia_continua_1_f9ed2707:

    # pov "¿Jeff?"
    pov "Jeff?"

# game/script.rpy:800
translate english historia_continua_1_d1ab8411:

    # "Ciertamente, estabas en desventaja aquí, por lo que intentas pensar maneras para dar vuelta la mesa."
    "Certainly, you were at a disadvantage here, so you tried to think of ways to turn the tables."

# game/script.rpy:801
translate english historia_continua_1_5cd86084:

    # pov "Wow, quién lo hubiera imaginado, de noche, alguien solo, callejón lúgubre, un clásico."
    pov "Wow, who would have thought, at night, someone alone, gloomy alley, a classic."

# game/script.rpy:802
translate english historia_continua_1_b641250c:

    # "Jeff se rió entre dientes ante tu sarcasmo."
    "Jeff chuckled at your sarcasm."

# game/script.rpy:803
translate english historia_continua_1_27e95444:

    # J "No dejas la actitud, ¿Eh?"
    J "You don't drop the act, huh?"

# game/script.rpy:807
translate english historia_continua_1_7ce8cd1f:

    # "Para luego sacar del bolsillo de su capucha un… cuchillo."
    "Then he pulled a... knife from his hoodie pocket."

# game/script.rpy:808
translate english historia_continua_1_65abf3f0:

    # J "Ahora… aseguráte de darme un buen espectáculo."
    J "Now... make sure you give me a good show."

# game/script.rpy:809
translate english historia_continua_1_87ac3896:

    # "La voz de él era rasposa, acelerada en un tono ansioso. Daba la impresión de que él estaba impaciente."
    "His voice was raspy, accelerated, with an anxious tone. He seemed impatient."

# game/script.rpy:810
translate english historia_continua_1_711eff21:

    # pov "¿... Espectáculo?"
    pov "...A show?"

# game/script.rpy:811
translate english historia_continua_1_59f910aa:

    # J "El miedo es exquisito…"
    J "Fear is exquisite..."

# game/script.rpy:812
translate english historia_continua_1_8f73355e:

    # "Él susurró, casi (e innecesariamente) poético, inclinándose hacia ti, su respiración rozando tu rostro."
    "He whispered, almost (and unnecessarily) poetically, leaning towards you, his breath grazing your face."

# game/script.rpy:813
translate english historia_continua_1_90c55b6f:

    # pov "Hey, no es por nada… pero todo tu acercamiento se siente muy cliché."
    pov "Hey, no offense... but your whole approach feels very cliché."

# game/script.rpy:814
translate english historia_continua_1_a2a56b45:

    # "Jeff ladeó la cabeza hacia un lado, hubieras jurado que eso era el equivalente de él alzando una ceja."
    "Jeff tilted his head to the side; you would have sworn it was his equivalent of raising an eyebrow."

# game/script.rpy:815
translate english historia_continua_1_f188a2b1:

    # "Si él tuviera cejas."
    "If he had eyebrows."

# game/script.rpy:816
translate english historia_continua_1_29af6601:

    # J "No es un momento adecuado para bromear, ¿No crees?"
    J "This isn't the time for jokes, don't you think?"

# game/script.rpy:817
translate english historia_continua_1_cf7fac73:

    # pov "Si, bueno, realmente no sé qué te motivó a atacarme, pensé que nos estábamos llevando bien."
    pov "Yeah, well, I really don't know what motivated you to attack me. I thought we were getting along."

# game/script.rpy:818
translate english historia_continua_1_b4b21736:

    # "Jeff presionó el ancho de la hoja contra tu mejilla, el metal frío contra tu piel tibia."
    "Jeff pressed the width of the blade against your cheek, the cold metal against your warm skin."

# game/script.rpy:819
translate english historia_continua_1_aeb4f907:

    # J "¿Estás preguntando qué te hace especial?"
    J "Are you asking what makes you special?"

# game/script.rpy:820
translate english historia_continua_1_b6fd1da7:

    # pov "¿Ser especial es que me lleves a un callejón oscuro?, Vaya, no debes ser muy popular."
    pov "Is being special having you drag me into a dark alley? Wow, you must not be very popular."

# game/script.rpy:821
translate english historia_continua_1_6eb80083:

    # "Jeff resopló con molestia."
    "Jeff snorted in annoyance."

# game/script.rpy:823
translate english historia_continua_1_e4740630:

    # "Te sujetó el hombro con la mano con la que te acorraló, y te estrelló contra el muro detrás de ti."
    "He grabbed your shoulder with the hand that had cornered you, and slammed you against the wall behind you."

# game/script.rpy:824
translate english historia_continua_1_4c5dd3b4:

    # "Sentiste tu cabeza golpear contra la textura áspera de la superficie dura, lo que te hizo sisear."
    "You felt your head hit the rough texture of the hard surface, making you wince."

# game/script.rpy:830
translate english historia_continua_1_a1e16c99:

    # pov "Lo siento, ¿Si?"
    pov "I'm sorry, okay?"

# game/script.rpy:831
translate english historia_continua_1_71679a68:

    # pov "No quise hacerte enojar."
    pov "I'm sorry, okay? I didn't mean to make you angry."

# game/script.rpy:832
translate english historia_continua_1_10d23d8c:

    # "Jeff estiró su ya de por sí gran sonrisa, y bajó el cuchillo."
    "Jeff stretched his already wide smile and lowered the knife."

# game/script.rpy:833
translate english historia_continua_1_c287a789:

    # "Pero en el momento en que sentiste alivio por no ver el arma blanca, una punzada en el estómago te invadió."
    "But the moment you felt relief from not seeing the blade, a pang in your stomach hit you."

# game/script.rpy:836
translate english historia_continua_1_9dbefc29:

    # "Instintivamente, tu voz salió en un grito, pero tu boca fue cubierta por una mano que ahogó tu voz en tu garganta."
    "Instinctively, a scream escaped your throat, but your mouth was covered by a hand that muffled your voice."

# game/script.rpy:837
translate english historia_continua_1_b66154e4:

    # J "Así que sí sientes miedo, después de todo…"
    J "So you do feel fear, after all..."

# game/script.rpy:840
translate english historia_continua_1_af4ddf79:

    # "¿De eso se trataba?"
    "Was that what this was about?"

# game/script.rpy:841
translate english historia_continua_1_985b0de6:

    # "De verdad había mucha gente rara en el mundo."
    "There really were a lot of weird people in the world."

# game/script.rpy:842
translate english historia_continua_1_393c0e5e:

    # "Bueno, estabas por dejar de dejar de existir de todas maneras, ya no tendrías que lidiar con eso."
    "Well, you were going to stop existing anyway, so you wouldn't have to deal with it anymore."

# game/script.rpy:845
translate english historia_continua_1_96dc7a76:

    # "Fuiste alguien más del montón para Jeff."
    "You were just another one in the crowd for Jeff."

# game/script.rpy:849
translate english historia_continua_1_a3b6b84e:

    # pov "Más fuerte~"
    pov "Harder~"

# game/script.rpy:850
translate english historia_continua_1_3e73e32c:

    # "Jeff te soltó y retrocedió un par de pasos, como si quemaras."
    "Jeff released you and stepped back a couple of paces, as if you burned him."

# game/script.rpy:855
translate english historia_continua_1_b96635c7:

    # "Su expresión reflejaba sorpresa, y fue una reacción más grande de lo que esperabas."
    "His expression reflected surprise, and it was a bigger reaction than you expected."

# game/script.rpy:856
translate english historia_continua_1_83625366:

    # pov "Relájate, sólo bromeo."
    pov "Relax, I'm just kidding."

# game/script.rpy:857
translate english historia_continua_1_0b347551:

    # J "…No fue gracioso."
    J "...That wasn't funny."

# game/script.rpy:858
translate english historia_continua_1_cfeeb0e6:

    # pov "Para mi lo fue."
    pov "It was to me."

# game/script.rpy:859
translate english historia_continua_1_f655c4e9:

    # J "¡Cállate, esto no debería ser divertido!"
    J "Shut up, this shouldn't be funny!"

# game/script.rpy:860
translate english historia_continua_1_4f9bc483:

    # J "¡Deberías tener miedo!"
    J "You should be afraid!"

# game/script.rpy:865
translate english supervivencia_1_87229444:

    # "Jeff se acercó nuevamente, alzando el cuchillo hasta tu cuello."
    "Jeff approached again, raising the knife to your neck."

# game/script.rpy:866
translate english supervivencia_1_f1361762:

    # "Por reflejo, te alejaste de la hoja, sintiendo la punta perforar tu barbilla."
    "Instinctively, you pulled away from the blade, feeling the tip pierce your chin."

# game/script.rpy:867
translate english supervivencia_1_12e06310:

    # J "Estás en un callejón, de noche, con un cuchillo en tu cuello…"
    J "You're in an alley, at night, with a knife at your throat..."

# game/script.rpy:868
translate english supervivencia_1_d7b64098:

    # J "Así que te preguntaré de nuevo."
    J "So I'll ask you again."

# game/script.rpy:869
translate english supervivencia_1_56b48378:

    # J "¿Tienes miedo?"
    J "Are you afraid?"

# game/script.rpy:874
translate english supervivencia_1_55323a12:

    # "Jeff no ha provocado mucha impresión en ti."
    "Jeff hadn't made much of an impression on you."

# game/script.rpy:875
translate english supervivencia_1_f2f1c3b2:

    # "Eres consciente que tu situación es peligrosa, pero… realmente no te podría importar menos."
    "You were aware your situation was dangerous, but... it really couldn't matter less to you."

# game/script.rpy:876
translate english supervivencia_1_ed2da1f7:

    # "Pero de todas formas, parecía ser divertido ver lo que sucede si te metes con él."
    "But anyway, it seemed fun to see what would happen if you messed with him."

# game/script.rpy:877
translate english supervivencia_1_0f4e1967:

    # "Por el momento, decidiste seguirle la corriente."
    "For now, you decided to play along."

# game/script.rpy:878
translate english supervivencia_1_08fbf2f1:

    # pov "¿Sabes qué?, si, tengo miedo."
    pov "You know what? Yes, I'm afraid."

# game/script.rpy:883
translate english supervivencia_1_fa5d173a:

    # "Que Jeff se joda."
    "Fuck Jeff."

# game/script.rpy:884
translate english supervivencia_1_0a058309:

    # "No tienes ganas de lidiar con un loco sádico."
    "You didn't feel like dealing with a sadistic madman."

# game/script.rpy:885
translate english supervivencia_1_a076b74f:

    # pov "Siga participando."
    pov "Keep participating."

# game/script.rpy:886
translate english supervivencia_1_fdc76934:

    # "La sonrisa de Jeff cae, sutilmente."
    "Jeff's smile fell, subtly."

# game/script.rpy:887
translate english supervivencia_1_5dfb0431:

    # J "¿Oh? ¿Así que así son las cosas?"
    J "Oh? So that's how it is?"

# game/script.rpy:890
translate english supervivencia_1_f48b149f:

    # "Un dolor intenso, agudo, que se ramifica desde tu estómago hasta las puntas de tus dedos te invade, quitándote el aliento."
    "A sharp, intense pain that branched from your stomach to your fingertips invaded you, taking your breath away."

# game/script.rpy:891
translate english supervivencia_1_c2cdfe7d:

    # "Tu voz se atora en la base de tu garganta."
    "Your voice caught in your throat."

# game/script.rpy:892
translate english supervivencia_1_64ffeb12:

    # J "¡¡Hahahahaha!!"
    J "Hahahahaha!!"

# game/script.rpy:893
translate english supervivencia_1_bef58e60:

    # "La risa descontrolada de Jeff es lo único que escuchas."
    "Jeff's uncontrolled laughter was the only thing you heard."

# game/script.rpy:894
translate english supervivencia_1_9ca6fe1a:

    # "Realmente suena como si se estuviera divirtiendo."
    "It truly sounded like he was having fun."

# game/script.rpy:896
translate english supervivencia_1_ea5b8ad9:

    # "Él te mantiene de pie con su mano en tu hombro, pero sientes que te suelta."
    "He kept you on your feet with his hand on your shoulder, but you felt him let go."

# game/script.rpy:898
translate english supervivencia_1_747987a4:

    # "Inevitablemente caes al suelo, sintiendo frío, mucho frío. Las extremidades te pesan y no puedes abrir los ojos por más que lo intentes."
    "You inevitably fell to the ground, feeling cold, very cold. Your limbs felt heavy and you couldn't open your eyes no matter how hard you tried."

# game/script.rpy:901
translate english supervivencia_1_561cdaaf:

    # "No contuviste a Jeff."
    "You didn't hold Jeff back."

# game/script.rpy:907
translate english supervivencia_2_721185f9:

    # "Jeff recuperó su ánimo, extendiendo su gran sonrisa."
    "Jeff recovered his spirits, extending his wide smile."

# game/script.rpy:908
translate english supervivencia_2_e93df6d2:

    # "Él bajó el cuchillo, pero lo mantuvo en su mano."
    "He lowered the knife, but kept it in his hand."

# game/script.rpy:909
translate english supervivencia_2_5fa9007d:

    # "No te estaba amenazando, quizás quería seguir divirtiéndose contigo."
    "He wasn't threatening you; maybe he wanted to keep having fun with you."

# game/script.rpy:910
translate english supervivencia_2_ed5207bf:

    # J "Bien, bien, eso quería oír."
    J "Good, good, that's what I wanted to hear."

# game/script.rpy:911
translate english supervivencia_2_db4fce28:

    # "Típico."
    "Typical."

# game/script.rpy:912
translate english supervivencia_2_6b526010:

    # J "Ahora, ¿Qué te da miedo de mi?"
    J "Now, what scares you about me?"

# game/script.rpy:913
translate english supervivencia_2_24733583:

    # "Evidentemente, Jeff disfrutaba de ver el miedo en sus víctimas."
    "Evidently, Jeff enjoyed seeing fear in his victims."

# game/script.rpy:914
translate english supervivencia_2_c7eb33ac:

    # "Por el momento lograste mantenerlo lo suficientemente contento como para mantener una conversación contigo, pero quizás él buscaba escarbar más."
    "For now, you managed to keep him happy enough to maintain a conversation with you, but maybe he wanted to dig deeper."

# game/script.rpy:915
translate english supervivencia_2_bff97120:

    # "Tal vez le gustaba saber lo que él provocaba en sus víctimas con detalle."
    "Perhaps he liked knowing in detail what he provoked in his victims."

# game/script.rpy:916
translate english supervivencia_2_8b30829a:

    # "Eso es gracioso."
    "That's funny."

# game/script.rpy:917
translate english supervivencia_2_d7c27310:

    # "¿Puedes aceptar el desafío de mimarlo?"
    "Can you accept the challenge of indulging him?"

# game/script.rpy:921
translate english supervivencia_2_1815d7fe:

    # J "¿Mi cara? No eres la única persona en decir eso."
    J "My face? You're not the only person to say that."

# game/script.rpy:922
translate english supervivencia_2_478efdd5:

    # pov "Sí bueno, es un look... Único."
    pov "Yeah, well, it's a look... Unique."

# game/script.rpy:924
translate english supervivencia_2_7f01bc01:

    # "La sonrisa de Jeff se extendió."
    "Jeff's smile stretched."

# game/script.rpy:925
translate english supervivencia_2_0630d6af:

    # J "¿Dices que soy hermoso?"
    J "Are you saying I'm beautiful?"

# game/script.rpy:926
translate english supervivencia_2_240153ac:

    # "Bueno, parece ser vanidoso respecto a su apariencia."
    "Well, he seemed vain about his appearance."

# game/script.rpy:927
translate english supervivencia_2_efd67d59:

    # pov "Claro, tus cicatrices son encantadoras."
    pov "Sure, your scars are enchanting."

# game/script.rpy:930
translate english supervivencia_2_c12880b6:

    # J "Huh, nadie había dicho antes eso, haha."
    J "Huh, nobody ever said that before, haha."

# game/script.rpy:931
translate english supervivencia_2_6eb2857f:

    # pov "Suenas joven, ¿Cuántos años tienes?"
    pov "You sound young. How old are you?"

# game/script.rpy:932
translate english supervivencia_2_6664fd83:

    # "Jeff se sobresaltó de la emoción."
    "Jeff was startled by the emotion."

# game/script.rpy:934
translate english supervivencia_2_5a3a4017:

    # J "¿Te parece?"
    J "You think?"

# game/script.rpy:935
translate english supervivencia_2_9e93dc8c:

    # "Y él ignoró por completo tu pregunta."
    "And he completely ignored your question."

# game/script.rpy:936
translate english supervivencia_2_0ab402a0:

    # "Tal vez era de esos que no le gustaba decir su edad."
    "Maybe he was one of those who didn't like to say their age"

# game/script.rpy:940
translate english supervivencia_2_4c56e5dc:

    # J "¡Qué grosero!"
    J "How rude!"

# game/script.rpy:941
translate english supervivencia_2_c404ba9b:

    # "Su voz sonó más divertida que ofendida."
    "His voice sounded more amused than offended."

# game/script.rpy:942
translate english supervivencia_2_5c10dc63:

    # J "Me gustan los desafíos…"
    J "I like challenges..."

# game/script.rpy:943
translate english supervivencia_2_fd0c67a2:

    # "La forma en que dijo eso fue aún más aterradora."
    "The way he said that was even more terrifying."

# game/script.rpy:946
translate english supervivencia_2_bc765010:

    # J "¡Ding! ¡Ding! ¡Tenemos un ganador!"
    J "Ding! Ding! We have a winner!"

# game/script.rpy:947
translate english supervivencia_2_9fba5ea9:

    # pov "¿Cuál es el premio?"
    pov "What's the prize?"

# game/script.rpy:949
translate english supervivencia_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:950
translate english supervivencia_2_feb1cf35:

    # "Jeff no parece apreciar tu sarcasmo, pero se lo toma a bien."
    "Jeff didn't seem to appreciate your sarcasm, but he took it well."

# game/script.rpy:951
translate english supervivencia_2_b505f7e0:

    # J "Podría pensar en algunos…"
    J "I could think of a few..."

# game/script.rpy:957
translate english supervivencia_3_8f1749ea:

    # J "Esto es más divertido de lo que creía."
    J "This is more fun than I thought it would be."

# game/script.rpy:958
translate english supervivencia_3_c48b34f5:

    # pov "De todas maneras… ¿Por qué me atacas?"
    pov "Anyway... why are you attacking me?"

# game/script.rpy:959
translate english supervivencia_3_bcf3e859:

    # "Jeff te queda mirando unos segundos en silencio, su sonrisa estática."
    "Jeff stared at you in silence for a few seconds, his smile static."

# game/script.rpy:960
translate english supervivencia_3_14a02595:

    # "Te daban ganas de exigirle que parpadee."
    "You felt like demanding he blink."

# game/script.rpy:961
translate english supervivencia_3_3d2eb5de:

    # J "Siento que matarte va a ser divertido."
    J "I think killing you will be fun."

# game/script.rpy:962
translate english supervivencia_3_b8806b9f:

    # "Genial."
    "Great."

# game/script.rpy:963
translate english supervivencia_3_26495026:

    # "Tenías la esperanza de que era un simple ladrón que seguía en su fase de adolescente angsty y sólo quería asustarte, pero resulta que es un loco que genuinamente piensa en asesinarte."
    "You had hoped he was just a simple thief going through an angsty teenage phase and only wanted to scare you, but it turns out he was a madman who genuinely intended to murder you."

# game/script.rpy:964
translate english supervivencia_3_6574df0b:

    # "Sacaste la lotería."
    "You hit the jackpot."

# game/script.rpy:965
translate english supervivencia_3_7e06a86c:

    # pov "Y yo creí que me había ganado tu corazón."
    pov "And I thought I had won your heart."

# game/script.rpy:966
translate english supervivencia_3_902f2a64:

    # J "Oh~ hace falta mucho más que sólo un día para eso."
    J "Oh~ that takes a lot more than just one day."

# game/script.rpy:967
translate english supervivencia_3_85cdb876:

    # "Eso parecía ser información útil."
    "That seemed like useful information."

# game/script.rpy:968
translate english supervivencia_3_32299f29:

    # "Pero para el futuro, ahora deberías concentrarte en sobrevivir."
    "But for the future, you should focus on surviving now."

# game/script.rpy:969
translate english supervivencia_3_5845e4f9:

    # J "Ya sé. Juguemos a algo."
    J "I know. Let's play a game."

# game/script.rpy:970
translate english supervivencia_3_d0bf93b8:

    # pov "¿Jugar a qué?"
    pov "Play what?"

# game/script.rpy:971
translate english supervivencia_3_a8450a72:

    # J "Un simple las traes."
    J "A simple game of tag."

# game/script.rpy:972
translate english supervivencia_3_9b1fb005:

    # pov "¿Qué pasa si gano?"
    pov "What happens if I win?"

# game/script.rpy:973
translate english supervivencia_3_3855746b:

    # J "..."
    J "..."

# game/script.rpy:974
translate english supervivencia_3_fbd8506e:

    # J "Te dejaré ir."
    J "I'll let you go."

# game/script.rpy:975
translate english supervivencia_3_a5a95d8a:

    # "……………….."
    "..........."

# game/script.rpy:977
translate english supervivencia_3_afcc87f7:

    # J "¡Es lo que te gustaría que dijera! ¡Hahahaha!"
    J "That's what you'd like me to say! Hahahaha!"

# game/script.rpy:978
translate english supervivencia_3_751b5c2a:

    # "Era un idiota. Un idiota muy peligroso."
    "He was an idiot. A very dangerous idiot."

# game/script.rpy:979
translate english supervivencia_3_8c4bab6b:

    # "Tenías que escoger con cuidado."
    "You had to choose carefully."

# game/script.rpy:985
translate english supervivencia_3_9981559c:

    # J "¡Estupendo!"
    J "Excellent!"

# game/script.rpy:987
translate english supervivencia_3_2535fd97:

    # "Jeff te suelta y retrocede un par de pasos."
    "Jeff let you go and stepped back a couple of paces."

# game/script.rpy:989
translate english supervivencia_3_2207b7a2:

    # J "Te daré una ventaja de 10 segundos."
    J "I'll give you a 10-second head start."

# game/script.rpy:990
translate english supervivencia_3_a7ce8336:

    # J "1….."
    J "1....."

# game/script.rpy:993
translate english supervivencia_3_d6cd672c:

    # "No dudas y sales corriendo hacia la salida del callejón. Las piernas te temblaban, pero las obligaste a seguir."
    "You didn't hesitate and ran towards the alley exit. Your legs trembled, but you forced them to keep going."

# game/script.rpy:994
translate english supervivencia_3_f867755c:

    # "No querías ser precisamente víctima de asesinato después de todo."
    "You didn't want to be a victim of murder, after all."

# game/script.rpy:995
translate english supervivencia_3_c7b62b46:

    # "Si de morir se trata, preferirías morir de manera indolora."
    "If you had to die, you'd prefer to die painlessly."

# game/script.rpy:996
translate english supervivencia_3_dcb3dbd1:

    # J "¡{size=30}...2,4, 6….{/size}!"
    J "{size=30}...2, 4, 6....{/size}!"

# game/script.rpy:997
translate english supervivencia_3_5d809fa7:

    # "¡¡!!"
    "!!"

# game/script.rpy:998
translate english supervivencia_3_5fc35918:

    # "¡El desgraciado está contando mal!"
    "The bastard is counting wrong!"

# game/script.rpy:999
translate english supervivencia_3_25bd8309:

    # "Pero era tu culpa por confiar en lo que él dice."
    "But it was your fault for trusting what he said."

# game/script.rpy:1000
translate english supervivencia_3_20e133db:

    # "¿Qué podías esperar de un demente?"
    "What could you expect from a madman?"

# game/script.rpy:1002
translate english supervivencia_3_040d801d:

    # "Sales del callejón, , casi te caes, pero la adrenalina te hace continuar."
    "You burst out of the alley, almost falling, but adrenaline kept you going."

# game/script.rpy:1006
translate english supervivencia_3_2074bdca:

    # "Estarás yendo de vuelta hacia la tienda."
    "You were heading back to the store."

# game/script.rpy:1007
translate english supervivencia_3_ca7b06dc:

    # "Cindy debería seguir ahí, podías pedir su ayuda y refugiarte."
    "Cindy should still be there; you could ask for her help and take refuge."

# game/script.rpy:1009
translate english supervivencia_3_8be8cba1:

    # "Llegas a la puerta, intentas abrir, pero está cerrada."
    "You reached the door, tried to open it, but it was locked."

# game/script.rpy:1011
translate english supervivencia_3_bf665b22:

    # "Golpeas la puerta con fuerza, sin importarte si rompes el vidrio."
    "You pounded on the door forcefully, not caring if you broke the glass."

# game/script.rpy:1012
translate english supervivencia_3_b50eda55:

    # pov "¡Cindy!, ¡Abre!, ¡Rápido!"
    pov "Cindy! Open up! Quickly!"

# game/script.rpy:1014
translate english supervivencia_3_f5ac74a1:

    # "Tu corazón acelerado rebota con esperanza al ver a Cindy entre las repisas de películas."
    "Your accelerated heart thumped with hope when you saw Cindy among the movie racks."

# game/script.rpy:1015
translate english supervivencia_3_d8d60e12:

    # "Pero tu esperanza cae cuando la ves audífonos mientras trapea el piso."
    "But your hope plummeted when you saw her wearing headphones while mopping the floor."

# game/script.rpy:1016
translate english supervivencia_3_78bfcf62:

    # pov "¡Cindy!, ¡Tu… perra, abre la puerta!"
    pov "Cindy! You... bitch, open the door!"

# game/script.rpy:1017
translate english supervivencia_3_fbb69540:

    # "Tus gritos no parecen ser escuchados, por la manera en la que la ves contonearse con el trapero en manos."
    "Your shouts didn't seem to be heard, judging by the way you saw her swaying with the mop in her hands."

# game/script.rpy:1018
translate english supervivencia_3_db17128d:

    # "No es la primera vez que Cindy te decepciona, pero esta vez se siente más doloroso."
    "It wasn't the first time Cindy had disappointed you, but this time it felt more painful."

# game/script.rpy:1019
translate english supervivencia_3_e54a1954:

    # "Y eso que pensaste que las cosas podían mejorar entre ustedes dos."
    "And you thought things might get better between you two."

# game/script.rpy:1021
translate english supervivencia_3_9f55fa5c:

    # J "{size=30}Las traes….{/size}"
    J "{size=30}You're it....{/size}"

# game/script.rpy:1024
translate english supervivencia_3_17eb7f0a:

    # "Escuchas ese susurro burlón en tu oído, pero no tienes momento para girarte cuando te empujan contra el vidrio de la puerta y sientes una presión dolorosa en tu costado derecho."
    "You heard that mocking whisper in your ear, but you had no time to turn around as you were pushed against the glass door and felt a painful pressure in your right side."

# game/script.rpy:1026
translate english supervivencia_3_5d88d5a7:

    # pov "¡Cough!"
    pov "Cough!"

# game/script.rpy:1027
translate english supervivencia_3_286d2a42:

    # "Te ahogas con tu propia sangre, el líquido salpica el vidrio."
    "You choked on your own blood, the liquid splattered on the glass."

# game/script.rpy:1028
translate english supervivencia_3_51ef2b57:

    # J "Pensé que sería más divertido… Bueno, qué más da."
    J "I thought it would be more fun... Oh well, whatever."

# game/script.rpy:1029
translate english supervivencia_3_6ea04490:

    # "No puedes formular ningún pensamiento en el momento que la presión de tu costado es liberada."
    "You couldn't form a single thought the moment the pressure on your side was released."

# game/script.rpy:1030
translate english supervivencia_3_d437c2ea:

    # "Sientes algo se derrama de tu costado, mojando tu pierna."
    "You felt something warm spill from your side, wetting your leg."

# game/script.rpy:1031
translate english supervivencia_3_cf9b0316:

    # "Instintivamente diriges una mano a la herida, con el impulso de detener la hemorragia."
    "Instinctively, you reached a hand to the wound, with the impulse to stop the bleeding."

# game/script.rpy:1032
translate english supervivencia_3_4ece4b0d:

    # "Pero es imposible."
    "But it was impossible."

# game/script.rpy:1033
translate english supervivencia_3_eed4c30c:

    # "Sientes que te sueltan, pero tus piernas pierden la fuerza."
    "You felt yourself being released, but your legs lost strength."

# game/script.rpy:1035
translate english supervivencia_3_af23b231:

    # "Te deslizas contra la puerta hasta llegar al suelo, sintiendo que debajo de ti se forma un charco de sangre drenada del lugar donde te apuñalaron."
    "You slid down the door to the ground, feeling a puddle of blood draining from where you were stabbed forming beneath you."

# game/script.rpy:1037
translate english supervivencia_3_c057e001:

    # "Tu consciencia se va, tus ojos pesan."
    "Your consciousness faded, your eyes felt heavy."

# game/script.rpy:1038
translate english supervivencia_3_d80eec30:

    # C "¿Qué está-? ¡¡[povname]!!"
    C "What's happen—? [povname]!!"

# game/script.rpy:1039
translate english supervivencia_3_18f1b098:

    # "Al menos Cindy se dio cuenta al final."
    "At least Cindy noticed in the end."

# game/script.rpy:1040
translate english supervivencia_3_538c6bd8:

    # "Ella era todo un caso, pero esperabas que ella lo hiciera mejor a futuro."
    "She was a real case, but you hoped she'd do better in the future."

# game/script.rpy:1043
translate english supervivencia_3_5f5b3cef:

    # "Perdiste el juego de Jeff."
    "You lost Jeff's game."

# game/script.rpy:1047
translate english supervivencia_3_cf52abc5:

    # "¡Si puedes llegar a tu hogar estarás a salvo!"
    "If you can get home, you'll be safe!"

# game/script.rpy:1049
translate english supervivencia_3_b6b99fa1:

    # "Corres hacia adelante sin mirar atrás, el aire frío perforando tus pulmones mientras escuchas los latidos de tu corazón en los oídos."
    "You ran forward without looking back, the cold air piercing your lungs as you heard your heart pounding in your ears."

# game/script.rpy:1050
translate english supervivencia_3_c5e00754:

    # "¡Falta poco….! ¡Sólo un poco más…!"
    "Almost there...! Just a little more...!"

# game/script.rpy:1055
translate english supervivencia_3_743cb459:

    # "Un peso demasiado pesado cae encima tuyo te inmoviliza contra el suelo."
    "A too-heavy weight fell on you, pinning you to the ground."

# game/script.rpy:1056
translate english supervivencia_3_da4c2f51:

    # J "¡Haaaa…. Eso fue divertido!"
    J "Haaaa.... That was fun!"

# game/script.rpy:1057
translate english supervivencia_3_d1f27681:

    # "Te congelas al escuchar la voz de Jeff, para después sacudirte con la esperanza de quitártelo de encima."
    "You froze at the sound of Jeff's voice, then struggled, hoping to shake him off."

# game/script.rpy:1058
translate english supervivencia_3_6e308af4:

    # J "Tsk, tsk… Aprende a perder, [povname]."
    J "Tsk, tsk... Learn to lose, [povname]."

# game/script.rpy:1059
translate english supervivencia_3_eb65b64d:

    # pov "E-espera, hiciste trampa, no contaste bien…"
    pov "W-wait, you cheated, you didn't count right..."

# game/script.rpy:1060
translate english supervivencia_3_14360a18:

    # J "…"
    J "..."

# game/script.rpy:1061
translate english supervivencia_3_5d4a1466:

    # J "Seh, eso no importa realmente."
    J "Yeah, that doesn't really matter."

# game/script.rpy:1062
translate english supervivencia_3_a8455697:

    # "Él sujeta tu cabeza con fuerza, lo que te saca un quejido de dolor."
    "He held your head tightly, eliciting a cry of pain from you."

# game/script.rpy:1064
translate english supervivencia_3_133603e5:

    # "El frío y duro filo de la hoja del cuchillo presiona tu cuello expuesto."
    "The cold, hard edge of the knife blade pressed against your exposed neck."

# game/script.rpy:1065
translate english supervivencia_3_13ee4ae2:

    # pov "P-pero jugamos como querías."
    pov "B-but we played as you wanted."
# game/script.rpy:1066
translate english supervivencia_3_3855746b_1:

    # J "..."
    J "..."

# game/script.rpy:1067
translate english supervivencia_3_ba610d29:

    # J "Heh….heh…"
    J "Heh….heh…"

# game/script.rpy:1068
translate english supervivencia_3_19cfa11b:

    # J "¡¡HAHAHAHAHA!!"
    J "HAHAHAHAHA!!"

# game/script.rpy:1069
translate english supervivencia_3_9aacd991:

    # J "Hah…. haha….."
    J "Hah…. haha….."

# game/script.rpy:1070
translate english supervivencia_3_44dfb139:

    # J "Esto fue refrescante."
    J "That was refreshing."

# game/script.rpy:1071
translate english supervivencia_3_59167366:

    # J "Pero ya me aburrí."
    J "But I'm bored now."

# game/script.rpy:1073
translate english supervivencia_3_1a645669:

    # "La hoja se deslizó de un extremo a otro de tu cuello."
    "The blade slid from one end of your neck to the other."

# game/script.rpy:1076
translate english supervivencia_3_020867c5:

    # "La sangre brotó de tu garganta en un gran chorro."
    "Blood gushed from your throat in a large stream."

# game/script.rpy:1077
translate english supervivencia_3_6ebf04ba:

    # "Tus ojos se nublaron y los músculos de tu cuello perdieron la fuerza."
    "Your eyes blurred and the muscles in your neck lost strength."

# game/script.rpy:1078
translate english supervivencia_3_08d817c2:

    # "El agarre en tu cabello fue soltado y tu cabeza cayó sobre el charco de sangre que seguía creciendo lentamente."
    "His grip on your hair loosened and your head fell onto the slowly spreading pool of blood."

# game/script.rpy:1079
translate english supervivencia_3_46cad9c1:

    # "No podías ver nada, pero percibiste el sonido de los pasos de él alejarse."
    "You couldn't see anything, but you perceived the sound of his footsteps walking away."

# game/script.rpy:1081
translate english supervivencia_3_82c37a85:

    # "¿Ibas a terminar así?"
    "Were you going to end like this?"

# game/script.rpy:1082
translate english supervivencia_3_e57b1fdb:

    # "Era injusto."
    "It was unfair."

# game/script.rpy:1083
translate english supervivencia_3_a2d26da0:

    # "Ser desechado."
    "To be discarded."

# game/script.rpy:1084
translate english supervivencia_3_3fff576a:

    # "Hubieras preferido morir de otra manera."
    "You would have preferred to die another way."

# game/script.rpy:1087
translate english supervivencia_3_45579616:

    # "Aburriste a Jeff."
    "You bored Jeff."

# game/script.rpy:1093
translate english supervivencia_3_6fac7ef3:

    # J "...."
    J "...."

# game/script.rpy:1094
translate english supervivencia_3_688f8e78:

    # "Los ojos de él se inyectan en sangre, sus dientes chocan y generan un chirrido que te provoca un escalofrío."
    "His eyes became bloodshot, his teeth clacked together, creating a grating sound that sent a shiver down your spine."

# game/script.rpy:1095
translate english supervivencia_3_4533ff0e:

    # J "¿Desprecias mi amabilidad?"
    J "You dare despise my kindness?"

# game/script.rpy:1096
translate english supervivencia_3_81e334ce:

    # "La voz de él se vuelve grave y temblorosa por la rabia."
    "His voice grew grave and trembled with rage."

# game/script.rpy:1097
translate english supervivencia_3_4973e052:

    # "Estás a punto de retractarte y tranquilizarlo."
    "You were about to retract and calm him."

# game/script.rpy:1100
translate english supervivencia_3_52bc9c43:

    # "Pero es tarde cuando sientes una repentina presión en tu barbilla, atravesando tu piel y músculos hasta atravesar tu lengua."
    "But it was too late as you felt a sudden pressure on your chin, piercing your skin and muscles, all the way through to your tongue."

# game/script.rpy:1102
translate english supervivencia_3_5bcbbd14:

    # "Te ahogas con la sangre que brota de tu boca, el dolor agudo nublando tu mente y visión."
    "You choked on the blood flowing from your mouth, the sharp pain clouding your mind and vision."

# game/script.rpy:1103
translate english supervivencia_3_21147a3e:

    # J "¡Te doy la elección y tú la desperdicias!"
    J "I give you the choice, and you waste it!"

# game/script.rpy:1104
translate english supervivencia_3_3f4e8d73:

    # "Él grita estridente, empujando más la hoja de su cuchillo en ti, hasta sentir que el metal llega a tu paladar."
    "He screamed shrilly, pushing the blade of his knife deeper into you, until the metal reached your palate."

# game/script.rpy:1106
translate english supervivencia_3_54324133:

    # "Tus sentidos se apagan lentamente, hasta que ya no sientes nada…"
    "Your senses slowly faded, until you felt nothing..."

# game/script.rpy:1107
translate english supervivencia_3_57811a7c:

    # "Que manera tan horrible de morir…"
    "What a horrible way to die..."

# game/script.rpy:1110
translate english supervivencia_3_dea93038:

    # "Despreciaste a Jeff."
    "You despised Jeff."

# game/script.rpy:1121
translate english supervivencia_4_3571cf5f:

    # "Jeff se trastabilla con sus palabras, sin haberse esperado esa respuesta."
    "Jeff stumbled over his words, not having expected that response."

# game/script.rpy:1122
translate english supervivencia_4_53e32e89:

    # J "............."
    J "............."

# game/script.rpy:1123
translate english supervivencia_4_34dc9b3a:

    # "Jeff se enderezó sobre ti, analizándote en silencio."
    "Jeff straightened up over you, analyzing you in silence."

# game/script.rpy:1126
translate english supervivencia_4_b96596f3:

    # "El rostro de él era extrañamente inexpresivo, supones porque con la boca rota como la tiene él, es una condena a tener la misma expresión permanentemente."
    "His face was strangely expressionless, you assumed because with his mouth mangled as it was, he was condemned to have the same expression permanently."

# game/script.rpy:1130
translate english supervivencia_4_76829a15:

    # "Repentinamente, sientes que tu cuello es apretado con fuerza, siendo difícil para ti respirar."
    "Suddenly, you felt your neck squeezed tightly, making it hard to breathe."

# game/script.rpy:1131
translate english supervivencia_4_a25243ff:

    # "Instintivamente, alzas las manos y tiras del brazo de Jeff, un impulso de tu cuerpo para tratar de luchar."
    "Instinctively, you raised your hands and pulled at Jeff's arm, an impulse from your body to try and fight."

# game/script.rpy:1132
translate english supervivencia_4_dc2bee19:

    # J "Témeme…"
    J "Fear me..."

# game/script.rpy:1133
translate english supervivencia_4_fdf0276d:

    # "El reclamo sonó casi infantil, a pesar de provenir de un hombre amenazante."
    "The complaint sounded almost childish, despite coming from a threatening man."

# game/script.rpy:1134
translate english supervivencia_4_07d11d74:

    # "Intentas responder algo, cualquier cosa, pero tus cuerdas vocales están siendo apretadas demasiado fuerte."
    "You tried to respond, anything, but your vocal cords were being squeezed too tightly."

# game/script.rpy:1135
translate english supervivencia_4_cb6ea212:

    # "Alcanzaste a escuchar el murmullo de él antes de sentir que la presión en tu cuello era liberada."
    "You managed to hear his murmur before you felt the pressure on your neck release."

# game/script.rpy:1136
translate english supervivencia_4_ddbff59f:

    # "La mano de él seguía sobre tu cuello, pero sólo presionaba lo suficiente como para inmovilizarte."
    "His hand remained on your neck, but only pressed enough to immobilize you."

# game/script.rpy:1137
translate english supervivencia_4_abf0ba29:

    # "Tosiste y respiraste aceleradamente, tratando de recuperar el aire que te faltaba."
    "You coughed and gasped for air, trying to recover your breath."

# game/script.rpy:1141
translate english supervivencia_4_ec90ca76:

    # "Pero entonces te diste cuenta que Jeff nuevamente estaba casi sobre ti, con cuchillo en mano."
    "But then you realized Jeff was again almost on top of you, knife in hand."

# game/script.rpy:1142
translate english supervivencia_4_c86edcb4:

    # "Sentiste una punzada de dolor en tu mejilla, pero fue por un instante."
    "You felt a pang of pain in your cheek, but it was for an instant."

# game/script.rpy:1143
translate english supervivencia_4_e6c4a7cd:

    # "Jeff le hizo un corte limpio a la piel de tu mejilla izquierda, sentiste el cosquilleo de una delgada línea de sangre caer hasta tu mandíbula."
    "Jeff made a clean cut on the skin of your left cheek; you felt the tickle of a thin line of blood running down to your jaw."

# game/script.rpy:1144
translate english supervivencia_4_c5c3f19e:

    # J "¿Por qué no tienes miedo?"
    J "Why aren't you afraid?"

# game/script.rpy:1145
translate english supervivencia_4_ab682701:

    # "Jeff te examinaba en silencio, como si al mirar tu reacción podría sacar una respuesta que lo satisfaga."
    "Jeff examined you in silence, as if looking at your reaction would give him a satisfying answer."

# game/script.rpy:1147
translate english supervivencia_4_a2ff6030:

    # "No era como si realmente no sintieras nada."
    "It wasn't as if you didn't really feel anything."

# game/script.rpy:1148
translate english supervivencia_4_f640861b:

    # "Reconocías que la situación era peligrosa, tu cuerpo lo sabía por el fuerte latir de tu corazón."
    "You recognized the situation was dangerous; your body knew it from the strong pounding of your heart."

# game/script.rpy:1149
translate english supervivencia_4_72918e70:

    # "Pero como ha sido desde el inicio, no te importaba."
    "But as it had been from the start, you didn't care."

# game/script.rpy:1150
translate english supervivencia_4_c03c3c74:

    # "Él pedía que te le temas, pero como él amenaza tu vida, y no te importa realmente morir, en consecuencia, no le temes."
    "He wanted you to fear him, but since he was threatening your life, and you didn't truly care about dying, consequently, you didn't fear him."

# game/script.rpy:1155
translate english supervivencia_4_d0958fb4:

    # "Bajas la mirada, pero no por miedo."
    "You lowered your gaze, but not out of fear."

# game/script.rpy:1156
translate english supervivencia_4_0fe9f491:

    # "Sino que por cansancio."
    "Rather, out of weariness."

# game/script.rpy:1157
translate english supervivencia_4_ec930570:

    # "¿Qué dejarías atrás si morías?"
    "What would you leave behind if you died?"

# game/script.rpy:1158
translate english supervivencia_4_2a829ef6:

    # "No mucho, así que ya no te importaba."
    "Not much, so you don't care anymore."

# game/script.rpy:1159
translate english supervivencia_4_a107038b:

    # pov "Lo siento Jeff, pero no tengo miedo para darte."
    pov "I'm sorry, Jeff, but I don't have fear to give you."

# game/script.rpy:1164
translate english supervivencia_4_c49c65c4:

    # "Lo miras directamente a los ojos."
    "You looked him directly in the eyes."

# game/script.rpy:1165
translate english supervivencia_4_a420ef97:

    # pov "Tanto drama… ¿Para esto?"
    pov "So much drama... for this?"

# game/script.rpy:1166
translate english supervivencia_4_edf0091d:

    # "La boca de Jeff se tuerce."
    "Jeff's mouth twisted."

# game/script.rpy:1167
translate english supervivencia_4_0bf262c8:

    # pov "Sólo eres un asesino genérico, acosando a la víctima y llevándola a un callejón."
    pov "You're just a generic killer, stalking your victim and taking them into an alley."

# game/script.rpy:1168
translate english supervivencia_4_20ef8dd6:

    # pov "Si querías causar una mejor impresión, podrías ser más original."
    pov "If you wanted to make a better impression, you could be more original."

# game/script.rpy:1169
translate english supervivencia_4_3331a0da:

    # "De repente, la comisura extendida de Jeff se alza, extrañándote."
    "Suddenly, Jeff's extended mouth quirked up, a strange sight."

# game/script.rpy:1170
translate english supervivencia_4_ded07d51:

    # J "Fue algo difícil de ver, pero…"
    J "It was hard to see, but..."

# game/script.rpy:1173
translate english supervivencia_4_31d5d579:

    # "Jeff clavó el cuchillo debajo de tus costillas, quitándote el aire."
    "Jeff plunged the knife below your ribs, taking your breath away."

# game/script.rpy:1174
translate english supervivencia_4_2708e788:

    # "Él se inclinó sobre tu oído"
    "He leaned over your ear."

# game/script.rpy:1175
translate english supervivencia_4_2fa024fe:

    # J "Eres de luchar, ¿No?"
    J "You're a fighter, aren't you?"

# game/script.rpy:1176
translate english supervivencia_4_4ebd09b2:

    # "La sangre sube por tu garganta, ahogándote."
    "Blood rose in your throat, choking you."

# game/script.rpy:1178
translate english supervivencia_4_023a8e77:

    # "Vaya, parece que desafiarlo lo interpretó como una manera de luchar por tu vida."
    "Well, it seems like he interpreted your defiance as a way to fight for your life."

# game/script.rpy:1179
translate english supervivencia_4_d76bf665:

    # "Realmente ese no era el caso, pero te resignaste."
    "That wasn't really the case, but you resigned yourself."

# game/script.rpy:1182
translate english supervivencia_4_ec31decd:

    # "Alargaste lo inevitable."
    "You prolonged the inevitable."

# game/script.rpy:1189
translate english supervivencia_5_3855746b:

    # J "..."
    J "..."

# game/script.rpy:1191
translate english supervivencia_5_e557b377:

    # "Jeff se mantuvo en silencio por un segundo, hasta que lograste notar cómo su sonrisa se extendía sutilmente."
    "Jeff remained silent for a second, until you noticed his smile subtly widen."

# game/script.rpy:1192
translate english supervivencia_5_2d55de67:

    # "Él lentamente se inclinó hacia a ti {w=0.5}y lamió tu mejilla herida, limpiando la línea de sangre."
    "He slowly leaned towards you {w=0.5} and licked your wounded cheek, wiping away the line of blood."

# game/script.rpy:1193
translate english supervivencia_5_afe026a6:

    # "Su respiración chocaba contra tu piel, tibia y húmeda."
    "His breath brushed against your skin, warm and damp."

# game/script.rpy:1194
translate english supervivencia_5_b1981d4e:

    # "El toque de su lengua te ardió en la herida, haciéndote sisear."
    "The touch of his tongue burned on the wound, making you hiss."

# game/script.rpy:1195
translate english supervivencia_5_8728fb3b:

    # "Podías aceptar que él te lamiera, sólo era él siendo raro."
    "You could accept him licking you; he was just being weird."

# game/script.rpy:1196
translate english supervivencia_5_4af39a27:

    # "Pero no podías quitarte de encima lo que él quería decirte con esa acción."
    "But you couldn't shake off what he wanted to tell you with that action."

# game/script.rpy:1201
translate english supervivencia_5_c4263066:

    # pov "¿Lamerme? Qué romántico. Me derrito."
    pov "Lick me? How romantic. I'm melting."

# game/script.rpy:1202
translate english supervivencia_5_63e56f22:

    # "¿Quizás si le tomas el pelo lo suficiente te deje en paz?"
    "Maybe if you tease him enough, he'll leave you alone?"

# game/script.rpy:1203
translate english supervivencia_5_519c5c0c:

    # "Tenías que intentar."
    "You had to try."

# game/script.rpy:1208
translate english supervivencia_5_a8639721:

    # "Una cosa es que no te importe que te atacan en la noche por un maníaco, pero otra cosa distinta es que te… ataquen de otra forma."
    "One thing is not caring about being attacked at night by a maniac, but it's another thing entirely to be... attacked in that way."

# game/script.rpy:1209
translate english supervivencia_5_6255dceb:

    # "No quieres ni pensarlo."
    "You didn't even want to think about it."

# game/script.rpy:1210
translate english supervivencia_5_89d11338:

    # pov "Por favor… no me hagas daño…."
    pov "Please... don't hurt me...."

# game/script.rpy:1211
translate english supervivencia_5_64be5f66:

    # "Quizás si pedías clemencia te deje ir."
    "Maybe if you begged for mercy, he'd let you go."

# game/script.rpy:1213
translate english supervivencia_5_32df0955:

    # J ".......Heh."
    J ".......Heh."

# game/script.rpy:1214
translate english supervivencia_5_9f30f070:

    # "Jeff rió entre dientes, bajando el cuchillo hasta tu abdomen."
    "Jeff chuckled, lowering the knife to your abdomen."

# game/script.rpy:1215
translate english supervivencia_5_0572e0bb:

    # J "Sabía que me temerías…."
    J "I knew you'd fear me...."

# game/script.rpy:1216
translate english supervivencia_5_f02a8d27:

    # "Buenop, parece que Jeff lo tomó como tu queriendo complacerlo para que no te haga daño."
    "Well, it seems Jeff took it as you trying to please him so he wouldn't hurt you."

# game/script.rpy:1217
translate english supervivencia_5_93a2f669:

    # "No estaba del todo equivocado, pero ciertamente tu intención era algo distinta…"
    "You weren't entirely wrong, but your intention was certainly different..."

# game/script.rpy:1220
translate english supervivencia_5_032bc689:

    # "Jeff hundió la hoja en tus entrañas, la punzada quitándote el aire."
    "Jeff plunged the blade into your guts, the pang taking your breath away."

# game/script.rpy:1222
translate english supervivencia_5_4f4f06d4:

    # "Pero eso no lo detuvo."
    "But that didn't stop him."

# game/script.rpy:1224
translate english supervivencia_5_f4987dc7:

    # "Te apuñaló una y otra vez, hasta que se sintiera satisfecho."
    "He stabbed you again and again, until he was satisfied."

# game/script.rpy:1226
translate english supervivencia_5_7bed8e66:

    # "El cansancio y el dolor era tan intensos que no podías mantener los ojos abiertos, pero aún podías escuchar."
    "The exhaustion and pain were so intense that you couldn't keep your eyes open, but you could still hear."

# game/script.rpy:1227
translate english supervivencia_5_e2eb7f2c:

    # J "Eso fue un dolor…."
    J "That was pain...."

# game/script.rpy:1230
translate english supervivencia_5_ec31decd:

    # "Alargaste lo inevitable."
    "You prolonged the inevitable."

# game/script.rpy:1239
translate english supervivencia_6_b3e1dfe3:

    # "Jeff gruñó entre dientes, volviendo a estrellarte contra la pared de ladrillos."
    "Jeff growled through gritted teeth, slamming you against the brick wall again."

# game/script.rpy:1240
translate english supervivencia_6_7c8c8fc8:

    # "Soltaste un quejido de dolor ante el impacto."
    "You let out a groan of pain from the impact."

# game/script.rpy:1241
translate english supervivencia_6_1673fd60:

    # J "¿Por qué… no me temes?"
    J "Why... don't you fear me?"

# game/script.rpy:1242
translate english supervivencia_6_5ddb771f:

    # pov "No sé qué quieres que te diga, Jeff."
    pov "I don't know what you want me to say, Jeff."

# game/script.rpy:1244
translate english supervivencia_6_27c953cc:

    # "Jeff bajó la cabeza, aparentemente decepcionado."
    "Jeff lowered his head, seemingly disappointed."

# game/script.rpy:1245
translate english supervivencia_6_d9ccfc41:

    # "Desviaste la mirada hacia los lados con duda, sin saber qué hacer."
    "You glanced around hesitantly, not knowing what to do."

# game/script.rpy:1247
translate english supervivencia_6_f85d2aab:

    # "Pero entonces él se enderezó nuevamente, con su sonrisa tan extendida que sus labios estaban tensos."
    "But then he straightened up again, his smile so wide his lips were taut."

# game/script.rpy:1248
translate english supervivencia_6_b6c4889b:

    # J "No hay nada que pueda hacer si no temes a la muerte."
    J "There's nothing I can do if you don't fear death."

# game/script.rpy:1249
translate english supervivencia_6_9d642099:

    # J "Pero puedo hacer que me temas."
    J "But I can make you fear me."

# game/script.rpy:1252
translate english supervivencia_6_f3c8232a:

    # "Alzó el cuchillo nuevamente, pero no a la altura para apuñalarte en un punto vital, sino que acercó la punta lentamente a tu rostro, a la altura de tu ojo izquierdo."
    "He raised the knife again, but not to stab you in a vital spot. Instead, he slowly brought the tip to your face, level with your left eye."

# game/script.rpy:1253
translate english supervivencia_6_2b90a2ec:

    # J "Así que haremos esto, [povname]."
    J "So we'll do this, [povname]."

# game/script.rpy:1254
translate english supervivencia_6_6330ffcc:

    # "Tragaste duro ante la visión distorsionada de la punta del cuchillo a milímetros de tu pupila."
    "You swallowed hard at the distorted vision of the knife tip millimeters from your pupil."

# game/script.rpy:1255
translate english supervivencia_6_ed1d67a2:

    # J "Voy a perseguirte. Cada vez que te atrape, te haré daño, y cada vez que me evites, me alejaré un poco."
    J "I'm going to hunt you. Every time I catch you, I'll hurt you, and every time you avoid me, I'll back off a little."

# game/script.rpy:1256
translate english supervivencia_6_93993593:

    # "Los ojos de Jeff temblaban, casi blancos, como dos focos en medio de la oscuridad."
    "Jeff's eyes trembled, almost white, like two spotlights in the dark."

# game/script.rpy:1257
translate english supervivencia_6_0ca5f186:

    # pov "E-espera…"
    pov "W-wait..."

# game/script.rpy:1258
translate english supervivencia_6_2b07c755:

    # J "Perdiste el primer turno."
    J "You lost the first round."

# game/script.rpy:1259
translate english supervivencia_6_4a942a8b:

    # "Dictó Jeff, empujando su mano."
    "Jeff dictated, pushing his hand forward."

# game/script.rpy:1263
translate english supervivencia_6_9b8d4e12:

    # "La hoja se enterró en la esquina de tu ojo, casi rozando el borde del párpado."
    "The blade dug into the corner of your eye, almost grazing your eyelid."

# game/script.rpy:1264
translate english supervivencia_6_583ee911:

    # "Gritaste con todas tus fuerzas, hasta que sentiste que tu garganta se desgarraba."
    "You screamed with all your might, until you felt your throat tear."

# game/script.rpy:1266
translate english supervivencia_6_442966d9:

    # "La sangre brotó como una pequeña cascada, y con la repentina sacudida de tu cuerpo, la sangre salpicó."
    "Blood flowed like a small waterfall, and with your sudden body shake, blood splattered."

# game/script.rpy:1267
translate english supervivencia_6_8f04e5ee:

    # "Jeff rió satisfecho con la reacción y enterró más la hoja, hundiéndola en la blanda carne de tu globo ocular."
    "Jeff laughed, satisfied with your reaction, and pushed the blade deeper, burying it into the soft flesh of your eyeball."

# game/script.rpy:1268
translate english supervivencia_6_df9fc0fc:

    # pov "¡A-ACK!"
    pov "A-ACK!"

# game/script.rpy:1269
translate english supervivencia_6_6e9ed3d0:

    # "Te atragantántaste con tu saliva, a punto de vomitar por el insoportable dolor."
    "You choked on your saliva, on the verge of vomiting from the unbearable pain."

# game/script.rpy:1270
translate english supervivencia_6_d7d41f4e:

    # "Tus manos dieron manotazos hacia el pecho de Jeff, pero no lo movieron ni un centímetro."
    "Your hands flailed at Jeff's chest, but you didn't move him an inch."

# game/script.rpy:1273
translate english supervivencia_6_63958df9:

    # "Jeff sacudió el mango del cuchillo violentamente, moviéndolo aún enterrado en el ojo."
    "Jeff violently shook the knife handle, moving it deeper into your eye."

# game/script.rpy:1275
translate english supervivencia_6_2eb8dfdd:

    # "Él sacudió un poco más el cuchillo y tiró, logrando sacar el globo ocular aún conectado a las venas."
    "He shook the knife a little more and pulled, managing to yank out your eyeball, still connected by veins."

# game/script.rpy:1276
translate english supervivencia_6_f9821093:

    # Stranger "¿Qué está pasando?"
    Stranger "What's happening?"

# game/script.rpy:1277
translate english supervivencia_6_7d950801:

    # Stranger "¿Hay alguien ahí?"
    Stranger "Is anyone there?"

# game/script.rpy:1278
translate english supervivencia_6_af979cd1:

    # "Como campanas celestiales, lograste escuchar las voces de otras personas proviniendo de un costado, pero ya no tenías fuerzas para mantenerte de pie."
    "Like heavenly bells, you managed to hear the voices of other people coming from nearby, but you no longer had the strength to stand."

# game/script.rpy:1281
translate english supervivencia_6_361d26d2:

    # "Te desplomas en el suelo, con la cuenca izquierda sangrando por el arranque."
    "You collapsed to the ground, your left eye socket bleeding from the raw wound."

# game/script.rpy:1282
translate english supervivencia_6_3a27b0b2:

    # "Tu visión estaba borrosa y dañada, no había manera de confiar en lo que veías."
    "Your vision was blurry and damaged; there was no way to trust what you saw."

# game/script.rpy:1283
translate english supervivencia_6_459373fe:

    # "Sólo podías centrarte en lo que escuchabas."
    "You could only focus on what you heard."

# game/script.rpy:1284
translate english supervivencia_6_14a84329:

    # J "Recuerda nuestro juego, [povname]."
    J "Remember our game, [povname]."

# game/script.rpy:1285
translate english supervivencia_6_d053d53b:

    # "Jeff murmuró suavemente, su voz escuchándose desde atrás."
    "Jeff murmured softly, his voice echoing from behind you."

# game/script.rpy:1288
translate english supervivencia_6_5f93ba9b:

    # "Lograste sentir los pasos de varias personas dirigiéndose a tu dirección, por lo que te rendiste ante el cansancio y el dolor."
    "You managed to feel the footsteps of several people heading your way, so you surrendered to exhaustion and pain."

# game/script.rpy:1303
translate english supervivencia_6_0427078d:

    # "Nunca habías sentido tanto dolor antes."
    "You had never felt so much pain before."

# game/script.rpy:1304
translate english supervivencia_6_6d1436d7:

    # "Claro, alguna vez te habías tropezado, raspado las rodillas, o quemado los dedos con agua hirviendo, cosas normales."
    "Sure, you'd stumbled, scraped your knees, or burned your fingers with boiling water, normal things."

# game/script.rpy:1305
translate english supervivencia_6_bdceb634:

    # "Pero esto…"
    "But this..."

# game/script.rpy:1306
translate english supervivencia_6_224029e3:

    # "Esto era otro nivel."
    "This was another level."

# game/script.rpy:1307
translate english supervivencia_6_f339c3a8:

    # "No era el dolor físico lo que más molestaba, sino el tipo de dolor que te hace consciente de que todo lo que está pasando importa más de lo que quisieras."
    "It wasn't the physical pain that bothered you most, but the kind of pain that made you aware that everything that was happening mattered more than you wanted it to."

# game/script.rpy:1308
translate english supervivencia_6_999b1722:

    # "El tipo de dolor que te despierta, te obliga a existir, te arranca de la comodidad de no sentir nada."
    "The kind of pain that wakes you up, forces you to exist, rips you from the comfort of feeling nothing."

# game/script.rpy:1309
translate english supervivencia_6_7b0da4d9:

    # "Para colmo, querías dormir. Dormir siempre ha sido tu mejor plan en cualquier situación."
    "To top it off, you wanted to sleep. Sleeping had always been your best plan in any situation."

# game/script.rpy:1310
translate english supervivencia_6_b4494801:

    # "Pero, por supuesto, a la vida le encanta arruinarte los planes."
    "But, of course, life loves to ruin your plans."

# game/script.rpy:1311
translate english supervivencia_6_d168d066:

    # Stranger "¿Despertaste?"
    Stranger "Are you awake?"

# game/script.rpy:1312
translate english supervivencia_6_20d16868:

    # "La voz era masculina, suave, con ese tono educado que inspiraba confianza."
    "The voice was masculine, soft, with that educated tone that inspired confidence."

# game/script.rpy:1313
translate english supervivencia_6_ec37c51e:

    # "No despertaste de inmediato. Sentías tu cuerpo pesado por el cansancio."
    "You didn't wake up immediately. You felt your body heavy with fatigue."

# game/script.rpy:1314
translate english supervivencia_6_b3241158:

    # "Pero después de un par de respiraciones incómodas, lograste forzarte a ver."
    "But after a couple of uncomfortable breaths, you managed to force yourself to see."

# game/script.rpy:1317
translate english supervivencia_6_a7606896:

    # "El blanco te rodeaba. Te tomó unos segundos entender que estabas en una camilla de hospital."
    "White surrounded you. It took you a few seconds to realize you were on a hospital gurney."

# game/script.rpy:1318
translate english supervivencia_6_a0495911:

    # "Sábanas ásperas, olor a desinfectante y esa luz fluorescente de las ampolletas led."
    "Rough sheets, the smell of disinfectant, and the fluorescent light of LED bulbs."

# game/script.rpy:1319
translate english supervivencia_6_c4d0302a:

    # "Lo bueno, si es que había algo bueno, es que estabas con cuidados médicos."
    "The good thing, if there was anything good, was that you were receiving medical care."

# game/script.rpy:1320
translate english supervivencia_6_aa224475:

    # "Con suerte no te iban a dejar morir de forma estúpida después de todo lo que pasaste anoche."
    "Hopefully, they wouldn't let you die stupidly after everything you went through last night."

# game/script.rpy:1321
translate english supervivencia_6_7de2feb3:

    # "Finalmente te enfocas en el responsable de la voz."
    "Finally, you focused on the source of the voice."

# game/script.rpy:1324
translate english supervivencia_6_2b2064bf:

    # "Frente a ti había un hombre de bata blanca. Joven, bien peinado, de rostro amable."
    "In front of you was a man in a white coat. Young, well-groomed, with a kind face."

# game/script.rpy:1325
translate english supervivencia_6_23321409:

    # Stranger "¿Sabes dónde estás?"
    Stranger "Do you know where you are?"

# game/script.rpy:1331
translate english supervivencia_6_1f7e3e82:

    # "El doctor asintió y anotó algo en unos papeles que llevaba consigo."
    "The doctor nodded and wrote something on the papers he was carrying."

# game/script.rpy:1332
translate english supervivencia_6_7f2e900c:

    # Stranger "Bien. Eso es un buen signo."
    Stranger "Good. That's a good sign."

# game/script.rpy:1333
translate english supervivencia_6_15ba08c5:

    # pov "¿Anotas por profesionalismo o porque necesitas llenar espacio?"
    pov "Are you writing that down out of professionalism, or because you need to fill space?"

# game/script.rpy:1334
translate english supervivencia_6_021dc0db:

    # "El doctor alzó una ceja a tu dirección, como si no se hubiera esperado un comentario tan seco, pero lejos de verse ofendido, se veía intrigado."
    "The doctor raised an eyebrow at you, as if he hadn't expected such a blunt comment, but far from looking offended, he seemed intrigued."

# game/script.rpy:1335
translate english supervivencia_6_4585ceaa:

    # Stranger "Ambas."
    Stranger "Both"

# game/script.rpy:1338
translate english supervivencia_6_4a9467f5:

    # pov "Creo que tengo un ángel ante mí."
    pov "I think I have an angel in front of me."

# game/script.rpy:1340
translate english supervivencia_6_8c00cbab:

    # "El doctor resopló divertido."
    "The doctor chuckled."

# game/script.rpy:1341
translate english supervivencia_6_c586da9a:

    # Stranger "Veo que tienes sentido del humor, eso es buena señal."
    Stranger "I see you have a sense of humor, that's a good sign."

# game/script.rpy:1342
translate english supervivencia_6_e409c40a:

    # pov "Hubiera dicho algo más original, pero no tengo tantas energías…"
    pov "I would have said something more original, but I don't have much energy..."

# game/script.rpy:1343
translate english supervivencia_6_208641f3:

    # Stranger "Me conformo. No todos los días me dicen ángel mientras trabajo."
    Stranger "I'll take it. Not every day someone calls me an angel while I work."

# game/script.rpy:1345
translate english supervivencia_6_24fa83cc:

    # "Anotó un par de cosas en los papeles que llevaba. Parecía estar más entretenido que preocupado."
    "He jotted down a few things on the papers he carried. He seemed more amused than worried."

# game/script.rpy:1350
translate english ruta_normal_11_0d22ae43:

    # "Tu voz estaba ronca y te dolía la garganta."
    "Your voice was hoarse and your throat hurt."

# game/script.rpy:1351
translate english ruta_normal_11_6c641bab:

    # "Tragaste con fuerza, tratando de aplacar el dolor."
    "You swallowed hard, trying to soothe the pain."

# game/script.rpy:1352
translate english ruta_normal_11_a06ad2c1:

    # "El doctor te dedicó una mirada seria, como si te dijera que te lo tomaras con calma."
    "The doctor gave you a serious look, as if telling you to take it easy."

# game/script.rpy:1353
translate english ruta_normal_11_77649624:

    # Stranger "¿Recuerdas tu nombre?"
    Stranger "Do you remember your name?"

# game/script.rpy:1358
translate english ruta_normal_11_931ad9fd:

    # "El doctor soltó una leve carcajada, negando con la cabeza."
    "The doctor let out a slight chuckle, shaking his head."

# game/script.rpy:1359
translate english ruta_normal_11_5cacde45:

    # Stranger "Responde seriamente."
    Stranger "Answer seriously."

# game/script.rpy:1369
translate english ruta_normal_12_b47ff447:

    # pov "Es… [povname]."
    pov "It's... [povname]."

# game/script.rpy:1370
translate english ruta_normal_12_83cfeb5e:

    # "Tu voz salió ronca y entrecortada, pero lo suficientemente clara para que él te entienda."
    "Your voice came out hoarse and broken, but clear enough for him to understand."

# game/script.rpy:1371
translate english ruta_normal_12_3bfee5af:

    # "El doctor asintió, concentrado."
    "The doctor nodded, concentrated."

# game/script.rpy:1372
translate english ruta_normal_12_ff988f40:

    # "Evidentemente te estaba haciendo esas preguntas para saber que tan desorientada estaba tu cabeza."
    "Evidently he was asking you those questions to find out how disoriented your head was."

# game/script.rpy:1373
translate english ruta_normal_12_9a121480:

    # Stranger "De acuerdo. ¿Sabes por qué estás aquí?"
    Stranger "Alright. Do you know why you're here?"

# game/script.rpy:1374
translate english ruta_normal_12_fcc1eb7a:

    # "No respondiste de inmediato."
    "You didn't answer immediately."

# game/script.rpy:1375
translate english ruta_normal_12_34507ba4:

    # "La imagen apareció sola. Una cara con cicatrices. Ojos hundidos. Una sonrisa deformada."
    "The image appeared on its own. A scarred face. Sunken eyes. A distorted smile."

# game/script.rpy:1376
translate english ruta_normal_12_c4879149:

    # "Y la risa. Esa maldita risa."
    "And the laughter. That damned laughter."

# game/script.rpy:1377
translate english ruta_normal_12_409e3172:

    # "Por supuesto que sabías por qué estabas ahí."
    "Of course you knew why you were there."

# game/script.rpy:1378
translate english ruta_normal_12_50f63a7d:

    # pov "Me atacó… alguien."
    pov "Someone... attacked me."

# game/script.rpy:1380
translate english ruta_normal_12_f2395561:

    # "El doctor se acercó y tomó tu mano con firmeza."
    "The doctor approached and took your hand firmly."

# game/script.rpy:1381
translate english ruta_normal_12_e7375928:

    # "No te preguntó si querías ese gesto. Solo lo hizo."
    "He didn't ask if you wanted that gesture. He just did it."

# game/script.rpy:1382
translate english ruta_normal_12_d1798ed2:

    # Stranger "Este lugar es seguro."
    Stranger "This place is safe."

# game/script.rpy:1383
translate english ruta_normal_12_b2076610:

    # Stranger "Él no puede hacerte daño ahora."
    Stranger "He can't hurt you now."

# game/script.rpy:1384
translate english ruta_normal_12_c6e9ad4d:

    # "Te quedaste mirando su mano sobre la tuya."
    "You stared at his hand over yours."

# game/script.rpy:1385
translate english ruta_normal_12_de523062:

    # "No sabías qué era peor: el dolor, o lo raro que se sentía que alguien te consolara de forma tan… correcta."
    "You didn't know what was worse: the pain, or how strange it felt for someone to comfort you in such... proper way."

# game/script.rpy:1386
translate english ruta_normal_12_ebd5b091:

    # "{i}Buen servicio{/i}, pensaste."
    "{i}Good service,{/i} you thought."

# game/script.rpy:1387
translate english ruta_normal_12_52345a77:

    # "Tal vez te traigan café gratis después."
    "Maybe they'll bring you free coffee later."

# game/script.rpy:1388
translate english ruta_normal_12_cbbb99ab:

    # "Salazar notó tu silencio y retiró la mano enseguida."
    "Salazar noticed your silence and quickly withdrew his hand."

# game/script.rpy:1390
translate english ruta_normal_12_1e30bc5f:

    # "Se aclaró la garganta, avergonzado."
    "He cleared his throat, embarrassed."

# game/script.rpy:1391
translate english ruta_normal_12_06423d78:

    # Stranger "Perdón… No me he presentado."
    Stranger "Sorry... I haven't introduced myself."

# game/script.rpy:1393
translate english ruta_normal_12_ed759624:

    # DR "Soy tu doctor, Paul Salazar."
    DR "I'm your doctor, Paul Salazar."

# game/script.rpy:1394
translate english ruta_normal_12_6bdcbf35:

    # "Te tomó un segundo procesarlo."
    "It took you a second to process."

# game/script.rpy:1395
translate english ruta_normal_12_a4ca3f82:

    # pov "Un gusto… Dr. Salazar."
    pov "Nice to meet you... Dr. Salazar."

# game/script.rpy:1396
translate english ruta_normal_12_487d741c:

    # pov "Diría que me habría gustado conocerte… en otra situación… pero ya sabes."
    pov "I'd say I would have liked to meet you... in another situation... but you know."

# game/script.rpy:1397
translate english ruta_normal_12_f2e04105:

    # "Él esbozó una sonrisa breve, sin saber si reír o disculparse otra vez."
    "He offered a brief smile, unsure whether to laugh or apologize again."

# game/script.rpy:1399
translate english ruta_normal_12_78511d7e:

    # DR "Te explicaré un poco tu situación."
    DR "I'll explain your situation a bit."

# game/script.rpy:1400
translate english ruta_normal_12_c0913212:

    # "Se puso más recto y serio."
    "He straightened up, becoming more serious."

# game/script.rpy:1401
translate english ruta_normal_12_75a36b4f:

    # DR "Tienes golpes en la cabeza. Hay que vigilarte por si presentas vómito, mareos o pérdida de conciencia."
    DR "You have head injuries. We need to monitor you for vomiting, dizziness, or loss of consciousness."

# game/script.rpy:1402
translate english ruta_normal_12_c99a4bf2:

    # DR "También tienes algunos cortes menores. No necesitas puntos, pero… nada de rascarse ni tocarlos. ¿De acuerdo?"
    DR "You also have some minor cuts. You don't need stitches, but... no scratching or touching them. Understood?"

# game/script.rpy:1403
translate english ruta_normal_12_61765e0f:

    # "En el instante exacto que lo dijo, la picazón te atacó. Maldita sugestión."
    "The exact moment he said it, the itch attacked you. Damn suggestion."

# game/script.rpy:1404
translate english ruta_normal_12_6422b0d1:

    # DR "Lo más importante ahora: Sufriste asfixia. No hagas esfuerzos, no hables mucho. Si te mareas o te cuesta respirar, avisa."
    DR "The most important thing now: You suffered asphyxiation. Don't strain yourself, don't talk much. If you feel dizzy or have trouble breathing, let us know."

# game/script.rpy:1406
translate english ruta_normal_12_88b747e6:

    # "Asentiste en silencio, acomodándote lentamente en la camilla."
    "You nodded in silence, settling slowly into the gurney."

# game/script.rpy:1407
translate english ruta_normal_12_91fb0d22:

    # "La tela de la bata raspaba un poco contra tu piel. El colchón olía a desinfectante. Todo olía a desinfectante."
    "The fabric of the gown scratched your skin a little. The mattress smelled of disinfectant. Everything smelled of disinfectant."

# game/script.rpy:1409
translate english ruta_normal_12_a5b20686:

    # DR "Y… respecto a tu ojo…"
    DR "And... about your eye..."

# game/script.rpy:1410
translate english ruta_normal_12_baef4747:

    # "Su tono cambió. Como si estuviera por dar muy malas noticias."
    "His tone changed. As if he was about to deliver very bad news."

# game/script.rpy:1411
translate english ruta_normal_12_41161dc8:

    # DR "Lo siento. No pudimos salvarlo."
    DR "I'm sorry. We couldn't save it."

# game/script.rpy:1412
translate english ruta_normal_12_22d61838:

    # "Frío. Como si alguien hubiera abierto una ventana en mitad del invierno."
    "Cold. As if someone had opened a window in the middle of winter."

# game/script.rpy:1413
translate english ruta_normal_12_8399e5bc:

    # "Por reflejo, llevaste una mano temblorosa al costado izquierdo de tu rostro."
    "Instinctively, you raised a trembling hand to the left side of your face."

# game/script.rpy:1414
translate english ruta_normal_12_230ff9bc:

    # "Sólo vendajes. Sólo vacío."
    "Just bandages. Just emptiness."

# game/script.rpy:1415
translate english ruta_normal_12_0b2e0907:

    # "Habías imaginado perder cosas. Objetos, relaciones, tiempo."
    "You had imagined losing things. Objects, relationships, time."

# game/script.rpy:1416
translate english ruta_normal_12_1c655e24:

    # "Pero esto era distinto. Perder pedazos."
    "But this was different. Losing pieces."

# game/script.rpy:1418
translate english ruta_normal_12_4d0bc2c5:

    # DR "Podrás tener una vida normal."
    DR "You'll be able to live a normal life."

# game/script.rpy:1419
translate english ruta_normal_12_3c227684:

    # "Él dijo rápidamente, como si quisiera remediar tu situación."
    "He said quickly, as if wanting to remedy your situation."

# game/script.rpy:1420
translate english ruta_normal_12_fb3c4e76:

    # DR "Perderás algo de percepción de profundidad, pero no te impedirá hacer tu vida. Más adelante puedes optar por una prótesis, si lo deseas."
    DR "You'll lose some depth perception, but it won't impede your life. Later, you can opt for a prosthesis, if you wish."

# game/script.rpy:1421
translate english ruta_normal_12_bc4cf9f3:

    # DR "Ahora… Lo importante es que cicatrice bien."
    DR "Now... The important thing is that it heals well."

# game/script.rpy:1423
#translate english ruta_normal_12_0ef77194:

    # "Él notó tu silencio. Tu falta de reacción lo incomodaba."
    #"He noticed your silence. Your lack of reaction made him uncomfortable."

# game/script.rpy:1424
translate english ruta_normal_12_8afab75c:

    # "Se inclinó levemente hacia ti."
    "He leaned slightly towards you."

# game/script.rpy:1425
translate english ruta_normal_12_3e1dadd5:

    # DR "¿Estás bien, [povname]?"
    DR "Are you okay, [povname]?"

# game/script.rpy:1429
translate english ruta_normal_12_c3f83adb:

    # "Tu voz bajó, al igual que tu mirada."
    "Your voice dropped, as did your gaze."

# game/script.rpy:1430
translate english ruta_normal_12_68315d3f:

    # pov "No… no estoy bien."
    pov "No... I'm not okay."

# game/script.rpy:1431
translate english ruta_normal_12_8dcc7612:

    # "No lo dijiste con drama, ni con lágrimas."
    "You didn't say it with drama, or with tears."

# game/script.rpy:1432
translate english ruta_normal_12_fff8f982:

    # "Solo lo dijiste porque era cierto."
    "You just said it because it was true."

# game/script.rpy:1433
translate english ruta_normal_12_a0a91b1b:

    # "Por una vez, no tenías energía para fingir."
    "For once, you didn't have the energy to pretend."

# game/script.rpy:1434
translate english ruta_normal_12_2dc3da98:

    # "El Dr. Salazar asintió despacio."
    "Dr. Salazar nodded slowly."

# game/script.rpy:1435
translate english ruta_normal_12_7555b820:

    # DR "No tienes por qué estarlo."
    DR "You don't have to be."

# game/script.rpy:1436
translate english ruta_normal_12_3c904b4e:

    # "El silencio se sintió pesado, pero no incómodo."
    "The silence felt heavy, but not uncomfortable."

# game/script.rpy:1437
translate english ruta_normal_12_8a69c36f:

    # "Era raro que alguien no tratara de llenar el espacio con frases vacías."
    "It was rare for someone not to try to fill the space with empty phrases."

# game/script.rpy:1438
translate english ruta_normal_12_6fd286eb:

    # pov "Creía que los doctores eran más… metódicos."
    pov "I thought doctors were more... methodical."

# game/script.rpy:1440
translate english ruta_normal_12_78a830b2:

    # "El Dr. Salazar sonrió apenas, como si entendiera más de lo que decía."
    "Dr. Salazar smiled faintly, as if he understood more than he was saying."

# game/script.rpy:1441
translate english ruta_normal_12_bfcb874c:

    # DR "No todos los doctores somos un cliché."
    DR "Not all doctors are a cliche."

# game/script.rpy:1442
translate english ruta_normal_12_5b8d8cdc:

    # "Por primera vez en mucho tiempo… sentiste menos soledad."
    "For the first time in a long time... you felt less alone."

# game/script.rpy:1443
translate english ruta_normal_12_299c7f85:

    # "Solo un poco. Pero algo era algo."
    "Just a little. But something was better than nothing."

# game/script.rpy:1448
translate english ruta_normal_12_e405c244:

    # pov "Estaré bien. Es sólo un ojo, tengo otro."
    pov "I'll be fine. It's just one eye, I have another."

# game/script.rpy:1449
translate english ruta_normal_12_82a9f63e:

    # "No sabías si era cierto, pero tampoco importaba."
    "You didn't know if that was true, but it didn't matter."

# game/script.rpy:1450
translate english ruta_normal_12_427b61a4:

    # "No lo dijiste para él. Lo dijiste para cortar la conversación."
    "You didn't say it for him. You said it to cut off the conversation."

# game/script.rpy:1451
translate english ruta_normal_12_af17194d:

    # "Hablar dolía. Escuchar también."
    "Talking hurt. Listening did too."

# game/script.rpy:1453
translate english ruta_normal_12_50d7d692:

    # "Salazar te miró, como queriendo leer algo más en tu cara, pero solo encontró lo de siempre: apatía."
    "Salazar looked at you, as if wanting to read something more on your face, but he only found the usual: apathy."

# game/script.rpy:1454
translate english ruta_normal_12_dbf02063:

    # DR "No tienes que fingir ser fuerte."
    DR "You don't have to pretend to be strong."

# game/script.rpy:1455
translate english ruta_normal_12_87a1efb2:

    # DR "Tenemos profesionales con los que puedes hablar-"
    DR "We have professionals you can talk to—"

# game/script.rpy:1456
translate english ruta_normal_12_2b24fec5:

    # pov "No estoy fingiendo. Solo… no me importa."
    pov "I'm not pretending. I just... don't care."

# game/script.rpy:1457
translate english ruta_normal_12_54b285ba:

    # "Ahí estaba: la barrera. Sutil, pero sólida."
    "There it was: the barrier. Subtle, but solid."

# game/script.rpy:1458
translate english ruta_normal_12_de9c8beb:

    # "No querías consuelo. No querías compañía. Solo querías que te dejaran en paz."
    "You didn't want comfort. You didn't want company. You just wanted to be left alone."

# game/script.rpy:1459
translate english ruta_normal_12_11b58f43:

    # "Por un segundo, el silencio en la sala pesó más que el dolor en el cuerpo."
    "For a second, the silence in the room weighed more than the pain in your body."

# game/script.rpy:1464
translate english ruta_normal_13_9a7546c2:

    # DR "¿Hay alguien a quien llamar?"
    DR "Is there anyone you'd like to call?"

# game/script.rpy:1465
translate english ruta_normal_13_75fd4299:

    # DR "¿Algún familiar, un amigo, pareja?"
    DR "Any family, a friend, a partner?"

# game/script.rpy:1466
translate english ruta_normal_13_f8b872b0:

    # pov "…."
    pov "...."

# game/script.rpy:1467
translate english ruta_normal_13_c7415228:

    # "No querías admitir que tu vida era solitaria, pero no podías simplemente mentirle a tu doctor."
    "You didn't want to admit your life was solitary, but you couldn't just lie to your doctor."

# game/script.rpy:1472
translate english ruta_normal_13_42d056b9:

    # DR "Oh, lo lamento mucho…"
    DR "Oh, I'm so sorry..."

# game/script.rpy:1476
translate english ruta_normal_13_0ff0e7b9:

    # DR "Entiendo…"
    DR "I understand..."

# game/script.rpy:1480
translate english ruta_normal_13_e782a7f3:

    # DR "Eso va hacer las cosas algo complicadas…."
    DR "That's going to make things a bit complicated..."

# game/script.rpy:1485
translate english character_2_3bfb7f2a:

    # "El Dr. Salazar se rascó la cabeza con incomodidad."
    "Dr. Salazar scratched his head awkwardly."

# game/script.rpy:1486
translate english character_2_9d7c39db:

    # "Precisamente por eso no querías decir nada en primer lugar."
    "Precisely why you didn't want to say anything in the first place."

# game/script.rpy:1487
translate english character_2_c46eadc2:

    # DR "Debe haber alguien en esta ciudad con la que tengas contacto, ¿Algún compañero de trabajo?"
    DR "There must be someone in this city you're in contact with, right? A coworker?"

# game/script.rpy:1488
translate english character_2_0a36c9f9:

    # "Hablar de trabajo te hizo recordar a cierta persona."
    "Talking about work reminded you of a certain person."

# game/script.rpy:1490
translate english character_2_b7876698:

    # pov "¿Qué hora es, doctor?"
    pov "What time is it, doctor?"

# game/script.rpy:1491
translate english character_2_f7897793:

    # "El Dr. Salazar se sacude la muñeca y ojea su reloj de muñeca."
    "Dr. Salazar shook his wrist and glanced at his watch."

# game/script.rpy:1492
translate english character_2_75c17823:

    # DR "Son las 4 am."
    DR "It's 4 AM."

# game/script.rpy:1493
translate english character_2_b8167d93:

    # DR "¿Por qué?"
    DR "Why?"

# game/script.rpy:1494
translate english character_2_7de095ba:

    # pov "… Hay alguien a quien puedo llamar, pero es muy temprano…"
    pov "There's someone I can call, but it's very early..."

# game/script.rpy:1495
translate english character_2_e08e3f59:

    # DR "Alguien te atacó, lo entenderá."
    DR "Someone attacked you, they'll understand."

# game/script.rpy:1496
translate english character_2_981f1251:

    # "Apretaste los labios en una línea, con duda."
    "You pursed your lips into a line, with doubt."

# game/script.rpy:1497
translate english character_2_f3a6ee2c:

    # "No tenías tanta cercanía con ella… pero no podías pensar en nadie más."
    "You didn't have much closeness with her... but you couldn't think of anyone else."

# game/script.rpy:1498
translate english character_2_8bccb757:

    # pov "Está bien… le daré su número."
    pov "Alright... I'll give you her number."

# game/script.rpy:1499
translate english character_2_4f296540:

    # "Anotas en un papel un número de teléfono y se lo entregas."
    "You wrote a phone number on a piece of paper and handed it to him."

# game/script.rpy:1500
translate english character_2_a403dee2:

    # DR "Van a estar viniendo miembros del personal, para monitorear."
    DR "Staff members will be coming by to monitor you."

# game/script.rpy:1501
translate english character_2_d5f56107:

    # DR "Puedes pedirles lo que necesites."
    DR "You can ask them for whatever you need."

# game/script.rpy:1502
translate english character_2_1cb031e6:

    # pov "De acuerdo."
    pov "Okay."

# game/script.rpy:1503
translate english character_2_173d27ad:

    # "El Dr. Salazar asiente levemente ante tu afirmativa, y se dirige a la puerta de la habitación."
    "Dr. Salazar nodded slightly at your affirmation, and headed for the room door."

# game/script.rpy:1504
translate english character_2_91622aa0:

    # "Pero antes de retirarse, se gira hacia ti."
    "But before leaving, he turned to you."

# game/script.rpy:1505
translate english character_2_40d10fae:

    # DR "Cuando te sientas mejor, podrás hablar con la policía."
    DR "When you feel better, you can talk to the police."

# game/script.rpy:1506
translate english character_2_51a04127:

    # DR "Por ahora, descansa."
    DR "For now, rest."

# game/script.rpy:1508
translate english character_2_e3bc4291:

    # "Y con eso, el doctor abandonó la habitación, dejándote con tus pensamientos."
    "And with that, the doctor left the room, leaving you with your thoughts."

# game/script.rpy:1509
translate english character_2_16d5b70d:

    # "Recuerdas vagamente que escuchaste personas acercarse a ti cuando te desmayaste en el callejón, seguramente ahuyentaron a Jeff."
    "You vaguely remembered hearing people approach you when you passed out in the alley; they surely scared Jeff away."

# game/script.rpy:1510
translate english character_2_7c061bdf:

    # "Lo importante es que estás bien y con vigilancia, no hay manera de que Jeff te alcance, ¿Cierto?"
    "The important thing is that you're safe and monitored, there's no way Jeff can reach you, right?"

# game/script.rpy:1511
translate english character_2_b6a9d0ff:

    # "No era extraño que te preocupara eso, ya que lo último que te dijo fue que te perseguiría hasta encontrarte."
    "It wasn't strange that you worried about it, since the last thing he told you was that he would hunt you down until he found you."

# game/script.rpy:1512
translate english character_2_c972ab96:

    # "Pero nuevamente, estás en un hospital, se supone que es seguro."
    "But again, you were in a hospital, so it was supposed to be safe."

# game/script.rpy:1513
translate english character_2_91f3abeb:

    # "Tanto pensar te agotó nuevamente, por lo que te acomodaste en la camilla para poder descansar."
    "All that thinking exhausted you again, so you settled into the gurney to rest."

# game/script.rpy:1514
translate english character_2_329aeee0:

    # "Unos minutos… querías dormir aunque sea unos minutos."
    "A few minutes... you wanted to sleep, even if just for a few minutes."

# game/script.rpy:1518
translate english character_2_7f348ac7:

    # "………."
    "………."

# game/script.rpy:1519
translate english character_2_daddafea:

    # "Mientras dormías, habrías jurado haber sentido una caricia en tu mejilla."
    "As you slept, you could have sworn you felt a caress on your cheek."

# game/script.rpy:1520
translate english character_2_546026d9:

    # "Era suave y delicada, unos dedos recorrieron la piel de tu pómulo derecho, bajando por tu mandíbula hasta rozar tus labios."
    "It was soft and delicate, fingers tracing your right cheekbone, moving down your jaw to lightly brush your lips."

# game/script.rpy:1523
translate english character_2_a24f52bf:

    # "Abriendo tu único ojo, miraste la habitación, buscando quien quiera que sea que te haya tocado mientras dormías."
    "Opening your single eye, you scanned the room, looking for whoever might have touched you while you slept."

# game/script.rpy:1526
translate english character_2_7cecf6f5:

    # "Pero sólo viste a Cindy."
    "But you only saw Cindy."

# game/script.rpy:1527
translate english character_2_c36c0133:

    # C "¡[povname]!"
    C "[povname]!"

# game/script.rpy:1529
translate english character_2_901479c4:

    # "Repentinamente, y para gran sorpresa tuya, Cindy rodeó tus hombros entre sus brazos, inclinándose sobre ti para estrecharse en un ligero abrazo."
    "Suddenly, and to your great surprise, Cindy wrapped her arms around your shoulders, leaning in for a tight hug."

# game/script.rpy:1530
translate english character_2_00a7bc9c:

    # "Te quedaste de piedra."
    "You froze."

# game/script.rpy:1531
translate english character_2_bc9db973:

    # C "¡Pensé que no despertarías!, oh, que susto…"
    C "I thought you wouldn't wake up! Oh, thank goodness..."

# game/script.rpy:1533
translate english character_2_c6c108fb:

    # "Cindy se separó de ti, tratándote con una delicadeza a la que no terminas de acostumbrarte."
    "Cindy pulled away from you, treating you with a delicacy you weren't used to."

# game/script.rpy:1534
translate english character_2_4514a241:

    # "¿Es tu idea, o es como si Cindy… tuviera el papel de tu mejor amiga?"
    "Is it your imagination, or is it as if Cindy... were playing the role of your best friend?"

# game/script.rpy:1535
translate english character_2_b521bee9:

    # "Ella era por lejos tu mejor amiga, sólo la conoces por un tiempo."
    "She was by far your best friend, you'd only known her for a while."

# game/script.rpy:1536
translate english character_2_92f57cfa:

    # "Está bien, tú fuiste quien le dio su contacto a Salazar, pero sólo porque es la persona más cercana que tienes a mano."
    "Okay, you were the one who gave Salazar her contact, but only because she's the closest person you have on hand."

# game/script.rpy:1537
translate english character_2_fb7c3408:

    # pov "Ehm… ¿A qué viene tanto cariño?"
    pov "Um... what's with all the affection?"

# game/script.rpy:1539
translate english character_2_01482190:

    # "Un rayo pareció partir a Cindy, haciéndola retroceder con una expresión consternada."
    "A ray seemed to strike Cindy, making her recoil with a dismayed expression."

# game/script.rpy:1540
translate english character_2_d4f2e9e4:

    # C "No… lo sé, pero es como… si tu de repente fueras muy importante."
    C "I... I don't know, but it's like... you suddenly became very important."

# game/script.rpy:1541
translate english character_2_b526851f:

    # "¿O sea que antes no lo eras?"
    "So you weren't before?"

# game/script.rpy:1542
translate english character_2_237535bd:

    # "Ok, una cosa es que tu pienses eso de ti personalmente, pero que otra persona lo diga te dolía un poco."
    "Okay, one thing is you thinking that about yourself personally, but it hurt a little to hear someone else say it."

# game/script.rpy:1544
translate english character_2_553edb11:

    # C "Cuando supe lo que te pasó, vine de inmediato."
    C "When I found out what happened to you, I came right away."

# game/script.rpy:1545
translate english character_2_1c43713d:

    # C "No quería que estuvieras por tu cuenta en estos momentos."
    C "I didn't want you to be alone right now."

# game/script.rpy:1547
translate english character_2_0f0c331d:

    # C "¿Cómo te sientes?"
    C "How are you feeling?"

# game/script.rpy:1548
translate english character_2_6f9c872b:

    # "Cindy tomó asiento en la silla a tu derecha, esta vez conservando una distancia más cordial."
    "Cindy sat in the chair to your right, this time maintaining a more cordial distance."

# game/script.rpy:1549
translate english character_2_f40988ee:

    # "Entendible, sólo trabajan en la misma tienda."
    "Understandable, you only worked in the same store."

# game/script.rpy:1550
translate english character_2_37ca398a:

    # pov "Con algo de dolor… pero creo que dentro de todo estoy bien."
    pov "A little pain... but I think overall I'm fine."

# game/script.rpy:1551
translate english character_2_d1a41b96:

    # "Cindy bajó la mirada con preocupación, para después elevarla hacia ti."
    "Cindy lowered her gaze with concern, then raised it to you."

# game/script.rpy:1552
translate english character_2_d97b4eb7:

    # "Ella suspiró pesado, llevando los dedos hacia su frente."
    "She sighed heavily, bringing her fingers to her forehead."

# game/script.rpy:1554
translate english character_2_4160d250:

    # C "Te dije que tuvieras cuidado…"
    C "I told you to be careful..."

# game/script.rpy:1555
translate english character_2_7dd63f9f:

    # "Ese comentario… estaba demás."
    "That comment... was unnecessary."

# game/script.rpy:1556
translate english character_2_55d8752f:

    # "¿Acaso ella quería echar la culpa hacia ti?"
    "Was she trying to blame you?"

# game/script.rpy:1557
translate english character_2_f20cd9e9:

    # "¿Cómo si lo que te pasó fue por tus acciones y no las del desgraciado que te arrancó un ojo?"
    "As if what happened to you was your fault and not the bastard who ripped out your eye?"

# game/script.rpy:1558
translate english character_2_719e9721:

    # pov "Te recuerdo que me atacaron, no es mi culpa."
    pov "I remind you, I was attacked, it's not my fault."

# game/script.rpy:1559
translate english character_2_ef019260:

    # C "No me refiero a eso, yo-"
    C "I don't mean that, I—"

# game/script.rpy:1560
translate english character_2_6b2c0f38:

    # pov "¿Ahora se supone que eres una compañera de trabajo atenta?, que mal chiste."
    pov "Now you're supposed to be a caring coworker? What a bad joke."

# game/script.rpy:1561
translate english character_2_c36c0133_1:

    # C "¡[povname]!"
    C "[povname]!"

# game/script.rpy:1562
translate english character_2_7ec8d295:

    # "No fue el volumen de su voz, ni tampoco el hecho de que te llamó por tu nombre."
    "It wasn't the volume of her voice, nor the fact that she called you by your name."

# game/script.rpy:1563
translate english character_2_70fd5b1e:

    # "Fue su tono desgarrador lo que te hizo detenerte."
    "It was her heartbreaking tone that made you stop."

# game/script.rpy:1565
translate english character_2_29887dc8:

    # C "Yo… tampoco me entiendo."
    C "I... I don't understand myself either."

# game/script.rpy:1566
translate english character_2_0ba71e1a:

    # C "No creí que me importaras tanto."
    C "I didn't think you mattered so much to me."

# game/script.rpy:1567
translate english character_2_5c08642b:

    # pov "Oye-"
    pov "Hey—"

# game/script.rpy:1569
translate english character_2_d77cb3fe:

    # C "Estuviste a punto de morir, y me sentí aterrada."
    C "You were on the verge of dying, and I was terrified."

# game/script.rpy:1570
translate english character_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:1571
translate english character_2_d94eb7d2:

    # "Es cómo… si hubieras empezado a desarrollar un campo gravitacional, y ahora varias personas giraban alrededor de ti. Jeff, Salazar, Cindy."
    "It's like... you've started to develop a gravitational field, and now several people are revolving around you. Jeff, Salazar, Cindy."

# game/script.rpy:1572
translate english character_2_f348cd95:

    # "Sólo bastó que un loco te acosara y te arrancara un ojo, ¿No?"
    "It only took a madman to stalk you and rip out your eye, right?"

# game/script.rpy:1573
translate english character_2_5cda6e5e:

    # C "No tengo cómo explicarlo, pero me preocupo por ti, ¿Podrías dejar de ser idiota al respecto y aceptarlo?"
    C "I don't know how to explain it, but I'm worried about you. Can you stop being an idiot about it and just accept it?"

# game/script.rpy:1574
translate english character_2_2749a053:

    # "No pudiste evitar callarte ante la declaración de ella."
    "You couldn't help but fall silent at her declaration."

# game/script.rpy:1575
translate english character_2_04774a0b:

    # "Estarías mintiendo si decías que tu corazón no latió fuerte."
    "You'd be lying if you said your heart didn't beat fast."

# game/script.rpy:1579
translate english character_2_e75eae6e:

    # pov "Yo… gracias, Cindy."
    pov "I... thank you, Cindy."

# game/script.rpy:1581
translate english character_2_d1d86ee0:

    # "Cindy te miró en silencio, uno reconfortante."
    "Cindy looked at you in a comforting silence."

# game/script.rpy:1582
translate english character_2_2c1446a4:

    # pov "No soy… de decir estas cosas, pero gracias, por preocuparte por mi."
    pov "I'm not... one to say these things, but thank you for worrying about me."

# game/script.rpy:1584
translate english character_2_9c2e5cde:

    # "Cindy bajó la mirada, para después sonreír levemente."
    "Cindy lowered her gaze, then smiled faintly."

# game/script.rpy:1585
translate english character_2_88c8189f:

    # C "No estás haciendo un buen trabajo en solitario… así que no me importa hacerlo por ti."
    C "You're not doing a very good job on your own... so I don't mind doing it for you."

# game/script.rpy:1586
translate english character_2_0877f647:

    # pov "Heh, si."
    pov "Heh, yeah."

# game/script.rpy:1587
translate english character_2_708d92b2:

    # "Cindy te sonrió levemente, pero de repente su expresión cambió."
    "Cindy smiled faintly, but then her expression changed."

# game/script.rpy:1592
translate english character_2_2a0854c6:

    # pov "¿De casualidad…. me acariciaste mientras dormía?"
    pov "By any chance... did you caress me while I was sleeping?"

# game/script.rpy:1594
translate english character_2_a9d05d0c:

    # "Cindy te quedó viendo inexpresiva."
    "Cindy stared at you expressionlessly."

# game/script.rpy:1595
translate english character_2_96188552:

    # C "Ew, no."
    C "Ew, no."

# game/script.rpy:1596
translate english character_2_8e014f46:

    # "Si, esa es la Cindy que conocías."
    "Yes, that's the Cindy you knew."

# game/script.rpy:1597
translate english character_2_9a060320:

    # pov "Bueno, ¿entonces quién fue?"
    pov "Well, then who was it?"

# game/script.rpy:1598
translate english character_2_e2011169:

    # C "¿Qué sé yo?, no es cómo si-"
    C "What do I know? It's not like—"

# game/script.rpy:1599
translate english character_2_055ff75c:

    # "Cindy detuvo sus palabras como si un pensamiento le hubiera llegado a la cabeza."
    "Cindy stopped speaking as if a thought had struck her."

# game/script.rpy:1605
translate english ruta_normal_14_6b41728c:

    # C "El que te atacó, ¿Fue el mismo rarito de la tienda?"
    C "The one who attacked you, was it the same weirdo from the store?"

# game/script.rpy:1606
translate english ruta_normal_14_e5d04b37:

    # pov "Yo-"
    pov "I—"

# game/script.rpy:1608
translate english ruta_normal_14_aa3f84bb:

    # "Tras un leve toque en la puerta de tu habitación, aparecieron dos personas."
    "After a light knock on your room door, two people appeared."

# game/script.rpy:1609
translate english ruta_normal_14_8432ea30:

    # "Perfecta entrada para interrumpir la conversación que estabas teniendo."
    "Perfect timing to interrupt your conversation."

# game/script.rpy:1616
translate english ruta_normal_14_e981f01c:

    # TW "Buenas, [povname]. Somos el teniente Wes y la detective Sean, ¿Podemos hacerte unas preguntas?"
    TW "Good evening, [povname]. We're Lieutenant Wes and Detective Sean. Can we ask you a few questions?"

# game/script.rpy:1617
translate english ruta_normal_14_3a6328c4:

    # "Miraste con tu único ojo a los policías."
    "You looked at the police with your one eye."

# game/script.rpy:1618
translate english ruta_normal_14_cdcc1043:

    # "Un hombre y una mujer, vestidos con ropa formal. El hombre fue el que habló, mostrando su placa, y la mujer, la detective Sean, lo imitó."
    "A man and a woman, dressed in formal attire. The man spoke, showing his badge, and the woman, Detective Sean, did the same."

# game/script.rpy:1619
translate english ruta_normal_14_d18098ad:

    # "Te miraban con seriedad, pero a la vez no se veían muy preocupados por ti."
    "They looked at you seriously, but at the same time, they didn't seem very worried about you."

# game/script.rpy:1620
translate english ruta_normal_14_dc325902:

    # "Más bien, pareciera que estaban más interesados en lo que tenías que decir."
    "Rather, it seemed they were more interested in what you had to say."

# game/script.rpy:1621
translate english ruta_normal_14_b339cd1c:

    # TW "Tu doctor nos dijo que tenías visita, si te es más cómodo, podemos hacer la entrevista con ella presente."
    TW "Your doctor told us you had visitors. If it's more comfortable for you, we can do the interview with her present."

# game/script.rpy:1622
translate english ruta_normal_14_4709f701:

    # C "[povname] recién despertó, debe descansar."
    C "[povname] just woke up, they needs to rest."

# game/script.rpy:1623
translate english ruta_normal_14_3fdc7f6a:

    # "Cindy les habló por encima del hombro, desinteresada en la presencia de ellos."
    "Cindy spoke over her shoulder to them, uninterested in their presence."

# game/script.rpy:1624
translate english ruta_normal_14_42297df1:

    # DS "Mientras más pronto hablemos, más pronto atraparemos al que te hizo esto."
    DS "The sooner we talk, the sooner we'll catch whoever did this to you."

# game/script.rpy:1625
translate english ruta_normal_14_c4a3b80d:

    # "El calor subió de tu pecho a tu cabeza, a tu cuenca."
    "Heat rose from your chest to your head, to your eye socket."

# game/script.rpy:1626
translate english ruta_normal_14_d670e43d:

    # "No sabías si era una respuesta de tu cuerpo o sólo enojo hacia Jeff, pero pudiste ocultarlo."
    "You didn't know if it was a response from your body or just anger towards Jeff, but you managed to hide it."

# game/script.rpy:1627
translate english ruta_normal_14_9e479590:

    # pov "Está bien, Cindy, responderé lo que pueda."
    pov "It's okay, Cindy, I'll answer what I can."

# game/script.rpy:1628
translate english ruta_normal_14_786260fa:

    # "Los detectives parecieron relajarse un poco ante tus palabras."
    "The detectives seemed to relax a little at your words."

# game/script.rpy:1629
translate english ruta_normal_14_c6db8d9f:

    # "Ellos se pusieron al otro lado de tu camilla, Wes se mantuvo de pie junto a ti, haciendo contacto visual contigo para transmitir más confianza, mientras Sean sacaba una libreta para tomar notas."
    "They stood on the other side of your bed, Wes standing next to you, making eye contact to convey more trust, while Sean took out a notebook to take notes."

# game/script.rpy:1630
translate english ruta_normal_14_d51d1082:

    # "Clásico, policía bueno y malo."
    "Classic, good cop, bad cop."

# game/script.rpy:1631
translate english ruta_normal_14_871aa33c:

    # TW "Empecemos con lo más importante, ¿Viste a tu atacante?"
    TW "Let's start with the most important thing, did you see your attacker?"

# game/script.rpy:1632
translate english ruta_normal_14_b94f4b41:

    # pov "Oh, si, no fue bonito."
    pov "Oh, yeah, it wasn't pretty."

# game/script.rpy:1633
translate english ruta_normal_14_e9300d7a:

    # DS "¿Podrías dar más detalles?"
    DS "Could you give us more details?"

# game/script.rpy:1634
translate english ruta_normal_14_7b2d2828:

    # pov "¿Cómo su número social?"
    pov "Like his social security number?"

# game/script.rpy:1635
translate english ruta_normal_14_a9505768:

    # "Estabas jugando, obviamente."
    "You were joking, obviously."

# game/script.rpy:1636
translate english ruta_normal_14_5fbfcf29:

    # "Ya estabas en camilla, sin un ojo y bajo analgésicos, tenías permitido divertirte."
    "You were in a hospital bed, with one eye missing and on painkillers; you were allowed to have some fun."

# game/script.rpy:1638
translate english ruta_normal_14_53009117:

    # C "Te preguntan si era hombre o mujer, estatura, complexión, ropa-"
    C "They asked if it was a man or a woman, height, build, clothes—"

# game/script.rpy:1639
translate english ruta_normal_14_5cda2a9c:

    # pov "Lo sé, cielos, nadie acepta un chiste…"
    pov "I know, geez, nobody appreciates a joke..."

# game/script.rpy:1640
translate english ruta_normal_14_333094f0:

    # pov "Era un hombre, blanco. Alto, no sé… ¿de un metro noventa?, quizás más. Llevaba una sudadera blanca, pésima ropa para un criminal si me preguntan a mí."
    pov "It was a man, white. Tall, I don't know... maybe six feet three? He was wearing a white hoodie, terrible clothes for a criminal if you ask me."

# game/script.rpy:1641
translate english ruta_normal_14_dc77f6a2:

    # "Miraste a Cindy de reojo, fácil porque estaba en tu lado derecho."
    "You glanced at Cindy, easy since she was on your right side."

# game/script.rpy:1642
translate english ruta_normal_14_c20f2332:

    # "Ella tenía una expresión pensativa, lo más probable es que ya haya concluído que estabas hablando de Jeff, o como ella lo conocía, “el rarito de la tienda”."
    "She had a thoughtful expression, most likely she had concluded you were talking about Jeff, or as she knew him, the weirdo from the store."

# game/script.rpy:1643
translate english ruta_normal_14_3c92176f:

    # TW "¿… Alguna característica en especial?"
    TW "...Any special characteristics?"

# game/script.rpy:1644
translate english ruta_normal_14_c798e9eb:

    # pov "Tenía la cara destrozada, si saben a lo que me refiero."
    pov "His face was messed up, if you know what I mean."

# game/script.rpy:1645
translate english ruta_normal_14_6c55ea90:

    # "Los tres presentes te miraron en silencio por unos segundos, y te sentiste bajo presión para dar más detalles."
    "The three of them looked at you in silence for a few seconds, and you felt pressured to give more details."

# game/script.rpy:1646
translate english ruta_normal_14_749f411c:

    # pov "… Tenía muchas cicatrices, la boca… la tenía rasgada."
    pov "... He had many scars, his mouth... it was ripped."

# game/script.rpy:1648
translate english ruta_normal_14_00c63b53:

    # "Cindy parecía tan asqueada con la descripción que parecía a punto de vomitar."
    "Cindy looked so disgusted with the description that she seemed about to vomit."

# game/script.rpy:1649
translate english ruta_normal_14_d1f59ce9:

    # "Wes y Sean se dedicaron una mirada silenciosa, para después volver a mirarte."
    "Wes and Sean exchanged a silent glance, then looked back at you."

# game/script.rpy:1650
translate english ruta_normal_14_e07f6adb:

    # TW "De acuerdo… ¿Pasó algo inusual el día de tu ataque?"
    TW "Alright... Did anything unusual happen the day of your attack?"

# game/script.rpy:1651
translate english ruta_normal_14_cf656439:

    # pov "Creo que la cantidad normal de “raro” que todos podemos tener en un día-"
    pov "I think the normal amount of 'weird' that we all can have in a day—"

# game/script.rpy:1652
translate english ruta_normal_14_acb06a1d:

    # C "¡Deja de joder!"
    C "Stop messing around!"

# game/script.rpy:1653
translate english ruta_normal_14_dca5840e:

    # "Cindy te regañó, no gritó pero si usó un tono elevado de voz que te hizo hacer un puchero."
    "Cindy scolded you, not shouting but using an elevated tone of voice that made you pout."

# game/script.rpy:1654
translate english ruta_normal_14_60f39125:

    # C "Fue un tipo raro que apareció en la tienda."
    C "There was a weird guy who showed up at the store."

# game/script.rpy:1655
translate english ruta_normal_14_cf949690:

    # DS "¿Qué definirías como raro?"
    DS "What would you define as weird?"

# game/script.rpy:1656
translate english ruta_normal_14_2b0c69b2:

    # "Cindy rodó los ojos."
    "Cindy rolled her eyes."

# game/script.rpy:1657
translate english ruta_normal_14_e8c22d1b:

    # "Vaya, no tomabas a Cindy como alguien que se rebele ante la autoridad."
    "Wow, you didn't see Cindy as someone who rebels against authority."

# game/script.rpy:1658
translate english ruta_normal_14_f7a00c97:

    # C "Dió vueltas por más de una hora. Estaba muy interesado en [povname]."
    C "He went on and on for over an hour. He was very interested in [povname]."

# game/script.rpy:1659
translate english ruta_normal_14_b334b8d9:

    # "Wes dirigió su atención a ti, alzando una ceja."
    "Wes directed his attention to you, raising an eyebrow."

# game/script.rpy:1660
translate english ruta_normal_14_1c0599e1:

    # TW "¿Tuviste interacción con él?"
    TW "Did you interact with him?"

# game/script.rpy:1666
translate english ruta_normal_14_191789ff:

    # pov "Bueno… la verdad es que coquetee un poco con él."
    pov "Well... truthfully, I flirted with him a little."

# game/script.rpy:1668
translate english ruta_normal_14_3928a113:

    # "......."
    "......."

# game/script.rpy:1669
translate english ruta_normal_14_deacd3f3:

    # "Sentiste que todos en la habitación te estaban juzgando."
    "You felt everyone in the room judging you."

# game/script.rpy:1670
translate english ruta_normal_14_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:1671
translate english ruta_normal_14_9f6a419c:

    # pov "Sí, era extraño, pero fue casi… lindo."
    pov "Yeah, it was strange, but it was almost... cute."

# game/script.rpy:1672
translate english ruta_normal_14_da389d35:

    # "El aire se tornó incómodo."
    "The air grew uncomfortable."

# game/script.rpy:1675
translate english ruta_normal_14_bc2cdb9a:

    # pov "Oh, fue muy incómodo."
    pov "Oh, it was very awkward."

# game/script.rpy:1676
translate english ruta_normal_14_32ec8b5e:

    # pov "No paraba de mirarme, y fingió buscar algo para comprar por una eternidad."
    pov "He kept staring at me, and pretended to look for something to buy for an eternity."

# game/script.rpy:1677
translate english ruta_normal_14_6b910a7b:

    # pov "Quería creer que era otro tipo de acosador."
    pov "I wanted to believe he was just another type of stalker."

# game/script.rpy:1679
translate english ruta_normal_14_796f1be5:

    # "Esperaste una reacción de los detectives, pero te miraron con la misma seriedad de antes."
    "You waited for a reaction from the detectives, but they looked at you with the same seriousness as before."

# game/script.rpy:1680
translate english ruta_normal_14_3b160322:

    # "Te giraste a Cindy, y ella estaba negando suavemente con la cabeza."
    "You turned to Cindy, and she was gently shaking her head."

# game/script.rpy:1681
translate english ruta_normal_14_6fcbe063:

    # "Público difícil, ¿Eh?"
    "Tough crowd, huh?"

# game/script.rpy:1686
translate english ruta_normal_15_c7d97404:

    # DS "¿Dijo algo sobre él, algún motivo o dijo por qué te dejó con vida?"
    DS "Did he say anything about himself, any motive, or why he left you alive?"

# game/script.rpy:1687
translate english ruta_normal_15_3304f1ff:

    # "La pregunta te extrañó un poco. Era cómo si les extrañara el que hayas sobrevivido."
    "The question surprised you. It was as if they were surprised you had survived."

# game/script.rpy:1688
translate english ruta_normal_15_fb7e6cb7:

    # "Bueno, no estaba del todo equivocada al preguntar eso, ya que precisamente por la amenaza de Jeff es que sigues con vida."
    "Well, she wasn't entirely wrong to ask that, since it was precisely Jeff's threat that kept you alive."

# game/script.rpy:1690
translate english ruta_normal_15_ddcf5e02:

    # "Quizás hubieras revelado esa parte de la información por un desliz de lengua, pero Cindy interrumpió antes de que dijeras algo."
    "You might have revealed that part of the information by a slip of the tongue, but Cindy interrupted before you could say anything."

# game/script.rpy:1691
translate english ruta_normal_15_a20a31bb:

    # C "¿Qué clase de pregunta es esa?"
    C "What kind of question is that?"

# game/script.rpy:1692
translate english ruta_normal_15_53a3fe4a:

    # DS "Estamos haciendo un perfil del sospechoso, cualquier detalle nos puede ayudar-"
    DS "We're building a profile of the suspect, any detail can help us—"

# game/script.rpy:1693
translate english ruta_normal_15_b01a6cdc:

    # C "¡El tipo literalmente anda con la cara tapada!, ¡Está lleno de cicatrices!, ¿Qué más quieren? ¿Cómo no pueden encontrar a alguien así?"
    C "The guy literally has his face covered! He's full of scars! What more do you want? How can you not find someone like that?"

# game/script.rpy:1694
translate english ruta_normal_15_99d4603c:

    # TW "Señorita, debes calmarte."
    TW "Miss, you need to calm down."

# game/script.rpy:1695
translate english ruta_normal_15_0c85b23f:

    # C "¡No!, para un caso como este, con la descripción física ya deberían empezar a buscarlo."
    C "No! For a case like this, with that physical description, you should already be looking for him."

# game/script.rpy:1696
translate english ruta_normal_15_b7939db5:

    # C "Mientras más pase el tiempo, puede que esté más lejos."
    C "The longer it takes, the further he might be."

# game/script.rpy:1697
translate english ruta_normal_15_67cc23b9:

    # "La habitación quedó en silencio por unos momentos, y sentiste incomodidad ante la discusión."
    "The room fell silent for a few moments, and you felt awkward about the argument."

# game/script.rpy:1698
translate english ruta_normal_15_a38238ca:

    # TW "… Tienes razón, pararemos por ahora."
    TW "... You're right, we'll stop for now."

# game/script.rpy:1699
translate english ruta_normal_15_814a3cb3:

    # DS "Pero teniente-"
    DS "But, Lieutenant—"

# game/script.rpy:1700
translate english ruta_normal_15_7b517a45:

    # TW "[povname] necesita descansar."
    TW "[povname] needs to rest."

# game/script.rpy:1701
translate english ruta_normal_15_f1dca1cc:

    # "Wes guió a Sean hacia la salida de la habitación, girándose por última vez hacia ti."
    "Wes guided Sean towards the room exit, turning back to you one last time."

# game/script.rpy:1702
translate english ruta_normal_15_f089f2ff:

    # TW "Que te mejores."
    TW "Get well."

# game/script.rpy:1707
translate english ruta_normal_15_8bfda79c:

    # "Asentiste en silencio, observando que se retiran."
    "You nodded in silence, watching them leave."

# game/script.rpy:1708
translate english ruta_normal_15_11167e6b:

    # "Nuevamente, quedaste a solas con Cindy."
    "Again, you were alone with Cindy."

# game/script.rpy:1709
translate english ruta_normal_15_462af4bd:

    # "Esta vez, el silencio pesaba con muchas preguntas, que seguramente hubieran sido útiles para atrapar a Jeff."
    "This time, the silence was heavy with many questions, questions that surely would have been useful for catching Jeff."

# game/script.rpy:1710
translate english ruta_normal_15_0d2a4fb8:

    # "Cindy murmuró para sí misma, pero después se dio cuenta de tu mirada sobre ella, por lo que se enderezó en su asiento como si nada hubiera pasado."
    "Cindy mumbled to herself, but then noticed your gaze on her, so she straightened in her seat as if nothing had happened."

# game/script.rpy:1711
translate english ruta_normal_15_684684f4:

    # C "No te preocupes, [povname], lo encontrarán."
    C "Don't worry, [povname], they'll find him."

# game/script.rpy:1712
translate english ruta_normal_15_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:1713
translate english ruta_normal_15_6e91d2ee:

    # "¿Deberías mencionar la promesa de Jeff?"
    "Should you mention Jeff's promise?"

# game/script.rpy:1714
translate english ruta_normal_15_7a0250e0:

    # "Probablemente sería lo más inteligente de hacer, pero por el momento, te permitiste preguntar una sola cosa."
    "It would probably be the smartest thing to do, but for now, you allowed yourself to ask just one thing."

# game/script.rpy:1715
translate english ruta_normal_15_f016741e:

    # pov "Hey, Cindy."
    pov "Hey, Cindy."

# game/script.rpy:1716
translate english ruta_normal_15_4085f106:

    # pov "¿... No te gustan los policías?"
    pov "...You don't like cops?"

# game/script.rpy:1718
translate english ruta_normal_15_1ae53b6f:

    # "Cindy se sobresaltó en su asiento, y su tez palideció."
    "Cindy started in her seat, and her face paled."

# game/script.rpy:1719
translate english ruta_normal_15_d8ad7747:

    # "Ella desvió la mirada, frotó sus dedos indecisa."
    "She averted her gaze, rubbing her fingers indecisively."

# game/script.rpy:1720
translate english ruta_normal_15_76fbead3:

    # "Era evidente que no quería responder."
    "It was clear she didn't want to answer."

# game/script.rpy:1721
translate english ruta_normal_15_da6c857f:

    # pov "No importa, ignora eso último."
    pov "It's okay, forget about it."

# game/script.rpy:1722
translate english ruta_normal_15_bf369a1e:

    # "Restaste importancia con una sonrisa y un gesto de tu mano."
    "You brushed it off with a smile and a wave of your hand."

# game/script.rpy:1724
translate english ruta_normal_15_a95e9ade:

    # "Afortunadamente, Cindy pareció tranquilizarse."
    "Fortunately, Cindy seemed to relax."

# game/script.rpy:1725
translate english ruta_normal_15_d824b603:

    # C "Yo… iré a desayunar, vuelvo en un rato."
    C "I... I'm going to get breakfast, I'll be back in a bit."

# game/script.rpy:1726
translate english ruta_normal_15_27773c99:

    # pov "De acuerdo. ¿Me traes algo?"
    pov "Okay. Will you bring me something?"

# game/script.rpy:1728
translate english ruta_normal_15_970b4e54:

    # C "Claro, ¿Qué prefieres?"
    C "Sure, what do you prefer?"

# game/script.rpy:1740
translate english character_3_16478d9b:

    # "Cindy asintió y se puso de pie."
    "Cindy nodded and stood up."

# game/script.rpy:1741
translate english character_3_69d60587:

    # "Ella se dirigió a la puerta de la habitación, pero antes de que ella tomara la manilla, alguien más la abrió."
    "She headed for the room door, but before she could grasp the handle, someone else opened it."

# game/script.rpy:1742
translate english character_3_5b85991f:

    # "Cindy se movió a un lado, dejando entrar a un doctor."
    "Cindy moved aside, letting a doctor in."

# game/script.rpy:1743
translate english character_3_148e382e:

    # "Ella dio un saludo breve, mirándolo de reojo antes de salir de la habitación."
    "She gave a brief greeting, glancing at him before leaving the room."

# game/script.rpy:1749
translate english character_3_fb8e35f6:

    # "Miraste cómo el doctor se adentraba en la habitación en silencio, cargando consigo una bandeja metálica."
    "You watched the doctor enter the room in silence, carrying a metal tray."

# game/script.rpy:1750
translate english character_3_a0c729ef:

    # "Recordaste que el Dr. Salazar te advirtió que te vendrían periódicamente a monitorear."
    "You remembered Dr. Salazar warning you that they would come periodically to monitor you."

# game/script.rpy:1752
translate english character_3_929be24d:

    # "Él empezó a mover sus manos, preparando lo que fuera que tuviera en la bandeja."
    "He began to move his hands, preparing whatever was on the tray."

# game/script.rpy:1756
translate english character_3_2df5f182:

    # pov "Hola."
    pov "Hello."

# game/script.rpy:1757
translate english character_3_753a7997:

    # "El doctor no respondió, te ignoró descaradamente mientras hacía lo que fuera que estaba haciendo."
    "The doctor didn't respond, blatantly ignoring you as he went about his business."

# game/script.rpy:1762
translate english character_3_7175dc46:

    # pov "Hey, ¿Vienes a monitorearme o algo así?"
    pov "Hey, are you here to monitor me or something?"

# game/script.rpy:1763
translate english character_3_19c225d0:

    # "No obtuviste respuesta."
    "You received no answer."

# game/script.rpy:1764
translate english character_3_8b8ac98a:

    # "Suspiraste y apartaste la mirada."
    "You sighed and looked away."

# game/script.rpy:1765
translate english character_3_bf7bcec3:

    # "No sabías si era respuesta a un trauma u otra cosa, pero sentías cierto rechazo a ese hombre, alto, vestido de blanco con cabello negro y largo."
    "You didn't know if it was a response to trauma or something else, but you felt a certain aversion to this tall man, dressed in white with long black hair."

# game/script.rpy:1766
translate english character_3_2fa38ab1:

    # "……."
    "……."

# game/script.rpy:1767
translate english character_3_262a24b2:

    # "Es sospechoso, ¿No?"
    "He's suspicious, isn't he?"

# game/script.rpy:1772
translate english ruta_normal_16_1cd6bc86:

    # "De todas formas, sentías tu garganta seca."
    "Anyway, your throat felt dry."

# game/script.rpy:1773
translate english ruta_normal_16_013c5e55:

    # pov "Disculpa, ¿Podrías darme agua?"
    pov "Excuse me, could I have some water?"

# game/script.rpy:1774
translate english ruta_normal_16_eee229a0:

    # "El doctor se quedó quieto de repente y se mantuvo así unos segundos."
    "The doctor suddenly froze and stayed like that for a few seconds."

# game/script.rpy:1775
translate english ruta_normal_16_90e890fc:

    # "Entonces, él volvió a moverse."
    "Then, he moved again."

# game/script.rpy:1776
translate english ruta_normal_16_1f54312f:

    # "Sólo podías ver desde tu lugar la espalda del doctor."
    "You could only see the doctor's back from your spot."

# game/script.rpy:1778
translate english ruta_normal_16_760b8586:

    # "Escuchaste el inconfundible sonido de agua siendo servida."
    "You heard the unmistakable sound of water being poured."

# game/script.rpy:1779
translate english ruta_normal_16_705ca6e2:

    # "El simple sonido te dio más sed, lo más probable porque tu garganta adolorida suplicaba ser refrescada."
    "The simple sound made you thirstier, most likely because your sore throat begged to be refreshed."

# game/script.rpy:1780
translate english ruta_normal_16_17956473:

    # "El doctor dio unos pasos y se acercó a ti."
    "The doctor took a few steps and approached you."

# game/script.rpy:1784
translate english ruta_normal_16_99e255c1:

    # "Intentaste sentarte, pero tu cuerpo pesaba mucho."
    "You tried to sit up, but your body felt very heavy."

# game/script.rpy:1786
translate english ruta_normal_16_58194281:

    # "Sentiste cómo una mano se posaba en tu espalda y te ayudaba a enderezarte."
    "You felt a hand on your back, helping you to straighten up."

# game/script.rpy:1787
translate english ruta_normal_16_3f991d56:

    # "El toque era suave y atento, te hizo consciente de lo vulnerable que estabas."
    "The touch was soft and attentive; it made you realize how vulnerable you were."

# game/script.rpy:1788
translate english ruta_normal_16_00d58f4a:

    # "Entonces sentiste el borde de un vaso en tus labios."
    "Then you felt the rim of a glass at your lips."

# game/script.rpy:1790
translate english ruta_normal_16_86f38f42:

    # "Bebiste agua lentamente, tu garganta ardiendo pero aliviada por la frescura."
    "You drank water slowly, your throat burning but relieved by the coolness."

# game/script.rpy:1791
translate english ruta_normal_16_451d17fb:

    # "No te limitaste a un sorbo."
    "You didn't just take a sip."

# game/script.rpy:1792
translate english ruta_normal_16_1cee69c4:

    # "Al terminar, suspiraste con alivio, mirando de reojo al doctor que te estaba atendiendo."
    "When you finished, you sighed with relief, glancing at the doctor attending to you."

# game/script.rpy:1793
translate english ruta_normal_16_ea88bce1:

    # "Su fleco cubría sus rasgos y llevaba una mascarilla desechable."
    "His bangs covered his features, and he wore a disposable mask."

# game/script.rpy:1794
translate english ruta_normal_16_442941ca:

    # "……"
    "……"

# game/script.rpy:1795
translate english ruta_normal_16_4a801ede:

    # "Bueno, bueno, ¿Dónde habías visto eso antes?"
    "Well, well, where had you seen that before?"

# game/script.rpy:1799
translate english ruta_normal_16_68521b19:

    # pov "Muchas gracias, {b}doctor{/b}."
    pov "Thank you, {b}doctor{/b}."

# game/script.rpy:1800
translate english ruta_normal_16_a46d6012:

    # "Decidiste fingir ignorancia, tal vez eso te da algo de tiempo para que alguien aparezca."
    "You decided to feign ignorance; maybe that would buy you some time for someone to show up."

# game/script.rpy:1801
translate english ruta_normal_16_6caa14af:

    # "Quizás un doctor real o Cindy."
    "Perhaps a real doctor or Cindy."

# game/script.rpy:1806
translate english ruta_normal_16_056345bf:

    # pov "¿Cuantos años de medicina te costaron para saber que un paciente inconsciente debe mantenerse hidratado, {b}doc{/b}?"
    pov "How many years of medical school did it take you to know that an unconscious patient needs to be hydrated, {b}doc{/b}?"

# game/script.rpy:1807
translate english ruta_normal_16_10dee8a2:

    # "Estabas jugando con fuego, pero la situación era tan bizarra que no podías tomártelo en serio."
    "You were playing with fire, but the situation was so bizarre you couldn't take it seriously."

# game/script.rpy:1815
translate english ruta_normal_17_02763b64:

    # "El doctor no respondió y volvió a su lugar anterior, a hacer lo que sea que estaba haciendo."
    "The doctor didn't respond and went back to his previous spot, doing whatever he was doing."

# game/script.rpy:1816
translate english ruta_normal_17_03da9579:

    # "Tras beber agua, te sentías mejor para hablar."
    "After drinking water, you felt better and could speak."

# game/script.rpy:1817
translate english ruta_normal_17_71e4f884:

    # "Según las indicaciones del Dr. Salazar, no debías hablar mucho, pero tenías la confianza de que te sentías lo suficientemente bien como para mantener una conversación, aunque sea unilateral."
    "According to Dr. Salazar's instructions, you shouldn't talk much, but you felt well enough to maintain a conversation, even if unilateral."

# game/script.rpy:1823
translate english ruta_normal_17_52290b21:

    # pov "¿Realmente eres doctor?"
    pov "Are you really a doctor?"

# game/script.rpy:1824
translate english ruta_normal_17_1c371e59:

    # Stranger "…"
    Stranger "…"

# game/script.rpy:1827
translate english ruta_normal_17_19f0439d:

    # pov "Si hubiera sabido que atienden tan bien, habría venido más seguido."
    pov "If I had known they took such good care, I would have come more often."

# game/script.rpy:1828
translate english ruta_normal_17_1c371e59_1:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1833
translate english ruta_normal_18_ee771de8:

    # "Estaba siendo bastante obvio que este doctor no tenía interés en congeniar contigo."
    "It was quite obvious that this doctor had no interest in getting along with you."

# game/script.rpy:1834
translate english ruta_normal_18_723378a4:

    # "No sabías si tomártelo personal o no."
    "You didn't know whether to take it personally or not."

# game/script.rpy:1835
translate english ruta_normal_18_0d010e22:

    # "Esperarías que te trataran con cuidado en el hospital. Pero todo apuntaba que no sería así."
    "You would expect to be treated with care in the hospital. But everything indicated that wouldn't be the case."

# game/script.rpy:1839
translate english ruta_normal_18_8ac3bb47:

    # pov "Ah, ya veo."
    pov "Oh, I see."

# game/script.rpy:1840
translate english ruta_normal_18_348b6cd7:

    # pov "No me presenté primero."
    pov "I didn't introduce myself first."

# game/script.rpy:1841
translate english ruta_normal_18_cc32c858:

    # pov "Soy [povname], ¿con quién tengo el gusto?"
    pov "I'm [povname], and who do I have the pleasure of meeting?"

# game/script.rpy:1842
translate english ruta_normal_18_1c371e59:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1847
translate english ruta_normal_18_d61d14f0:

    # pov "Hey, si no tienes ánimos de congeniar con gente, creo que deberías reevaluar tu carrera."
    pov "Hey, if you don't feel like getting along with people, I think you should reevaluate your career."

# game/script.rpy:1848
translate english ruta_normal_18_1c371e59_1:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1849
translate english ruta_normal_18_e5b58650:

    # pov "¿Me escuchaste?"
    pov "Did you hear me?"

# game/script.rpy:1854
translate english ruta_normal_19_3242deab:

    # "El doctor siguió guardando silencio."
    "The doctor continued to remain silent."

# game/script.rpy:1855
translate english ruta_normal_19_151fc69a:

    # "Te estaba empezando a molestar."
    "He was starting to annoy you."

# game/script.rpy:1856
translate english ruta_normal_19_c196e39a:

    # "Un intento más, tal vez podrías sacarle unas palabras si insistías por última vez."
    "One more try, maybe you could get some words out of him if you insisted one last time."

# game/script.rpy:1862
translate english ruta_normal_19_80580610:

    # pov "Sabes, alguien me atacó."
    pov "You know, someone attacked me."

# game/script.rpy:1863
translate english ruta_normal_19_9d7adffa:

    # "El doctor se quedó inmóvil en su lugar."
    "The doctor remained motionless in his spot."

# game/script.rpy:1864
translate english ruta_normal_19_7928f4b4:

    # pov "Fue alguien con el que hablé en mi trabajo."
    pov "It was someone I talked to at my job."

# game/script.rpy:1865
translate english ruta_normal_19_55c975ad:

    # pov "Creo que no le gusté, haha."
    pov "I guess he didn't like me, haha."

# game/script.rpy:1866
translate english ruta_normal_19_fc8f6b35:

    # Stranger "Oh, yo no diría eso."
    Stranger "Oh, I wouldn't say that."

# game/script.rpy:1867
translate english ruta_normal_19_2961b1ed:

    # "El “doctor” murmuró de repente, su voz demasiado familiar."
    "The 'doctor' suddenly murmured, his voice too familiar."

# game/script.rpy:1870
translate english ruta_normal_19_6e8ac612:

    # pov "Ya conozco al Dr. Salazar, ¿eres su estudiante, quizás su colega?"
    pov "I already know Dr. Salazar, are you his student, perhaps his colleague?"

# game/script.rpy:1871
translate english ruta_normal_19_1c371e59:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1872
translate english ruta_normal_19_e6c602c5:

    # Stranger "Oh, soy algo mucho mejor que eso."
    Stranger "Oh, I'm something much better than that."

# game/script.rpy:1886
translate english ruta_mala_2_43f7d0f2:

    # "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    "The doctor returned to your side, pulling down his disposable mask to his chin."

# game/script.rpy:1890
translate english ruta_mala_2_18c89918:

    # J "Hola, [povname]."
    J "Hello, [povname]."

# game/script.rpy:1891
translate english ruta_mala_2_cbed57d9:

    # J "¿Disfrutando tu estancia en el hospital?"
    J "Enjoying your stay at the hospital?"

# game/script.rpy:1892
translate english ruta_mala_2_4de26740:

    # J "Qué pena… no soy fan de este lugar."
    J "What a shame... I'm not a fan of this place."

# game/script.rpy:1893
translate english ruta_mala_2_8297fb91:

    # J "¡Pero parece que tú lo eres!"
    J "But you seem to be!"

# game/script.rpy:1896
translate english ruta_mala_2_83d828e7:

    # "No tuviste tiempo para hablar cuando Jeff sacó un bisturí."
    "You had no time to speak when Jeff pulled out a scalpel."

# game/script.rpy:1897
translate english ruta_mala_2_076da34d:

    # pov "Espera, Jeff, escúchame…"
    pov "Wait, Jeff, listen to me..."

# game/script.rpy:1898
translate english ruta_mala_2_d22ca4c3:

    # J "No, no, no hay nada que decir."
    J "No, no, there's nothing to say."

# game/script.rpy:1899
translate english ruta_mala_2_fd26ada5:

    # J "Prefieres a los doctores, no tienes que dar más explicaciones."
    J "You prefer doctors, you don't need any more explanations."

# game/script.rpy:1902
translate english ruta_mala_2_0cfd5351:

    # "Jeff impulsó su brazo hacia ti, perforando tu garganta con la punta del bisturí."
    "Jeff thrust his arm towards you, piercing your throat with the tip of the scalpel."

# game/script.rpy:1903
translate english ruta_mala_2_13db7fc3:

    # "Te ahogaste con tu sangre, gorgojeaste sin poder gritar ni hablar."
    "You choked on your blood, gurgling, unable to scream or speak."

# game/script.rpy:1904
translate english ruta_mala_2_c7252d4f:

    # J "No soy tan bueno como un cirujano…"
    J "I'm not as good as a surgeon..."

# game/script.rpy:1905
translate english ruta_mala_2_2f58ccb2:

    # "Jeff susurró contra tu oído, tu inhalas con dificultad, tosiendo sangre."
    "Jeff whispered against your ear; you inhaled with difficulty, coughing up blood."

# game/script.rpy:1906
translate english ruta_mala_2_0d7bf9b4:

    # J "¡Pero pasión no me falta!"
    J "But I'm not lacking in passion!"

# game/script.rpy:1908
translate english ruta_mala_2_6064511a:

    # "La hoja del bisturí bajó desde tu cuello hasta tu clavícula, abriendo tu piel como un cierre, la hoja tan hundida en ti que sentías el choque del metal contra tus huesos."
    "The scalpel blade slid from your neck to your collarbone, opening your skin like a zipper, the blade so deep you felt the metal clash against your bones."

# game/script.rpy:1909
translate english ruta_mala_2_abcbc7c9:

    # "Él rió con entusiasmo, divertido con la vista de ti estremeciéndote del dolor mientras la sangre brotaba de tu cuello y se derramaba hacia los lados, empapando la ropa de hospital y las sábanas debajo de ti."
    "He laughed with enthusiasm, amused by the sight of you writhing in pain as blood gushed from your neck and spilled everywhere, soaking the hospital gown and the sheets beneath you."

# game/script.rpy:1910
translate english ruta_mala_2_e6dfb6f4:

    # "Dolía, pero por alguna razón no tanto."
    "It hurt, but for some reason, not that much."

# game/script.rpy:1911
translate english ruta_mala_2_90f71bf7:

    # "Sentías un cosquilleo en el lugar de tus heridas, lo más probable es que estabas con analgésicos."
    "You felt a tingling sensation where you were wounded; most likely, you were on painkillers."

# game/script.rpy:1913
translate english ruta_mala_2_96f9e185:

    # "Menos mal."
    "Good thing."

# game/script.rpy:1914
translate english ruta_mala_2_c2172e1f:

    # "Claro, que te hayan degollado con un bisturí no es la manera con la que hubieras preferido morir."
    "Of course, being slashed with a scalpel wasn't the way you would have preferred to die."

# game/script.rpy:1915
translate english ruta_mala_2_dd16970a:

    # "Pero ciertamente, el hecho de no experimentar el dolor verdadero lo hacía mejor."
    "But certainly, the fact that you didn't experience the true pain made it better."

# game/script.rpy:1916
translate english ruta_mala_2_1729c08a:

    # "Tal vez consigan atrapar a Jeff una vez que alguien aparezca, por la forma en que seguía a tu lado, riéndose como el loco que es."
    "Maybe they'll catch Jeff once someone shows up, given how he kept lingering beside you, laughing like the madman he was."

# game/script.rpy:1917
translate english ruta_mala_2_89550e4a:

    # "Al final, ¿Te mató porque fuiste amable con los doctores?"
    "In the end, did he kill you because you were nice to the doctors?"

# game/script.rpy:1918
translate english ruta_mala_2_a8bacfac:

    # "No será que él… ¿Estaba celoso?"
    "It can't be that he... was jealous?"

# game/script.rpy:1919
translate english ruta_mala_2_6b73473a:

    # "Nah, no puede ser eso."
    "Nah, that couldn't be it."

# game/script.rpy:1920
translate english ruta_mala_2_54f9ea25:

    # "Tal vez simplemente odiaba los hospitales, como él había dicho."
    "Maybe he just hated hospitals, as he had said."

# game/script.rpy:1923
translate english ruta_mala_2_c3f3b31b:

    # "{b}Final II: Ningún Doctor Pudo Salvarte{/b}"
    "{b}Ending II: No Doctor Could Save You{/b}"

# game/script.rpy:1930
translate english historia_continua_2_43f7d0f2:

    # "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    "The doctor returned to your side, pulling down his disposable mask to his chin."

# game/script.rpy:1935
translate english historia_continua_2_76a20fbe:

    # pov "Jeff, qué sorpresa, no sabía que eras tú."
    pov "Jeff, what a surprise, I didn't know it was you."

# game/script.rpy:1936
translate english historia_continua_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:1937
translate english historia_continua_2_8baa59f0:

    # J "No aprecio tu sarcasmo."
    J "I don't appreciate your sarcasm."

# game/script.rpy:1939
translate english historia_continua_2_ef1b1843:

    # "Tu corazón latía con fuerza, respuesta a la cercanía de la persona que te arrancó el ojo izquierdo."
    "Your heart pounded, a response to the proximity of the person who ripped out your left eye."

# game/script.rpy:1940
translate english historia_continua_2_a4788ae9:

    # "Tu cuerpo tenía miedo, pero tu mente no."
    "Your body was afraid, but your mind wasn't."

# game/script.rpy:1941
translate english historia_continua_2_90f059c1:

    # pov "Así que… ¿Viniste a darme cuidados especiales?"
    pov "So... did you come to give me special care?"

# game/script.rpy:1942
translate english historia_continua_2_e5b916b8:

    # "Jeff rió entre dientes, sacando una jeringa de su bolsillo."
    "Jeff chuckled, pulling a syringe from his pocket."

# game/script.rpy:1943
translate english historia_continua_2_09d1773a:

    # J "Algo así."
    J "Something like that."

# game/script.rpy:1944
translate english historia_continua_2_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Wait, what are you doing?"

# game/script.rpy:1945
translate english historia_continua_2_3653c69f:

    # "Él llevó la jeringa a tu intravenosa y la inyectó en la manguera."
    "He brought the syringe to your IV and injected it into the tubing."

# game/script.rpy:1946
translate english historia_continua_2_f8eb4f5d:

    # J "Relájate, no te matará."
    J "Relax, it wont kill you."

# game/script.rpy:1947
translate english historia_continua_2_22f84aa2:

    # J "Te hará sentir… algo de agitación."
    J "It will make you feel... a little agitated."

# game/script.rpy:1949
translate english historia_continua_2_ba488d1d:

    # "En el momento en que él dijo eso, sentiste que tu corazón empezó a latir más rápido."
    "The moment he said that, you felt your heart start to pound faster."

# game/script.rpy:1950
translate english historia_continua_2_38cf03a1:

    # "Empezaste a respirar aceleradamente, como si hubieras corrido una maratón."
    "You began to breathe rapidly, as if you had run a marathon."

# game/script.rpy:1951
translate english historia_continua_2_5443d4f7:

    # "Por reflejo, te llevaste una mano al pecho, apretando la tela de la bata de hospital."
    "Instinctively, you brought a hand to your chest, clutching the fabric of the hospital gown."

# game/script.rpy:1952
translate english historia_continua_2_623161fd:

    # pov "Tu…ah…. desgraciado…"
    pov "You... ah.... bastard..."

# game/script.rpy:1953
translate english historia_continua_2_3a9aebcd:

    # "Jeff chasqueó la lengua, negando con la cabeza"
    "Jeff clicked his tongue, shaking his head."

# game/script.rpy:1954
translate english historia_continua_2_24df739b:

    # J "Ten algo de respeto por tu doctor."
    J "Have some respect for your doctor."

# game/script.rpy:1955
translate english historia_continua_2_959fcb31:

    # "Jeff dirigió su mano hacia ti y sujetó entre sus dedos tu barbilla, alzando tu cabeza para verlo."
    "Jeff reached his hand towards you and held your chin between his fingers, lifting your head to look at him."

# game/script.rpy:1956
translate english historia_continua_2_9d2eee6b:

    # "Sintiéndote débil y con cansancio, te dejaste ser, sin fuerzas para gritar por auxilio ni para soltarte de su agarre."
    "Feeling weak and tired, you let yourself be held, too drained to scream for help or break free from his grip."

# game/script.rpy:1957
translate english historia_continua_2_0640d5ea:

    # J "Recuerda, estamos jugando."
    J "Remember, we're playing."

# game/script.rpy:1958
translate english historia_continua_2_9529c18c:

    # pov "Estoy…. en el hospital…. ¿Cómo…. esperas que…. huya de ti?"
    pov "I'm... in the hospital.... How.... do you expect me to.... escape you?"

# game/script.rpy:1959
translate english historia_continua_2_8cff178e:

    # pov "Eres… un tramposo…"
    pov "You're... a cheater..."

# game/script.rpy:1960
translate english historia_continua_2_bbf84d79:

    # "Jadeaste con frustración, ya que no tenías energías ni para hablar bien."
    "You gasped in frustration, lacking the energy to speak properly."

# game/script.rpy:1961
translate english historia_continua_2_f0ede4b8:

    # J "Tómalo como una advertencia."
    J "Consider it a warning."

# game/script.rpy:1962
translate english historia_continua_2_254db073:

    # "Jeff se encogió de hombros despreocupado."
    "Jeff shrugged, unconcerned."

# game/script.rpy:1964
translate english historia_continua_2_75c08509:

    # "De repente, una alarma empezó a sonar, y el ruido de pasos rápidos llegaron de afuera de la habitación."
    "Suddenly, an alarm began to blare, and the sound of rapid footsteps came from outside the room."

# game/script.rpy:1965
translate english historia_continua_2_3be0642a:

    # J "Esa es mi señal."
    J "That's my cue."

# game/script.rpy:1966
translate english historia_continua_2_e8eaf987:

    # "Jeff se colocó la mascarilla nuevamente y se puso de pie."
    "Jeff put his mask back on and stood up."

# game/script.rpy:1968
translate english historia_continua_2_0a2cc06f:

    # J "Espero que mejores tu estrategia, sería una lástima que termines aburriendome."
    J "I hope you improve your strategy, it would be a shame if you ended up boring me."

# game/script.rpy:1969
translate english historia_continua_2_a02492aa:

    # "Dijo Jeff, antes de desaparecer entre la pequeña multitud de enfermeras y doctores que entraron y se dirigieron hacia ti."
    "Jeff said, before disappearing among the small crowd of nurses and doctors who entered and headed for you."

# game/script.rpy:1970
translate english historia_continua_2_33985c4a:

    # DR "¡Tenemos una hiperpotasemia grave!"
    DR "We have severe hyperkalemia!"

# game/script.rpy:1971
translate english historia_continua_2_11df6b07:

    # DR "Administra gluconato de calcio intravenoso, 10 ml al 10 por ciento en bolo lento. ¡Ahora!"
    DR "Administer calcium gluconate intravenously, 10 ml of 10 percent solution slowly. Now!"

# game/script.rpy:1972
translate english historia_continua_2_644fe612:

    # "Entre instrucciones y palabras de lenguaje médico que no entendías del todo, miraste con recelo a Jeff, que se retiró como si nada, oculto a plena vista."
    "Amidst instructions and medical jargon you didn't fully understand, you eyed Jeff suspiciously as he retreated as if nothing had happened, hidden in plain sight."

# game/script.rpy:1973
translate english historia_continua_2_c0e01897:

    # "¿De verdad fue tan fácil para él infiltrarse?"
    "Was it really that easy for him to infiltrate?"

# game/script.rpy:1974
translate english historia_continua_2_32034f33:

    # "O Jeff tenía una habilidad sobrehumana para pasar desapercibido, o la gente de este hospital era inepta."
    "Either Jeff had a superhuman ability to go unnoticed, or the people in this hospital were inept."

# game/script.rpy:1975
translate english historia_continua_2_29769bdd:

    # "Querías creer que fuera la primera opción."
    "You wanted to believe it was the first option."

# game/script.rpy:1977
translate english historia_continua_2_60d6d30f:

    # "De todas formas, pudieron tratarte con rapidez, por lo que te sentías considerablemente mejor."
    "Anyway, they were able to treat you quickly, so you felt considerably better."

# game/script.rpy:1980
translate english historia_continua_2_74a1375b:

    # DR "Si notas la función renal comprometida, pide diálisis urgente."
    DR "If you notice compromised kidney function, order urgent dialysis."

# game/script.rpy:1981
translate english historia_continua_2_dc097126:

    # "El Dr. Salazar le estaba dando unas instrucciones a otro doctor, uno que ahora tenías la seguridad de que se trataba de un residente."
    "Dr. Salazar was giving instructions to another doctor, one you now were sure was a resident."

# game/script.rpy:1982
translate english historia_continua_2_aaec7888:

    # "El residente asintió ante las órdenes del Dr. Salazar y se retiró, dejándolos solos a ustedes dos."
    "The resident nodded at Dr. Salazar's orders and withdrew, leaving you two alone."

# game/script.rpy:1984
translate english historia_continua_2_a4b927c7:

    # "El Dr. Salazar se masajeó las sienes y se dirigió a tu camilla."
    "Dr. Salazar rubbed his temples and came to your bedside."

# game/script.rpy:1985
translate english historia_continua_2_a4b5fdd4:

    # "Su mirada reflejaba preocupación, por lo que no pudiste evitar desviar la mirada con culpabilidad."
    "His gaze reflected concern, so you couldn't help but look away, feeling guilty."

# game/script.rpy:1986
translate english historia_continua_2_c0f409e7:

    # DR "[povname], sufriste una hiperpotasemia severa, ¿Tienes alguna idea de lo que lo pudo haber provocado?"
    DR "[povname], you suffered severe hyperkalemia. Do you have any idea what might have caused it?"

# game/script.rpy:1987
translate english historia_continua_2_38b0402f:

    # "Te mordiste el labio inferior ante la pregunta."
    "You bit your lower lip at the question."

# game/script.rpy:1988
translate english historia_continua_2_0b96ee01:

    # "Estabas teniendo un momento difícil, tratando de convencerte de confiar todo el tema de Jeff con alguien más."
    "You were having a hard time convincing yourself to trust anyone with the whole Jeff situation."

# game/script.rpy:1993
translate english historia_continua_2_5f453a5d:

    # "Pero las acciones rápidas y el cuidado atento que él te dirigía te convenció de que era digno de confianza."
    "But his quick actions and attentive care convinced you that he was trustworthy."

# game/script.rpy:1994
translate english historia_continua_2_38c28b60:

    # pov "La verdad es que… Mi atacante vino."
    pov "The truth is... my attacker came."

# game/script.rpy:1995
translate english historia_continua_2_97c9bb38:

    # pov "Él… me hizo algo, le puso algo a mi intravenosa."
    pov "He... did something to me, put something in my IV."

# game/script.rpy:1996
translate english historia_continua_2_4e1edf9d:

    # "El Dr. Salazar abrió los ojos con sorpresa, para después bajar la mirada con lástima."
    "Dr. Salazar's eyes widened in surprise, then lowered his gaze with pity."

# game/script.rpy:1998
translate english historia_continua_2_5a89d0fd:

    # DR "Lo siento tanto, [povname], este se supone que debería ser un lugar seguro, y te falló."
    DR "I'm so sorry, [povname], this is supposed to be a safe place, and I failed you."

# game/script.rpy:1999
translate english historia_continua_2_f4ecc088:

    # DR "Yo te fallé."
    DR "I failed you."

# game/script.rpy:2001
translate english historia_continua_2_c16b3ac5:

    # "Tomaste la mano del doctor con la tuya, y trataste de sonreír reconfortante."
    "You took the doctor's hand in yours, and tried to offer a comforting smile."

# game/script.rpy:2002
translate english historia_continua_2_7f9c7eea:

    # pov "No es tu culpa, sé que haces lo mejor que puedes."
    pov "It's not your fault, I know you're doing your best."

# game/script.rpy:2003
translate english historia_continua_2_0e7d22cf:

    # "El Dr. Salazar miró en silencio sus manos entrelazadas, y acarició tu dorso con su pulgar."
    "Dr. Salazar looked silently at your intertwined hands, then stroked the back of yours with his thumb."

# game/script.rpy:2004
translate english historia_continua_2_f67a73f0:

    # "No evitaste sentir tus mejillas encenderse ligeramente."
    "You couldn't help but feel your cheeks flush slightly."

# game/script.rpy:2005
translate english historia_continua_2_375e0520:

    # DR "No es una idea muy convencional… pero puedo sacarte de aquí, ir a un lugar seguro."
    DR "It's not a very conventional idea... but I can get you out of here, to a safe place."

# game/script.rpy:2006
translate english historia_continua_2_a7b564e9:

    # "Eso… no sonaba muy profesional."
    "That... didn't sound very professional."

# game/script.rpy:2007
translate english historia_continua_2_af7963b3:

    # "Era casi como si no se estuviera comportando seriamente como un doctor, más bien parecía… estar engatusado."
    "It was almost as if he wasn't acting seriously like a doctor, but rather... trying to charm you."

# game/script.rpy:2008
translate english historia_continua_2_6c7e8ade:

    # "Pero ya no confiabas en el hospital."
    "But you no longer trusted the hospital."

# game/script.rpy:2009
translate english historia_continua_2_271f6a65:

    # "Cualquier otra cosa sonaba mejor para ti."
    "Anything else sounded better to you."

# game/script.rpy:2010
translate english historia_continua_2_f978a387:

    # pov "Hagámoslo."
    pov "Let's do it."

# game/script.rpy:2012
translate english historia_continua_2_27927256:

    # "El Dr. Salazar hizo un rápido papeleo en el que te dio de alta, te entregó tu ropa y te transportó en silla de ruedas por los pasillos del hospital."
    "Dr. Salazar quickly handled the paperwork to discharge you, gave you your clothes, and wheeled you through the hospital corridors."

# game/script.rpy:2013
translate english historia_continua_2_a706b908:

    # pov "¿A dónde vamos?"
    pov "Where are we going?"

# game/script.rpy:2016
translate english historia_continua_2_ae66f7db:

    # DR "A mi casa."
    DR "To my house."

# game/script.rpy:2017
translate english historia_continua_2_a0851940:

    # pov "Wow, invítame a cenar primero."
    pov "Wow, invite me to dinner first."

# game/script.rpy:2019
translate english historia_continua_2_fe272588:

    # "El Dr. Salazar rió entre dientes detrás de ti, empujando la silla de ruedas."
    "Dr. Salazar chuckled behind you, pushing the wheelchair."

# game/script.rpy:2020
translate english historia_continua_2_36a33978:

    # DR "Te realicé cirugía, ya nos saltamos unos cuantos pasos."
    DR "I performed surgery on you, we've already skipped a few steps."

# game/script.rpy:2021
translate english historia_continua_2_84b058f8:

    # "Al menos podían tomarse las cosas con humor."
    "At least you could take things with humor."

# game/script.rpy:2023
translate english historia_continua_2_1f97f75f:

    # "Ustedes llegaron al ascensor. El Dr. Salazar te entró primero, dejándote de espaldas a las puertas."
    "You arrived at the elevator. Dr. Salazar let you in first, leaving you with your back to the doors."

# game/script.rpy:2024
translate english historia_continua_2_5d0ecdbd:

    # pov "¿Viste a Cindy?"
    pov "Did you see Cindy?"

# game/script.rpy:2027
translate english historia_continua_2_0cc5c2c7:

    # DR "Si, linda chica, aunque un poco…"
    DR "Yes, nice girl, although a little…"

# game/script.rpy:2028
translate english historia_continua_2_112f6505:

    # pov "¿Criticona?"
    pov "Nitpicky?"

# game/script.rpy:2029
translate english historia_continua_2_9dc8e642:

    # DR "… Son tus palabras, no las mías."
    DR "… Those are your words, not mine."

# game/script.rpy:2033
translate english historia_continua_2_b7638da9:

    # "Ustedes quedan en silencio cuando escucharon las puertas del ascensor abrirse."
    "You fell silent when you heard the elevator doors open."

# game/script.rpy:2034
translate english historia_continua_2_15592602:

    # "Esperaste en silencio para que alguien subiera y apretara un botón, pero en cambio escuchaste un sonido ahogado y un forcejeo detrás de ti."
    "You waited silently for someone to come up and press a button, but instead you heard a muffled sound and a struggle behind you."

# game/script.rpy:2036
translate english historia_continua_2_00dd73c3:

    # "Miraste el espejo frente a ti, y te sorprendiste al ver que el Dr. Salazar ya no estaba detrás de ti."
    "You looked in the mirror in front of you, and you were surprised to see that Dr. Salazar was no longer behind you."

# game/script.rpy:2037
translate english historia_continua_2_cb9eafa9:

    # "Las puertas del ascensor estaban abiertas, dejando ver a un pasillo del hospital que estaba a oscuras."
    "The elevator doors were open, revealing a dark hospital hallway."

# game/script.rpy:2038
translate english historia_continua_2_8510a904:

    # pov "¿Doctor?"
    pov "Doctor?"

# game/script.rpy:2039
translate english historia_continua_2_54f6bf63:

    # "Llamaste, en un intento de recibir respuesta, pero no nada."
    "You called, trying to get a response, but nothing."

# game/script.rpy:2040
translate english historia_continua_2_57b6e6be:

    # J "Qué pena…"
    J "Too bad…"

# game/script.rpy:2041
translate english historia_continua_2_3f2d45e5:

    # "Esa voz te hizo estremecer."
    "That voice made you shudder."

# game/script.rpy:2042
translate english historia_continua_2_2ef3a9d3:

    # pov "¿Jeff…?"
    pov "Jeff…?"

# game/script.rpy:2043
translate english historia_continua_2_11bf8424:

    # J "¿Quién hace trampa ahora?"
    J "Who's cheating now?"

# game/script.rpy:2048
translate english historia_continua_2_bfe2ca31:

    # "Tras la burla, Jeff da un paso adelante, dejándose ver en el umbral del ascensor."
    "After the mockery, Jeff takes a step forward, revealing himself at the threshold of the elevator."

# game/script.rpy:2049
translate english historia_continua_2_a2a0d5dc:

    # pov "Yo…"
    pov "I..."

# game/script.rpy:2050
translate english historia_continua_2_f717968c:

    # J "Nuestro juego es entre tu y yo, nadie más."
    J "Our game is between you and me, no one else."

# game/script.rpy:2051
translate english historia_continua_2_2219bf95:

    # J "Pero ya no importa, el juego terminó."
    J "But it doesn't matter anymore, the game is over."

# game/script.rpy:2054
translate english historia_continua_2_2756808d:

    # "Jeff se adentra en el ascensor, mirándote desde el espejo."
    "Jeff walks into the elevator, looking at you from the mirror."

# game/script.rpy:2055
translate english historia_continua_2_129d3574:

    # "Su tono era burlesco, pero sus ojos estaban inyectados en sangre."
    "His tone was mocking, but his eyes were bloodshot."

# game/script.rpy:2056
translate english historia_continua_2_377afe9d:

    # "Con lentitud, él sacó su cuchillo y lo dirigió con la misma lentitud hacia tu estómago."
    "Slowly, he pulled out his knife and just as slowly directed it toward your stomach."

# game/script.rpy:2057
translate english historia_continua_2_85cddaf7:

    # "Jadeaste ante la expectación."
    "You gasped in anticipation."

# game/script.rpy:2058
translate english historia_continua_2_85557e85:

    # "Sabías lo que venía, sin embargo la ansiedad te abrumaba."
    "You knew what was coming, yet anxiety overwhelmed you."

# game/script.rpy:2060
translate english historia_continua_2_974b5030:

    # "De la misma manera lenta y calma, Jeff enterró la hoja del cuchillo en tu estómago, atravesando tu ropa hasta tu interior."
    "In the same slow and calm way, Jeff buried the knife blade into your stomach, passing through your clothes and into your core."

# game/script.rpy:2061
translate english historia_continua_2_2970ff53:

    # "Te doblaste del dolor, pero Jeff te forzó a enderezarte tras rodear tu cuello con su brazo."
    "You doubled over in pain, but Jeff forced you to straighten up after wrapping his arm around your neck."

# game/script.rpy:2062
translate english historia_continua_2_571cc53e:

    # "Sentiste su respiración a través de la mascarilla contra tu oreja."
    "You felt his breath through the mask against your ear."

# game/script.rpy:2063
translate english historia_continua_2_e9ec0ba7:

    # "Apretaste los dientes con fuerza, hasta el punto de lastimar tu boca."
    "You clenched your teeth so hard it hurt your mouth."

# game/script.rpy:2064
translate english historia_continua_2_edabb818:

    # J "Ssh… Ve a dormir…"
    J "Ssh… Go to sleep…"

# game/script.rpy:2065
translate english historia_continua_2_0d77114a:

    # "Él susurró, enterrando más la hoja en tu interior."
    "He whispered, burying the blade deeper inside you."

# game/script.rpy:2067
translate english historia_continua_2_713c8252:

    # "Era tanto el dolor, que no podías gritar."
    "The pain was so much that you couldn't scream."

# game/script.rpy:2068
translate english historia_continua_2_46cd4c40:

    # "Pero el trato de él, sujetándote con un abrazo mientras te consolaba con susurros te daba la impresión de que estaba tomando cierta consideración."
    "But the way he treated you, holding you in a hug while comforting you with whispers, gave you the impression that he was taking some consideration."

# game/script.rpy:2069
translate english historia_continua_2_0c9ebdc7:

    # "Pudo haber sido mucho más cruel, tal vez estaba siendo un poco considerado porque fuiste un breve acompañante de juegos."
    "He could have been much crueler, maybe he was being a little considerate because you were a brief playmate."

# game/script.rpy:2072
translate english historia_continua_2_ab8846e6:

    # "{b}Final III: No Seguiste El Juego{/b}"
    "{b}Ending III: You Didn't Play Along{/b}"

# game/script.rpy:2080
translate english supervivencia_7_e83b19bb:

    # "Decidiste que era mejor lidiar con eso por tu propia cuenta."
    "You decided it was best to deal with it on your own."

# game/script.rpy:2081
translate english supervivencia_7_8e8df0a9:

    # "Que Jeff tuviese la facilidad de entrar a un hospital e inyectarte algo bajo vigilancia te decía que la protección en ese lugar no era segura."
    "The fact that Jeff was able to walk into a hospital and inject you with something under guard told you that the protection in that place was not safe."

# game/script.rpy:2082
translate english supervivencia_7_191097d6:

    # pov "No lo sé, estuve inconsciente todo el tiempo."
    pov "I don't know, I was unconscious the whole time."

# game/script.rpy:2083
translate english supervivencia_7_03d0f93c:

    # "El Dr. Salazar se inclinó a ti, apoyando una mano a un costado de tu cabeza."
    "Dr. Salazar leaned toward you, placing a hand on the side of your head."

# game/script.rpy:2084
translate english supervivencia_7_6eb1e1ad:

    # DR "Lo que sea que haya pasado, puedes confiar en mí."
    DR "Whatever happened, you can trust me."

# game/script.rpy:2085
translate english supervivencia_7_f31580f0:

    # "….."
    "...."

# game/script.rpy:2086
translate english supervivencia_7_9f789813:

    # "Si…"
    "Yeah..."

# game/script.rpy:2087
translate english supervivencia_7_bcf6dd4d:

    # "No."
    "No."

# game/script.rpy:2088
translate english supervivencia_7_a7cbfb4e:

    # "Te las has arreglado para sobrevivir hasta ahora, puedes seguir haciéndolo sin ayuda de nadie."
    "You've managed to survive so far, you can continue to do so without anyone's help."

# game/script.rpy:2089
translate english supervivencia_7_450e9843:

    # "Llámalo presentimiento, pero algo te decía que Jeff no te atacaría por el momento, así que tenías tiempo para formar un plan."
    "Call it a feeling, but something told you Jeff wasn't going to attack you anytime soon, so you had time to form a plan."

# game/script.rpy:2090
translate english supervivencia_7_4679d11e:

    # "Jeff no te hizo tanto daño como antes, así que lo más seguro es que hablaba en serio cuando decía que era una advertencia."
    "Jeff didn't hurt you as much as he did before, so he probably meant it when he said it was a warning."

# game/script.rpy:2091
translate english supervivencia_7_ef145e81:

    # "Una advertencia de que podía hacerte algo peor, y depende de ti evitarlo."
    "A warning that he could do something worse to you, and it's up to you to prevent it."

# game/script.rpy:2092
translate english supervivencia_7_3a8c3acc:

    # "Así que no, no tenías por qué confiar en un doctor que acabas de conocer."
    "So no, you didn't have to trust a doctor you just met."

# game/script.rpy:2093
translate english supervivencia_7_9fcd9310:

    # pov "Doctor, digo la verdad."
    pov "Doctor, I'm telling the truth."

# game/script.rpy:2095
translate english supervivencia_7_bec541bf:

    # "El Dr. Salazar te miró unos segundos, no convencido, para después suspirar y tomar distancia."
    "Dr. Salazar looked at you for a few seconds, unconvinced, then sighed and distanced himself."

# game/script.rpy:2096
translate english supervivencia_7_dd3f172a:

    # DR "De acuerdo… trata de descansar."
    DR "Okay… try to rest."

# game/script.rpy:2097
translate english supervivencia_7_903b9054:

    # "Asentiste en silencio, pero a diferencia de antes, el doctor llamó a alguien de afuera de la habitación."
    "You nodded silently, but unlike before, the doctor called someone from outside the room."

# game/script.rpy:2098
translate english supervivencia_7_c35fdf56:

    # "Con rapidez, llegó una enfermera."
    "A nurse quickly arrived."

# game/script.rpy:2099
translate english supervivencia_7_685b025e:

    # DR "Estate alerta del monitor. Ante cualquier alteración, da aviso."
    DR "Be alert to the monitor. If there is any change, report it."

# game/script.rpy:2100
translate english supervivencia_7_129c912f:

    # "La enfermera asintió ante la instrucción y se quedó en la habitación, cerca del monitor cardiaco que tenías conectado."
    "The nurse nodded at the instruction and stayed in the room, near the heart monitor you had connected."

# game/script.rpy:2101
translate english supervivencia_7_394189ee:

    # "Claramente, el Dr. Salazar no confiaba en dejarte a solas."
    "Clearly, Dr. Salazar didn't trust leaving you alone."

# game/script.rpy:2102
translate english supervivencia_7_ff03ad2d:

    # DR "Vendré periódicamente."
    DR "I will come periodically."

# game/script.rpy:2105
translate english supervivencia_7_6e6aad82:

    # "No sabías si se lo dijo a la enfermera o a ti, pero de todas formas asentiste y te recostaste en la camilla con un suspiro de cansancio."
    "You didn't know if he said it to the nurse or to you, but you nodded anyway and lay back on the stretcher with a tired sigh."

# game/script.rpy:2106
translate english supervivencia_7_7587c487:

    # "Sobrevivir a un sádico asesino era exhausto."
    "Surviving a sadistic killer was exhausting."

# game/script.rpy:2108
translate english supervivencia_7_9d8f09b0:

    # "Cuando Cindy llegó y el Dr. Salazar le comentó que tuviste una pequeña crisis, ella se preocupó mucho, hasta el punto de considerar quedarse el resto del día contigo."
    "When Cindy arrived and Dr. Salazar told her you had a minor seizure, she became so concerned that she considered staying with you for the rest of the day."

# game/script.rpy:2109
translate english supervivencia_7_8032cbf9:

    # "Aunque apreciaras el gesto, no estabas del todo bien con eso. Así que la convenciste de que fuera a trabajar, pidiéndole que te cubra."
    "Even though you appreciated the gesture, you weren't entirely happy with it. So you convinced her to go to work, asking her to cover for you."

# game/script.rpy:2110
translate english supervivencia_7_80af0230:

    # "De todas formas, el Dr. Salazar te dio una semana de reposo."
    "Anyway, Dr. Salazar gave you a week of rest."

# game/script.rpy:2112
translate english supervivencia_7_ffe628b8:

    # "Como te dejaron en observación, tuviste que pasar el resto del día y la noche en el hospital, pero cuando llegara la mañana del día siguiente, todo estaba listo para darte de alta."
    "Since you were kept under observation, you had to spend the rest of the day and night in the hospital, but when the next morning came, everything was ready to discharge you."

# game/script.rpy:2128
translate english supervivencia_7_854cc4a4:

    # "Al día siguiente, te dieron de alta."
    "The next day, you were discharged."

# game/script.rpy:2129
translate english supervivencia_7_269c2368:

    # "Y por suerte, tenías el asunto del transporte cubierto."
    "And luckily, you had the transportation issue covered."

# game/script.rpy:2132
translate english supervivencia_7_41ad32d4:

    # TW "Adelante, [povname]."
    TW "Go ahead, [povname]."

# game/script.rpy:2133
translate english supervivencia_7_6d54df8e:

    # "El Teniente Wes abrió la puerta del auto para ti, mientras la detective Sean tomaba asiento en el puesto del conductor."
    "Lieutenant Wes opened the car door for you, while Detective Sean took the driver's seat."

# game/script.rpy:2134
translate english supervivencia_7_c3510aa7:

    # "Te levantas de tu lugar en la silla de ruedas en la que te llevaron a la entrada del hospital."
    "You got up from the wheelchair you were taken to the hospital entrance in."

# game/script.rpy:2140
translate english supervivencia_7_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2141
translate english supervivencia_7_8ab2a384:

    # "Te giras ante el llamado de tu nombre."
    "You turned at the sound of your name."

# game/script.rpy:2142
translate english supervivencia_7_d3c7a0ac:

    # pov "¿Dr. Salazar, qué sucede?"
    pov "Dr. Salazar, what is it?"

# game/script.rpy:2143
translate english supervivencia_7_5174155d:

    # "El Dr. Salazar se toma un momento para tomar aire, para después extenderte una tarjeta de presentación."
    "Dr. Salazar took a moment to breathe, then handed you a business card."

# game/script.rpy:2149
translate english supervivencia_7_b4a00926:

    # DR "Mi tarjeta, puedes llamarme cuando quieras… o si necesitas algo."
    DR "My card, you can call me whenever you want... or if you need anything."

# game/script.rpy:2151
translate english supervivencia_7_c8424d49:

    # "Recibiste el pedazo de papel y lo agitaste juguetonamente."
    "You took the piece of paper and playfully shook it."

# game/script.rpy:2152
translate english supervivencia_7_c0c38372:

    # pov "¿Quién diría que podría conseguir el número de alguien si me lastimaba un poco?"
    pov "Who would have thought I could get someone's number if I get hurt a little?"

# game/script.rpy:2154
translate english supervivencia_7_14e047c9:

    # "El Dr. Salazar abre la boca con impresión, para después carraspear con las mejillas encendidas."
    "Dr. Salazar's mouth dropped open in surprise, then he cleared his throat, his cheeks flushed."

# game/script.rpy:2155
translate english supervivencia_7_65c67a35:

    # DR "Esto… es preocupación profesional."
    DR "This... is professional concern."

# game/script.rpy:2156
translate english supervivencia_7_4f6feb5d:

    # "Wes alzó una ceja al doctor, el cual se rascó la cabeza con incomodidad y se retiró."
    "Wes raised an eyebrow at the doctor, who awkwardly scratched his head and retreated."

# game/script.rpy:2160
translate english supervivencia_7_1045acd9:

    # TW "¿Ese doctor no se ha sobrepasado contigo?"
    TW "Has that doctor been inappropriate with you?"

# game/script.rpy:2161
translate english supervivencia_7_e2082dd3:

    # pov "Para nada, ha sido bastante atento."
    pov "Not at all, he's been quite nice."

# game/script.rpy:2162
translate english supervivencia_7_600a2630:

    # "Wes se encogió de hombros y volvió a apuntar al interior del auto."
    "Wes shrugged and gestured back to the car."

# game/script.rpy:2165
translate english supervivencia_7_5919879c:

    # "Esta vez, sin interrupciones, te sentaste en los asientos traseros."
    "This time, without interruption, you sat in the back seat."

# game/script.rpy:2166
translate english supervivencia_7_fe311ec5:

    # "Cuando Wes tomó asiento en el lado del copiloto, el auto encendió y avanzó."
    "When Wes got into the passenger seat, the car started and drove off."

# game/script.rpy:2167
translate english supervivencia_7_9da7b463:

    # "La mayoría del tiempo, hubo silencio, hasta que viste disimuladamente cómo Wes le daba un leve codazo a Sean."
    "Most of the time, there was silence, until you subtly saw Wes nudge Sean."

# game/script.rpy:2172
translate english supervivencia_7_9fe86a32:

    # DS "Ehem."
    DS "Ahem."

# game/script.rpy:2173
translate english supervivencia_7_179f04b9:

    # "Ella carraspeó, mirándote por el espejo retrovisor."
    "She cleared her throat, looking at you in the rearview mirror."

# game/script.rpy:2174
translate english supervivencia_7_20be4162:

    # DS "Así que… [povname], ¿Cómo te sientes hasta el momento?"
    DS "So... [povname], how are you feeling right now?"

# game/script.rpy:2175
translate english supervivencia_7_caf5b14f:

    # "Te extrañó el que la policía más distante esté intentando conversar contigo, pero no tenías por qué ser idiota y rechazar sus esfuerzos."
    "It surprised you that the more distant cop was trying to talk to you, but you didn't have to be rude and reject her efforts."

# game/script.rpy:2176
translate english supervivencia_7_90901f6c:

    # pov "Bien, aunque en su mayoría es por los analgésicos."
    pov "Well, mostly because of the painkillers."

# game/script.rpy:2177
translate english supervivencia_7_3a7a25ea:

    # "No pudiste evitar acariciar con la punta de tus dedos el parche clínico que cubría tu cuenca izquierda."
    "You couldn't help but caress the clinical patch covering your left eye socket with your fingertips."

# game/script.rpy:2178
translate english supervivencia_7_99df20b2:

    # "Sean dio una pausa, para después responder."
    "Sean paused, then replied."

# game/script.rpy:2179
translate english supervivencia_7_8bf2ade2:

    # DS "… Tal vez tengas cicatrices, pero son la evidencia de que sobreviviste."
    DS "...You may have scars, but they are proof that you survived."

# game/script.rpy:2180
translate english supervivencia_7_8ffc9f45:

    # "No pudiste evitar sorprenderte por un momento ante el comentario alentador, pero debes admitir que te hizo el día."
    "You couldn't help but be surprised for a moment by the encouraging comment, but you had to admit it made your day."

# game/script.rpy:2181
translate english supervivencia_7_d1e890a4:

    # pov "Gracias."
    pov "Thank you."

# game/script.rpy:2182
translate english supervivencia_7_087cbbee:

    # "Sean miró al frente, concentrada en el camino, pero algo te hace pensar que se siente más tranquila."
    "Sean looked straight ahead, focused on the road, but something made you think she felt calmer."

# game/script.rpy:2183
translate english supervivencia_7_6e0b6066:

    # TW "¿Tu novia irá a verte a tu hogar?"
    TW "Will your girlfriend come to see you at your home?"

# game/script.rpy:2184
translate english supervivencia_7_e9643459:

    # "Tu mente se congela por instantes ante la pregunta de Wes."
    "Your mind froze for an instant at Wes's question."

# game/script.rpy:2185
translate english supervivencia_7_74267743:

    # pov "¿Disculpa?"
    pov "Excuse me?"

# game/script.rpy:2186
translate english supervivencia_7_e9c3f5a4:

    # TW "La señorita Cindy."
    TW "Miss Cindy."

# game/script.rpy:2187
translate english supervivencia_7_4a2bd410:

    # pov "Ah."
    pov "Oh."

# game/script.rpy:2188
translate english supervivencia_7_9016db8c:

    # "No sabías si ofenderte o avergonzarte."
    "You didn't know whether to be offended or embarrassed."

# game/script.rpy:2189
#translate english supervivencia_7_3168bde1:

    # pov "Es sólo una compañera de trabajo, ni siquiera somos tan amigas."
    #pov "She's just a coworker, we're not even that close."

# game/script.rpy:2190
translate english supervivencia_7_0fd21e0f:

    # TW "Oh, yo pensé…"
    TW "Oh, I thought..."

# game/script.rpy:2191
translate english supervivencia_7_f412babb:

    # "Él se giró a Sean, con una mirada que pedía ayuda, pero fue completamente ignorado."
    "He turned to Sean, with a look that asked for help, but he was completely ignored."

# game/script.rpy:2192
translate english supervivencia_7_7d3cfe72:

    # TW "La vi muy atenta y protectora de ti, lo siento, no quise…"
    TW "I saw her very attentive and protective of you, I'm sorry, I didn't mean to..."

# game/script.rpy:2193
translate english supervivencia_7_28fe49be:

    # pov "Está bien, también me llama la atención que sea así."
    pov "It's okay, it also strikes me that way."

# game/script.rpy:2194
translate english supervivencia_7_6a9963dc:

    # pov "Pero… es agradable ver que alguien se preocupa de mí en esta ciudad."
    pov "But... it's nice to see that someone cares about me in this city."

# game/script.rpy:2195
translate english supervivencia_7_579af3ec:

    # TW "Estás por tu cuenta tengo entendido."
    TW "You're on your own, I understand."

# game/script.rpy:2196
translate english supervivencia_7_8831ab95:

    # pov "Si, pero lidio con eso."
    pov "Yeah, but I deal with it."

# game/script.rpy:2197
translate english supervivencia_7_273b423c:

    # DS "Podemos pedir protección para ti."
    DS "We can ask for protection for you."

# game/script.rpy:2198
translate english supervivencia_7_419ad3d2:

    # pov "Oh, ¿Como vigilar donde vivo?"
    pov "Oh, like watching where I live?"

# game/script.rpy:2199
translate english supervivencia_7_a7f8607a:

    # DS "Si, ahora asumimos que tu atacante está en la fuga, pero no podemos suponer que no volverá para terminar el trabajo."
    DS "Yes, now we assume your attacker is on the run, but we can't assume he won't come back to finish the job."

# game/script.rpy:2200
translate english supervivencia_7_9e5d0d64:

    # "Wes se removió incómodo en su lugar."
    "Wes shifted uncomfortably in his seat."

# game/script.rpy:2201
translate english supervivencia_7_7c1a1a67:

    # TW "Elise…"
    TW "Elise…"

# game/script.rpy:2202
translate english supervivencia_7_59cbfea6:

    # pov "Está bien, no me importa."
    pov "It's okay, I don't mind."

# game/script.rpy:2203
translate english supervivencia_7_57016c31:

    # "En realidad, que te estén protegiendo te da cierta seguridad, considerando que Jeff irá a buscarte."
    "In fact, having protection gave you a sense of security, considering Jeff would come looking for you."

# game/script.rpy:2204
translate english supervivencia_7_8fd34851:

    # "Eres consciente de que estás entorpeciendo la investigación al ocultar información clave, como el nombre de Jeff y el juego que él instauró."
    "You were aware that you were hindering the investigation by concealing key information, such as Jeff's name and the game he initiated."

# game/script.rpy:2205
translate english supervivencia_7_9671a893:

    # "Pero tras presenciar cómo él se salía con la suya muy fácilmente en el hospital, algo te decía que el universo estaba a favor de él."
    "But after witnessing how easily he got away with it in the hospital, something told you the universe was on his side."

# game/script.rpy:2206
translate english supervivencia_7_8dcff2f8:

    # pov "La verdad, me hace sentir mejor."
    pov "Honestly, it makes me feel better."

# game/script.rpy:2207
translate english supervivencia_7_647a8c4b:

    # "Un escalofrío de peligro se enraíza desde tu nuca, como si tu cuerpo sintiera la presencia de Jeff cerca."
    "A shiver of danger ran down your neck, as if your body sensed Jeff's presence nearby."

# game/script.rpy:2209
translate english supervivencia_7_e863b50c:

    # "El recuerdo del dolor punzante de tu ojo siendo arrancado te hace acomodarte en tu asiento."
    "The memory of the sharp pain of your eye being ripped out made you settle deeper into your seat."

# game/script.rpy:2210
translate english supervivencia_7_cac656f4:

    # "Tal vez, sólo tal vez, te estaba afectando más de lo que te gustaría."
    "Perhaps, just perhaps, it was affecting you more than you cared to admit."

# game/script.rpy:2211
translate english supervivencia_7_74e055de:

    # DS "Llegamos."
    DS "We're here."

# game/script.rpy:2212
translate english supervivencia_7_c51e7fd2:

    # "Ves por la ventana del auto la entrada a tu edificio, lo que te hace suspirar de alivio."
    "You saw your building's entrance from the car window, making you sigh with relief."

# game/script.rpy:2213
translate english supervivencia_7_faa04ad0:

    # "Por fin puedes volver a tu cama."
    "Finally, you could go back to your bed."

# game/script.rpy:2214
translate english supervivencia_7_cec94954:

    # TW "Vamos a estar al pendiente, cualquier actualización te avisaremos."
    TW "We'll be on alert, we'll notify you of any updates."

# game/script.rpy:2220
translate english supervivencia_7_594526dc:

    # TW "Este es mi número, llama si necesitas algo, y te aseguro que mi preocupación es estrictamente profesional."
    TW "This is my number, call if you need anything, and I assure you my concern is strictly professional."

# game/script.rpy:2221
translate english supervivencia_7_aa401881:

    # "Recibes la tarjeta de presentación con la punta de tus dedos, viendo el nombre impreso, “W. Wes”."
    "You took the business card with your fingertips, seeing the name printed, 'W. Wes'."

# game/script.rpy:2226
translate english supervivencia_7_a7856b9d:

    # pov "Oh, W, ¿será de William?"
    pov "Oh, W, could that be William?"

# game/script.rpy:2228
translate english supervivencia_7_8623e9c5:

    # "Wes se ríe entre dientes, su voz grave vibrante es un dulce para los oídos."
    "Wes chuckled, his deep, vibrant voice a sweet sound to your ears."

# game/script.rpy:2229
translate english supervivencia_7_6d116769:

    # TW "No, pero buen intento."
    TW "No, but good try."

# game/script.rpy:2230
translate english supervivencia_7_e81521d4:

    # pov "¿Al menos puedo saber si hay señora Wes esperando en casa?"
    pov "At least can I know if there's a Mrs. Wes waiting at home?"

# game/script.rpy:2231
translate english supervivencia_7_bd02e432:

    # "Wes se sorprende por unos segundos, para después soltar una carcajada ligera."
    "Wes was surprised for a few seconds, then let out a light laugh."

# game/script.rpy:2233
translate english supervivencia_7_b7023bb1:

    # "Escuchas a un lado que Sean suelta un quejido lastimero."
    "You heard Sean let out a groaning sigh from the side."

# game/script.rpy:2234
translate english supervivencia_7_e7fa0442:

    # DS "La W es de Wallace, ¿Feliz?"
    DS "The W is for Wallace, happy?"

# game/script.rpy:2235
translate english supervivencia_7_b3a484cc:

    # "Alzas las manos en rendición, con una pequeña sonrisa traviesa."
    "You raised your hands in surrender, with a small playful smile."

# game/script.rpy:2236
translate english supervivencia_7_a01f58a9:

    # "Abres la puerta del auto y te tomas un momento para despedirte."
    "You opened the car door and took a moment to say goodbye."

# game/script.rpy:2237
translate english supervivencia_7_b76b4043:

    # pov "De acuerdo, geez. Fue un gusto, detective."
    pov "Alright, geez. It was a pleasure, detective."

# game/script.rpy:2238
translate english supervivencia_7_334493b0:

    # "Sean hace un ademán de despedida con la mano, como si te estuviera apresurando."
    "Sean waved goodbye, as if rushing you."

# game/script.rpy:2239
translate english supervivencia_7_62934f2a:

    # pov "Wallace, ¿Puedo llamarte Wallace?"
    pov "Wallace, can I call you Wallace?"

# game/script.rpy:2240
translate english supervivencia_7_b80127c9:

    # "Wes alzó una ceja con una sonrisa sarcástica."
    "Wes raised an eyebrow with a sarcastic smile."

# game/script.rpy:2241
translate english supervivencia_7_bd831bd5:

    # TW "Ya lo hiciste."
    TW "You already did."

# game/script.rpy:2242
translate english supervivencia_7_9fe64b69:

    # pov "Fue un placer, Wallace."
    pov "It was a pleasure, Wallace."

# game/script.rpy:2243
translate english supervivencia_7_dea47636:

    # "Él vuelve a reír levemente, despidiéndote con la mano."
    "He chuckled softly again, waving goodbye to you."

# game/script.rpy:2244
translate english supervivencia_7_20334c32:

    # TW "Ya nos veremos, player."
    TW "See you around, player."

# game/script.rpy:2248
translate english supervivencia_7_6c158f2f:

    # pov "¿Puedo tener su número, detective?"
    pov "Can I have your number, detective?"

# game/script.rpy:2250
translate english supervivencia_7_c61f0fa2:

    # "Ves por el espejo retrovisor que los ojos de Sean se abren con sorpresa."
    "You saw in the rearview mirror that Sean's eyes widened in surprise."

# game/script.rpy:2251
translate english supervivencia_7_106b82e3:

    # DS "¿Disculpa?"
    DS "Excuse me?"

# game/script.rpy:2252
translate english supervivencia_7_02efd91a:

    # pov "El teniente me dió el de él, ¿Puedo tener el suyo?"
    pov "The lieutenant gave me his, can I have yours?"

# game/script.rpy:2253
translate english supervivencia_7_2efaf03a:

    # "Sean mira de reojo a Wes, el cual se encoge de hombros."
    "Sean glanced at Wes, who shrugged."

# game/script.rpy:2255
translate english supervivencia_7_fd8550e3:

    # DS "Bueno… yo…"
    DS "Well... I..."

# game/script.rpy:2256
translate english supervivencia_7_e61fc35a:

    # TW "Discúlpala, no tiene muchas habilidades sociales."
    TW "Excuse her, she doesn't have many social skills."

# game/script.rpy:2257
translate english supervivencia_7_b0115458:

    # "Sean le da un codazo a Wes, quién se ríe levemente con burla."
    "Sean elbowed Wes, who chuckled lightly."

# game/script.rpy:2258
translate english supervivencia_7_055318f6:

    # DS "¡Wallace!"
    DS "Wallace!"

# game/script.rpy:2259
translate english supervivencia_7_edf0575d:

    # pov "Eso es lindo."
    pov "That's cute."

# game/script.rpy:2260
translate english supervivencia_7_a5092d8b:

    # "Sean se queda en silencio por un momento, para después sacar a regañadientes su billetera."
    "Sean remained silent for a moment, then reluctantly took out her wallet."

# game/script.rpy:2267
translate english supervivencia_7_22fcf735:

    # DS "Este… es mi número, llama cuando quieras- digo, cuando necesites."
    DS "This... is my number, call whenever you want – I mean, whenever you need it."

# game/script.rpy:2268
translate english supervivencia_7_092ee1c6:

    # "Ves por el rabillo de tu ojo restante cómo Wes alza una ceja ante los murmullos de Sean, quien desvía la mirada de ti."
    "You saw out of your remaining eye that Wes raised an eyebrow at Sean's murmurs, and she looked away from you."

# game/script.rpy:2269
translate english supervivencia_7_9d85e64f:

    # pov "Entendido."
    pov "Understood."

# game/script.rpy:2270
translate english supervivencia_7_fbbc3b23:

    # "Asientes firmemente."
    "You nodded firmly."

# game/script.rpy:2274
translate english supervivencia_7_f4225670:

    # pov "¿Puedo… preguntarles algo?"
    pov "Can I... ask you something?"

# game/script.rpy:2275
translate english supervivencia_7_7e125fc5:

    # "Ellos te miran desde sus lugares, expectantes a tus próximas palabras."
    "They looked at you from their seats, expecting your next words."

# game/script.rpy:2276
translate english supervivencia_7_058f65a3:

    # pov "No pude evitar darme cuenta… que les sorprendió ver que sobreviví."
    pov "I couldn't help but notice... that you were surprised to see me survive."

# game/script.rpy:2277
translate english supervivencia_7_835c9619:

    # "Wes mira un momento a Sean, con seriedad. Ella asiente firmemente."
    "Wes looked at Sean for a moment, seriously. She nodded firmly."

# game/script.rpy:2278
translate english supervivencia_7_fa263165:

    # DS "Hay que decirle, Wallace."
    DS "We have to tell them, Wallace."

# game/script.rpy:2279
translate english supervivencia_7_0c6d21a6:

    # "Wes hace una pausa, para después suspirar pesado."
    "Wes paused, then sighed heavily."

# game/script.rpy:2280
translate english supervivencia_7_bc674072:

    # TW "… Sospechamos de alguien que puede ser el hombre que te atacó."
    TW "We suspect someone who might be the man who attacked you."

# game/script.rpy:2281
translate english supervivencia_7_144c9fb4:

    # "Tragas fuertemente."
    "You swallowed hard."

# game/script.rpy:2282
translate english supervivencia_7_285aa2ba:

    # pov "¿... Quién creen que es?"
    pov "...Who do you think it is?"

# game/script.rpy:2283
translate english supervivencia_7_aff88bd5:

    # DS "Creemos que es alguien llamado Jeff, su apellido no lo sabemos con exactitud. Es un hombre muy peligroso, lleva escapando de la ley por más de una década."
    DS "We believe it's someone named Jeff, we don't know his last name exactly. He's a very dangerous man, he's been evading the law for over a decade."

# game/script.rpy:2284
translate english supervivencia_7_eca2b8ad:

    # "Wes se acomoda en su asiento para enfrentarte."
    "Wes settled into his seat to face you."

# game/script.rpy:2285
translate english supervivencia_7_a15ec728:

    # TW "[povname]... Es un asesino demente, y si tenemos razón respecto a esto… Serías la primera víctima de la que sabemos que él deja viva."
    TW "[povname]... He's a crazy killer, and if we're right about this... You'd be the first victim we know of that he leaves alive."

# game/script.rpy:2286
translate english supervivencia_7_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2287
#translate english supervivencia_7_89b76321:

    # "Bueno, eso fue una gran volcado de información, presuntamente valiosa."
    #"Well, that was a big information dump, presumably valuable."

# game/script.rpy:2288
translate english supervivencia_7_b9fe1b5c:

    # pov "De acuerdo, entiendo."
    pov "Alright, I understand."

# game/script.rpy:2289
translate english supervivencia_7_8d77837c:

    # TW "¿Vas a estar bien por tu cuenta?, ¿No quieres que te consigamos un hotel?"
    TW "Are you going to be okay on your own? Do you want us to get you a hotel?"

# game/script.rpy:2290
translate english supervivencia_7_1fbf6da9:

    # pov "No, gracias… estaré bien."
    pov "No, thanks... I'll be fine."

# game/script.rpy:2291
translate english supervivencia_7_1e74ec06:

    # "Wes te miró indeciso por un momento, pero cedió al verte que bajas del auto."
    "Wes looked at you indecisively for a moment, but then gave in when he saw you get out of the car."

# game/script.rpy:2299
translate english charla_1_3e23d177:

    # "Cierras la puerta y te quedas un momento sobre la acera, observando cómo el auto se mezcla en el tráfico."
    "You closed the door and stood on the sidewalk for a moment, watching the car blend into traffic."

# game/script.rpy:2300
translate english charla_1_7e1dbd33:

    # "Suspiras con alivio, girándote al vestíbulo de tu edificio."
    "You sighed with relief, turning towards your building's lobby."

# game/script.rpy:2302
translate english charla_1_970f18c5:

    # "Cuando llegas a tu departamento, está igual a cómo lo dejaste hace dos días."
    "When you reached your apartment, it was just as you had left it two days ago."

# game/script.rpy:2303
translate english charla_1_5985f91d:

    # "Te entregaron el departamento amueblado y tenías pocas cosas propias, así que no había desorden, pero definitivamente haber dejado el lugar por dos días hizo que se acumulara algo de polvo."
    "The apartment was furnished, and you had few belongings, so there was no mess, but definitely leaving the place for two days had caused some dust to accumulate."

# game/script.rpy:2305
translate english charla_1_661a8bb4:

    # "Así que lo primero que haces es ponerte a barrer y sacudir."
    "So the first thing you did was sweep and dust."

# game/script.rpy:2306
translate english charla_1_f1ebc1f5:

    # "Abres las ventanas mientras agitas los cojines del sofá, y después sacudes el polvo de la tv."
    "You opened the windows while shaking the sofa cushions, then dusted the TV."

# game/script.rpy:2309
translate english charla_1_6773f2ee:

    # "Deshechas todo de la nevera que está en mal estado y limpias el interior."
    "You threw out all the bad food in the fridge and cleaned the inside."

# game/script.rpy:2311
translate english charla_1_5c8f4564:

    # "Pasas al baño, donde limpias las superficies hasta que no puedes ver ni un rastro de suciedad."
    "You went to the bathroom, where you cleaned the surfaces until you couldn't see a trace of dirt."

# game/script.rpy:2314
translate english charla_1_cfd9eb9a:

    # "Por último, llegas a tu habitación. Está más vacía de lo que te gustaría."
    "Finally, you reached your bedroom. It was emptier than you would have liked."

# game/script.rpy:2315
translate english charla_1_887a93a3:

    # "Te gustaría tener…"
    "You would have..."

# game/script.rpy:2319
translate english charla_1_9958e21b:

    # "Lo que sea para cubrir las paredes blancas."
    "Whatever it was to cover the white walls."

# game/script.rpy:2322
translate english charla_1_e5bba708:

    # "Iluminación extra y estética le vendría bien."
    "Extra lighting and aesthetics would be nice."

# game/script.rpy:2325
translate english charla_1_00db2001:

    # "Más que adornos, preferirías tener muebles para guardar tus cosas."
    "More than decorations, you'd prefer to have furniture to store your things."

# game/script.rpy:2330
translate english character_4_95f06fba:

    # "De todas formas, ahora no tienes tiempo para preocuparte por eso."
    "Anyway, now you don't have time to worry about that."

# game/script.rpy:2331
translate english character_4_d82049e2:

    # "Tienes que lidiar con lo más importante…"
    "You have to deal with the most important thing..."

# game/script.rpy:2334
translate english character_4_0aa4328b:

    # "Cierras todas las ventanas a tu alcance con seguro, luego vas a la entrada y pones doble llave a la cerradura."
    "You locked all the windows you could reach, then went to the entrance and double-locked the door."

# game/script.rpy:2335
translate english character_4_b6b7faa7:

    # "Te asomas por una ventana, y ves que en la calle de enfrente hay una patrulla estacionada."
    "You peered out a window, and saw a patrol car parked on the street across from you."

# game/script.rpy:2337
translate english character_4_4ebb7a9d:

    # "Suspiras, sentándote en el sofá, recuperando el aire y la sensación de seguridad que habías perdido hace tiempo."
    "You sighed, sitting on the sofa, recovering your breath and the sense of security you had lost a long time ago."

# game/script.rpy:2338
translate english character_4_14d6a519:

    # "Técnicamente, Jeff no podría alcanzarte. No debería."
    "Technically, Jeff couldn't reach you. He shouldn't."

# game/script.rpy:2339
translate english character_4_464170cf:

    # "Pero uno nunca puede estar seguro, para conveniencias del guión."
    "But you can never be too sure, for the convenience of the script."

# game/script.rpy:2341
translate english character_4_77db2485:

    # "Para distraerte, enciendes la tv y cambias de canal hasta alguno que te interese, hasta que llegas a un noticiario mostrando un escenario muy familiar."
    "To distract yourself, you turned on the TV and changed channels until you found one you were interested in, until you landed on a news report showing a very familiar scene."

# game/script.rpy:2342
translate english character_4_05fe7baa:

    # "Esa es… ¿La calle donde está la tienda de películas?"
    "Is that... the street where the video store is?"

# game/script.rpy:2343
translate english character_4_59d4805a:

    # "Subes el volúmen, con mayor interés."
    "You turned up the volume, with more interest."

# game/script.rpy:2344
translate english character_4_7c138c67:

    # Peri "… Una persona fue atacada a las 9 horas de la noche el día jueves, con heridas graves. Fuentes médicas informaron que la víctima se encuentra en recuperación."
    Peri "A person was attacked at 9 PM on Thursday, with serious injuries. Medical sources reported that the victim is recovering."

# game/script.rpy:2345
translate english character_4_b7b4970a:

    # Peri "Descripciones del atacante indican que es un hombre alto, blanco, entre 20 y 30 años con cicatrices en el rostro. Lleva ropa blanca y negra, y frecuenta cubrirse el rostro."
    Peri "Descriptions of the attacker indicate a tall, white male, between 20 and 30 years old with scars on his face. He wears black and white clothes, and frequently covers his face."

# game/script.rpy:2346
translate english character_4_1daa3ac5:

    # Peri "Al sospechoso se le atribuyen 27 víctimas de asesinato, pero los investigadores estiman que el número real podría superar al centenar."
    Peri "The suspect is attributed with 27 murders, but investigators estimate the real number could exceed a hundred."

# game/script.rpy:2347
translate english character_4_79ee9085:

    # "Era bastante obvio que estaban hablando de tu ataque."
    "It was pretty obvious they were talking about your attack."

# game/script.rpy:2348
translate english character_4_9a412531:

    # "Sientes que pierdes fuerzas en las manos mientras más escuchas a la periodista, mientras más sabes de Jeff."
    "You felt your hands lose strength the more you listened to the journalist, the more you learned about Jeff."

# game/script.rpy:2349
translate english character_4_e3bd9b29:

    # "¿Tantas personas había matado?"
    "He had killed so many people?"

# game/script.rpy:2350
translate english character_4_bd9017a0:

    # "¿Realmente te había dejado con vida?"
    "Did he really leave you alive?"

# game/script.rpy:2351
translate english character_4_b775e333:

    # "Recuerdas vagamente que Wes había discutido con unas personas fuera de tu habitación en el hospital, seguramente estaba ahuyentando a periodistas que querían hablar contigo."
    "You vaguely remembered Wes arguing with some people outside your hospital room; he was surely chasing away journalists who wanted to talk to you."

# game/script.rpy:2352
translate english character_4_6e1df953:

    # "Mejor, así hubieras tenido menos chance de meter la pata."
    "Better that way, you would have had less chance to mess up."

# game/script.rpy:2353
translate english character_4_55de361a:

    # "Si te hubieran puesto ante las cámaras, con micrófonos en la boca y periodistas viéndote con hambre de información, hubieras revelado información que no te convendría por el acecho de Jeff."
    "If they had put you in front of cameras, with microphones in your face and journalists looking at you hungry for information, you would have revealed information that wouldn't have been convenient for Jeff's stalking."

# game/script.rpy:2354
translate english character_4_41bb9c8c:

    # "Ya que todo indicaba que no importaba a donde fueras, Jeff te encontraría."
    "Because everything indicated that no matter where you went, Jeff would find you."

# game/script.rpy:2357
translate english character_4_2418e16c:

    # "Sintiendo que el sudor baja por tu frente, vas a al baño y te lavas la cara, suspirando frente al lavabo."
    "Feeling the sweat run down your face, you went to the bathroom and washed your face, sighing in front of the sink."

# game/script.rpy:2358
translate english character_4_0048272b:

    # "Te miras en el espejo, y por primera vez presencias tu apariencia actual."
    "You looked at yourself in the mirror, and for the first time, you witnessed your current appearance."

# game/script.rpy:2359
translate english character_4_436ce400:

    # "Tu expresión se ve cansada, no llegaba a ser demacrada, pero estaba a punto."
    "Your expression was tired, not haggard yet, but close."

# game/script.rpy:2360
translate english character_4_1c5e571e:

    # "Marcas moradas en forma de dedos rodeaban la piel de tu cuello, lo que te hizo tragar."
    "Dark, finger-shaped marks surrounded your neck, making you swallow."

# game/script.rpy:2361
translate english character_4_5f89f852:

    # "Pero entonces caes en cuenta del parche sobre tu ojo izquierdo."
    "But then you noticed the patch over your left eye."

# game/script.rpy:2363
translate english character_4_a1eec882:

    # "Con dedos temblorosos, desenganchas los elásticos del parche de tu cabeza, dejando a la vista un parche adhesivo. Remueves esa pieza, y sólo queda una gasa."
    "With trembling fingers, you unhooked the elastic straps of the patch from your head, revealing an adhesive patch. You removed that piece, and all that remained was a gauze."

# game/script.rpy:2364
translate english character_4_c7cf1e93:

    # "Pacientemente, quitas la gasa, para finalmente ver lo que había hecho Jeff de ti."
    "Patiently, you removed the gauze, to finally see what Jeff had done to you."

# game/script.rpy:2365
translate english character_4_0e558445:

    # "Tras quitar el pedazo de tela, ves tu párpado caído, y cuando intentas pestañear, tu párpado tiembla, dejando ver el interior de tu cuenca, recubierto con piel rosada y brillante."
    "After removing the piece of cloth, you saw your eyelid drooping, and when you tried to blink, your eyelid trembled, revealing the inside of your eye socket, covered with pink, shiny skin."

# game/script.rpy:2366
translate english character_4_a2b4e1b4:

    # "Sientes curiosidad y extiendes tu párpado inferior para ver mejor el interior de tu cuenca."
    "You felt curious and extended your lower eyelid to get a better look at the inside of your eye socket."

# game/script.rpy:2367
translate english character_4_e538b6bd:

    # "Es curioso, porque de alguna forma, sientes que tu ojo sigue ahí."
    "It's strange, because somehow, you feel like your eye is still there."

# game/script.rpy:2368
translate english character_4_15e0e58c:

    # "¿Cómo se llamaba?, ¿Sensación fantasma?"
    "What was it called? Phantom sensation?"

# game/script.rpy:2369
translate english character_4_565bdf76:

    # "Si giras tu ojo derecho a algún lado, sientes que tu ojo izquierdo hace lo mismo, aunque claramente ya no se encuentra ahí."
    "If you looked to your right, you felt your left eye do the same, even though it clearly wasn't there anymore."

# game/script.rpy:2370
translate english character_4_935dcc7e:

    # J "Es uno de mis mejores trabajos."
    J "It's one of my best works."

# game/script.rpy:2373
translate english character_4_832f7687:

    # "Te congelas ante la voz."
    "You froze at the voice."

# game/script.rpy:2379
translate english character_4_36bb159b:

    # "Tu visión se aclara, y en el reflejo del espejo, detrás de ti, puedes ver la silueta de Jeff."
    "Your vision cleared, and in the mirror's reflection, behind you, you could see Jeff's silhouette."

# game/script.rpy:2380
translate english character_4_06e9e468:

    # "Te giras repentinamente, con el corazón acelerado."
    "You turned suddenly, your heart pounding."

# game/script.rpy:2381
translate english character_4_1eca6826:

    # "Pero no hay nadie."
    "But there was no one."

# game/script.rpy:2382
translate english character_4_f19ad975:

    # "Te tomas un momento para recuperar la respiración, para luego llevarte una mano a la cara."
    "You took a moment to catch your breath, then brought a hand to your face."

# game/script.rpy:2383
translate english character_4_5563a14a:

    # "¿Realmente estabas empezando a alucinar?"
    "Were you really starting to hallucinate?"

# game/script.rpy:2384
translate english character_4_ddaf4c4c:

    # "Parece que Jeff había causado una gran impresión en ti."
    "It seemed Jeff had made quite an impression on you."

# game/script.rpy:2385
translate english character_4_a7596b4a:

    # "¿Puede que realmente…. tengas miedo?"
    "Could it be that you were truly... afraid?"

# game/script.rpy:2390
translate english character_4_ec91358c:

    # "No querías admitirlo… pero parece que es el caso."
    "You didn't want to admit it... but it seemed to be the case."

# game/script.rpy:2391
translate english character_4_7ebfdb1c:

    # "Pero tu miedo no es el de morir precisamente, es… de recibir más daño."
    "But your fear wasn't precisely of dying, it was... of receiving more harm."

# game/script.rpy:2395
translate english character_4_ea81ff4a:

    # "Nah, no era para tanto."
    "Nah, it wasn't that big of a deal."

# game/script.rpy:2396
translate english character_4_dc802691:

    # "Ese era tu cuerpo reaccionando al trauma, nada más."
    "That was your body reacting to trauma, nothing more."

# game/script.rpy:2403
translate english character_5_c32adeca:

    # "Tanto pensar en ese desquiciado te estaba cansando."
    "All that thinking about that madman was making you tired."

# game/script.rpy:2405
translate english character_5_18f4962d:

    # "Vas a la cocina a comer algo."
    "You went to the kitchen to eat something."

# game/script.rpy:2407
translate english character_5_94eab407:

    # "Tenías un par de donas en buen estado guardadas en la alacena."
    "You had a couple of good donuts stored in the cupboard."

# game/script.rpy:2408
translate english character_5_41716333:

    # "Bebes un poco de jugo y te tomas los analgésicos que te corresponden, y te vas a la cama."
    "You drank some juice and took your painkillers, then went to bed."

# game/script.rpy:2410
translate english character_5_6e269041:

    # "Decides hacerte un ramen instantáneo."
    "You decided to make instant ramen."

# game/script.rpy:2411
translate english character_5_b086fe2d:

    # "Lo acompañas con soda y te tomas los analgésicos que te corresponden, y te vas a la cama."
    "You accompanied it with soda and took your painkillers, then went to bed."

# game/script.rpy:2415
translate english character_5_40c200ae:

    # "Quieres ir a dormir sintiendo que estás a salvo, pensando que estarás bien."
    "You wanted to go to sleep feeling safe, thinking you'd be fine."

# game/script.rpy:2416
translate english character_5_640cdfa9:

    # "Pero como alguien está leyendo esto, eso no pasa."
    "But since someone is reading this, that won't happen."

# game/script.rpy:2419
translate english character_5_0d2d99c4:

    # "Escuchas un crujido, lo que te despierta de inmediato."
    "You heard a creak, which woke you up immediately."

# game/script.rpy:2421
translate english character_5_199d40c8:

    # "No sabes si es por tener el sueño ligero o porque estás alerta, pero agradeces que sea así."
    "You didn't know if it was because you're a light sleeper or because you're alert, but you were glad it was."

# game/script.rpy:2423
translate english character_5_0f86233a:

    # "Te quedas un momento en tu lugar, esperando que se trate de tu imaginación nuevamente, pero vuelves a escuchar un crujido, esta vez sabes que es por que hay alguien en la casa."
    "You stayed in your spot for a moment, hoping it was just your imagination again, but you heard another creak; this time you knew it was because there was someone in the house."

# game/script.rpy:2425
translate english character_5_6ca1be20:

    # "¡Tienes que esconderte!"
    "You have to hide!"

# game/script.rpy:2434
translate english game_over_227d368c:

    # J "¡Te encontré!"
    J "Found you!"

# game/script.rpy:2445
translate english muerte_cama_debd40ba:

    # "Es un buen escondite."
    "It's a good hiding spot."

# game/script.rpy:2446
translate english muerte_cama_9c64c59e:

    # "Aunque un poco predecible."
    "A bit predictable though."

# game/script.rpy:2447
translate english muerte_cama_5f9b772e:

    # "...."
    "...."

# game/script.rpy:2452
translate english muerte_cama_b8691e1d:

    # J "¡Boo!"
    J "Boo!"

# game/script.rpy:2453
translate english muerte_cama_2b928eff:

    # "Tal vez demasiado."
    "Maybe too much."

# game/script.rpy:2456
translate english muerte_cama_946aaa9f:

    # "Te arrastras hasta el fondo, y Jeff te sigue a gatas, mientras se ríe."
    "You crawled to the back, and Jeff crawled after you, laughing."

# game/script.rpy:2457
translate english muerte_cama_8c52690f:

    # J "¡[povname]!, ¡Qué movimiento tan travieso!"
    J "[povname]! What a naughty move!"

# game/script.rpy:2458
translate english muerte_cama_1c647f2d:

    # "El espacio es tan reducido que pronto sientes la respiración de Jeff en tu oído."
    "The space was so small that you soon felt Jeff's breath on your ear."

# game/script.rpy:2459
translate english muerte_cama_ee733ec5:

    # J "Pierdes de nuevo…"
    J "You lost again..."

# game/script.rpy:2461
translate english muerte_cama_265621ed:

    # "Sientes la fría hoja del cuchillo en tu cuello, y con un chirrido, sientes que el ardor te atraviesa."
    "You felt the cold blade of the knife on your neck, and with a screech, you felt the burning sensation pierce you."

# game/script.rpy:2471
translate english muerte_closet_8683ebd2:

    # "Esperas unos segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    "You waited a few seconds, which turned into an eternity, as you heard the sound of someone opening doors and rummaging through things."

# game/script.rpy:2473
translate english muerte_closet_c649c8a1:

    # "Pero tus esperanzas de haber escogido un buen escondite se van cuando escuchas que la puerta del closet se abre."
    "But your hopes of having chosen a good hiding spot vanished when you heard the closet door open."

# game/script.rpy:2477
translate english muerte_closet_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:2478
translate english muerte_closet_3547e498:

    # "Jeff suena encantado por verte, pero el gran cuchillo en su mano no inspira nada bueno."
    "Jeff sounded delighted to see you, but the big knife in his hand didn't inspire anything good."

# game/script.rpy:2479
translate english muerte_closet_ad0c25ee:

    # J "Volviste a perder, jeje."
    J "You lost again, hehe."

# game/script.rpy:2483
translate english muerte_closet_1d67348d:

    # "No tienes momento para pensar cuando Jeff te apuñala en el estómago."
    "You had no time to think as Jeff stabbed you in the stomach."

# game/script.rpy:2485
#translate english muerte_closet_7fb41fc5:

    # "Caes en el suelo, por el color intenso y la pérdida de sangre."
    #"You fell to the floor, because of the intense color and loss of blood."

# game/script.rpy:2487
translate english muerte_closet_5c6ab507:

    # J "No sabes jugar muy bien, [povname]."
    J "You’re not that good at this game, [povname]."

# game/script.rpy:2488
translate english muerte_closet_3c529790:

    # "Sintiendo la luz de la luna fría filtrándose por las ventanas, caes en el inconsciente."
    "Feeling the cold moonlight filter through the windows, you fell unconscious."

# game/script.rpy:2496
translate english muerte_baño_503dcb72:

    # "Te sientes a salvo."
    "You felt safe."

# game/script.rpy:2497
translate english muerte_baño_5172f0a6:

    # "Pero entonces, escuchas como el pomo se agita."
    "But then, you heard the doorknob rattle."

# game/script.rpy:2498
translate english muerte_baño_4328316e:

    # J "¡[povname]!, ¡Te atrapé!"
    J "[povname]! I caught you!"

# game/script.rpy:2499
translate english muerte_baño_39c9e21f:

    # "No respondes."
    "You didn't answer."

# game/script.rpy:2501
translate english muerte_baño_269c9c28:

    # "La puerta es golpeada y se escuchan golpes estruendosos."
    "The door was struck and you heard thunderous blows."

# game/script.rpy:2502
translate english muerte_baño_a553fa9d:

    # J "¡Déjame entrar!, ¡Ya gané!"
    J "Let me in! I won!"

# game/script.rpy:2503
translate english muerte_baño_9790d876:

    # "Te quedas en silencio."
    "You remained silent."

# game/script.rpy:2504
translate english muerte_baño_883eb8e0:

    # "Quizás se canse y se vaya."
    "Maybe he'd get tired and leave."

# game/script.rpy:2505
translate english muerte_baño_14360a18:

    # J "…"
    J "..."

# game/script.rpy:2507
translate english muerte_baño_47accf77:

    # J "¡Ábreme!"
    J "Open up!"

# game/script.rpy:2508
translate english muerte_baño_83b0fc52:

    # "La puerta se sacude y te encoges ante la sorpresa."
    "The door shook and you flinched in surprise."

# game/script.rpy:2509
translate english muerte_baño_9bb27832:

    # "Un golpe contundente choca contra la puerta, luego otro, y otro."
    "A heavy blow hit the door, then another, and another."

# game/script.rpy:2511
translate english muerte_baño_45fa5a2d:

    # "Hasta que la madera cede."
    "Until the wood gave way."

# game/script.rpy:2514
translate english muerte_baño_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:2515
translate english muerte_baño_411c2304:

    # "El modo en que dice tu nombre es tenebroso, con los dientes apretados y en un gruñido."
    "The way he said your name was eerie, with clenched teeth and a growl."

# game/script.rpy:2517
translate english muerte_baño_8c3abdc5:

    # "No alcanzas a hacer nada cuando Jeff se abalanza sobre ti con cuchillo en mano."
    "You couldn't do anything as Jeff lunged at you with knife in hand."

# game/script.rpy:2528
translate english muerte_sala_8a9907ec:

    # "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    "You waited patiently, in silence, hoping the time would pass quickly."

# game/script.rpy:2530
translate english muerte_sala_68fc838e:

    # "Pero un crujido frente a ti te pretrifica."
    "But a creak in front of you froze you."

# game/script.rpy:2533
translate english muerte_sala_14360a18:

    # J "…"
    J "..."

# game/script.rpy:2534
translate english muerte_sala_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2535
translate english muerte_sala_65711022:

    # J "¿Si sabes que tienes que esconderte?"
    J "Do you know you have to hide?"

# game/script.rpy:2536
translate english muerte_sala_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:2537
translate english muerte_sala_0d97ff77:

    # J "Oh bueno, será."
    J "Oh well."

# game/script.rpy:2539
translate english muerte_sala_17198994:

    # "Jeff te sujeta del cuello, ahorcándote."
    "Jeff grabbed you by the neck, choking you."

# game/script.rpy:2543
translate english muerte_sala_ac1e07ed:

    # "Y entonces sientes que te perforan en el costado."
    "And then you felt yourself being pierced in the side."

# game/script.rpy:2545
translate english muerte_sala_b230520b:

    # J "Esto fue… demasiado fácil."
    J "This was... too easy."

# game/script.rpy:2554
translate english supervivencia_8_0c2bf72f:

    # "Te arrastras lo más silenciosamente posible debajo de la cama, y esperas."
    "You crawled as silently as possible under the bed, and waited."

# game/script.rpy:2556
translate english supervivencia_8_cec7c6dd:

    # "Escuchas crujidos suaves y continuos."
    "You heard soft, continuous creaks."

# game/script.rpy:2557
translate english supervivencia_8_00a46ad7:

    # "De repente ves unos pies atravesando la puerta de tu habitación, y tu respiración se detiene."
    "Suddenly you saw feet crossing your bedroom door, and your breathing stopped."

# game/script.rpy:2558
translate english supervivencia_8_7de54985:

    # "Los zapatos negros de combate avanzan con lentitud, rodeando tu cama."
    "Black combat boots advanced slowly, surrounding your bed."

# game/script.rpy:2559
translate english supervivencia_8_e1168643:

    # "Tu observas, rezando porque se vaya pronto."
    "You watched, praying he would leave soon."

# game/script.rpy:2560
translate english supervivencia_8_64d1793c:

    # "La persona se queda unos momentos más, para después retirarse con la misma lentitud."
    "The person stayed for a few more moments, then retreated with the same slowness."

# game/script.rpy:2561
translate english supervivencia_8_78463db0:

    # "Sientes que puedes respirar."
    "You felt you could breathe again."

# game/script.rpy:2562
translate english supervivencia_8_417015fd:

    # "Te quedas unos momentos, para después volver a pensar en qué hacer."
    "You stayed for a few moments, then started thinking about what to do next."

# game/script.rpy:2569
translate english supervivencia_9_3235a01c:

    # "Corres de puntillas al baño y cierras la puerta con seguro."
    "You tiptoed to the bathroom and locked the door."

# game/script.rpy:2570
translate english supervivencia_9_9fd87df2:

    # "Te metes en la tina, tomando resguardo detrás de la cortina."
    "You got into the tub, taking shelter behind the curtain."

# game/script.rpy:2572
translate english supervivencia_9_f727f90f:

    # "Esperas pacientemente, escuchando el sonido de alguien abriendo puertas y moviendo cosas."
    "You waited patiently, listening to the sound of someone opening doors and moving things."

# game/script.rpy:2573
translate english supervivencia_9_2f4ff68d:

    # "De repente, silencio."
    "Suddenly, silence."

# game/script.rpy:2580
translate english supervivencia_10_3c33d576:

    # "Disimuladamente, vas a la sala y te escondes detrás del sofá."
    "Stealthily, you went to the living room and hid behind the sofa."

# game/script.rpy:2581
translate english supervivencia_10_8a9907ec:

    # "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    "You waited patiently, in silence, hoping the time would pass quickly."

# game/script.rpy:2582
translate english supervivencia_10_ce617998:

    # "…"
    "..."

# game/script.rpy:2583
translate english supervivencia_10_807ef186:

    # "Aunque… estás en un lugar demasiado expuesto."
    "Although... you were in a very exposed place."

# game/script.rpy:2591
translate english supervivencia_11_e25e3544:

    # "Entras al closet y te quedas en silencio, escuchando el latido de tu corazón en tus oídos."
    "You went into the closet and stayed silent, listening to your heartbeat in your ears."

# game/script.rpy:2592
translate english supervivencia_11_dd5f1273:

    # "Esperas segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    "You waited for seconds, which felt like an eternity, as you heard someone opening doors and moving things around."

# game/script.rpy:2593
translate english supervivencia_11_223c4185:

    # "Tus esperanzas se están agotando."
    "Your hopes were fading."

# game/script.rpy:2594
translate english supervivencia_11_d72a9fd9:

    # "No puedes ir de un lugar a otro durante toda la noche."
    "You couldn't go from one place to another all night."

# game/script.rpy:2595
translate english supervivencia_11_e2a0e0b9:

    # "¿Cómo puede ser tan insistente?"
    "How could he be so persistent?"

# game/script.rpy:2596
translate english supervivencia_11_cc7fca97:

    # "El cansancio te está invadiendo, pierdes fuerzas en tus piernas."
    "Exhaustion was overcoming you, you felt your legs losing strength."

# game/script.rpy:2597
translate english supervivencia_11_f0ceb37a:

    # "Caes lentamente sobre tus rodillas, y te apoyas contra la pared."
    "You slowly fell to your knees, leaning against the wall."

# game/script.rpy:2598
translate english supervivencia_11_c1568c83:

    # "Ya no te importa si Jeff te atrapa."
    "You no longer cared if Jeff caught you."

# game/script.rpy:2599
translate english supervivencia_11_67c49334:

    # "Que se joda él y su estúpido juego."
    "To hell with him and his stupid game."

# game/script.rpy:2600
translate english supervivencia_11_2c222d01:

    # "De repente, escuchas un suspiro pesado desde algún lugar de tu departamento."
    "Suddenly, you heard a heavy sigh from somewhere in your apartment."

# game/script.rpy:2602
translate english supervivencia_11_0c22c3d8:

    # "Lentamente y con sigilo, te asomas por la abertura del closet."
    "Slowly and stealthily, you peered through the closet opening."

# game/script.rpy:2607
translate english supervivencia_11_1ea55987:

    # "Jeff está en tu sala, iluminado sutilmente por la luz de la luna que se filtra por la ventana."
    "Jeff was in your living room, subtly lit by the moonlight filtering through the window."

# game/script.rpy:2608
translate english supervivencia_11_d16bb677:

    # "Tiene el cuchillo a la mano, lo que te hace pensar que tuviste suerte de poder evitarlo."
    "He had the knife in his hand, which made you think you were lucky to have avoided him."

# game/script.rpy:2609
translate english supervivencia_11_d8b555fb:

    # J "¡Sé que me escuchas [povname]!"
    J "I know you hear me, [povname]!"

# game/script.rpy:2610
translate english supervivencia_11_6a59e688:

    # J "¡Tu ganas esta ronda!"
    J "You win this round!"

# game/script.rpy:2611
translate english supervivencia_11_afdb86b5:

    # "El cansancio te abandona por un instante, reemplazado por euforia."
    "Your exhaustion vanished for an instant, replaced by euphoria."

# game/script.rpy:2612
translate english supervivencia_11_615deda3:

    # J "Pero no olvides que te estaré vigilando."
    J "But don't forget I'll be watching you."

# game/script.rpy:2613
translate english supervivencia_11_4f075332:

    # "Eso era un hecho que ya tenías claro."
    "That was a fact you already knew."

# game/script.rpy:2616
translate english supervivencia_11_c726c171:

    # "Ya te visitó al hospital y te siguió a tu casa."
    "He had visited you in the hospital and followed you home."

# game/script.rpy:2617
translate english supervivencia_11_8955a1e2:

    # "No está de más decir que ya no te sientes a salvo en ninguna parte."
    "It goes without saying that you no longer felt safe anywhere."

# game/script.rpy:2620
translate english supervivencia_11_0f2e0ca2:

    # "Escuchas que la puerta principal se abre y se cierra, y eso te llena de un alivio que te hizo caer inconsciente en tu lugar."
    "You heard the main door open and close, and that filled you with a relief that made you fall unconscious in your spot."

# game/script.rpy:2621
translate english supervivencia_11_c7c6f2d0:

    # "De todas maneras, ¿Cómo pudo burlar a los policías ese maniaco?"
    "Anyway, how could that maniac have fooled the police?"

# game/script.rpy:2622
translate english supervivencia_11_baeb4af9:

    # "Una de tres."
    "One of three options."

# game/script.rpy:2623
translate english supervivencia_11_0273c1af:

    # "Uno, mató a los policías. Es el escenario más latoso, ya que eso involucraría muchos más policías."
    "One, he killed the police. That's the most tedious scenario, as it would involve many more police."

# game/script.rpy:2624
translate english supervivencia_11_3f0caf85:

    # "Dos, los policías no lo vieron. Lo que te causa una decepción inmensa."
    "Two, the police didn't see him. Which caused you immense disappointment."

# game/script.rpy:2625
translate english supervivencia_11_f6a136af:

    # "Y tres, Jeff es muy bueno escabulléndose."
    "And three, Jeff is very good at slipping away."

# game/script.rpy:2627
translate english supervivencia_11_867f8734:

    # "Aún no sabías cómo lo hacía."
    "You still didn't know how he did it."

# game/script.rpy:2628
translate english supervivencia_11_9d31e13f:

    # "Quizás lo sepas en un futuro, o quizás no."
    "Maybe you'll find out in the future, or maybe not."

# game/script.rpy:2629
translate english supervivencia_11_6efa74f7:

    # "El tiempo lo dirá."
    "Time would tell."

# game/script.rpy:2646
translate english supervivencia_11_26da947c:

    # "El día siguiente estaba… extrañamente calmo."
    "The next day was... strangely calm."

# game/script.rpy:2647
translate english supervivencia_11_8cf397f4:

    # "La noche anterior apenas pudiste dormir decentemente, dentro del closet cabe decir."
    "The night before, you barely got any decent sleep, in the closet, it must be said."

# game/script.rpy:2648
translate english supervivencia_11_1cff0ed2:

    # "El alivio de sentir que el acecho hacia ti terminó, aunque sea un día, agotó las fuerzas de tu cuerpo."
    "The relief of feeling that his stalking had ended, even if for just one day, drained your body's strength."

# game/script.rpy:2649
translate english supervivencia_11_8de1c803:

    # "Por lo que despertaste en el espacio reducido del closet, con un cuerpo adolorido."
    "So you woke up in the cramped space of the closet, with an aching body."

# game/script.rpy:2651
translate english supervivencia_11_973ee163:

    # "Lo primero que haces al despertar es asomarte por la ventana, y no sabes si reír o llorar cuando ves la misma patrulla de ayer en el mismo lugar."
    "The first thing you did upon waking was look out the window, and you didn't know whether to laugh or cry when you saw the same patrol car from yesterday in the same spot."

# game/script.rpy:2652
translate english supervivencia_11_6d297368:

    # "¿En serio Jeff se coló a tu departamento tan fácilmente?"
    "Did Jeff really sneak into your apartment so easily?"

# game/script.rpy:2653
translate english supervivencia_11_c2789734:

    # "Revisas las cerraduras, y no están rotas."
    "You checked the locks, and they weren't broken."

# game/script.rpy:2654
translate english supervivencia_11_6a4b7a71:

    # "Eso quiere decir que Jeff, además de burlar a los policías, no forzó la entrada."
    "That meant Jeff, besides bypassing the police, didn't force his way in."

# game/script.rpy:2655
translate english supervivencia_11_67c38527:

    # "¿Qué mierda?"
    "What the fuck?"

# game/script.rpy:2656
translate english supervivencia_11_c7c92968:

    # "Todo se estaba volviendo demasiado conveniente, sobre todo para una historia de suspenso."
    "Everything was becoming too convenient, especially for a suspense story."

# game/script.rpy:2657
translate english supervivencia_11_4218019b:

    # "Antes, sabías con seguridad que Jeff se trataba de un humano, pero ahora… estabas empezando a considerar otras opciones."
    "Before, you were sure Jeff was a human, but now... you were starting to consider other options."

# game/script.rpy:2658
translate english supervivencia_11_5d0a5525:

    # "Aseguras nuevamente la puerta de entrada, y consideras comprar un nuevo pestillo."
    "You secured the front door again, and considered buying a new deadbolt."

# game/script.rpy:2659
translate english supervivencia_11_f7478a4d:

    # "Pero primero lo primero, tienes que desayunar."
    "But first things first, you had to eat breakfast."

# game/script.rpy:2662
translate english supervivencia_11_a8299a43:

    # "Abres tu nevera, y la decepción te invade al ver que está prácticamente vacía."
    "You opened your fridge, and disappointment flooded you when you saw it was practically empty."

# game/script.rpy:2663
translate english supervivencia_11_11222b78:

    # "Hay dos tomates arrugados, una caja de jugo que tras agitarla ves que está media vacía y la mitad de un limón."
    "There were two wrinkled tomatoes, a half-empty juice carton you checked by shaking it, and half a lemon."

# game/script.rpy:2664
translate english supervivencia_11_5834a163:

    # "Recuerdas que desechaste lo que estaba en mal estado el día anterior, pero también que no fuiste de compras."
    "You remembered throwing out the spoiled food the day before, but you also hadn't gone grocery shopping."

# game/script.rpy:2667
translate english supervivencia_11_c57b6a18:

    # "Te preparas para salir, tomas tu billetera y te diriges al recibidor de tu departamento, jugando con tus llaves."
    "You prepared to leave, grabbed your wallet, and headed to your apartment's entryway, fiddling with your keys."

# game/script.rpy:2668
translate english supervivencia_11_c928dbb5:

    # "Miras por última vez el interior de tu departamento y te retiras, colocando llave a todas las cerraduras."
    "You took one last look inside your apartment and left, locking all the doors."

# game/script.rpy:2669
translate english supervivencia_11_68216be4:

    # "Un momento de duda te detiene, y revisas la ampolleta que está en la esquina superior de tu puerta."
    "A moment of doubt stopped you, and you checked the light bulb in the upper corner of your door."

# game/script.rpy:2670
translate english supervivencia_11_0dbfbecb:

    # "Excelente, ahí estaba la habilidad superhumana de Jeff para meterse en tu departamento, se llamaba llaves de repuesto."
    "Excellent, Jeff's superhuman ability to get into your apartment was called spare keys."

# game/script.rpy:2671
translate english supervivencia_11_64f32b62:

    # "No puedes creer que realmente te hayas olvidado de eso."
    "You couldn't believe you had actually forgotten that."

# game/script.rpy:2677
translate english supervivencia_11_77b85f45:

    # "El minimarket que visitas es uno que está a dos calles de tu departamento, al lado contrario donde se encuentra la tienda de películas."
    "The minimarket you visited was two blocks from your apartment, on the opposite side from the video store."

# game/script.rpy:2678
translate english supervivencia_11_53b9be7a:

    # "No tiene tantas cosas, pero sirve para momentos desesperados como el de ahora."
    "It didn't have many things, but it was enough for desperate times like now."

# game/script.rpy:2679
translate english supervivencia_11_52d85d04:

    # "Buscas los esenciales entre los pasillos y las neveras."
    "You looked for essentials among the aisles and refrigerators."

# game/script.rpy:2692
translate english character_6_05eb9169:

    # "Yendo a la caja, sientes un movimiento por el rabillo del ojo derecho. Un movimiento de color blanco."
    "Walking to the checkout, you felt a movement in the corner of your right eye. A white movement."

# game/script.rpy:2695
translate english character_6_3bf44f40:

    # "Tu corazón se agita, pero la presencia de muchas personas te regresa algo de confianza, por lo que disimuladamente sigues el movimiento."
    "Your heart raced, but the presence of many people restored some confidence, so you subtly followed the movement."

# game/script.rpy:2696
translate english character_6_7213ea58:

    # "Te acercas a un estante de bocadillos."
    "You approached a snack shelf."

# game/script.rpy:2700
translate english character_6_e4bf0893:

    # "Entre las etiquetas de los precios, bolsas coloridas y envases brillantes, puedes percibir un destello blanco, oculto del otro lado de la estantería."
    "Among the price tags, colorful bags, and shiny containers, you could perceive a white glint, hidden on the other side of the shelf."

# game/script.rpy:2701
translate english character_6_687a84d7:

    # "Te inclinas en la esquina, asomándote lentamente por el costado."
    "You leaned around the corner, slowly peeking out."

# game/script.rpy:2702
translate english character_6_96f69104:

    # "Puedes percibir la postura de alguien agachado, usando ropa blanca."
    "You could make out the posture of someone crouched, wearing white clothes."

# game/script.rpy:2704
translate english character_6_aecd6a06:

    # Stranger "¡[povname]!"
    Stranger "[povname]!"

# game/script.rpy:2708
translate english character_6_31dcdf50:

    # "El llamado de tu nombre te sobresalta, lo que te hace caer tus compras."
    "The call of your name startled you, making you drop your groceries."

# game/script.rpy:2712
translate english character_6_f089efd8:

    # DR "Oh, lo siento mucho."
    DR "Oh, I'm so sorry."

# game/script.rpy:2714
translate english character_6_815988b2:

    # "Ves con asombro al Dr. Salazar apoyándose en una rodilla, empezando a recoger tus compras."
    "You watched in amazement as Dr. Salazar knelt down, beginning to pick up your groceries."

# game/script.rpy:2715
translate english character_6_97213182:

    # pov "¿Dr. Salazar?"
    pov "Dr. Salazar?"

# game/script.rpy:2717
translate english character_6_5fc03f89:

    # DR "Puedes llamarme Paul."
    DR "You can call me Paul."

# game/script.rpy:2718
translate english character_6_e47b23e0:

    # pov "… Ok, Paul, ¿Qué haces aquí?"
    pov "... Okay, Paul, what are you doing here?"

# game/script.rpy:2719
translate english character_6_1f9a1a27:

    # "No sabes si es que el acoso de Jeff te estaba empezando a afectar más de lo que te gustaría, pero te convenciste de que sólo estabas tomando precauciones."
    "You didn't know if Jeff's stalking was starting to affect you more than you'd like, but you convinced yourself you were just taking precautions."

# game/script.rpy:2720
translate english character_6_62c93f76:

    # "No necesitabas otro acosador en la lista."
    "You didn't need another stalker on your list."

# game/script.rpy:2721
translate english character_6_cd144de8:

    # DR "Terminé mi turno hace unas horas. Me gusta venir a un café que está por aquí y no pude evitar verte por la ventana, ¿Espero no te moleste?"
    DR "My shift ended a few hours ago. I like coming to a coffee shop nearby, and I couldn't help but see you through the window. I hope it doesn't bother you?"

# game/script.rpy:2722
translate english character_6_6d8913c8:

    # "Salazar se ríe levemente, incómodo, como si quisiera sacarse de encima una mala imagen."
    "Salazar chuckled softly, awkwardly, as if trying to shed a bad image."

# game/script.rpy:2723
translate english character_6_b33a44f1:

    # pov "Oh, ok."
    pov "Oh, okay."

# game/script.rpy:2725
translate english character_6_4dc51fa0:

    # "Te agachas también, terminando de recoger tus cosas."
    "You knelt too, finishing picking up your things."

# game/script.rpy:2727
translate english character_6_f40d0710:

    # DR "¿Cómo te sientes?, ¿Cómo está tu… eh, ojo?"
    DR "How are you feeling? How's your... uh, eye?"

# game/script.rpy:2728
translate english character_6_0afd9c3e:

    # "Te llevas instintivamente una mano a tu párpado izquierdo, cubierto por el parche."
    "You instinctively brought a hand to your left eyelid, covered by the patch."

# game/script.rpy:2729
translate english character_6_303da67a:

    # pov "Ya no duele."
    pov "It doesn't hurt anymore."

# game/script.rpy:2731
translate english character_6_255f15a7:

    # DR "Eso es bueno. ¿Vas a querer una prótesis?"
    DR "That's good. Are you going to want a prosthesis?"

# game/script.rpy:2732
translate english character_6_e055bbf8:

    # pov "Depende, ¿Puedo escoger el color?"
    pov "It depends, can I choose the color?"

# game/script.rpy:2733
translate english character_6_469bddb4:

    # DR "Por supuesto, puedes escoger el color y tamaño de la iris, de la pupila e incluso de la esclerótica."
    DR "Of course, you can choose the color and size of the iris, the pupil, and even the sclera."

# game/script.rpy:2734
translate english character_6_32d1fbee:

    # pov "Eso es genial, lo pensaré."
    pov "That's great, I'll think about it."

# game/script.rpy:2735
translate english character_6_af08cda3:

    # "El Dr. Salazar asiente con una leve sonrisa."
    "Dr. Salazar nodded with a faint smile."

# game/script.rpy:2736
translate english character_6_267ba007:

    # DR "¿Te ayudo con tus compras?"
    DR "Can I help you with your shopping?
"

# game/script.rpy:2737
translate english character_6_cd2823d8:

    # pov "Gracias, eres muy amable."
    pov "Thanks, you're very kind."

# game/script.rpy:2738
translate english character_6_0cde97e4:

    # DR "Lo que sea por mi paciente."
    DR "Anything for my patient."

# game/script.rpy:2740
translate english character_6_7ee2abaf:

    # "Salazar te ayuda a llevar tus cosas a la caja, y tú pagas."
    "Salazar helped you carry your things to the checkout, and you paid."

# game/script.rpy:2742
translate english character_6_533ade6e:

    # "Ustedes salen de la tienda, y se quedan un momento en la acera. Llevas una de las bolsas en tu mano, mientras él lleva la otra."
    "You left the store and stood on the sidewalk for a moment. You held one of the bags in your hand, while he carried the other."

# game/script.rpy:2745
translate english character_6_7dd1623a:

    # DR "¿Haces las compras?"
    DR "Are you doing your groceries?"

# game/script.rpy:2746
translate english character_6_622c7d22:

    # pov "Es para mi desayuno."
    pov "It's for my breakfast."

# game/script.rpy:2748
translate english character_6_73ee964d:

    # "Salazar te mira con ojos sorprendidos, para después negar con la cabeza."
    "Salazar looked at you with surprised eyes, then shook his head."

# game/script.rpy:2749
translate english character_6_f683b72e:

    # DR "Ya es mediodía, [povname]."
    DR "It's already noon, [povname]."

# game/script.rpy:2750
translate english character_6_f176499f:

    # "Te encoges ante el regaño. El te lo diga un doctor te hace sentir más culpable."
    "You flinched at the scolding. Hearing it from a doctor made you feel more guilty."

# game/script.rpy:2751
translate english character_6_998e4620:

    # pov "Lo sé… Hubo circunstancias, pero ahora estoy en eso."
    pov "I know... there were circumstances, but now I'm on it."

# game/script.rpy:2752
translate english character_6_a96da2e2:

    # "Él te mira en silencio unos segundos, para después carraspear contra su puño."
    "He looked at you in silence for a few seconds, then cleared his throat against his fist."

# game/script.rpy:2754
translate english character_6_bb37a5b2:

    # DR "Puedo… Invitarte a desayunar."
    DR "I could... invite you to breakfast."

# game/script.rpy:2755
translate english character_6_8ee09a5d:

    # pov "¿Cómo dices?"
    pov "What?"

# game/script.rpy:2756
translate english character_6_bc99059a:

    # DR "Ehem, dije que quisiera invitarte a desayunar."
    DR "Ahem, I said I wanted to invite you to breakfast."

# game/script.rpy:2757
translate english character_6_8993a8bd:

    # "Ves la postura nerviosa de Salazar y el evidente color en sus mejillas."
    "You saw Salazar's nervous posture and the obvious blush on his cheeks."

# game/script.rpy:2758
translate english character_6_4358d10c:

    # "Ladeas la cabeza, con curiosidad."
    "You tilted your head, curious."

# game/script.rpy:2759
translate english character_6_36d56e5e:

    # pov "¿Cómo en una cita?"
    pov "Like a date?"

# game/script.rpy:2761
translate english character_6_826fda20:

    # "Salazar tose contra su mano, pero se recupera rápidamente."
    "Salazar coughed into his hand, but quickly recovered."

# game/script.rpy:2762
translate english character_6_4953c45c:

    # DR "No quisiera que me malinterpretaras, pero… "
    DR "I wouldn't want you to misunderstand, but..."

# game/script.rpy:2764
translate english character_6_0a2071ff:

    # DR "Sí, supongo que sí, te estoy invitando a una cita."
    DR "Yes, I guess so, I'm inviting you on a date."

# game/script.rpy:2765
translate english character_6_68b49a5f:

    # "Te quedas un momento en silencio, considerando la propuesta."
    "You stood in silence for a moment, considering the proposal."

# game/script.rpy:2766
translate english character_6_020aca84:

    # "Siempre tienes la opción de coquetear con las personas que te encuentres, pero eso no quiere decir que vayas en serio."
    "You always had the option to flirt with people you met, but that didn't mean you were serious."

# game/script.rpy:2767
translate english character_6_e96ca752:

    # "Es divertido ver la reacción de los demás con tus provocaciones, y quizás había un poco de esperanza en ti de que eso te llevara a algún lado."
    "It was fun to see other people's reactions to your teasing, and maybe there was a little hope in you that it would lead somewhere."

# game/script.rpy:2768
translate english character_6_ac5bd01b:

    # "Y ahora, tienes la opción, de ir más allá."
    "And now, you had the option, to go further."

# game/script.rpy:2772
translate english character_6_e88686cd:

    # pov "Me encantaría."
    pov "I'd love to."

# game/script.rpy:2773
translate english character_6_ca90f25e:

    # "La expresión de Salazar se iluminó ante tu respuesta."
    "Salazar's expression brightened at your response."

# game/script.rpy:2774
translate english character_6_577d3f71:

    # "Con timidez, él alzó su mano libre hacia ti."
    "Tentatively, he raised his free hand towards you."

# game/script.rpy:2776
translate english character_6_4a559a8f:

    # "Tomas la mano de él con la tuya, entrelazando tus dedos con los de él."
    "You took his hand in yours, intertwining your fingers with his."

# game/script.rpy:2778
translate english character_6_dfbd0bec:

    # "Caminan en silencio por la calle, y dejas que él te guíe, ya que era él el que te estaba invitando."
    "You walked in silence down the street, letting him guide you, since he was the one inviting you."

# game/script.rpy:2780
translate english character_6_9b30cebb:

    # "De repente, ante ustedes, un niño se cae sobre el asfalto y pega un grito desgarrador."
    "Suddenly, in front of you, a child fell on the asphalt and let out a heartbreaking scream."

# game/script.rpy:2781
translate english character_6_0d7134b5:

    # "Los padres se acercan con rapidez, levantándolo sobre el suelo y dejando ver que su rodilla tenía una herida sangrante."
    "The parents quickly approached, picking him up off the ground and revealing that his knee had a bleeding wound."

# game/script.rpy:2784
translate english character_6_8ff1257a:

    # DR "Déjenme ver, soy doctor."
    DR "Let me see, I'm a doctor."

# game/script.rpy:2785
translate english character_6_43dd9291:

    # "Observas que Salazar se acerca con rapidez y seriedad, sacando de uno de sus bolsillos desinfectante para manos."
    "You watched Salazar approach quickly and seriously, pulling hand sanitizer from one of his pockets."

# game/script.rpy:2786
translate english character_6_02ee6558:

    # "Sonríes levemente ante la atención de Salazar."
    "You smiled faintly at Salazar's attentiveness."

# game/script.rpy:2787
translate english character_6_03862fdb:

    # "Tal vez… Necesitabas un hombre atento después de todo, que respetara la vida."
    "Perhaps... you needed an attentive man after all, one who respected life."

# game/script.rpy:2788
translate english character_6_c67f906d:

    # "Incomparable con…"
    "Incomparable with..."

# game/script.rpy:2789
translate english character_6_e73d7375:

    # "Bueno, ya no tenías por qué pensar en él."
    "Well, you didn't have to think about him anymore."

# game/script.rpy:2797
translate english character_6_7082cb48:

    # "De repente, un gran peso te derrumba sobre el suelo, y te inmoviliza."
    "Suddenly, a great weight knocked you to the ground, immobilizing you."

# game/script.rpy:2798
translate english character_6_aa32fcfa:

    # "Sientes que algo húmedo cae sobre tus mejillas, es tibio."
    "You felt something wet fall on your cheeks; it was warm."

# game/script.rpy:2803
translate english character_6_0f74d63c:

    # "Miras arriba, y presencias una expresión que no esperabas ver nunca."
    "You looked up, and witnessed an expression you never expected to see."

# game/script.rpy:2804
translate english character_6_8fdf740a:

    # "Jeff lloraba inconsolablemente sobre ti."
    "Jeff was crying inconsolably over you."

# game/script.rpy:2805
translate english character_6_0b612e01:

    # J "¿Cómo pudiste [povname]...?"
    J "How could you, [povname]...?"

# game/script.rpy:2806
translate english character_6_3729e321:

    # J "¿No soy suficiente para ti…?"
    J "Am I not enough for you...?"

# game/script.rpy:2807
translate english character_6_218a5cd7:

    # "Sientes que tu voz se quiebra ante el desconcierto."
    "You felt your voice crack with bewilderment."

# game/script.rpy:2808
translate english character_6_caf5688d:

    # "Por suerte, aparentemente las personas presenciaron todo, lo que indicaba que todo acabaría."
    "Fortunately, it seemed everyone had witnessed everything, which meant it would all be over."

# game/script.rpy:2809
translate english character_6_b8ac4475:

    # "Jeff sería atrapado, y tú podrías volver a tu vida."
    "Jeff would be caught, and you could go back to your life."

# game/script.rpy:2810
translate english character_6_ebbe04c7:

    # J "¡¿No soy suficiente para ti?!"
    J "Am I not enough for you?!"

# game/script.rpy:2814
translate english character_6_c236e479:

    # "El estruendoso alarido de Jeff te saca de tus pensamientos, y es tarde cuando ves que él alza un cuchillo, y lo entierra en tu pecho."
    "Jeff's thunderous scream jolted you from your thoughts, and it was too late when you saw him raise a knife and plunge it into your chest."

# game/script.rpy:2816
translate english character_6_8c9097ed:

    # J "¡[povname]! ¡[povname]!"
    J "[povname]! ![povname]!"

# game/script.rpy:2818
translate english character_6_a814095e:

    # "Con cada pronunciación de tu nombre, te ganabas una nueva a apuñalada, que agitaba tu cuerpo y derramaba más sangre."
    "With each pronunciation of your name, you earned another stab, which made your body convulse and shed more blood."

# game/script.rpy:2820
translate english character_6_ff7e2fda:

    # "Y la expresión de él no cambió, estaba llena de dolor."
    "And his expression didn't change; it was full of pain."

# game/script.rpy:2825
translate english character_6_90d48e96:

    # "Con tu visión borrosa, alcanzas a ver que Jeff es sujetado e inmovilizado al suelo, mientras sigue gritando."
    "With your blurred vision, you managed to see Jeff being held and immobilized on the ground, still screaming."

# game/script.rpy:2826
translate english character_6_64bca0e6:

    # "Tu párpado pesa, y lo cierras."
    "Your eyelid felt heavy, and you closed it."

# game/script.rpy:2828
translate english character_6_2f61cc9b:

    # "Suspiras por última vez, con el alivio de que Jeff pudo ser atrapado."
    "You sighed one last time, with the relief that Jeff had been caught."

# game/script.rpy:2829
translate english character_6_927655ce:

    # "A costa tuya, claro."
    "At your expense, of course."

# game/script.rpy:2830
translate english character_6_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2831
translate english character_6_4d8c8a5b:

    # "Sientes que tus mejillas son sujetadas por manos mojadas y pegajosas."
    "You felt your cheeks being held by wet, sticky hands."

# game/script.rpy:2833
translate english character_6_880e2969:

    # "Escuchas la voz desgarradora de Salazar, quien te sujeta desesperado."
    "You heard Salazar's heartbroken voice, holding you desperately."

# game/script.rpy:2834
translate english character_6_eb222b0a:

    # DR "¡Quédate conmigo!, ¡T-te ayudaré!"
    DR "Stay with me! I-I'll help you!"

# game/script.rpy:2835
translate english character_6_56c83cbd_1:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2836
translate english character_6_71250745:

    # "Sonríes levemente, sintiendo la calidez del abrazo de Salazar."
    "You smiled faintly, feeling the warmth of Salazar's embrace."

# game/script.rpy:2837
translate english character_6_cab4b5cc:

    # "Eso era lo que querías, ¿No?"
    "That's what you wanted, right?"

# game/script.rpy:2840
translate english character_6_e899acaa:

    # "{b}Final IV: Ninguno De Ustedes Ganó{/b}"
    "{b}Ending IV: None Of You Won{/b}"

# game/script.rpy:2847
translate english historia_continua_3_6e478ad6:

    # pov "Lo siento, pero no puedo."
    pov "I'm sorry, but I can't."

# game/script.rpy:2849
translate english historia_continua_3_4ff694b6:

    # "La decepción se refleja en la expresión de Salazar."
    "Disappointment reflected in Salazar's expression."

# game/script.rpy:2850
translate english historia_continua_3_63fa2dad:

    # DR "O-oh, ¿Tienes a alguien más…?"
    DR "O-oh, do you have someone else...?"

# game/script.rpy:2851
translate english historia_continua_3_e3b8f462:

    # pov "No es eso. Hoy tengo cosas que hacer, pero otro día podríamos salir, ¿Si?"
    pov "It's not that. I have things to do today, but we could go out another day, okay?"

# game/script.rpy:2852
translate english historia_continua_3_cbebe1b6:

    # "La mueca de Salazar no parece cambiar ante tus palabras, pero con tu silencio expectante, Salazar sonríe levemente."
    "Salazar's grimace didn't seem to change at your words, but with your expectant silence, Salazar smiled faintly."

# game/script.rpy:2854
translate english historia_continua_3_c53042ff:

    # DR "Entiendo, otro día será."
    DR "I understand, another day it is."

# game/script.rpy:2855
translate english historia_continua_3_b7451d16:

    # DR "Al menos déjame acompañarte a dejar tus compras."
    DR "At least let me walk you back with your groceries."

# game/script.rpy:2856
translate english historia_continua_3_47f77fee:

    # "Reflexionas sus palabras por un momento."
    "You pondered his words for a moment."

# game/script.rpy:2857
translate english historia_continua_3_880f22d8:

    # "Definitivamente, no estaría demás que te acompañe."
    "Definitely, it wouldn't hurt to have him accompany you."

# game/script.rpy:2858
translate english historia_continua_3_05f76a79:

    # "Se sentiría seguro, de hecho."
    "It would feel safe, in fact."

# game/script.rpy:2859
translate english historia_continua_3_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:2860
translate english historia_continua_3_d96ad88a:

    # "Guías el camino, y ustedes caminan en silencio durante todo el trayecto."
    "You led the way, and you walked in silence all the way."

# game/script.rpy:2862
translate english historia_continua_3_8ab55e4e:

    # "Ustedes llegan a la entrada de tu edificio, y al ver que Salazar no tenía intenciones de dejarte ahí, seguiste guiando el camino hasta detenerte en la puerta de tu departamento."
    "You arrived at the entrance of your building, and seeing that Salazar had no intention of leaving you there, you continued guiding him until you stopped at your apartment door."

# game/script.rpy:2863
translate english historia_continua_3_cdcf2858:

    # pov "Aquí es."
    pov "Here we are."

# game/script.rpy:2867
translate english historia_continua_3_8ed0c5b2:

    # "Salazar se queda mirando la puerta por unos segundos, para después sonreír levemente, mientras extendía la bolsa que él cargaba hacia ti."
    "Salazar remained looking at the door for a few seconds, then smiled faintly, as he extended the bag he was carrying towards you."

# game/script.rpy:2869
translate english historia_continua_3_557c98d0:

    # DR "Fue un placer verte, [povname]."
    DR "It was a pleasure seeing you, [povname]."

# game/script.rpy:2870
translate english historia_continua_3_8285c797:

    # pov "Igualmente, Dr- digo, Paul."
    pov "Likewise, Dr.—I mean, Paul."

# game/script.rpy:2871
translate english historia_continua_3_3bdd1c5d:

    # "La sonrisa de Salazar se extiende, recuperando un poco de la energía que había perdido desde tu rechazo."
    "Salazar's smile widened, regaining some of the energy he had lost from your rejection."

# game/script.rpy:2872
translate english historia_continua_3_9b6f9b74:

    # DR "Puedes llamarme cuando quieras."
    DR "You can call me whenever you want."

# game/script.rpy:2873
translate english historia_continua_3_17f813e3:

    # pov "Lo tengo en cuenta."
    pov "I'll keep that in mind."

# game/script.rpy:2874
translate english historia_continua_3_8fb45874:

    # "Salazar se dirige a la salida, no sin antes voltearse por un momento hacia ti para despedirse con la mano."
    "Salazar headed for the exit, not without turning back for a moment to wave goodbye to you."

# game/script.rpy:2876
translate english historia_continua_3_63d3a8c2:

    # "Tu le correspondiste la despedida, y te quedaste en el pasillo hasta que ya no lo viste."
    "You returned his wave, and stayed in the hallway until you no longer saw him."

# game/script.rpy:2877
translate english historia_continua_3_66eed3d3:

    # "Suspiras levemente, volviendo a la realidad de tu situación."
    "You sighed softly, returning to the reality of your situation."

# game/script.rpy:2878
translate english historia_continua_3_b4ec8c82:

    # "Cierto, debes tener cuidado."
    "Right, you need to be careful."

# game/script.rpy:2880
translate english historia_continua_3_99ed2004:

    # "Desbloqueas cada cerradura y entras a tu departamento, volviendo a cerrar con llave. También te cercioras de ocultar las llaves de repuesto dentro de tu departamento."
    "You unlocked every lock and entered your apartment, locking it again. You also made sure to hide the spare keys inside your apartment."

# game/script.rpy:2883
translate english historia_continua_3_580ae45f:

    # "Dejas tus compras en la cocina y guardas todo donde corresponde y te quedas con lo que harás el desayuno."
    "You left your groceries in the kitchen and put everything away, then thought about what you would have for breakfast."

# game/script.rpy:2884
translate english historia_continua_3_b4c12402:

    # "Enciendes la cafetera, con el nuevo café que compraste, y pones dos rebanadas de pan en la tostadora."
    "You started the coffee maker, with the new coffee you bought, and put two slices of bread in the toaster."

# game/script.rpy:2885
translate english historia_continua_3_6f628d8c:

    # "No te habías dado cuenta lo tarde que era cuando Salazar te lo señaló."
    "You hadn't realized how late it was when Salazar pointed it out to you."

# game/script.rpy:2886
translate english historia_continua_3_f872d74f:

    # "Debiste tener mucho cansancio como para haber dormido casi 10 horas después de que Jeff entrara a tu departamento en la madrugada."
    "You must have been very tired to have slept almost 10 hours after Jeff entered your apartment in the early morning."

# game/script.rpy:2887
translate english historia_continua_3_a51cd2ee:

    # "Te asomas en la ventana nuevamente, y la patrulla sigue ahí. No sabes si es la misma o es otra diferente, pero al menos tienes protección, ¿No?"
    "You peered out the window again, and the patrol car was still there. You didn't know if it was the same one or a different one, but at least you had protection, right?"

# game/script.rpy:2888
translate english historia_continua_3_f3aae7ee:

    # "Que chiste."
    "What a joke."

# game/script.rpy:2889
translate english historia_continua_3_7dfce5f3:

    # "Con tu café listo y tus tostadas, tomas asiento en la pequeña mesa que tú llamas comedor."
    "With your coffee ready and your toast, you sat at the small table you called your dining table."

# game/script.rpy:2892
translate english historia_continua_3_b8ff8107:

    # "Estás a media mordida, cuando escuchas un toque en la puerta."
    "You were halfway through a bite when you heard a knock at the door."

# game/script.rpy:2893
translate english historia_continua_3_315084b7:

    # "Miras con sigilo la puerta, en silencio."
    "You quietly looked at the door, in silence."

# game/script.rpy:2894
translate english historia_continua_3_e8adb890:

    # C "¡[povname]!, ¡Soy yo!"
    C "[povname]! It's me!"

# game/script.rpy:2896
translate english historia_continua_3_4b0806eb:

    # "Te relajas cuando te das cuenta de que se trata de Cindy."
    "You relaxed when you realized it was Cindy."

# game/script.rpy:2897
translate english historia_continua_3_0692bb80:

    # "Vaya, estás siendo bastante popular hoy."
    "Wow, you're quite popular today."

# game/script.rpy:2903
translate english historia_continua_3_4be66cfe:

    # "Vas y abres la puerta, dejando espacio para que ella entre. Cindy pasa con rapidez."
    "You went and opened the door, making space for her to enter. Cindy quickly came in."

# game/script.rpy:2904
translate english historia_continua_3_fc361df2:

    # pov "¿Qué te trae por aquí?"
    pov "What brings you here?"

# game/script.rpy:2905
translate english historia_continua_3_8d3ebc3a:

    # "No era sorpresa que ella supiera donde vivías, ya que no es la primera vez que viene."
    "It wasn't a surprise that she knew where you lived, as it wasn't the first time she had visited."

# game/script.rpy:2906
translate english historia_continua_3_af62866e:

    # "Al ser ella y su padre, tu jefe, las únicas dos personas que conoces en la ciudad, cuando sucedía un imprevisto como un cheque rebotado o algún percance en la tienda, te iban a avisar personalmente a tu departamento."
    "Since she and her father, your boss, were the only two people you knew in the city, if something unexpected happened, like a bounced check or some mishap at the store, they would personally notify you at your apartment."

# game/script.rpy:2907
translate english historia_continua_3_4d61f914:

    # C "¿Han atrapado al tipo?"
    C "Did they catch the guy?"

# game/script.rpy:2908
translate english historia_continua_3_c191c049:

    # "Te encoges de hombros."
    "You shrugged."

# game/script.rpy:2909
translate english historia_continua_3_beae822b:

    # pov "Nop."
    pov "Nope."

# game/script.rpy:2911
translate english historia_continua_3_bd074926:

    # C "Tienes que tomarte en serio esto, aunque hayan pedido protección para ti, no es seguro confiar 100 por ciento en eso."
    C "You need to take this seriously, even if they've arranged protection for you, it's not 100 percent safe to rely on that."

# game/script.rpy:2912
translate english historia_continua_3_9f749202:

    # pov "Así que viste la patrulla de afuera."
    pov "So you saw the patrol car outside."

# game/script.rpy:2913
translate english historia_continua_3_236f4eec:

    # "Cindy se lleva una mano a la frente."
    "Cindy brought a hand to her forehead."

# game/script.rpy:2914
translate english historia_continua_3_29bfff94:

    # C "Si... también fueron muchos periodistas a la tienda. Se filtró que trabajas ahí, así que tuve que cerrar temporalmente."
    C "Yeah... there were also many journalists at the store. It leaked that you work there, so I had to close temporarily."

# game/script.rpy:2915
translate english historia_continua_3_df0e7779:

    # pov "Oh, lo siento…"
    pov "Oh, I'm sorry..."

# game/script.rpy:2918
translate english historia_continua_3_46966592:

    # "Cindy suspira, tomando asiento en el sofá."
    "Cindy sighed, taking a seat on the sofa."

# game/script.rpy:2919
translate english historia_continua_3_aee14885:

    # C "Nada de esto es tu culpa, [povname]. Debí haberte acompañado ese día."
    C "None of this is your fault, [povname]. I should have accompanied you that day."

# game/script.rpy:2921
translate english historia_continua_3_ba993bdc:

    # "Tu la acompañas, tomando asiento junto a ella."
    "You joined her, sitting next to her."

# game/script.rpy:2922
translate english historia_continua_3_185493bf:

    # pov "No digas eso. No tenías cómo saberlo."
    pov "Don't say that. You had no way of knowing."

# game/script.rpy:2923
translate english historia_continua_3_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:2924
translate english historia_continua_3_a0c93c73:

    # "Cindy carraspea, cambiando de tema."
    "Cindy cleared her throat, changing the subject."

# game/script.rpy:2925
translate english historia_continua_3_8ed23b80:

    # C "Así que… ¿Sabes detalles de tu caso?"
    C "So... do you know details about your case?"

# game/script.rpy:2926
translate english historia_continua_3_59363691:

    # pov "Oh, bueno, parece que saben quién es."
    pov "Oh, well, it seems they know who he is."

# game/script.rpy:2927
translate english historia_continua_3_ae6301f1:

    # "El interés de Cindy fue picado."
    "Cindy's interest was piqued."

# game/script.rpy:2928
translate english historia_continua_3_f098d53b:

    # C "¿En serio, quién?"
    C "Really?, Who?"

# game/script.rpy:2929
translate english historia_continua_3_08c59881:

    # pov "Un tipo que tiene un body count de 27… De víctimas me refiero."
    pov "A guy with a body count of 27... I mean victims."

# game/script.rpy:2930
translate english historia_continua_3_e5231df3:

    # "Cindy te miró expectante, ignorando tu broma. Parece que ella no ha visto las noticias."
    "Cindy looked at you expectantly, ignoring your joke. It seemed she hadn't seen the news."

# game/script.rpy:2931
translate english historia_continua_3_150467e1:

    # "Claro, en qué momento si tenía que lidiar con ahuyentar a los periodistas invasivos."
    "Of course, when would she have time, having to deal with chasing away invasive journalists?"

# game/script.rpy:2932
translate english historia_continua_3_36d0d8fc:

    # pov "Parece que soy la primera víctima que dejó con vida."
    pov "It seems I'm the first victim he left alive."

# game/script.rpy:2933
translate english historia_continua_3_7f76495a_1:

    # C "…"
    C "..."

# game/script.rpy:2935
translate english historia_continua_3_7c8042a4:

    # "Cindy deja escapar un quejido."
    "Cindy let out a gasp."

# game/script.rpy:2936
translate english historia_continua_3_94273819:

    # C "Lo que faltaba, un asesino serial se fijó en ti."
    C "Just what we needed, a serial killer fixated on you."

# game/script.rpy:2937
translate english historia_continua_3_0d380f65:

    # "Ella no está equivocada."
    "She wasn't wrong."

# game/script.rpy:2938
translate english historia_continua_3_be8b6c00:

    # pov "No dijeron que fuera un asesino serial."
    pov "They didn't say he was a serial killer."

# game/script.rpy:2939
translate english historia_continua_3_0a0b6675:

    # C "Si asesinó a más de tres personas y lleva haciéndolo desde hace años, cae en la categoría de asesino serial."
    C "If he's murdered more than three people and has been doing it for years, he falls into the category of serial killer."

# game/script.rpy:2940
translate english historia_continua_3_9fba3a17:

    # pov "¿... De acuerdo?"
    pov "...Okay?"

# game/script.rpy:2941
#translate english historia_continua_3_9250641c:

    # C "¿Viste si tenía sentía placer al atacarte?"
    #C "Did you see if he felt pleasure attacking you?"

# game/script.rpy:2942
translate english historia_continua_3_7b9f7faa:

    # pov "Oh, si, definitivamente."
    pov "Oh, yes, definitely."

# game/script.rpy:2943
translate english historia_continua_3_3df569b1:

    # "Recordabas cómo él insistía que admitieras que tenías miedo, incluso querer saber los detalles."
    "You remembered how he insisted you admit you were afraid, even wanting to know the details."

# game/script.rpy:2944
translate english historia_continua_3_c19dc43b:

    # "Ups, ¿quizás debiste guardarte eso para ti?"
    "Oops, maybe you should have kept that to yourself?"

# game/script.rpy:2945
translate english historia_continua_3_57673a71:

    # "Cindy se llevó unos dedos a la barbilla, pensativa mientras murmuraba para sí misma."
    "Cindy put her fingers to her chin, thoughtfully murmuring to herself."

# game/script.rpy:2946
translate english historia_continua_3_9cb9b2b7:

    # C "Entonces caería en la categoría dos…"
    C "Then he would fall into category two..."

# game/script.rpy:2947
translate english historia_continua_3_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2948
translate english historia_continua_3_685f2ad0:

    # pov "¿Cindy?"
    pov "Cindy?"

# game/script.rpy:2950
translate english historia_continua_3_77b5f57c:

    # C "¿Si?"
    C "Yeah?"

# game/script.rpy:2951
translate english historia_continua_3_9088b2fd:

    # pov "¿Puedo preguntarte algo, sin que te enojes?"
    pov "Can I ask you something, without you getting angry?"

# game/script.rpy:2952
translate english historia_continua_3_26a803bc:

    # C "..."
    C "..."

# game/script.rpy:2953
translate english historia_continua_3_a1d004ff:

    # C "¿De acuerdo?"
    C "Okay?"

# game/script.rpy:2954
translate english historia_continua_3_674cadde:

    # pov "Tu… ¿cómo sabes tanto término policial?"
    pov "How... how do you know so many police terms?"

# game/script.rpy:2956
translate english historia_continua_3_7f76495a_2:

    # C "…"
    C "..."

# game/script.rpy:2957
translate english historia_continua_3_e427fb3d:

    # "Cindy se quedó congelada, mirándote con sorpresa."
    "Cindy froze, looking at you in surprise."

# game/script.rpy:2958
translate english historia_continua_3_edaefa11:

    # C "… Yo…"
    C "I..."

# game/script.rpy:2959
translate english historia_continua_3_17cdfe7f:

    # "Entonces, ella suspiró pesadamente."
    "Then she sighed heavily."

# game/script.rpy:2960
translate english historia_continua_3_38b8fcfd:

    # C "Yo… nunca quise ser una clerk en la tienda de mi padre."
    C "I... never wanted to be a clerk in my dad's store."

# game/script.rpy:2961
translate english historia_continua_3_39d30cc7:

    # pov "Si, nadie quiere serlo."
    pov "Yeah, nobody wants to be."

# game/script.rpy:2963
translate english historia_continua_3_db5c18cc:

    # "Cindy te dedicó una mirada reprochadora ante tu comentario sarcástico, pero continuó."
    "Cindy gave you a reproving look at your sarcastic comment, but continued."

# game/script.rpy:2965
translate english historia_continua_3_0a34c7c7:

    # C "… Estudié criminología por 4 años, y luego entré a la academia de policía."
    C "... I studied criminology for 4 years, and then I entered the police academy."

# game/script.rpy:2966
translate english historia_continua_3_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:2967
translate english historia_continua_3_e60958a4:

    # "Vaya, eso no te lo esperabas."
    "Wow, you didn't expect that."

# game/script.rpy:2968
translate english historia_continua_3_efb29312:

    # "Cindy… no daba la imagen de querer ser algo en la vida, mucho menos policía."
    "Cindy... didn't give the impression of wanting to be anything in life, much less a cop."

# game/script.rpy:2969
translate english historia_continua_3_5eff10dd:

    # C "Desde que tengo memoria, quise ser detective, y me esforcé mucho para graduarme con honores."
    C "As long as I can remember, I wanted to be a detective, and I worked hard to graduate with honors."

# game/script.rpy:2971
translate english historia_continua_3_dba45f40:

    # C "Pero cuando entré a la academia, la tienda de mi papá fue robada."
    C "But when I entered the academy, my dad's store was robbed."

# game/script.rpy:2972
translate english historia_continua_3_96471828:

    # C "Atraparon a los culpables, pero como uno de ellos era el sobrino de un teniente, los dejaron libres."
    C "They caught the culprits, but since one of them was a lieutenant's nephew, they let them go free."

# game/script.rpy:2973
translate english historia_continua_3_4973b8f8:

    # C "El sistema se jacta de ser una red justa, pero tiene demasiados agujeros."
    C "The system boasts of being a fair network, but it has too many loopholes."

# game/script.rpy:2974
translate english historia_continua_3_51e63619:

    # C "Abandoné la academia y trabajo para papá desde entonces."
    C "I dropped out of the academy and have been working for Dad ever since."

# game/script.rpy:2975
translate english historia_continua_3_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:2976
translate english historia_continua_3_379b78fc:

    # pov "Vaya, quién lo diría."
    pov "Wow, who would've thought."

# game/script.rpy:2977
translate english historia_continua_3_33e75352:

    # "Cindy farfulló entre dientes."
    "Cindy grumbled through clenched teeth."

# game/script.rpy:2978
translate english historia_continua_3_e17d2dcb:

    # C "No seas condescendiente conmigo."
    C "Don't be condescending with me."

# game/script.rpy:2979
translate english historia_continua_3_773064b2:

    # pov "¡No, no!, para nada. Me llama la atención, eso es todo."
    pov "No, no! Not at all. It just caught my attention, that's all."

# game/script.rpy:2980
translate english historia_continua_3_dde94ff2:

    # pov "Eso explica porque fuiste tan… hosca con el teniente Wes y la detective Sean."
    pov "That explains why you were so... harsh with Lieutenant Wes and Detective Sean."

# game/script.rpy:2981
translate english historia_continua_3_a75b9407:

    # "Cindy resopló, desviando la mirada."
    "Cindy snorted, looking away."

# game/script.rpy:2982
translate english historia_continua_3_5bd494a4:

    # C "… ¿Tú crees que ellos están haciendo un buen trabajo?"
    C "... Do you think they're doing a good job?"

# game/script.rpy:2983
translate english historia_continua_3_50d7397c:

    # pov "Bueno, no sé en qué estarán ahora, pero tengo el presentimiento de que están esforzándose."
    pov "Well, I don't know what they're doing now, but I have a feeling they're trying hard."

# game/script.rpy:2985
translate english historia_continua_3_e768f91b:

    # "Cindy bajó la mirada, desganada."
    "Cindy lowered her gaze, dispirited."

# game/script.rpy:2986
translate english historia_continua_3_cc6a8bcf:

    # C "Espero que el sistema no te falle como me falló a mí, [povname]."
    C "I hope the system doesn't fail you like it failed me, [povname]."

# game/script.rpy:2987
translate english historia_continua_3_bedd6fae_3:

    # pov "…"
    pov "..."

# game/script.rpy:2988
translate english historia_continua_3_2c8b7da9:

    # pov "Creo que eso es lo segundo más lindo que me has dicho."
    pov "I think that's the second nicest thing you've ever said to me."

# game/script.rpy:2989
translate english historia_continua_3_652599d5:

    # "Cindy alza una ceja."
    "Cindy raised an eyebrow."

# game/script.rpy:2990
translate english historia_continua_3_5162cf85:

    # C "¿Qué fue lo primero?"
    C "What was the first?"

# game/script.rpy:2991
translate english historia_continua_3_b4d1e299:

    # pov "Que sientes paz conmigo."
    pov "That you feel peaceful with me."

# game/script.rpy:2992
translate english historia_continua_3_7f76495a_3:

    # C "…"
    C "..."

# game/script.rpy:2993
translate english historia_continua_3_5bee2644:

    # C "Si, bueno, sigo pensando eso."
    C "Yeah, well, I still think that."

# game/script.rpy:2994
translate english historia_continua_3_c2f5a848:

    # "Ustedes se quedan un momento en silencio, hasta que tu lo rompes."
    "You two fell silent for a moment, until you broke it."

# game/script.rpy:2995
translate english historia_continua_3_f01ece38:

    # pov "Me alegra que nos estemos llevando bien, Cin."
    pov "I'm glad we're getting along, Cin."

# game/script.rpy:2996
translate english historia_continua_3_7f76495a_4:

    # C "…"
    C "..."

# game/script.rpy:2998
translate english historia_continua_3_7bcd459a:

    # "Ella sonríe levemente."
    "She smiled faintly."

# game/script.rpy:2999
translate english historia_continua_3_04d03096:

    # C "Yo también."
    C "Me too."

# game/script.rpy:3001
translate english historia_continua_3_49dfef4e:

    # C "Bueno, ya es hora de irme."
    C "Well, it's time for me to go."

# game/script.rpy:3002
translate english historia_continua_3_591d5e9a:

    # pov "¿Tan pronto?"
    pov "So soon?"

# game/script.rpy:3003
translate english historia_continua_3_d9e4690d:

    # C "Sólo vine a ver cómo estabas. Por lo que veo, estás bien."
    C "I just came to check on you. From what I see, you're fine."

# game/script.rpy:3004
translate english historia_continua_3_b0adbbb3:

    # pov "Pero…"
    pov "But..."

# game/script.rpy:3005
translate english historia_continua_3_e6774950:

    # "Cindy se gira hacia ti, interrogante."
    "Cindy turned to you, questioning."

# game/script.rpy:3006
translate english historia_continua_3_0e11cf84:

    # C "¿Sucede algo?"
    C "What is it?"

# game/script.rpy:3007
translate english historia_continua_3_bedd6fae_4:

    # pov "…"
    pov "..."

# game/script.rpy:3008
translate english historia_continua_3_93b41066:

    # "No, no podías decirle sobre el juego de Jeff."
    "No, you couldn't tell her about Jeff's game."

# game/script.rpy:3009
translate english historia_continua_3_b1b4e2b6:

    # pov "No, nada, regresa segura."
    pov "No, nothing, go home safely."

# game/script.rpy:3010
translate english historia_continua_3_d979128e:

    # "Cindy te miró un par de segundos en silencio, para después marcharse."
    "Cindy looked at you for a couple of seconds in silence, then left."

# game/script.rpy:3012
translate english historia_continua_3_04040263:

    # "Viendo que estabas por tu cuenta, suspiras pesadamente."
    "Seeing that you were on your own, you sighed heavily."

# game/script.rpy:3014
translate english historia_continua_3_0d299175:

    # "Pasas el resto del día en tu departamento. Sentías que iba a ser una noche tranquila."
    "You spent the rest of the day in your apartment. You felt like it was going to be a quiet night."

# game/script.rpy:3016
translate english historia_continua_3_52bfd283:

    # "Pero cuando llegó la noche, cambiaste de parecer."
    "But when night came, you changed your mind."

# game/script.rpy:3017
translate english historia_continua_3_b1b7917d:

    # "Jeff dijo que cada vez que lo evadieras, él se alejaría. Así que técnicamente, deberías estar a salvo esta noche."
    "Jeff said that every time you evaded him, he would go away. So technically, you should be safe tonight."

# game/script.rpy:3018
translate english historia_continua_3_49481fcc:

    # "Pero por otro lado, era Jeff de quien se estaba hablando."
    "But on the other hand, it was Jeff you were talking about."

# game/script.rpy:3019
translate english historia_continua_3_b9d0a718:

    # "El tipo es un demente cobarde tramposo, no puedes confiar en las palabras de él."
    "The guy is a cowardly, cheating maniac; you can't trust his words."

# game/script.rpy:3020
translate english historia_continua_3_38d35ff0:

    # "Así que decides salir."
    "So you decided to go out."

# game/script.rpy:3021
translate english historia_continua_3_3c7d5376:

    # "¿A dónde?, No importa, sólo te vas a donde haya una gran multitud de gente, donde sea imposible atacarte."
    "Where? It didn't matter, you just went somewhere with a large crowd, where it would be impossible to attack you."

# game/script.rpy:3025
translate english historia_continua_3_00d75c6d:

    # "Entonces llegas a una calle llena de bares."
    "So you arrived at a street full of bars."

# game/script.rpy:3026
translate english historia_continua_3_1536b002:

    # "Las luces pintan de colores las calles y la música se escapa suavemente de los lugares."
    "Lights painted the streets with colors and music gently escaped from the venues."

# game/script.rpy:3027
translate english historia_continua_3_259cb52c:

    # "Te encoges de hombros y escoges un bar para entrar."
    "You shrugged and picked a bar to enter."

# game/script.rpy:3029
translate english historia_continua_3_e47b98c0:

    # "El lugar es tranquilo y una cantidad considerable de gente, perfecto."
    "The place was quiet and had a considerable number of people, perfect."

# game/script.rpy:3030
translate english historia_continua_3_c585b154:

    # "No querías ir a un lugar medio vacío, era como ser un ciervo e ir a la pradera."
    "You didn't want to go to a half-empty place; it would be like a deer going to a meadow."

# game/script.rpy:3031
translate english historia_continua_3_6eb35a29:

    # "Pero tampoco a un lugar concurrido, es lo que menos necesitas en tu estado paranóico."
    "But not a crowded place either; that's the last thing you needed in your paranoid state."

# game/script.rpy:3032
translate english historia_continua_3_1757ebc6:

    # "Así que te sientas en la barra y te preparas para pedir."
    "So you sat at the bar and prepared to order."

# game/script.rpy:3042
translate english character_7_ae51851c:

    # "Te sientas a esperar pacientemente por tu pedido."
    "You sat waiting patiently for your order."

# game/script.rpy:3045
translate english character_7_0be6b95e:

    # "Y es entonces que sientes que alguien toma el lugar junto a ti."
    "And that's when you felt someone take the seat next to you."

# game/script.rpy:3051
translate english character_7_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3052
translate english character_7_9b0f8d89:

    # pov "¿En serio?"
    pov "Seriously?"

# game/script.rpy:3053
translate english character_7_4f58d838:

    # J "¿Qué?"
    J "What?"

# game/script.rpy:3054
translate english character_7_4a819460:

    # J "Puedo ir a donde quiera, este es un lugar público."
    J "I can go wherever I want, this is a public place."

# game/script.rpy:3055
translate english character_7_27eb3e50:

    # pov "¿Y no crees que con sólo gritar puedo hacer que te arresten?"
    pov "And don't you think if I just scream, I can get you arrested?"

# game/script.rpy:3056
translate english character_7_ceb04f78:

    # "Jeff te mira por encima del hombro, con desinterés ante tu amenaza."
    "Jeff looked at you over his shoulder, disinterested in your threat."

# game/script.rpy:3057
translate english character_7_ddb12ed8:

    # J "Claro, puedes hacer eso, y en lo que se tarda en venir un policía, puedo arrancarte el otro ojo y huir de nuevo."
    J "Sure, you can do that, and by the time a cop comes, I can rip out your other eye and run away again."

# game/script.rpy:3058
translate english character_7_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3059
translate english character_7_0ed17e2e:

    # pov "Eres un cobarde."
    pov "You're a coward."

# game/script.rpy:3061
translate english character_7_619e8b75:

    # J "Heh."
    J "Heh."

# game/script.rpy:3062
translate english character_7_d0bb4f6e:

    # J "Soy muchas cosas."
    J "I'm many things."

# game/script.rpy:3064
translate english character_7_14719ca7:

    # "El bartender se acerca y Jeff le hace una seña para hacer un pedido."
    "The bartender approached and Jeff gestured to him to take an order."

# game/script.rpy:3065
translate english character_7_f8c65899:

    # J "Un whisky, seco."
    J "Whiskey, neat."

# game/script.rpy:3066
translate english character_7_b5fa365e:

    # pov "¿Oh?, ¿A la vieja escuela?, ¿O sólo te estás luciendo?"
    pov "Oh? Old school? Or just showing off?"

# game/script.rpy:3067
translate english character_7_c8a16db8:

    # J "¿Ante quién me voy a lucir?, ¿Tú?"
    J "Who am I showing off to? You?"

# game/script.rpy:3073
translate english character_7_793ab315:

    # pov "Parece que te esfuerzas mucho en llamar mi atención."
    pov "You seem to try very hard to get my attention."

# game/script.rpy:3074
translate english character_7_e6054fc3:

    # J "Yo no…"
    J "I don't..."

# game/script.rpy:3075
translate english character_7_87867b62:

    # J "Cállate…"
    J "Shut up..."

# game/script.rpy:3078
translate english character_7_fed5583c:

    # pov "No fuiste tan sutil al dejarme vivir."
    pov "You weren't so subtle about leaving me alive."

# game/script.rpy:3079
translate english character_7_93227467:

    # "Escuchas como él chasquea la lengua con molestia bajo la bandana."
    "You heard him click his tongue in annoyance under his bandana."

# game/script.rpy:3084
translate english ruta_normal_21_9734f240:

    # pov "Soy la primera persona que dejas con vida."
    pov "I'm the first person you've left alive."

# game/script.rpy:3085
translate english ruta_normal_21_f3b9b8f0:

    # pov "Creo que eso me hace al menos relevante para ti."
    pov "I guess that makes me at least relevant to you."

# game/script.rpy:3086
translate english ruta_normal_21_2dd0672f:

    # "Tus palabras parecen llamar la atención de él."
    "Your words seemed to catch his attention."

# game/script.rpy:3087
translate english ruta_normal_21_f47a32d5:

    # J "No te creas tan especial, no eres la primera."
    J "Don't flatter yourself, you're not the first."

# game/script.rpy:3088
translate english ruta_normal_21_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3089
translate english ruta_normal_21_9175b202:

    # pov "¿Oh?"
    pov "Oh?"

# game/script.rpy:3090
translate english ruta_normal_21_fe9f694b:

    # "El bartender llega con tu pedido y el de él."
    "The bartender arrived with your order and his."

# game/script.rpy:3094
translate english ruta_normal_21_8e268cc4:

    # "Jeff envuelve con sus dedos el vaso de vidrio, y baja un poco la bandana de su boca. Puedes ver un poco de su perfil."
    "Jeff wrapped his fingers around the glass, and pulled his bandana down slightly. You could see a bit of his profile."

# game/script.rpy:3095
translate english ruta_normal_21_a802543e:

    # "Es raro verlo… tan tranquilo."
    "It was strange to see him... so calm."

# game/script.rpy:3096
translate english ruta_normal_21_867d10ca:

    # J "Fue un error de principiante… La chica era linda conmigo, y sufrió lo mismo que yo, así que me compadecí."
    J "It was a beginner's mistake... The girl was nice to me, and she suffered the same as me, so I felt sorry for her."

# game/script.rpy:3097
translate english ruta_normal_21_fd3f1530:

    # "Jeff bebió un sorbo, para después dar vueltas el vaso, revolviendo la bebida en su interior."
    "Jeff took a sip, then swirled the drink in his glass."

# game/script.rpy:3098
translate english ruta_normal_21_c635a4a6:

    # J "No sé si sigue viva, pero la última vez que la vi quería matarme, así que ya no me importa."
    J "I don't know if she's still alive, but last time I saw her, she wanted to kill me, so I don't care anymore."

# game/script.rpy:3099
translate english ruta_normal_21_193fb22c:

    # pov "Wow, tú siendo compasivo, eso es nuevo."
    pov "Wow, you being compassionate, that's new."

# game/script.rpy:3100
translate english ruta_normal_21_c599da4c:

    # pov "¿Y qué fue lo que ustedes sufrieron, sí se puede saber?"
    pov "And what did you two suffer from, if I may ask?"

# game/script.rpy:3101
translate english ruta_normal_21_d49e5dbf:

    # "Él señaló con la punta de su índice su propio rostro."
    "He pointed to his own face with his index finger."

# game/script.rpy:3102
translate english ruta_normal_21_eec8464c:

    # J "Las quemaduras."
    J "The burns."

# game/script.rpy:3103
translate english ruta_normal_21_4a2bd410:

    # pov "Ah."
    pov "Ah."

# game/script.rpy:3104
translate english ruta_normal_21_50ec702c:

    # pov "¿Puedo… preguntar cómo pasó?"
    pov "Can I... ask how it happened?"

# game/script.rpy:3105
translate english ruta_normal_21_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3106
translate english ruta_normal_21_ac7ea2df:

    # J "En un accidente… me vertí ácido encima."
    J "In an accident... I spilled acid on myself."

# game/script.rpy:3107
translate english ruta_normal_21_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3111
translate english ruta_normal_21_00be0d9b:

    # pov "Yo… lamento que te pasó eso."
    pov "I... I'm sorry that happened to you."

# game/script.rpy:3112
translate english ruta_normal_21_25effc38:

    # J "… Seh. "
    J "... Yeah."

# game/script.rpy:3113
translate english ruta_normal_21_e1aa7efd:

    # "Jeff bebió otro sorbo de su whisky."
    "Jeff took another sip of his whiskey."

# game/script.rpy:3118
translate english ruta_normal_21_e5bb0ccb:

    # pov "Con accidentalmente… ¿Te refieres a que lo derramaste o te lo echaste?"
    pov "Accidentally... Do you mean you spilled it or threw it on yourself?"

# game/script.rpy:3119
translate english ruta_normal_21_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3120
translate english ruta_normal_21_6100450e:

    # J "¿Un poco las dos?"
    J "A bit of both?"

# game/script.rpy:3121
translate english ruta_normal_21_3ee9947e:

    # pov "Wow, simplemente… Wow."
    pov "Wow, just... wow."

# game/script.rpy:3122
translate english ruta_normal_21_1dcf767e:

    # "Jeff resopla. Aparenta molestarse, pero percibes la diversión en su voz."
    "Jeff snorted. He seemed annoyed, but you sensed the amusement in his voice."

# game/script.rpy:3123
translate english ruta_normal_21_c8d530bd:

    # J "Oh, cállate, no eres quien juzgarme."
    J "Oh, shut up, you're not one to judge me."

# game/script.rpy:3124
translate english ruta_normal_21_578970d8:

    # pov "¿Eso qué quiere decir?"
    pov "What's that supposed to mean?"

# game/script.rpy:3125
translate english ruta_normal_21_f1fc5595:

    # J "Averígualo tú."
    J "You figure it out"

# game/script.rpy:3126
translate english ruta_normal_21_e1aa7efd_1:

    # "Jeff bebió otro sorbo de su whisky."
    "Jeff took another sip of his whiskey."

# game/script.rpy:3131
translate english ruta_normal_22_0c4f3680:

    # pov "De todas formas, ¿A qué viniste aquí?"
    pov "Anyway, why did you come here?"

# game/script.rpy:3132
translate english ruta_normal_22_118652d1:

    # pov "Pensé que querías mantener… “esto” entre nosotros, sin público."
    pov "I thought you wanted to keep... 'this' between us, without an audience."

# game/script.rpy:3133
translate english ruta_normal_22_1d908765:

    # J "Relájate, no te haré nada. Cumpliré con mi promesa."
    J "Relax, I won't hurt you. I'll keep my promise."

# game/script.rpy:3134
translate english ruta_normal_22_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3135
translate english ruta_normal_22_e1187afd:

    # pov "“Por ahora”, ¿No?"
    pov "'For now', right?"

# game/script.rpy:3136
translate english ruta_normal_22_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3138
translate english ruta_normal_22_5a87224c:

    # "Pones los ojos en blanco y bebes tu propia bebida."
    "You rolled your eyes and drank your own drink."

# game/script.rpy:3139
translate english ruta_normal_22_b06c570b:

    # "Ustedes se mantienen en silencio por un rato, escuchando la música del bar y el ruido de las demás personas conversando entre sí."
    "You both sat in silence for a while, listening to the bar's music and the chatter of other people."

# game/script.rpy:3143
translate english ruta_normal_22_8c76e806:

    # pov "Así que… hoy fui de compras."
    pov "So... I went shopping today."

# game/script.rpy:3144
translate english ruta_normal_22_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3145
translate english ruta_normal_22_77e3ad29:

    # pov "Me encontré con mi doctor. No fue tan impactante como encontrarte a ti, pero fue… algo."
    pov "I ran into my doctor. It wasn't as impactful as running into you, but it was... something."

# game/script.rpy:3146
translate english ruta_normal_22_8c51a72f:

    # "Jeff resopla, con el borde del vaso contra sus labios."
    "Jeff snorted, the rim of the glass against his lips."

# game/script.rpy:3147
translate english ruta_normal_22_6546a324:

    # J "Llevar tus comestibles por ti, clásico."
    J "Carrying your groceries for you, classic."

# game/script.rpy:3148
translate english ruta_normal_22_8215b681:

    # J "No tienes que fingir que te agrada frente a él, ¿Sabes?"
    J "You don't have to pretend you like him, you know?"

# game/script.rpy:3149
translate english ruta_normal_22_36c53943:

    # pov "Yo no- espera, ¿Cómo sabes eso?"
    pov "I don't—wait, how do you know that?"

# game/script.rpy:3150
translate english ruta_normal_22_6a8a3250:

    # "Jeff ladeó la cabeza burlonamente."
    "Jeff tilted his head mockingly."

# game/script.rpy:3155
translate english ruta_normal_22_38dbdc3c:

    # pov "¿Qué hiciste hoy?"
    pov "What did you do today?"

# game/script.rpy:3156
translate english ruta_normal_22_52e5fdec:

    # "Jeff se gira a ti con sorpresa."
    "Jeff turned to you in surprise."

# game/script.rpy:3157
translate english ruta_normal_22_d314e011:

    # J "Yo… no hice mucho."
    J "I... I didn't do much."

# game/script.rpy:3158
translate english ruta_normal_22_afaa60ae:

    # "Él regresó su mirada al frente."
    "He turned his gaze back to the front."

# game/script.rpy:3159
translate english ruta_normal_22_a99ad301:

    # J "Fui de compras…"
    J "I went shopping..."

# game/script.rpy:3160
translate english ruta_normal_22_ac10e2fa:

    # J "Recorrí las calles…"
    J "I walked the streets..."

# game/script.rpy:3161
translate english ruta_normal_22_25e9b76b:

    # J "Descansé un poco…"
    J "I rested a little..."

# game/script.rpy:3162
translate english ruta_normal_22_943e6cc7:

    # J "Y vine a este bar."
    J "And I came to this bar."

# game/script.rpy:3163
translate english ruta_normal_22_d8be11d5:

    # "Mientras escuchas atentamente, miras que la comisura de Jeff se alarga en una sonrisa burlona, a la vez que te das cuenta."
    "As you listened intently, you saw the corner of Jeff's mouth curl into a mocking smile, and you realized."

# game/script.rpy:3168
translate english ruta_normal_23_c6c3b4bf:

    # pov "¡Si eras tú el me estaba siguiendo!"
    pov "So it was you following me!"

# game/script.rpy:3170
translate english ruta_normal_23_597fec25:

    # J "¡Hahaha!"
    J "Hahaha!"

# game/script.rpy:3171
translate english ruta_normal_23_2476690b:

    # "Lo miras con enojo, pero lejos de estar molesto, a Jeff parecía agradarle causar esa reacción en ti."
    "You glared at him, but far from being annoyed, Jeff seemed to enjoy causing that reaction in you."

# game/script.rpy:3172
translate english ruta_normal_23_58c4b40a:

    # "Tomas un sorbo de tu bebida, y él hace lo mismo."
    "You took a sip of your drink, and he did the same."

# game/script.rpy:3173
translate english ruta_normal_23_883bedb7:

    # "Cada vez que él termina de beber, se sube la bandana de nuevo, cubriendo su rostro."
    "Every time he finished drinking, he pulled his bandana up again, covering his face."

# game/script.rpy:3174
translate english ruta_normal_23_a73a9834:

    # "Tienen una pausa, un momento para tranquilizar la emoción anterior."
    "You both paused, a moment to calm the previous emotion."

# game/script.rpy:3175
translate english ruta_normal_23_8fa24223:

    # pov "¿De… verdad no me harás nada esta noche?"
    pov "Are you... really not going to do anything to me tonight?"

# game/script.rpy:3177
translate english ruta_normal_23_a898f5e6:

    # "Jeff apoya su mejilla en su mano con aburrimiento."
    "Jeff rested his cheek on his hand, bored."

# game/script.rpy:3178
translate english ruta_normal_23_916fd24c:

    # J "¿Por qué, ahora me tienes miedo?"
    J "Why, now you're afraid of me?"

# game/script.rpy:3179
translate english ruta_normal_23_e431dac1:

    # pov "No es por eso… Apreciaría no ir de nuevo al hospital tan pronto después de haber salido."
    pov "It's not that... I just wouldn't appreciate going back to the hospital so soon after leaving."

# game/script.rpy:3180
translate english ruta_normal_23_27dfc42a:

    # "Jeff chasquea la lengua."
    "Jeff clicked his tongue."

# game/script.rpy:3181
translate english ruta_normal_23_7f1b271a:

    # J "No te preocupes, mejor disfruta que no te estoy destripando donde estás."
    J "Don't worry, just enjoy that I'm not gutting you where you are."

# game/script.rpy:3182
translate english ruta_normal_23_898b2b8f:

    # pov "Ok, eso no es tranquilizador."
    pov "Okay, that's not reassuring."

# game/script.rpy:3183
translate english ruta_normal_23_65c6c85f:

    # "Jeff suspira, girándose hacia ti."
    "Jeff sighed, turning to you."

# game/script.rpy:3184
translate english ruta_normal_23_2ed81fc1:

    # "Sus ojos, azules como el cielo, lechosos como un día nublado, te miran fijamente."
    "His eyes, sky-blue, milky like a cloudy day, stared fixedly at you."

# game/script.rpy:3185
translate english ruta_normal_23_6daada17:

    # J "Prometo que no haré nada."
    J "I promise I won't do anything."

# game/script.rpy:3191
translate english ruta_normal_23_fa4b1cd9:

    # pov "¿No podrías ser así de lindo la mayoría del tiempo?"
    pov "Couldn't you be this cute most of the time?"

# game/script.rpy:3192
translate english ruta_normal_23_054948c3:

    # pov "Es una pérdida de tiempo que actúes como un loco todo el tiempo."
    pov "It's a waste of time to act crazy all the time."

# game/script.rpy:3193
translate english ruta_normal_23_0cca5aa2:

    # "Crees que Jeff hizo el ademán de alzar una ceja, porque… él no tiene cejas, duh."
    "You thought Jeff made a gesture of raising an eyebrow, because... he doesn't have eyebrows, duh."

# game/script.rpy:3194
translate english ruta_normal_23_a1a780e8:

    # J "¿Y que sea un asesino?"
    J "And what about being a killer?"

# game/script.rpy:3195
translate english ruta_normal_23_eec302f8:

    # pov "Sí, eso también."
    pov "Yeah, that too."

# game/script.rpy:3196
translate english ruta_normal_23_8a93848e:

    # J "Huh."
    J "Huh."

# game/script.rpy:3197
translate english ruta_normal_23_ac456684:

    # "Jeff regresa a su lugar en silencio, como si no se esperara tu respuesta."
    "Jeff returned to his spot in silence, as if he hadn't expected your answer."

# game/script.rpy:3198
translate english ruta_normal_23_c0eb1e23:

    # "No lo puedes ver con claridad, pero jurarías que debajo de sus párpados negros, puedes ver un tono de rosa distinto al de las llagas de su piel."
    "You couldn't see it clearly, but you could swear that beneath his dark eyelids, you could see a distinct pink tone different from the sores on his skin."

# game/script.rpy:3201
translate english ruta_normal_23_2ee3dfc5:

    # "Entrecierras los ojos con sospecha, y bebes un sorbo de tu bebida."
    "You narrowed your eyes suspiciously, and took a sip of your drink."

# game/script.rpy:3202
translate english ruta_normal_23_e091b0dd:

    # pov "Eso veremos."
    pov "We'll see about that."

# game/script.rpy:3203
translate english ruta_normal_23_968422c3:

    # "Jeff pone los ojos en blanco."
    "Jeff rolled his eyes."

# game/script.rpy:3208
translate english ruta_normal_24_772d11fe:

    # "Ustedes guardan silencio nuevamente, esta vez se sienten más tranquilos, como si se hubieran sacudido la incomodidad anterior."
    "You both fell silent again; this time you felt calmer, as if you had shaken off the previous awkwardness."

# game/script.rpy:3209
translate english ruta_normal_24_406d6eae:

    # pov "¿Por qué haces esto, de todos modos?"
    pov "Why are you doing this, anyway?"

# game/script.rpy:3210
translate english ruta_normal_24_c750ec27:

    # "Jeff te mira interrogativamente."
    "Jeff looked at you questioningly."

# game/script.rpy:3211
translate english ruta_normal_24_011a4b11:

    # pov "No sé… lo que piensas. No sé si me odias o te agrado, no sé si me quieres matar u observar."
    pov "I don't know... what you're thinking. I don't know if you hate me or like me, I don't know if you want to kill me or observe me."

# game/script.rpy:3212
translate english ruta_normal_24_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3213
translate english ruta_normal_24_6befebaf:

    # J "Yo tampoco lo sé con claridad."
    J "I don't know either, clearly."

# game/script.rpy:3214
translate english ruta_normal_24_4bf18d0e:

    # J "Pierdo el control cuando se trata de ti."
    J "I lose control when it comes to you."

# game/script.rpy:3215
translate english ruta_normal_24_2b0c247f:

    # "Jeff suelta una carcajada seca."
    "Jeff let out a dry chuckle."

# game/script.rpy:3217
translate english ruta_normal_24_30a7abdf:

    # J "Siempre fui bueno improvisando, pero desde que te conocí, no sé qué mierda estoy haciendo."
    J "I was always good at improvising, but since I met you, I don't know what the fuck I'm doing."

# game/script.rpy:3223
translate english ruta_normal_24_5e49003c:

    # pov "Siempre fuiste bueno en esto de… matar personas."
    pov "You were always good at... killing people."

# game/script.rpy:3224
translate english ruta_normal_24_89742677:

    # pov "¿Qué es diferente ahora?"
    pov "What's different now?"

# game/script.rpy:3227
translate english ruta_normal_24_d9a5fc94:

    # pov "Supongo que es cómo encontrar un obstáculo nuevo."
    pov "I guess it's like finding a new obstacle."

# game/script.rpy:3228
translate english ruta_normal_24_c0afeac1:

    # "Jeff niega levemente con la cabeza."
    "Jeff shook his head slightly."

# game/script.rpy:3234
translate english ruta_normal_25_ade66aab:

    # J "Tú… eres un enigma. Creí entender a toda la humanidad, por eso la odiaba, pero contigo… es como si quisiera averiguar más."
    J "You... you're an enigma. I thought I understood all of humanity, that's why I hated it, but with you... it's like I want to find out more."

# game/script.rpy:3235
translate english ruta_normal_25_f634d120:

    # J "Me llamas la atención, en eso estoy seguro."
    J "You caught my attention, I'm sure of that."

# game/script.rpy:3237
translate english ruta_normal_25_7a1d28e9:

    # "Él lentamente dirigió su mano hacia ti."
    "He slowly brought his hand towards you."

# game/script.rpy:3238
translate english ruta_normal_25_a35964b7:

    # "No te mueves, no sabes si es por temor a que haga algo, o si quieres que te alcance."
    "You didn't move; you didn't know if it was out of fear he would do something, or if you wanted him to reach you."

# game/script.rpy:3239
translate english ruta_normal_25_d4c8d459:

    # "Los dedos de Jeff rodean tu cuello, y aprietan suavemente. No llega a ahorcarte, pero su agarre es firme."
    "Jeff's fingers wrapped around your neck, and squeezed gently. It wasn't choking you, but his grip was firm."

# game/script.rpy:3240
translate english ruta_normal_25_b51a783a:

    # J "Aún estoy pensando qué hacer contigo una vez me aburra de nuestro juego."
    J "I'm still thinking about what to do with you once I get bored of our game."

# game/script.rpy:3241
translate english ruta_normal_25_5dea302d:

    # "Él te acerca a él, su respiración rozando con tu rostro mientras él habla suavemente."
    "He pulled you closer, his breath grazing your face as he spoke softly."

# game/script.rpy:3242
translate english ruta_normal_25_087d03e9:

    # J "Ya que me aburro fácilmente."
    J "Because I get bored easily."

# game/script.rpy:3246
translate english ruta_normal_25_cc9a7052:

    # "Tomas la mano de Jeff entre la tuya, y afortunadamente, él no se resiste a tu toque."
    "You took Jeff's hand in yours, and fortunately, he didn't resist your touch."

# game/script.rpy:3248
translate english ruta_normal_25_e449308b:

    # "Liberas tu cuello de la mano de él, alejándola de ti mientras te acaricias el cuello."
    "You freed your neck from his hand, pulling it away from you while caressing your neck."

# game/script.rpy:3249
translate english ruta_normal_25_5097a720:

    # pov "Geez, ok, ya entendí."
    pov "Geez, okay, I get it."

# game/script.rpy:3250
translate english ruta_normal_25_582d850e:

    # J "Más te vale."
    J "You better."

# game/script.rpy:3251
translate english ruta_normal_25_20ca486d:

    # "Él volvió a su lugar, y siguió bebiendo su whisky."
    "He returned to his spot, and continued drinking his whiskey."

# game/script.rpy:3256
translate english ruta_normal_25_09edf0e4:

    # pov "Ngh~"
    pov "Ngh~"

# game/script.rpy:3257
translate english ruta_normal_25_f6b92c46:

    # "Jeff abrió en grande los ojos, soltándote, como si contagiaras."
    "Jeff's eyes widened, letting you go, as if you were contagious."

# game/script.rpy:3258
translate english ruta_normal_25_b6fa1ff1:

    # "Él te miró con asombro un par de segundos, para después farfullar."
    "He stared at you in astonishment for a couple of seconds, then stammered."

# game/script.rpy:3259
translate english ruta_normal_25_b77121c2:

    # J "De nuevo caí en eso…"
    J "I fell for that again..."

# game/script.rpy:3260
translate english ruta_normal_25_74a20463:

    # "Él gruñó por lo bajo, y siguió bebiendo su whisky."
    "He grunted under his breath, and continued drinking his whiskey."

# game/script.rpy:3265
translate english ruta_normal_26_ad1b6c7e:

    # pov "Hey, así que… ¿Cuál es el plan?"
    pov "Hey, so... what's the plan?"

# game/script.rpy:3266
translate english ruta_normal_26_0eb96dcd:

    # J "¿Huh?"
    J "Huh?"

# game/script.rpy:3267
translate english ruta_normal_26_d8bb2dbf:

    # pov "¿Vamos a charlar como si fuéramos amigos, a pesar de que me arrancaste un ojo y me estás acosando?"
    pov "Are we going to chat like friends, even though you ripped out my eye and are stalking me?"

# game/script.rpy:3268
translate english ruta_normal_26_fc177ac5:

    # "Jeff resopla una carcajada, alzando su vaso."
    "Jeff snorted a laugh, raising his glass."

# game/script.rpy:3270
translate english ruta_normal_26_43eff71f:

    # J "¡Brindo por eso!"
    J "I'll drink to that!"

# game/script.rpy:3276
translate english ruta_normal_26_4a04a202:

    # pov "Lo que tú digas."
    pov "Whatever you say."

# game/script.rpy:3278
translate english ruta_normal_26_bb5552e4:

    # "Alzas el contenedor de tu bebida y chocas el vaso de él en un pequeño brindis."
    "You raised your drink and clinked it against his glass in a small toast."

# game/script.rpy:3279
translate english ruta_normal_26_5c1cf14e:

    # "Él te queda mirando en silencio, pensativo."
    "He stared at you in silence, thoughtfully."

# game/script.rpy:3280
translate english ruta_normal_26_291482a1:

    # J "… Eres una persona muy rara, [povname]."
    J "... You're a very strange person, [povname]."

# game/script.rpy:3281
translate english ruta_normal_26_4f9c0089:

    # pov "¿Eso te gusta? "
    pov "Do you like that?"

# game/script.rpy:3282
translate english ruta_normal_26_2c836599:

    # "Jeff ríe levemente."
    "Jeff chuckled softly."

# game/script.rpy:3283
translate english ruta_normal_26_069571c9:

    # J "Ya veremos."
    J "We'll see."

# game/script.rpy:3286
translate english ruta_normal_26_98a4fb8a:

    # pov "Estás loco."
    pov "You're crazy."

# game/script.rpy:3287
translate english ruta_normal_26_652521b6:

    # J "Ese es mi encanto, por si no lo has notado."
    J "That's my charm, in case you haven't noticed."

# game/script.rpy:3288
translate english ruta_normal_26_3ddec117:

    # "Pones los ojos en blanco, ignorándolo."
    "You rolled your eyes, ignoring him."

# game/script.rpy:3293
translate english ruta_normal_27_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3294
translate english ruta_normal_27_ea954a60:

    # pov "Gracias, por dejarme en paz esta noche."
    pov "Thanks for leaving me alone tonight."

# game/script.rpy:3296
translate english ruta_normal_27_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3297
translate english ruta_normal_27_ca9e1581:

    # J "Tus estándares son muy bajos, ¿No?"
    J "Your standards are very low, aren't they?"

# game/script.rpy:3298
translate english ruta_normal_27_6dada04a:

    # pov "Hey, dije gracias, no que te volviste mágicamente decente porque hiciste una sola cosa buena por mí."
    pov "Hey, I said thanks, not that you magically became decent just because you did one good thing for me."

# game/script.rpy:3299
translate english ruta_normal_27_d97fdb34:

    # "Esto no es un dark romance."
    "This isn't a dark romance."

# game/script.rpy:3300
translate english ruta_normal_27_ce617998:

    # "…"
    "..."

# game/script.rpy:3301
translate english ruta_normal_27_63b2d046:

    # "Quizás."
    "Perhaps."

# game/script.rpy:3302
translate english ruta_normal_27_9a4f30dc:

    # "Jeff alzó sus manos en rendición, su postura despreocupada."
    "Jeff raised his hands in surrender, his posture unconcerned."

# game/script.rpy:3303
translate english ruta_normal_27_b7513d45:

    # J "Estoy de buen humor, sólo puedo decir eso."
    J "I'm in a good mood, that's all I can say."

# game/script.rpy:3304
translate english ruta_normal_27_fe3b7119:

    # pov "¿Tiene algo que ver a que rechacé la cita con Paul?"
    pov "Does it have anything to do with me rejecting the date with Paul?"

# game/script.rpy:3305
translate english ruta_normal_27_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3306
translate english ruta_normal_27_8a5554d2:

    # J "Piensa lo que quieras."
    J "Think what you want."

# game/script.rpy:3307
translate english ruta_normal_27_7532ae70:

    # "Sonríes levemente, y bebes de tu bebida."
    "You smiled faintly, and drank your drink."

# game/script.rpy:3308
translate english ruta_normal_27_588d8c9b:

    # "Ustedes se quedan en silencio, escuchando la música del bar."
    "You both fell silent, listening to the bar music."

# game/script.rpy:3309
translate english ruta_normal_27_c28b39a2:

    # "El jazz es relajante, y extrañamente, no te sientes mal."
    "Jazz was relaxing, and strangely, you didn't feel bad."

# game/script.rpy:3310
translate english ruta_normal_27_6548bb03:

    # "Era increíble cómo podías pasar de un momento temiendo que te encontrara en tu escondite, y en otro parece que ustedes están teniendo una…"
    "It was incredible how you could go from fearing he'd find you in your hiding place, and in another moment it seems you two are having a..."

# game/script.rpy:3311
translate english ruta_normal_27_abab1354:

    # "¿Oh?"
    "Oh?"

# game/script.rpy:3312
translate english ruta_normal_27_fd70c5ba:

    # "¿Era tu idea o esto parecía una cita?"
    "Was it your idea, or did this seem like a date?"

# game/script.rpy:3313
translate english ruta_normal_27_743b8537:

    # "Saliendo con el tipo que te arrancó el ojo y amenaza con matarte, ¿Tal vez sí es un dark romance después de todo?"
    "Dating the guy who ripped out your eye and threatens to kill you, maybe it is a dark romance after all?"

# game/script.rpy:3317
translate english ruta_normal_27_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:3318
translate english ruta_normal_27_a4161811:

    # J "¿A qué viene eso?"
    J "What's that got to do with anything?"

# game/script.rpy:3319
translate english ruta_normal_27_961ddd40:

    # pov "No pude evitar notar que realmente odias cuando alguien es… amable conmigo."
    pov "I couldn't help but notice that you really hated it when someone was... nice to me."

# game/script.rpy:3320
translate english ruta_normal_27_9d9285f9:

    # pov "¿Eres del tipo celoso, Jeff?"
    pov "Are you the jealous type, Jeff?"

# game/script.rpy:3321
translate english ruta_normal_27_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:3322
translate english ruta_normal_27_efe6af85:

    # J "Estás jugando con fuego, [povname]."
    J "You're playing with fire, [povname]."

# game/script.rpy:3327
translate english ruta_normal_27_06316e8b:

    # pov "¿Por qué?"
    pov "Why?"

# game/script.rpy:3328
translate english ruta_normal_27_a50ffdb3:

    # pov "¿Porque es insensato provocar a un asesino serial que me tiene en la mira?"
    pov "Because it's senseless to provoke a serial killer who has me in his sights?"

# game/script.rpy:3329
translate english ruta_normal_27_bc41ba1b:

    # "Tal vez no estabas tan bien mentalmente por meterte con alguien tan peligroso, pero definitivamente tienes sentido común como para reconocer lo jodida que es la situación."
    "Maybe you weren't mentally well enough to mess with someone so dangerous, but you definitely had enough common sense to recognize how screwed up the situation was."

# game/script.rpy:3330
translate english ruta_normal_27_c8b59c30:

    # J "Ha, veo que entiendes a lo que me refiero."
    J "Ha, I see you understand what I mean."

# game/script.rpy:3333
translate english ruta_normal_27_c9ad646a:

    # pov "Quizás quiera quemarme."
    pov "Maybe I want to burn myself."

# game/script.rpy:3334
translate english ruta_normal_27_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:3335
translate english ruta_normal_27_612ebbec:

    # J "No lo recomiendo."
    J "I don't recommend it."

# game/script.rpy:3336
translate english ruta_normal_27_9f148813:

    # J "Una vez que el fuego te alcanza, no hay vuelta atrás."
    J "Once the fire reaches you, there's no going back."

# game/script.rpy:3337
translate english ruta_normal_27_adbe995a:

    # "Para tu sorpresa, su tono de voz se marchita."
    "To your surprise, his tone withered."

# game/script.rpy:3340
translate english ruta_normal_27_30f88e9c:

    # pov "Para pagar lo que estás bebiendo, digo."
    pov "To pay for what you're drinking, I mean."

# game/script.rpy:3341
translate english ruta_normal_27_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:3342
translate english ruta_normal_27_fe362c51:

    # J "Normalmente mataría al bartender."
    J "I'd usually kill the bartender."

# game/script.rpy:3343
translate english ruta_normal_27_54f26506:

    # "Sientes una sonrisa burlona en su voz."
    "You felt a mocking smile in his voice."

# game/script.rpy:3344
translate english ruta_normal_27_c6251083:

    # J "Pero prometí que me comportaría, así que tendrás que invitarme."
    J "But I promised I'd behave, so you'll have to treat me."

# game/script.rpy:3347
translate english ruta_normal_27_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3348
translate english ruta_normal_27_992b49fd:

    # "Supsiras en rendición."
    "You sighed in surrender."

# game/script.rpy:3349
translate english ruta_normal_27_02e833ca:

    # pov "De acuerdo, sólo porque no quiero que me asocien contigo si te arrancas."
    pov "Alright, only because I don't want them to associate me with you if you act up."

# game/script.rpy:3350
translate english ruta_normal_27_2ad9eeae:

    # "Jeff resopló una risa corta y ligera, victorioso."
    "Jeff snorted a short, light, victorious laugh."

# game/script.rpy:3355
translate english ruta_normal_27_f3c857fb:

    # pov "¿Qué-?, ¡Nah-ah!"
    pov "What? Nah-ah!"

# game/script.rpy:3356
translate english ruta_normal_27_c0117adb:

    # J "Si-ih."
    J "Yeah-ah."

# game/script.rpy:3357
translate english ruta_normal_27_760bfd0a:

    # "Él tocó la punta de tu nariz con su dedo, juguetonamente."
    "He playfully touched the tip of your nose with his finger."

# game/script.rpy:3358
translate english ruta_normal_27_cdc0c994:

    # J "Si no lo haces, me iré corriendo y tendrás que pagar igual."
    J "If you don't do it, I'll run off and you'll have to pay anyway."

# game/script.rpy:3359
translate english ruta_normal_27_f67650fa:

    # J "¿No sería mejor evitar el mal rato y que te miren mal por juntarte con alguien que no paga la cuenta?"
    J "Wouldn't it be better to avoid the hassle and people giving you dirty looks for hanging out with someone who doesn't pay?"

# game/script.rpy:3360
translate english ruta_normal_27_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:3361
translate english ruta_normal_27_2a310e9c:

    # pov "Te odio."
    pov "I hate you."

# game/script.rpy:3362
translate english ruta_normal_27_619e8b75:

    # J "Heh."
    J "Heh."

# game/script.rpy:3363
translate english ruta_normal_27_344cd34b:

    # "Lejos de sentirse molesto, Jeff se ríe entre dientes."
    "Far from being upset, Jeff chuckled."

# game/script.rpy:3366
translate english ruta_normal_27_14360a18_6:

    # J "…"
    J "..."

# game/script.rpy:3367
translate english ruta_normal_27_cda0de51:

    # J "Muy personal, ¿No crees?"
    J "Very personal, don't you think?"

# game/script.rpy:3368
translate english ruta_normal_27_f3055ac4:

    # pov "Me fuiste a matar a mi casa, creo que tengo derecho a saber un poco más de ti."
    pov "You came to kill me at my house, I think I have the right to know a little more about you."

# game/script.rpy:3369
translate english ruta_normal_27_14360a18_7:

    # J "…"
    J "..."

# game/script.rpy:3370
translate english ruta_normal_27_1d8c5b27:

    # J "No te atrevas a juzgarme."
    J "Don't you dare judge me."

# game/script.rpy:3371
translate english ruta_normal_27_a73890d5:

    # pov "Lo intentaré."
    pov "I'll try."

# game/script.rpy:3372
translate english ruta_normal_27_0f4f8710:

    # "Jeff gruñó por lo bajo."
    "Jeff grumbled under his breath."

# game/script.rpy:3373
translate english ruta_normal_27_f78af336:

    # J "… Me la corté yo."
    J "... I cut it myself."

# game/script.rpy:3374
translate english ruta_normal_27_9b0f8d89:

    # pov "¿En serio?"
    pov "Seriously?"

# game/script.rpy:3375
translate english ruta_normal_27_06316e8b_1:

    # pov "¿Por qué?"
    pov "Why?"

# game/script.rpy:3376
translate english ruta_normal_27_ac95bb4e:

    # "Jeff deja salir un quejido frustrado."
    "Jeff let out a frustrated groan."

# game/script.rpy:3377
translate english ruta_normal_27_df6d16c8:

    # J "Era un angsty teen, era otra época, estaba pasando por algo…"
    J "I was an angsty teen, it was another time, I was going through something..."

# game/script.rpy:3382
translate english ruta_normal_27_537ebd21:

    # pov "Increíble, ¿A quién tratabas de emular?"
    pov "Unbelievable, who were you trying to emulate?"

# game/script.rpy:3383
translate english ruta_normal_27_fdf1da16:

    # "Él te enfrenta, con molestia."
    "He faced you, annoyed."

# game/script.rpy:3384
translate english ruta_normal_27_7813825a:

    # "No se veía enojado, por lo que estabas a salvo por ahora."
    "He didn't seem angry, so you were safe for now."

# game/script.rpy:3385
translate english ruta_normal_27_94e8552e:

    # J "¡A nadie!"
    J "No one!"

# game/script.rpy:3386
translate english ruta_normal_27_8cbb3165:

    # J "Este es mi estilo original."
    J "This is my original style."

# game/script.rpy:3387
translate english ruta_normal_27_401e9d61:

    # J "Y no me arrepiento."
    J "And I don't regret it."

# game/script.rpy:3388
translate english ruta_normal_27_c0737491:

    # J "Me gusta cómo soy."
    J "I like how I am."

# game/script.rpy:3389
translate english ruta_normal_27_b6b1c0a7:

    # "Asientes en silencio, con una falsa expresión de comprensión."
    "You nodded in silence, with a fake expression of understanding."

# game/script.rpy:3392
translate english ruta_normal_27_8e82615f:

    # pov "Hey, está bien."
    pov "Hey, that's fine."

# game/script.rpy:3393
translate english ruta_normal_27_b4613844:

    # pov "Yo también pasé por fases en la adolescencia."
    pov "I also went through phases in adolescence."

# game/script.rpy:3394
translate english ruta_normal_27_ba57f941:

    # pov "Es normal."
    pov "It's normal."

# game/script.rpy:3395
translate english ruta_normal_27_14360a18_8:

    # J "…"
    J "..."

# game/script.rpy:3396
translate english ruta_normal_27_806236b5:

    # "Jeff se rasca la cabeza."
    "Jeff scratched his head."

# game/script.rpy:3401
translate english ruta_normal_28_8104acb1:

    # J "No te acomodes tanto, mañana volveré a buscarte."
    J "Don't get too comfortable, I'll come back for you tomorrow."

# game/script.rpy:3402
translate english ruta_normal_28_42baa75b:

    # pov "Oh, si, cierto."
    pov "Oh, right, sure."

# game/script.rpy:3403
translate english ruta_normal_28_79ef3c2e:

    # pov "Me estás acosando."
    pov "You're stalking me."

# game/script.rpy:3404
translate english ruta_normal_28_1fc1710f:

    # pov "Por un momento lo olvidé. Pasar el tiempo contigo como alguien normal no es tan malo."
    pov "For a moment I forgot. Spending time with you as a normal person wasn't so bad."

# game/script.rpy:3405
translate english ruta_normal_28_24bc2d63:

    # pov "Podría llamarlo una cita, incluso."
    pov "I could even call it a date."

# game/script.rpy:3406
translate english ruta_normal_28_dca56c1e:

    # "Estás hablando por hablar, pero puedes presenciar que tus palabras crearon una reacción en Jeff."
    "You were just talking, but you could see that your words created a reaction in Jeff."

# game/script.rpy:3407
translate english ruta_normal_28_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3408
translate english ruta_normal_28_ff8cf2ae:

    # J "¿Crees que alguien como yo puede experimentar cosas normales?"
    J "Do you think someone like me can experience normal things?"

# game/script.rpy:3409
translate english ruta_normal_28_49b83eda:

    # J "¿Cómo una cita?"
    J "Like a date?"

# game/script.rpy:3415
translate english ruta_normal_28_08f5c536:

    # pov "Si, claro."
    pov "Yeah, sure."

# game/script.rpy:3418
translate english ruta_normal_28_7f1e7d9c:

    # pov "Nah, para nada."
    pov "Nah, not at all."

# game/script.rpy:3428
translate english ruta_normal_29_f2d59205:

    # "Él se queda un segundo en silencio, para después depositar el vaso vacío sobre la barra y levantarse de su asiento."
    "He stood silently for a second, then placed the empty glass on the bar and rose from his seat."

# game/script.rpy:3429
translate english ruta_normal_29_25341a6a:

    # "Seguiste el movimiento de él, girándote desde el taburete."
    "You followed his movement, turning from your stool."

# game/script.rpy:3430
translate english ruta_normal_29_043ec79a:

    # J "Buenas noches, [povname], suerte para mañana."
    J "Good night, [povname], good luck tomorrow."

# game/script.rpy:3432
translate english ruta_normal_29_840d146b:

    # "Jeff hace el ademán de acercarse, alzando su mano hacia ti."
    "Jeff made a gesture to approach, raising his hand towards you."

# game/script.rpy:3433
translate english ruta_normal_29_330de78c:

    # "Ves que no saca el cuchillo, por lo que te inclinas a él."
    "You saw he wasn't pulling out the knife, so you leaned towards him."

# game/script.rpy:3437
translate english ruta_normal_29_31e2d9cc:

    # "Estrechas tu mano con la de él, en un apretón suave y cordial."
    "You shook his hand, a soft, cordial squeeze."

# game/script.rpy:3438
translate english ruta_normal_29_03cf4942:

    # "Ojalá lo hubieras conocido en este contexto mundano."
    "You wished you had met him in this mundane context."

# game/script.rpy:3439
translate english ruta_normal_29_af51d501:

    # pov "Me esforzaré."
    pov "I'll do my best."

# game/script.rpy:3440
translate english ruta_normal_29_0d12932b:

    # "Jeff asiente silenciosamente y se retira."
    "Jeff nodded silently and left."

# game/script.rpy:3446
translate english ruta_normal_29_7560e31e:

    # "Sujetas la mano de él con la tuya, pero lo atraes hacia ti y apoyas tu mejilla contra el costado de su rostro cubierto por la bandana."
    "You held his hand in yours, but you pulled him closer and rested your cheek against the side of his face covered by the bandana."

# game/script.rpy:3447
translate english ruta_normal_29_f95088bd:

    # pov "Nos vemos luego, Jeff."
    pov "See you later, Jeff."

# game/script.rpy:3448
translate english ruta_normal_29_895f962a:

    # "Susurras suavemente, cerca del oído de él."
    "You whispered softly, close to his ear."

# game/script.rpy:3449
translate english ruta_normal_29_a677f41f:

    # "Él no responde, de hecho sientes un espasmo en la mano de él."
    "He didn't respond, in fact you felt a spasm in his hand."

# game/script.rpy:3450
translate english ruta_normal_29_69c2eff9:

    # "Jeff se retira lentamente, ocultando sus ojos tras el fleco y la capucha."
    "Jeff slowly retreated, hiding his eyes behind his bangs and hood."

# game/script.rpy:3456
translate english ruta_normal_30_86a40ef8:

    # "Observas cómo él desaparece por la puerta del bar, y entonces te das cuenta que hay algo en tu mano."
    "You watched him disappear through the bar door, and then you realized there was something in your hand."

# game/script.rpy:3458
translate english ruta_normal_30_48b9879b:

    # "Es un papel arrugado, y cuando lo estiras ves que es un billete."
    "It was a crumpled piece of paper, and when you smoothed it out, you saw it was a bill."

# game/script.rpy:3461
translate english ruta_normal_30_7a87f7c0:

    # "Manchado con sangre."
    "Stained with blood."

# game/script.rpy:3462
translate english ruta_normal_30_93835778:

    # "Así que sí tenía para pagar después de todo."
    "So he did have money to pay after all."

# game/script.rpy:3465
translate english ruta_normal_30_441f6153:

    # "De todas maneras, no podías usar ese billete, te verán con sospecha."
    "Anyway, you couldn't use that bill; they'd look at you with suspicion."

# game/script.rpy:3466
translate english ruta_normal_30_e768e166:

    # "Decides quedarte un rato más, reflexionando sobre todo lo que acaba de pasar."
    "You decided to stay a little longer, reflecting on everything that had just happened."

# game/script.rpy:3467
translate english ruta_normal_30_6552b585:

    # "Ahora, sabes con seguridad que esta noche no va a pasar nada."
    "Now, you knew for sure that nothing bad would happen tonight."

# game/script.rpy:3468
translate english ruta_normal_30_0943c4cb:

    # "Pero debes tener cuidado, mañana se retoma el juego."
    "But you had to be careful; tomorrow, the game would resume."

# game/script.rpy:3485
translate english ruta_normal_30_f5a3f63b:

    # "Despiertas como siempre en la seguridad de tu habitación, con la diferencia de que no dejas de pensar lo que pasó la noche anterior."
    "You woke up as usual in the safety of your room, the only difference being that you couldn't stop thinking about what happened last night."

# game/script.rpy:3486
translate english ruta_normal_30_77aae322:

    # "Aún conservas el billete manchado con sangre que te dió Jeff."
    "You still had the blood-stained bill Jeff gave you."

# game/script.rpy:3487
translate english ruta_normal_30_abdaacac:

    # "Seguramente te lo dió sabiendo que no podías gastarlo, lo hizo a propósito."
    "He surely gave it to you knowing you couldn't spend it; he did it on purpose."

# game/script.rpy:3488
translate english ruta_normal_30_9b8e54df:

    # "Era… extraño."
    "It was... strange."

# game/script.rpy:3489
translate english ruta_normal_30_a32941b4:

    # "Por experiencia propia, sabes que él se comporta erráticamente."
    "From your own experience, you knew he behaved erratically."

# game/script.rpy:3490
translate english ruta_normal_30_f5da1d8a:

    # "Claro, de alguna forma te la has ingeniado para interactuar con él en momentos peligrosos donde tu vida está en juego."
    "Of course, somehow you had managed to interact with him in dangerous moments where your life was at stake."

# game/script.rpy:3491
translate english ruta_normal_30_630ea33b:

    # "Pero eso no quita que haya sido increíble que Jeff, tan impredecible como es, haya establecido cierta relación contigo."
    "But that didn't mean it wasn't incredible that Jeff, as unpredictable as he was, had established some sort of relationship with you."

# game/script.rpy:3492
translate english ruta_normal_30_feb9a5a7:

    # "Podías admitir que había momentos donde su compañía, cuando él no trataba de enterrar un cuchillo en tus entrañas, no era tan desagradable."
    "You could admit there were times when his company, when he wasn't trying to bury a knife in your guts, wasn't so unpleasant."

# game/script.rpy:3493
translate english ruta_normal_30_b57459d0:

    # "Era como si Jeff tuviera dos lados: Uno es el asesino desquiciado, y el otro es un tipo arrogante que no salía de su fase edgy."
    "It was as if Jeff had two sides: one was the deranged killer, and the other was an arrogant guy who never grew out of his edgy phase."

# game/script.rpy:3494
translate english ruta_normal_30_9d8a2c49:

    # "Oh no."
    "Oh no."

# game/script.rpy:3495
translate english ruta_normal_30_17a5966c:

    # "¿Esto se trataba del síndrome de Estocolmo?"
    "Was this the Stockholm Syndrome?"

# game/script.rpy:3496
translate english ruta_normal_30_7677e467:

    # "Otra casilla del bingo de novela visual."
    "Another box checked on the visual novel bingo card."

# game/script.rpy:3498
translate english ruta_normal_30_d379f5f2:

    # "De todas formas, hoy tenías que estar más en guardia."
    "Anyway, today you had to be more on guard."

# game/script.rpy:3499
translate english ruta_normal_30_8ba2b14a:

    # "Jeff volvería, y él ya conoce el terreno de tu departamento, por lo que estabas en desventaja."
    "Jeff would return, and he already knew the layout of your apartment, so you were at a disadvantage."

# game/script.rpy:3500
translate english ruta_normal_30_3d9de359:

    # "Tal vez tengas más chance si te vas a un hotel por esta noche."
    "Maybe you'd have a better chance if you went to a hotel tonight."

# game/script.rpy:3501
translate english ruta_normal_30_d02c7242:

    # "Lo más probable es que te siga la pista, pero las oportunidades de que te ataque caerían enormemente."
    "He'd most likely track you down, but the chances of him attacking you would decrease greatly."

# game/script.rpy:3502
translate english ruta_normal_30_836b2dc3:

    # "Sonaba como una estrategia. Cambiar frecuentemente tu ubicación."
    "It sounded like a strategy. Frequently changing your location."

# game/script.rpy:3505
translate english ruta_normal_30_dd14c851:

    # "De repente, tu timbre suena en medio de tu reflexión."
    "Suddenly, your doorbell rang in the middle of your reflection."

# game/script.rpy:3506
translate english ruta_normal_30_ce617998:

    # "…"
    "..."

# game/script.rpy:3507
translate english ruta_normal_30_a2d2ba46:

    # "No puede tratarse de Jeff, ¿Cierto?"
    "It couldn't be Jeff, right?"

# game/script.rpy:3508
translate english ruta_normal_30_fb3c4b3c:

    # "Él no es de la clase que toca timbres."
    "He's not the kind of guy who rings doorbells."

# game/script.rpy:3509
translate english ruta_normal_30_2e416f3f:

    # "¿Qué tan gracioso sería que fuera él?"
    "How funny would it be if it was him?"

# game/script.rpy:3511
translate english ruta_normal_30_ce617998_1:

    # "…"
    "..."

# game/script.rpy:3514
translate english ruta_normal_30_db1d330f:

    # "Te diriges a la puerta aún con tu ropa para dormir y te asomas por la mirilla en silencio."
    "You walked to the door still in your pajamas and peered through the peephole in silence."

# game/script.rpy:3515
translate english ruta_normal_30_01dd2783:

    # "Reconoces de inmediato el cabello castaño del Dr. Salazar."
    "You immediately recognized Dr. Salazar's brown hair."

# game/script.rpy:3518
translate english ruta_normal_30_63e8a612:

    # "Si, no."
    "Yeah, no."

# game/script.rpy:3519
translate english ruta_normal_30_9373d708:

    # "Es mejor no arriesgarte."
    "It's better not to risk it."

# game/script.rpy:3520
translate english ruta_normal_30_9c4a2d94:

    # DR "… ¿[povname]?"
    DR "… [povname]?"

# game/script.rpy:3521
translate english ruta_normal_30_c60084f6:

    # "Te sobresaltas al escuchar la voz apagada del Dr. Salazar del otro lado."
    "You jumped at the muffled voice of Dr. Salazar from the other side."

# game/script.rpy:3522
translate english ruta_normal_30_764bbfb7:

    # "Bueno, sustos que dan gusto dice el dicho."
    "Well, as the saying goes, chills and thrills"

# game/script.rpy:3529
translate english lol_94ad48cc:

    # "Desbloqueas las cerraduras de la puerta y la abres, dejándolo pasar."
    "You unlocked the door and opened it, letting him in."

# game/script.rpy:3532
translate english lol_124b3d7f:

    # pov "¿Qué haces aquí?"
    pov "What are you doing here?"

# game/script.rpy:3533
translate english lol_10d7a055:

    # "Salazar juega con sus manos nerviosamente."
    "Salazar fiddled nervously with his hands."

# game/script.rpy:3534
translate english lol_2f0b1666:

    # DR "Lo siento… No pude evitar preocuparme."
    DR "I'm sorry... I couldn't help but worry."

# game/script.rpy:3535
translate english lol_a8e28c4b:

    # pov "¿Huh?"
    pov "Huh?"

# game/script.rpy:3536
translate english lol_7e9f5557:

    # DR "Unos detectives me contactaron, preguntaron por tu ojo."
    DR "Some detectives contacted me, they asked about your eye."

# game/script.rpy:3537
translate english lol_7878583a:

    # pov "¿... Ok?"
    pov "...Okay?"

# game/script.rpy:3538
translate english lol_7ef0c636:

    # DR "[povname]... No lo tengo."
    DR "[povname]... I don't have it."

# game/script.rpy:3539
translate english lol_74267743:

    # pov "¿Disculpa?"
    pov "Excuse me?"

# game/script.rpy:3540
translate english lol_298d2928:

    # DR "Según el informe, cuando te trasladaron al hospital, recuperaron tu ojo."
    DR "According to the report, when you were transferred to the hospital, they recovered your eye."

# game/script.rpy:3541
translate english lol_c8901a34:

    # pov "¿Para qué recogerían un ojo inservible?"
    pov "Why would they pick up a useless eye?"

# game/script.rpy:3542
translate english lol_5980ee67:

    # "Salazar carraspea."
    "Salazar cleared his throat."

# game/script.rpy:3543
translate english lol_51055ef4:

    # DR "Es protocolo, tanto policial como médico. Todo lo encontrado en escena debe guardarse."
    DR "It's protocol, both police and medical. Everything found at the scene must be kept."

# game/script.rpy:3544
translate english lol_d9b6a177:

    # pov "De acuerdo, entiendo eso, ¿Pero qué quieres decir con que no lo tienes?"
    pov "Okay, I understand that, but what do you mean you don't have it?"

# game/script.rpy:3545
translate english lol_67cbcdce:

    # DR "Eso es lo extraño. Tu ojo está registrado en el hospital, pero cuando fui a revisar, no estaba."
    DR "That's the strange thing. Your eye is registered at the hospital, but when I went to check, it wasn't there."

# game/script.rpy:3546
translate english lol_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3547
translate english lol_93291e2c:

    # "Podías adivinar quién lo pudo haber tomado."
    "You could guess who might have taken it."

# game/script.rpy:3548
translate english lol_92bf0841:

    # DR "Creo que tu atacante está obsesionado contigo, ¿Has sentido que te siguen últimamente?"
    DR "I think your attacker is obsessed with you. Have you felt like you're being followed lately?"

# game/script.rpy:3549
translate english lol_0e33cbe8:

    # "Oh, el dulce e ingenuo doctor no tiene idea."
    "Oh, the sweet and naive doctor has no idea."

# game/script.rpy:3550
translate english lol_fbd2e09c:

    # "Te limitas a encogerte de hombros."
    "You simply shrugged."

# game/script.rpy:3551
translate english lol_855a37c6:

    # pov "Supongo."
    pov "I guess so."

# game/script.rpy:3552
translate english lol_c209892a:

    # DR "Yo… Tengo razones para pensar que vendrá por ti."
    DR "I... I have reasons to think he'll come for you."

# game/script.rpy:3553
translate english lol_3dfc5c25:

    # "Vaya, este doctor hace mucho más que sólo operarte, aparentemente. Se ofrece para ser tu príncipe de brillante armadura."
    "Wow, this doctor was doing a lot more than just operating on you, apparently. He was offering to be your shining armored prince."

# game/script.rpy:3554
translate english lol_3e06fb14:

    # pov "¿Eso quiere decir que estás aquí por mí?"
    pov "So, does that mean you're here for me?"

# game/script.rpy:3555
translate english lol_a6c98f36:

    # DR "Eh.. yo…"
    DR "Uh... I..."

# game/script.rpy:3556
translate english lol_79b54982:

    # pov "¿Vienes a cuidarme, Paul?"
    pov "Are you here to take care of me, Paul?"

# game/script.rpy:3557
translate english lol_419c25af:

    # pov "¿No crees que eso es favoritismo para un paciente entre muchos?"
    pov "Don't you think that's favoritism for one patient among many?"

# game/script.rpy:3560
translate english lol_72b198f4:

    # "El labio inferior de Salazar empezó a temblar levemente, sorprendiéndote."
    "Salazar's lower lip began to tremble slightly, surprising you."

# game/script.rpy:3561
translate english lol_f0f94bf6:

    # pov "Wow, cálmate, no es para tanto."
    pov "Wow, calm down, it's not that big of a deal."

# game/script.rpy:3562
translate english lol_9002dd5b:

    # DR "Tampoco lo entiendo…"
    DR "I don't understand it either..."

# game/script.rpy:3564
translate english lol_82db7efd:

    # "Tienes la sensación de deja vu, ya que alguien más te había dicho algo igual."
    "You had a sense of déjà vu, as someone else had told you something similar."

# game/script.rpy:3566
translate english lol_a02f3068:

    # DR "Eres… Increíble."
    DR "You're... incredible."

# game/script.rpy:3567
translate english lol_403ba90b:

    # DR "Nunca tuve un paciente como tú. Desde que despertaste y hablamos, me produces taquicardia, sudoración, confusión…"
    DR "I've never had a patient like you. Ever since you woke up and we talked, you've given me tachycardia, sweating, confusion..."

# game/script.rpy:3568
translate english lol_457fb31a:

    # "Pareciera que lo estás haciendo sentir enfermo con tanto término médico."
    "It seemed like you were making him feel sick with so much medical jargon."

# game/script.rpy:3569
translate english lol_af12650c:

    # "Pero entiendes la idea."
    "But you got the idea."

# game/script.rpy:3570
translate english lol_84e8e4f6:

    # DR "¿Esto es lo que… llamarían amor a primera vista?"
    DR "Is this what... they'd call love at first sight?"

# game/script.rpy:3571
translate english lol_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3572
translate english lol_29cf2a55:

    # "Ok, estabas en una situación algo complicada."
    "Okay, you were in a complicated situation."

# game/script.rpy:3573
translate english lol_301590d2:

    # "No todos los días viene tu doctor a tu departamento y confiesa su amor por ti."
    "Not every day does your doctor come to your apartment and confess his love for you."

# game/script.rpy:3574
translate english lol_848ae8f7:

    # "Pero ya te han pasado demasiadas cosas inusuales como para sorprenderte."
    "But you had already gone through too many unusual things to be surprised."

# game/script.rpy:3575
translate english lol_c6f61278:

    # pov "Paul, yo-"
    pov "Paul, I—"

# game/script.rpy:3578
translate english lol_b96599aa:

    # "Antes de que puedas responder, se escucha un toque en la puerta."
    "Before you could answer, there was a knock at the door."

# game/script.rpy:3579
translate english lol_3cb5aa16:

    # "¿Cuáles son las posibilidades?"
    "What are the chances?"

# game/script.rpy:3580
translate english lol_8ec664eb:

    # C "¡Soy yo!"
    C "It's me!"

# game/script.rpy:3582
translate english lol_9bed6c34:

    # "Te volteas a Salazar con una sonrisa torcida."
    "You turned to Salazar with a twisted smile."

# game/script.rpy:3583
translate english lol_8a51d2d5:

    # pov "Disculpa, tengo que atender-"
    pov "Excuse me, I have to get that—"

# game/script.rpy:3585
translate english lol_6dd11a02:

    # DR "[povname]."
    DR "[povname]."

# game/script.rpy:3586
translate english lol_04c38799:

    # "Repentinamente, él te sujeta la mano con firmeza, lo que te desconcierta."
    "Suddenly, he gripped your hand firmly, which confused you."

# game/script.rpy:3587
translate english lol_c1609263:

    # "Los ojos comúnmente calmos de él brillaban con desesperación."
    "His usually calm eyes gleamed with desperation."

# game/script.rpy:3588
translate english lol_c3c70fbb:

    # "No sabes qué pensar."
    "You didn't know what to think."

# game/script.rpy:3590
translate english lol_1c1fd878:

    # "Los golpes en la puerta se vuelven más insistentes."
    "The knocking on the door grew more insistent."

# game/script.rpy:3591
translate english lol_0a54cd1d:

    # C "¡Llamaré a la policía si no obtengo respuesta en 1…!"
    C "I'll call the police if I don't get an answer in 1...!"

# game/script.rpy:3593
translate english lol_ee816c05:

    # "Te liberas del agarre de Salazar y te apresuras a abrir la puerta."
    "You broke free from Salazar's grip and rushed to open the door."

# game/script.rpy:3594
translate english lol_5bff04d3:

    # pov "¡Ya voy, ya voy!, geez, estoy en algo aquí."
    pov "I'm coming, I'm coming! Geez, I'm in something here!"

# game/script.rpy:3601
translate english lol_7fe0a190:

    # "Cindy te mira con seriedad desde el momento que abres la puerta. Ella entra, con un montón de papeles en sus brazos."
    "Cindy looked at you seriously from the moment you opened the door. She entered, with a pile of papers in her arms."

# game/script.rpy:3602
translate english lol_d1552d0a:

    # C "Esto es urgente, tenemos- ¿Qué mierda?"
    C "This is urgent, we have— What the fuck?"

# game/script.rpy:3603
translate english lol_8b263ba6:

    # "Cindy se detiene en medio de la sala, viendo con confusión a Salazar, el cual se mantiene de brazos cruzados apoyado en una pared."
    "Cindy stopped in the middle of the living room, looking confused at Salazar, who remained leaning against a wall with his arms crossed."

# game/script.rpy:3604
translate english lol_0d78abe0:

    # C "¿Qué hace él aquí?"
    C "What's he doing here?"

# game/script.rpy:3605
translate english lol_77281e97:

    # pov "Oh, ehm… vino a verme."
    pov "Oh, um... he came to see me."

# game/script.rpy:3606
translate english lol_4046e08d:

    # "Ella alza una ceja hacia ti."
    "She raised an eyebrow at you."

# game/script.rpy:3607
translate english lol_7badbd4d:

    # C "¿Para qué?"
    C "What for?"

# game/script.rpy:3608
translate english lol_6cd7a3a3:

    # pov "Estaba preocupado por mí."
    pov "He was worried about me."

# game/script.rpy:3609
translate english lol_b62e81f2:

    # "Salazar desvía la mirada incómodamente."
    "Salazar averted his gaze uncomfortably."

# game/script.rpy:3610
translate english lol_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:3611
translate english lol_696f658b:

    # C "¿Síndrome de Florence Nightingale?"
    C "Florence Nightingale Syndrome?"

# game/script.rpy:3613
translate english lol_6c10fbfd:

    # "Salazar se ruboriza en su lugar."
    "Salazar blushed."

# game/script.rpy:3614
translate english lol_a769160a:

    # DR "¡Eso es-!"
    DR "That's—!"

# game/script.rpy:3615
translate english lol_39de5245:

    # pov "¿Qué es eso?"
    pov "What's that?"

# game/script.rpy:3617
translate english lol_30a4c58c:

    # C "Cuando el cuidador se enamora del paciente."
    C "When the caregiver falls in love with the patient."

# game/script.rpy:3618
translate english lol_d59119c0:

    # pov "Oh, entonces sí."
    pov "Oh, so it is."

# game/script.rpy:3619
translate english lol_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:3620
translate english lol_c750a803:

    # "Salazar protestó con las mejillas aún encendidas."
    "Salazar protested, his cheeks still flushed."

# game/script.rpy:3621
translate english lol_d0c5d05c:

    # "Te encoges de hombros despreocupadamente."
    "You shrugged nonchalantly."

# game/script.rpy:3622
translate english lol_d0430941:

    # pov "Tu viniste por tu cuenta."
    pov "You came on your own."

# game/script.rpy:3623
translate english lol_33964f79:

    # DR "Pensé que seríamos nosotros dos."
    DR "I thought it would be just us two."

# game/script.rpy:3629
translate english lol_9455b903:

    # "Cindy pasa a la cocina y deja el montón de papeles sobre tu mesa, mirando de soslayo a Salazar."
    "Cindy walked into the kitchen and put the pile of papers on your table, glancing sideways at Salazar."

# game/script.rpy:3630
translate english lol_940093e2:

    # pov "Ah, si, ¿A qué viniste, Cin?"
    pov "Oh, right, what did you come for, Cin?"

# game/script.rpy:3631
translate english lol_f05c477a:

    # C "Averigüe cosas sobre el rarito de la tienda."
    C "I found out some things about the weirdo from the store."

# game/script.rpy:3632
translate english lol_5cb80255:

    # "Tomas asiento, mirando con curiosidad los papeles."
    "You sat down, looking at the papers with curiosity."

# game/script.rpy:3633
translate english lol_21bfa775:

    # "Varían de noticias impresas de sitios web, hojas de peridódico con párrafos destacados, fotos de personas e informes."
    "They ranged from printed news articles from websites, newspaper pages with highlighted paragraphs, photos of people, and reports."

# game/script.rpy:3634
translate english lol_3f3663cf:

    # pov "¿De dónde sacaste todo esto?"
    pov "Where did you get all this?"

# game/script.rpy:3635
translate english lol_0b624bf8:

    # C "Tengo mis medios."
    C "I have my ways."

# game/script.rpy:3636
translate english lol_6150d308:

    # "Cindy tomó asiento contigo, apuntando las hojas de papel."
    "Cindy sat next to you, pointing at the papers."

# game/script.rpy:3637
translate english lol_df2a2a58:

    # C "Este tipo, Jeff, está involucrado en muchos asesinatos, y también incendios."
    C "This guy, Jeff, is involved in many murders, and also arsons."

# game/script.rpy:3638
translate english lol_e7187687:

    # C "Lleva fugitivo al menos 15 años. No tiene un perfil de víctimas en específico, son desde borrachos en la calle hasta familias de los suburbios."
    C "He's been a fugitive for at least 15 years. He doesn't have a specific victim profile; they range from street drunks to suburban families."

# game/script.rpy:3639
translate english lol_437b958a:

    # C " Sigue el mismo modus operandi, apuñala a sus víctimas en lugares vitales y les corta la boca, con un cuchillo de cocina."
    C "He follows the same modus operandi: he stabs his victims in vital spots and cuts their mouths with a kitchen knife."

# game/script.rpy:3640
translate english lol_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:3641
translate english lol_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3642
translate english lol_7f76495a_1:

    # C "…"
    C "..."

# game/script.rpy:3643
translate english lol_fc98751c:

    # C "El peor arma, si me preguntas a mí."
    C "The worst weapon, if you ask me."

# game/script.rpy:3644
translate english lol_5418c542:

    # "Pones los ojos en blanco ante el comentario de ella."
    "You rolled your eyes at her comment."

# game/script.rpy:3645
translate english lol_e78d9ab4:

    # pov "Continúa, por favor."
    pov "Continue, please."

# game/script.rpy:3647
translate english lol_3cd16a17:

    # "Cindy frunce el ceño, esparciendo los papeles para verlos todos juntos."
    "Cindy frowned, spreading the papers to see them all together."

# game/script.rpy:3648
translate english lol_e549f191:

    # C "Lo extraño es que nunca lo han atrapado."
    C "The strange thing is that he's never been caught."

# game/script.rpy:3649
translate english lol_8df4386b:

    # C "El tipo es muy descuidado. Usa ropa blanca, fácil de manchar, lleva el pelo largo, sin importarle dejar ADN, no lleva guantes, deja sus huellas por todas partes."
    C "The guy is very careless. He wears white clothes, easy to stain, has long hair, doesn't care about leaving DNA, doesn't wear gloves, leaves his fingerprints everywhere."

# game/script.rpy:3650
translate english lol_c4fa7ff1:

    # C "Lo buscan en varias regiones, y aún así nunca lo han arrestado."
    C "They're looking for him in several regions, and he's never been arrested."

# game/script.rpy:3651
translate english lol_e804627b:

    # C "No tiene dirección ni familia, ni siquiera se sabe con exactitud su pasado ni quién era antes."
    C "He has no address or family, and his past and who he used to be are not even known exactly."

# game/script.rpy:3652
translate english lol_e964df60:

    # C "Lo que me llama la atención… Es que para ser un simple tipo, su nivel de conveniencia supera lo normal."
    C "What strikes me... Is that for a simple guy, his level of convenience surpasses normal."

# game/script.rpy:3653
translate english lol_f4e250cc:

    # C "Logra escapar del fuego, evita las cámaras de seguridad, incluso sabe trepar muros. Es cómo… Si tuviera el guión de su lado."
    C "He manages to escape fire, avoids security cameras, even knows how to climb walls. It's like... he has the script on his side."

# game/script.rpy:3654
translate english lol_2660c90d:

    # pov "Haha, ¿Guión?, ¿De qué hablas?"
    pov "Haha, 'script'? What are you talking about?"

# game/script.rpy:3655
translate english lol_f7362b9f:

    # C "No lo digo literalmente. Es como si el universo estuviera de su lado."
    C "I don't mean it literally. It's like the universe is on his side."

# game/script.rpy:3656
translate english lol_e2a4bb75:

    # "Uf, eso estuvo cerca. No necesitamos otro personaje con autoconciencia narrativa."
    "Ugh, that was close. We don't need another character with narrative self-awareness."

# game/script.rpy:3657
translate english lol_ac3ecb47:

    # "Pero ahora que Cindy lo menciona, es verdad."
    "But now that Cindy mentioned it, it was true."

# game/script.rpy:3658
translate english lol_f45fef9a:

    # "Se supone que dieron su descripción física por las noticias, y aún así, se las arregla para seguirte durante el día, o para ir a un bar por la noche."
    "They supposedly gave his physical description on the news, and yet he managed to follow you during the day, or to go to a bar at night."

# game/script.rpy:3659
translate english lol_2578041a:

    # "Es como… Si fuera invisible para los demás."
    "It was as if... he was invisible to others."

# game/script.rpy:3660
translate english lol_b29a36ef:

    # "No, no hay plot twist de que en realidad él es parte de tu imaginación, o que es un fantasma."
    "No, no plot twist that he's actually part of your imagination, or that he's a ghost."

# game/script.rpy:3661
translate english lol_4a9fa1c2:

    # "Jeff es solamente muy escurridizo."
    "Jeff is just very elusive."

# game/script.rpy:3663
translate english lol_ee49931c:

    # DR "Con mayor razón tienes que tener cuidado, [povname]."
    DR "All the more reason you need to be careful, [povname]."

# game/script.rpy:3664
translate english lol_8049b509:

    # DR "Volverá por ti."
    DR "He'll come back for you."

# game/script.rpy:3665
translate english lol_975b7c12:

    # "Ya lo hizo y lo volverá hacer, pero no puedes decir eso en voz alta."
    "He already did and he'll do it again, but you can't say that out loud."

# game/script.rpy:3666
translate english lol_cfe8a43d:

    # C "¿De qué hablas?"
    C "What are you talking about?"

# game/script.rpy:3667
translate english lol_39f73aa1:

    # DR "Creo que está obsesionado con [povname]."
    DR "I think he's obsessed with [povname]."

# game/script.rpy:3668
translate english lol_fd51d5a5:

    # "Cindy te mira con seriedad."
    "Cindy looked at you seriously."

# game/script.rpy:3669
translate english lol_5b3d5093:

    # C "Si ese es el caso, no puedes quedarte aquí, al menos no por tu cuenta."
    C "If that's the case, you can't stay here, at least not on your own."

# game/script.rpy:3670
translate english lol_8b9cbd70:

    # pov "¿Entonces cuál es la idea, piensan quedarse conmigo 24/7?"
    pov "So what's the idea, do you plan to stay with me 24/7?"

# game/script.rpy:3673
translate english lol_7f76495a_2:

    # C "…"
    C "..."

# game/script.rpy:3674
translate english lol_723c69de_1:

    # DR "…"
    DR "..."

# game/script.rpy:3675
translate english lol_86305ee3:

    # pov "Oh no, lo es."
    pov "Oh no, it is."

# game/script.rpy:3676
translate english lol_5548f283:

    # C "No es la solución más elegante, pero me aseguraré de que estés bien."
    C "It's not the most elegant solution, but I'll make sure you're okay."

# game/script.rpy:3677
translate english lol_f2355920:

    # DR "Yo puedo protegerte."
    DR "I can protect you."

# game/script.rpy:3678
translate english lol_3e9dd253:

    # "De repente, Cindy y Salazar se miran en silencio."
    "Suddenly, Cindy and Salazar looked at each other in silence."

# game/script.rpy:3680
translate english lol_9b99acfd:

    # C "Yo me quedaré con [povname]. Soy su compañera de trabajo, nos conocemos desde hace más tiempo."
    C "I'll stay with [povname]. I'm their coworker, we've known each other longer."

# game/script.rpy:3681
translate english lol_b08290d3:

    # DR "Soy su doctor, tengo el deber de velar por su bienestar."
    DR "I'm their doctor, I have a duty to look after their well-being."

# game/script.rpy:3682
translate english lol_467ef742:

    # C "Lo que estás haciendo, y me refiero venir a su casa, no es para nada profesional para un doctor."
    C "What you're doing, coming to their house, is totally unprofessional for a doctor."

# game/script.rpy:3683
translate english lol_0aeb9634:

    # C "Podría decir que estás acosando a [povname]. ¿Cómo supiste donde vivía?, ¿Lo viste en su expediente?"
    C "You could say you're stalking [povname]. How did you know where they lived? Did you see it in their file?"

# game/script.rpy:3685
translate english lol_95da8c07:

    # DR "¡Nos encontramos ayer!, fue pura casualidad- hasta me atrevería decir que fue el destino."
    DR "We met yesterday! It was pure coincidence—I'd even say it was fate."

# game/script.rpy:3686
translate english lol_bf7fb264:

    # "Cindy resopla una risa irónica."
    "Cindy snorted an ironic laugh."

# game/script.rpy:3687
translate english lol_6e81cb9f:

    # C "¿Vas a hablar de destino?, ¿En serio?"
    C "Are you going to talk about fate? Seriously?"

# game/script.rpy:3689
translate english lol_0b9c060c:

    # pov "Chicos, ¿Podemos relajarnos un momento?"
    pov "Guys, can we just relax for a moment?"

# game/script.rpy:3690
translate english lol_1d7d2b6f:

    # "Los dos se callan y te miran."
    "They both fell silent and looked at you."

# game/script.rpy:3691
translate english lol_6f8b19e9:

    # "Los miras con aburrimiento."
    "You looked at them with boredom."

# game/script.rpy:3692
translate english lol_766bc61f:

    # pov "¿Me dejan ir a bañarme?, Todavía estoy en mi ropa para dormir."
    pov "Are you going to let me bathe? I'm still in my pajamas."

# game/script.rpy:3695
translate english lol_6409361a:

    # "Repentinamente, ambos desvían la mirada, con las mejillas encendidas."
    "Suddenly, both looked away, their cheeks flushed."

# game/script.rpy:3696
translate english lol_6429ba86:

    # C "Ah, claro, claro…"
    C "Oh, sure, sure..."

# game/script.rpy:3697
translate english lol_a2956b58:

    # DR "Lo siento, adelante…"
    DR "I'm sorry, go ahead..."

# game/script.rpy:3698
translate english lol_83f7f650:

    # "Te retiras de la cocina y vas al baño."
    "You retreated from the kitchen and went to the bathroom."

# game/script.rpy:3700
translate english lol_4a6713e5:

    # "No esperabas recibir tanta visita, tampoco que vinieran a tu rescate."
    "You didn't expect so many visitors, nor that they would come to your rescue."

# game/script.rpy:3701
translate english lol_432caa29:

    # "Parecía casi como si te hubieras echado perfume de feromonas o algo así, ya que atraes a tanta gente."
    "It almost seemed like you had put on pheromone perfume or something, attracting so many people."

# game/script.rpy:3707
translate english lol_8c76ab47:

    # "Al final, ellos decidieron quedarse contigo durante el día."
    "In the end, they decided to stay with you during the day."

# game/script.rpy:3708
translate english lol_bce6c146:

    # "El plan de ir a un hotel se había ido por la borda, ya que se podría decir que te atraparon dentro de tu departamento."
    "The plan to go to a hotel had fallen through, as it could be said you were trapped inside your apartment."

# game/script.rpy:3709
translate english lol_0ad70050:

    # "Si mostrabas interés en salir, Cindy y Salazar saltaban de sus lugares y te seguían como patitos bebés hacia su mamá pato."
    "If you showed any interest in leaving, Cindy and Salazar would jump up and follow you like baby ducks to their mother."

# game/script.rpy:3710
translate english lol_9461ca12:

    # "Así que no podías costear ir a un hotel con dos personas más, además de que no querías estar en deuda con ellos si se ofrecían a pagar."
    "So you couldn't afford to go to a hotel with two other people, plus you didn't want to owe them if they offered to pay."

# game/script.rpy:3711
translate english lol_1846f626:

    # "Se estaba tornando cansador la vigilancia sobre ti."
    "Being watched was becoming tiresome."

# game/script.rpy:3713
translate english lol_2685493b:

    # "Hasta que llegó la noche."
    "Until night fell."

# game/script.rpy:3714
translate english lol_c0f66587:

    # "Con cada minuto, los nervios subían por tu cuerpo, ya que mientras más se oscurecía, más grande era la probabilidad de que Jeff llegara."
    "With every minute, your nerves rose, because the darker it got, the greater the probability that Jeff would arrive."

# game/script.rpy:3720
translate english lol_82578fa0:

    # DR "Se está volviendo tarde, Cindy, deberías volver a tu casa pronto."
    DR "It's getting late, Cindy, you should go home soon."

# game/script.rpy:3722
translate english lol_d27eb48a:

    # C "¿Yo?, ¿Qué me dices de ti?, ¿No tienes un trabajo que hacer en el hospital?"
    C "Me? What about you? Don't you have a job to do at the hospital?"

# game/script.rpy:3723
translate english lol_affcc77f:

    # DR "Mi turno empieza mañana."
    DR "My shift starts tomorrow."

# game/script.rpy:3724
translate english lol_3d9ed6fc:

    # C "Sí, bueno, conozco mejor a [povname]. Si alguien debería quedarse en la noche, debería ser yo."
    C "Yes, well, I know [povname] better. If anyone should stay tonight, it should be me."

# game/script.rpy:3725
translate english lol_1f361abf:

    # DR "¿Qué es más seguro que un doctor?"
    DR "What's safer than a doctor?"

# game/script.rpy:3726
translate english lol_642f7fb6:

    # "Cindy y Salazar se fulminan con la mirada, mientras tú aguantas."
    "Cindy and Salazar glared at each other, while you waited."

# game/script.rpy:3727
translate english lol_920a57f1:

    # pov "No quiero tener a los dos aquí esta noche, fue suficiente tenerlos todo el día."
    pov "I don't want both of you here tonight; having you all day was enough."

# game/script.rpy:3728
translate english lol_86f95e7b:

    # C "Entonces tu decide."
    C "Then you decide."

# game/script.rpy:3729
translate english lol_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:3730
translate english lol_d5700b15:

    # DR "O nos quedamos ambos, o uno. Pero no ninguno."
    DR "Either we both stay, or one. But not none."

# game/script.rpy:3731
translate english lol_6b3229ea:

    # "Para acorralarte, saben trabajar en equipo, ¿no?"
    "To corner you, they knew how to work as a team, didn't they?"

# game/script.rpy:3745
translate english salazar_2f7b6d00:

    # pov "Elijo al doctor."
    pov "I choose the doctor."

# game/script.rpy:3747
translate english salazar_9cb1e624:

    # "Salazar sonríe, triunfante."
    "Salazar smiled triumphantly."

# game/script.rpy:3748
translate english salazar_fb97a381:

    # C "¿En serio?"
    C "Seriously?"

# game/script.rpy:3749
translate english salazar_c191c049:

    # "Te encoges de hombros."
    "You shrugged."

# game/script.rpy:3750
translate english salazar_58759d1e:

    # "¿La oportunidad de pasar la noche con un doctor guapo?, No querías desperdiciarlo."
    "The chance to spend the night with a handsome doctor? You didn't want to miss it."

# game/script.rpy:3751
translate english salazar_f841f260:

    # DR "No te preocupes, cuidaré bien de [povname]."
    DR "Don't worry, I'll take good care of [povname]."

# game/script.rpy:3752
translate english salazar_af0d704a:

    # C "Más te vale."
    C "You better."

# game/script.rpy:3757
translate english salazar_5827f328:

    # "Cindy toma sus cosas y se dirige a la puerta, tu la sigues para abrirle y despedirla."
    "Cindy gathered her things and headed for the door; you followed her to open it and say goodbye."

# game/script.rpy:3758
translate english salazar_c98342b6:

    # pov "Gracias por venir, en serio."
    pov "Thanks for coming, really."

# game/script.rpy:3759
translate english salazar_16c87ee6:

    # pov "Creo… Que me hacía falta sentir que me cuidan."
    pov "I guess... I needed to feel cared for."

# game/script.rpy:3761
translate english salazar_f7b50ae9:

    # "Cindy te mira de reojo, y sonríe levemente."
    "Cindy glanced at you sideways, and smiled faintly."

# game/script.rpy:3762
translate english salazar_45625aa7:

    # C "Sí, cuando quieras."
    C "Yeah, anytime."

# game/script.rpy:3764
translate english salazar_2945ae96:

    # "Ella rodea tu hombro con el brazo y te da un beso en la mejilla como despedida."
    "She wrapped her arm around your shoulder and gave you a kiss on the cheek as a farewell."

# game/script.rpy:3765
translate english salazar_feb8ea57:

    # "Cindy desaparece tras la puerta, y te quedas con Salazar."
    "Cindy disappeared behind the door, and you were left with Salazar."

# game/script.rpy:3769
translate english salazar_03245aa1:

    # pov "¿Quieres cenar?"
    pov "Do you want dinner?"

# game/script.rpy:3770
translate english salazar_7114bff8:

    # DR "Oh, puedo cocinar algo."
    DR "Oh, I can cook something."

# game/script.rpy:3771
translate english salazar_7bb763ab:

    # pov "No señor, ya haces demasiado con quedarte aquí, déjame servirte."
    pov "No sir, you're doing too much just by staying here, let me serve you."

# game/script.rpy:3772
translate english salazar_9422ccca:

    # DR "Te ayudaré entonces."
    DR "I'll help you then."

# game/script.rpy:3773
translate english salazar_a1785aa4:

    # "Te ríes levemente ante la insistencia de él."
    "You chuckled softly at his insistence."

# game/script.rpy:3774
translate english salazar_148da79d:

    # "Es indiscutiblemente adorable."
    "He was undeniably cute."

# game/script.rpy:3775
translate english salazar_cb598581:

    # "Ustedes empiezan a moverse dentro de la cocina."
    "You both began to move around the kitchen."

# game/script.rpy:3780
translate english salazar_e58c7bc0:

    # pov "Así que, ¿Eres oculista o algo así?"
    pov "So, are you an ophthalmologist or something?"

# game/script.rpy:3781
translate english salazar_d8a40bc7:

    # DR "Soy cirujano."
    DR "I'm a surgeon."

# game/script.rpy:3782
translate english salazar_f98a817f:

    # pov "¿Hace cuánto que ejerces?"
    pov "How long have you been practicing?"

# game/script.rpy:3783
translate english salazar_25502407:

    # DR "Completé mi residencia hace 4 años. Fue duro, sobre todo porque tengo TDAH."
    DR "I completed my residency 4 years ago. It was tough, especially because I have ADHD."

# game/script.rpy:3784
translate english salazar_35031104:

    # DR "Pero con ayuda de profesores pude sobrellevarlo."
    DR "But with the help of professors, I managed."

# game/script.rpy:3785
translate english salazar_75cb5173:

    # pov "Me alegro. Soy la prueba viviente de que haces un estupendo trabajo."
    pov "I'm glad. I'm living proof that you do an excellent job."

# game/script.rpy:3788
translate english salazar_9b834060:

    # pov "Entonces, ¿El destino, amor a primera vista?"
    pov "So, fate, love at first sight?"

# game/script.rpy:3789
translate english salazar_1b4aadbd:

    # pov "Como hombre de ciencia, no pensé que creerías en esas cosas."
    pov "As a man of science, I didn't think you'd believe in such things."

# game/script.rpy:3791
translate english salazar_54f0d528:

    # "Ves como Salazar se sonroja."
    "You watched Salazar blush."

# game/script.rpy:3792
translate english salazar_d6ef3f8e:

    # DR "No te burles de mí."
    DR "Don't tease me."

# game/script.rpy:3793
translate english salazar_09ec5844:

    # pov "No, no, es lindo."
    pov "No, no, it's cute."

# game/script.rpy:3794
translate english salazar_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3795
translate english salazar_db415736:

    # DR "¿Tu crees?"
    DR "You think?"

# game/script.rpy:3796
translate english salazar_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:3803
translate english salazar2_3494407d:

    # "Salazar sonríe ante tus palabras, observándote mientras sacas los ingredientes para cocinar."
    "Salazar smiled at your words, watching you take out ingredients for cooking."

# game/script.rpy:3804
translate english salazar2_4162d12c:

    # DR "¿Qué vamos a cenar?"
    DR "What are we having for dinner?"

# game/script.rpy:3807
translate english salazar2_a83a462a:

    # pov "Risotto de champiñones."
    pov "Mushroom risotto."

# game/script.rpy:3808
translate english salazar2_13695833:

    # pov "¿Está bien?"
    pov "Is that okay?"

# game/script.rpy:3809
translate english salazar2_ba2b2537:

    # DR "Por supuesto, no soy quisquilloso."
    DR "Of course, I'm not picky."

# game/script.rpy:3811
translate english salazar2_1c968cb7:

    # pov "Espagueti con boloñesa."
    pov "Spaghetti with bolognese."

# game/script.rpy:3812
translate english salazar2_4660b495:

    # DR "Ah, que rico."
    DR "Oh, that's delicious."

# game/script.rpy:3813
translate english salazar2_4c98e8bf:

    # pov "¿Te gusta?"
    pov "You like it?"

# game/script.rpy:3814
translate english salazar2_332976ea:

    # DR "Diría que es mi platillo favorito."
    DR "I'd say it's my favorite dish."

# game/script.rpy:3816
translate english salazar2_f59c34cc:

    # "Ustedes toman asiento en la mesa y comen."
    "You both sat at the table and ate."

# game/script.rpy:3817
translate english salazar2_12195f94:

    # "La velada es bastante íntima, parece… como si tuvieran una cita."
    "The evening felt quite intimate, almost... like a date."

# game/script.rpy:3821
translate english salazar2_a1876a9b:

    # pov "Así que al final pudimos tener nuestra cita."
    pov "So in the end, you finally had your date."

# game/script.rpy:3823
translate english salazar2_0d81ac85:

    # DR "¿Huh?"
    DR "Huh?"

# game/script.rpy:3824
translate english salazar2_5254ae5c:

    # pov "Qué estrategia. Venir a protegerme para lograrlo."
    pov "What a strategy. Coming to protect me to achieve it."

# game/script.rpy:3826
translate english salazar2_ecd68f72:

    # "Salazar carraspea y se limpia la boca."
    "Salazar cleared his throat and wiped his mouth."

# game/script.rpy:3827
translate english salazar2_a23fa959:

    # DR "Te aseguro que mis intenciones son genuinamente de preocupación."
    DR "I assure you my intentions are genuinely out of concern."

# game/script.rpy:3828
translate english salazar2_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3830
translate english salazar2_73fa7511:

    # DR "Que eso haya acabado en una cita fue un bonus."
    DR "That it ended up being a date was a bonus."

# game/script.rpy:3831
translate english salazar2_cabb102c:

    # pov "¡Hey!"
    pov "Hey!"

# game/script.rpy:3832
translate english salazar2_e4991e5b:

    # "Salazar se ríe ante tu reacción a su respuesta."
    "Salazar laughed at your reaction to his answer."

# game/script.rpy:3833
translate english salazar2_2b92f220:

    # "Parece que se está acostumbrando a ti."
    "It seemed he was getting used to you."

# game/script.rpy:3836
translate english salazar2_10a26677:

    # pov "¿Se adapta a tu gusto?"
    pov "Does it suit your taste?"

# game/script.rpy:3837
translate english salazar2_17f89897:

    # DR "Sí, definitivamente."
    DR "Yes, definitely."

# game/script.rpy:3838
translate english salazar2_e0c893cc:

    # DR "Cocinas bien."
    DR "You cook well."

# game/script.rpy:3839
translate english salazar2_9e3b862c:

    # pov "No exageres, es algo simple."
    pov "Don't exaggerate, it's a simple dish."

# game/script.rpy:3840
translate english salazar2_36c3d5d5:

    # "Salazar te sonríe levemente, murmurando para sí mismo."
    "Salazar smiled faintly at you, murmuring to himself."

# game/script.rpy:3841
translate english salazar2_67311c74:

    # DR "Podría comerlo todos los días…"
    DR "I could eat it every day..."

# game/script.rpy:3846
translate english salazar3_aa583df7:

    # DR "Así que, dime [povname], ¿A qué te dedicas?"
    DR "So, tell me [povname], what do you do?"

# game/script.rpy:3847
translate english salazar3_1f7f5268:

    # pov "Oh, no es la gran cosa, sólo soy dependiente en una tienda de películas."
    pov "Oh, it's no big deal, I'm just an attendant at a video store."

# game/script.rpy:3848
translate english salazar3_29e9b86a:

    # DR "Oh, ¿Como un blockbuster?"
    DR "Oh, like a blockbuster?"

# game/script.rpy:3849
translate english salazar3_78bdadea:

    # pov "Básicamente, pero es sólo una tienda local, no una cadena."
    pov "Basically, but it's just a local store, not a chain."

# game/script.rpy:3850
translate english salazar3_6d594a6a:

    # pov "El dueño es un amante del séptimo arte, y también el padre de Cin."
    pov "The owner is an cinema lover, and also Cin's father."

# game/script.rpy:3851
translate english salazar3_05d5ba1d:

    # DR "Ah, ya veo."
    DR "Ah, I see."

# game/script.rpy:3852
translate english salazar3_9e8a2215:

    # DR "¿No hay nepotismo?"
    DR "No nepotism?"

# game/script.rpy:3853
translate english salazar3_d186a46f:

    # pov "Para nada. De hecho, creo que a mi jefe le frustra que Cindy no comparta su pasión."
    pov "Not at all. In fact, I think my boss is frustrated that Cindy doesn't share his passion."

# game/script.rpy:3854
translate english salazar3_2cbac6b6:

    # DR "¿Qué me dices de ti?"
    DR "What about you?"

# game/script.rpy:3855
translate english salazar3_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:3856
translate english salazar3_a72770d2:

    # DR "¿Te apasionan las películas?"
    DR "Are you passionate about movies?"

# game/script.rpy:3858
translate english salazar3_5336a684:

    # pov "Claro, es lo que me hace disfrutar un poco más mi trabajo."
    pov "Of course, it's what makes me enjoy my job a little more."

# game/script.rpy:3859
#translate english salazar3_4d241c1c:

    # pov "Pero considerando que ya casi nadie compra películas porque prefieren verlas por streaming, el negocio no prospera como lo haría en el pasado."
    #pov "But considering almost no one buys movies anymore because they prefer streaming, the business isn't as prosperous as it used to be."

# game/script.rpy:3861
translate english salazar3_fa1b1549:

    # pov "La verdad es que no mucho."
    pov "Truth is, not really."

# game/script.rpy:3862
translate english salazar3_f178c85e:

    # pov "El trabajo me sirve porque está cerca de donde vivo y la paga es buena."
    pov "The job suits me because it's close to where I live and the pay is good."

# game/script.rpy:3863
translate english salazar3_732ab2cd:

    # pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "Anyway, my last memory from there isn't very pleasant."

# game/script.rpy:3864
translate english salazar3_356b26c9:

    # pov "Todavía tenía los dos ojos."
    pov "I still had both eyes."

# game/script.rpy:3866
translate english salazar3_2c86f2d5:

    # "Salazar se remueve incómodo ante tu comentario."
    "Salazar shifted uncomfortably at your comment."

# game/script.rpy:3867
translate english salazar3_fb8e715b:

    # DR "Me hubiera gustado poder recuperar tu ojo, pero…"
    DR "I wish I could have saved your eye, but..."

# game/script.rpy:3868
translate english salazar3_3d4aeb98:

    # pov "Lo entiendo, no te preocupes."
    pov "I understand, don't worry."

# game/script.rpy:3869
translate english salazar3_cde22bdc:

    # pov "El cuerpo humano es frágil."
    pov "The human body is fragile."

# game/script.rpy:3871
translate english salazar3_487c2e57:

    # DR "Cierto. Es imposible para nosotros crear un órgano o extremidad a gusto, hay que proteger nuestro cuerpo."
    DR "True. It's impossible for us to create an organ or limb at will; we must protect our bodies."

# game/script.rpy:3872
translate english salazar3_f0fa9ff9:

    # "La seriedad en la voz de Salazar te deja en silencio. Claro, siendo doctor, es parte de su trabajo velar por la seguridad del cuerpo humano."
    "The seriousness in Salazar's voice left you silent. Of course, as a doctor, it was part of his job to look after the safety of the human body."

# game/script.rpy:3873
translate english salazar3_944eea90:

    # "Pero podías ver preocupación verdadera por la vida."
    "But you could see genuine concern for life."

# game/script.rpy:3875
translate english salazar3_52a9f735:

    # "Viendo los platos vacíos, haces el ademán de levantarte, pero Salazar te detiene con un gesto de su mano."
    "Seeing the empty plates, you made a move to get up, but Salazar stopped you with a gesture of his hand."

# game/script.rpy:3876
translate english salazar3_c8695aa7:

    # DR "Yo lavaré los platos."
    DR "I'll do the dishes."

# game/script.rpy:3877
translate english salazar3_a5c191d7:

    # "Alzas las manos en derrota."
    "You threw up your hands in defeat."

# game/script.rpy:3878
translate english salazar3_364f35a4:

    # pov "Lo que digas."
    pov "Whatever you say."

# game/script.rpy:3880
translate english salazar3_92a5850d:

    # "Observas cómo él se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "You watched him get up with the used plates, utensils, and glasses, and go to the sink, starting to maneuver with the water and detergent."

# game/script.rpy:3881
translate english salazar3_e6f7560f:

    # "Te quedas cerca, admirando la figura de su espalda ancha y sus brazos moviéndose."
    "You stayed close, admiring the broadness of his back and his moving arms."

# game/script.rpy:3882
translate english salazar3_afcbbbf2:

    # pov "Así que… Sólo tengo una cama."
    pov "So... I only have one bed."

# game/script.rpy:3884
translate english salazar3_7fd2734b:

    # "Los platos se le caen de las manos a Salazar, pero afortunadamente dentro del lavadero."
    "The plates slipped from Salazar's hands, but fortunately, they stayed in the sink."

# game/script.rpy:3886
translate english salazar3_afe607a0:

    # DR "N-no te preocupes, puedo dormir en el sofá."
    DR "D-don't worry, I can sleep on the sofa."

# game/script.rpy:3887
translate english salazar3_2399dfd5:

    # DR "No podría abusar de tu hospitalidad…"
    DR "I couldn't abuse your hospitality..."

# game/script.rpy:3891
translate english salazar3_ca4afc7e:

    # pov "Hey, tranquilo."
    pov "Hey, calm down."

# game/script.rpy:3892
translate english salazar3_10e5d453:

    # pov "No tenemos que hacer nada."
    pov "We don't have to do anything."

# game/script.rpy:3893
translate english salazar3_8ffabcbf:

    # pov "Pero no me gusta la idea de dejarte solo con un asesino suelto, mejor juntos que separados, ¿No?"
    pov "But I don't like the idea of leaving you alone with a loose killer; better together than separate, right?"

# game/script.rpy:3896
translate english salazar3_d3ec7b81:

    # pov "No te preocupes, no va a pasar nada."
    pov "Don't worry, nothing's going to happen."

# game/script.rpy:3897
translate english salazar3_7afa90de:

    # pov "Mi cama es lo suficientemente grande."
    pov "My bed is big enough."

# game/script.rpy:3898
translate english salazar3_1b10b761:

    # pov "Me sentiré mal si te dejo durmiendo en mi duro sofá."
    pov "I'd feel bad if I left you sleeping on my hard sofa."

# game/script.rpy:3905
translate english salazar4_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3906
translate english salazar4_005c554f:

    # DR "De acuerdo."
    DR "Okay."

# game/script.rpy:3907
translate english salazar4_05f7534a:

    # "Asientes levemente, retirándote de la cocina."
    "You nodded slightly, retreating from the kitchen."

# game/script.rpy:3908
translate english salazar4_89c67d48:

    # pov "Iré a prepararme para dormir."
    pov "I'll go get ready for bed."

# game/script.rpy:3910
translate english salazar4_d3bb59d0:

    # "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "You went to the bathroom, where you showered and put on your sleep clothes."

# game/script.rpy:3911
translate english salazar4_36efb37c:

    # "Por un momento te detienes frente al espejo."
    "For a moment, you stopped in front of the mirror."

# game/script.rpy:3912
translate english salazar4_812d7ddc:

    # "Tienes un poco de nervios por pasar la noche con Salazar, pero había algo más…"
    "You were a little nervous about spending the night with Salazar, but there was something else..."

# game/script.rpy:3913
translate english salazar4_744ba675:

    # "Si Jeff venía…"
    "If Jeff came..."

# game/script.rpy:3914
translate english salazar4_4c031422:

    # "No, no debías pensar así."
    "No, you shouldn't think that way."

# game/script.rpy:3915
translate english salazar4_44f55333:

    # "Él era un cobarde, sólo te atacaba cuando estabas a solas."
    "He was a coward; he only attacked you when you were alone."

# game/script.rpy:3916
translate english salazar4_a9ad4690:

    # "Si, eso era seguro."
    "Yes, that was certain."

# game/script.rpy:3917
translate english salazar4_2f8afdd7:

    # "Técnicamente, tener a alguien contigo era evitarlo."
    "Technically, having someone with you avoided it."

# game/script.rpy:3918
translate english salazar4_2d44ad4c:

    # "Él mismo lo había dicho, este juego era entre ustedes dos. Así que Jeff no debería involucrar a Salazar."
    "He himself had said that this game was between the two of you. So Jeff shouldn't involve Salazar."

# game/script.rpy:3922
translate english salazar4_c68da183:

    # "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Salazar."
    "With that in mind, you left the bathroom and went back to the kitchen, to look for Salazar."

# game/script.rpy:3923
translate english salazar4_dccb1337:

    # pov "El baño está libre, por si quieres usarlo. Es la puerta al fondo del pasillo, a la izquierda."
    pov "The bathroom is free, if you want to use it."

# game/script.rpy:3924
translate english salazar4_5d91858d:

    # DR "Oh, gracias."
    DR "Oh, thanks."

# game/script.rpy:3925
translate english salazar4_f0b8251b:

    # pov "Mi habitación es la puerta de enfrente."
    pov "My room is the door across."

# game/script.rpy:3926
translate english salazar4_723c69de_1:

    # DR "…"
    DR "..."

# game/script.rpy:3927
translate english salazar4_bf6b01c5:

    # DR "S-sí…"
    DR "Y-yeah..."

# game/script.rpy:3928
translate english salazar4_c1b51dda:

    # "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    "You nodded silently and went back the way you came, this time heading for your room."

# game/script.rpy:3932
translate english salazar4_3b666ceb:

    # "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Salazar."
    "You lay down on the bed, making sure to leave space for Salazar."

# game/script.rpy:3933
translate english salazar4_0bec2b3e:

    # "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "From your spot, you heard the lights being turned off and on, and the water running."

# game/script.rpy:3934
translate english salazar4_8ab1535a:

    # "Unos instantes después, Salazar avanzaba hacia ti, lentamente, como si temiera sobresaltarte."
    "A few moments later, Salazar walked slowly towards you, as if fearing to startle you."

# game/script.rpy:3935
translate english salazar4_86f6bfdc:

    # pov "Adelante, no muerdo."
    pov "Go ahead, I don't bite."

# game/script.rpy:3942
translate english salazar4_daf8ad5e:

    # "Con la escasa luz, alcanzas a ver que él sonreía levemente ante tu broma, pero se mantuvo en silencio mientras se acomodaba bajo las sábanas junto a ti."
    "In the dim light, you could see him smiling faintly at your joke, but he remained silent as he settled under the covers next to you."

# game/script.rpy:3943
translate english salazar4_4df2ba05:

    # "Él fue cuidadoso, pero no pudo evitar rozar su pierna con la tuya."
    "He was careful, but couldn't help but brush his leg against yours."

# game/script.rpy:3944
translate english salazar4_dd316d3a:

    # DR "Lo siento, yo no-"
    DR "I'm sorry, I didn't—"

# game/script.rpy:3945
translate english salazar4_73aa2c46:

    # pov "Está bien."
    pov "It's okay."

# game/script.rpy:3946
translate english salazar4_2ba06661:

    # pov "No soy tan frágil, ¿Sabes?"
    pov "I'm not that fragile, you know?"

# game/script.rpy:3947
translate english salazar4_3f0ad104:

    # "Él te mira, sus ojos brillando con la escasa luz."
    "He looked at you, his eyes shining in the dim light."

# game/script.rpy:3948
translate english salazar4_ddd79075:

    # DR "Temo que por pensar así, no vas a tener cuidado."
    DR "I'm afraid that by thinking that, you won't be careful."

# game/script.rpy:3949
translate english salazar4_e65934ca:

    # "Bueno, no estaba del todo equivocado."
    "Well, he wasn't entirely wrong."

# game/script.rpy:3950
translate english salazar4_3135bcf1:

    # "Al final, todo se remonta a lo que sucedió con Jeff."
    "In the end, it all came back to what happened with Jeff."

# game/script.rpy:3951
translate english salazar4_07d3ac4f:

    # "Tal vez si no te hubiera atacado, nunca hubieras conocido a Salazar."
    "Perhaps if he hadn't attacked you, you would never have met Salazar."

# game/script.rpy:3952
translate english salazar4_5aacd7c1:

    # pov "¿Por qué yo?"
    pov "Why me?"

# game/script.rpy:3953
translate english salazar4_7b9a00e2:

    # pov "¿Qué tengo de especial?"
    pov "What's so special about me?"

# game/script.rpy:3955
translate english salazar4_a6a132c5:

    # "Inesperadamente, sientes que la mano de él roza tu mejilla, y acaricia con su pulgar delicadamente."
    "Unexpectedly, you felt his hand brush your cheek, and his thumb gently caressed it."

# game/script.rpy:3956
translate english salazar4_7c9a1f9a:

    # DR "No lo sé, porque eres tú."
    DR "I don't know, because it's you."

# game/script.rpy:3957
translate english salazar4_6905f509:

    # "Él se ríe levemente."
    "He chuckled softly."

# game/script.rpy:3958
translate english salazar4_246d0cac:

    # DR "Es extraño, siento que conozco tu rostro, pero no puedo describirlo con palabras."
    DR "It's strange, I feel like I know your face, but I can't describe it in words."

# game/script.rpy:3959
translate english salazar4_24a51992:

    # DR "Pero aún así, me gustas."
    DR "But even so, I like you."

# game/script.rpy:3961
translate english salazar4_c99d28b0:

    # "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    "Your heart raced at his words, feeling the air between you two grow warm."

# game/script.rpy:3962
translate english salazar4_7d52aa18:

    # pov "B-buenas noches."
    pov "G-good night."

# game/script.rpy:3963
translate english salazar4_bc9280c2:

    # DR "Descansa, [povname]."
    DR "Rest well, [povname]."

# game/script.rpy:3966
translate english salazar4_b6855784:

    # "Cierras tu ojo, concentrándote en tu respiración y la de él para dormir."
    "You closed your eye, concentrating on your breathing and his, to fall asleep."

# game/script.rpy:3967
translate english salazar4_c71d7ef8:

    # "Pronto, lo logras."
    "Soon, you succeeded."

# game/script.rpy:3969
translate english salazar4_c8c6c79c:

    # "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Salazar, te das cuenta de que no está en la cama."
    "You weren't sure if you were dreaming when you thought you heard a noise, but when you reached out to Salazar, you realized he wasn't in bed."

# game/script.rpy:3972
translate english salazar4_b0a34dc6:

    # "Te levantas y sigilosamente sales de tu habitación."
    "You got up and quietly left your room."

# game/script.rpy:3973
translate english salazar4_2c0d1dba:

    # "No escuchas nada, pero eso no te calma."
    "You heard nothing, but that didn't calm you."

# game/script.rpy:3975
translate english salazar4_6558a98d:

    # "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    "You immediately reached the living room, where you witnessed the worst-case scenario."

# game/script.rpy:3981
translate english salazar4_2defa1a6:

    # "Jeff tiene a Salazar sujetado desde el cuello, apuntando la punta del cuchillo contra su garganta."
    "Jeff has Salazar pinned by the neck, the tip of the knife pointed at his throat."

# game/script.rpy:3982
translate english salazar4_e90ea612:

    # "¿En qué momento entró Jeff, Salazar se levantó y se enfrentaron?"
    "At what point did Jeff come in, Salazar get up and they confront each other?"

# game/script.rpy:3983
translate english salazar4_1dcafc75:

    # "Eso debió producir un ruido, pero no tenías idea."
    "That must have made a noise, but you had no idea."

# game/script.rpy:3984
translate english salazar4_c380c9fc:

    # "Parece que Jeff es muy bueno en lo que hace."
    "It seems Jeff is very good at what he does."

# game/script.rpy:3985
translate english salazar4_2ebc0818:

    # J "[povname]... Dije que volvería."
    J "[povname]... I said I'd be back."

# game/script.rpy:3986
translate english salazar4_ff798c78:

    # pov "… Si, puedo darme cuenta."
    pov "… Yeah, I can tell."

# game/script.rpy:3987
translate english salazar4_fdb72a44:

    # J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    J "I advise you to be careful what you say, someone could get hurt."

# game/script.rpy:3988
translate english salazar4_bfc95450:

    # "Jeff acercó más el cuchillo al cuello de Salazar."
    "Jeff brought the knife closer to Salazar's neck."

# game/script.rpy:3991
translate english salazar4_7d652c82:

    # pov "N-no le hagas daño."
    pov "D-don't hurt him."

# game/script.rpy:3992
translate english salazar4_80f14a61:

    # J "¿Oh?"
    J "Oh?"

# game/script.rpy:3993
translate english salazar4_9f2d13ed:

    # J "¿Así que te preocupas por este bastardo?"
    J "So you care about this motherfucker?"

# game/script.rpy:3994
translate english salazar4_3a8de979:

    # pov "Hey, no le digas así."
    pov "Hey, don't call him that."

# game/script.rpy:3995
translate english salazar4_0b6f4b11:

    # J "Sigues probando mi punto."
    J "You keep proving my point."

# game/script.rpy:3997
translate english salazar4_9b0f8d89:

    # pov "¿En serio?"
    pov "Seriously?"

# game/script.rpy:3998
translate english salazar4_e95a949d:

    # pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
    pov "They're looking for you for attacking me, and now you're going to hurt another person?"

# game/script.rpy:3999
translate english salazar4_e3b99848:

    # pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
    pov "Think a little, Jeff, that means more cops looking for your head."

# game/script.rpy:4000
translate english salazar4_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4002
translate english salazar4_8320052c:

    # J "Entonces… No te importará si hago esto, ¿O sí?"
    J "So… You won’t mind if I do this, will you?"

# game/script.rpy:4004
translate english salazar4_439a6e00:

    # "Jeff hace un corte en la mejilla de Salazar, el cual suelta un quejido ahogado mientras la hoja corta su piel."
    "Jeff cuts Salazar's cheek, causing him to gasp as the blade slices into his skin."

# game/script.rpy:4005
translate english salazar4_b0290aa3:

    # pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "Wait, wait! This is between us two, remember?"

# game/script.rpy:4006
translate english salazar4_7b2d9b72:

    # pov "No hay por qué involucrarlo."
    pov "There's no need to involve him."

# game/script.rpy:4007
translate english salazar4_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4022
translate english muerte_salazar_8fad5404:

    # "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por la garganta de Salazar."
    "Jeff completely ignores your words and slides the blade of the knife across Salazar's throat."

# game/script.rpy:4024
translate english muerte_salazar_9318ba06:

    # "Él gorgotea y Jeff lo suelta."
    "He gurgles and Jeff lets him go."

# game/script.rpy:4027
translate english muerte_salazar_aeb4ad77:

    # "Salazar se lleva las manos al cuello, tratando de parar la hemorragia, pero sus piernas ceden y él cae."
    "Salazar puts his hands to his neck, trying to stop the bleeding, but his legs give way and he falls."

# game/script.rpy:4028
translate english muerte_salazar_4c449a05:

    # "Te petrificas en tu lugar, viendo que debajo de Salazar crece un charco oscuro."
    "You freeze in place, watching a dark pool grow beneath Salazar."

# game/script.rpy:4031
translate english muerte_salazar_cb65dbdc:

    # J "Hah… Eres tan hipócrita."
    J "Hah… You are such a hypocrite."

# game/script.rpy:4032
translate english muerte_salazar_4eef6bc5:

    # "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Jeff walks towards you, stepping indifferently into the pool of blood."

# game/script.rpy:4033
translate english muerte_salazar_423bd7b9:

    # "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "He grabs you by the collar of your clothes, raising the bloody knife."

# game/script.rpy:4034
translate english muerte_salazar_48a4acbc:

    # "Tú aún no puedes desviar tu mirada atónita del cadáver de Salazar en el suelo."
    "You still can't tear your astonished gaze away from Salazar's corpse on the ground."

# game/script.rpy:4035
translate english muerte_salazar_ac78924b:

    # J "Te advertí que me aburro fácilmente."
    J "I warned you that I get bored easily."

# game/script.rpy:4036
translate english muerte_salazar_ed84a216:

    # "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    "The last thing you see is Jeff raising his knife high, staring at you."

# game/script.rpy:4042
translate english muerte_salazar_f4ec26fd:

    # "{b}Final V: Lo Decepcionaste{/b}"
    "{b}Ending V: You Disappointed Him{/b}"

# game/script.rpy:4052
translate english hisotria_continua_salazar_7dd60366:

    # "Jeff aleja el cuchillo del cuello de Salazar, y en cambio lo entierra en su hombro."
    "Jeff moves the knife away from Salazar's neck, and instead buries it in his shoulder."

# game/script.rpy:4053
translate english hisotria_continua_salazar_c794cb8d:

    # "Salazar deja salir un alarido que es prontamente callado por la mano de Jeff."
    "Salazar lets out a scream that is quickly silenced by Jeff's hand."

# game/script.rpy:4056
translate english hisotria_continua_salazar_ed4b3062:

    # "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo y Salazar cae al suelo, su herida sangrando constantemente."
    "You watch as the two struggle until Jeff pulls the knife away and Salazar falls to the ground, his wound bleeding constantly."

# game/script.rpy:4057
translate english hisotria_continua_salazar_2c9160f8:

    # DR "[povname]... Corre…"
    DR "[povname]... Run…"

# game/script.rpy:4060
translate english hisotria_continua_salazar_d1f17cd0:

    # J "No te molestes, guapo."
    J "Don't bother, handsome."

# game/script.rpy:4061
translate english hisotria_continua_salazar_a01357f1:

    # "Jeff estiró una sonrisa burlona."
    "Jeff stretched a mocking smile."

# game/script.rpy:4062
translate english hisotria_continua_salazar_1f8a5cca:

    # J "Hay nueva jurisdicción."
    J "There is a new jurisdiction."

# game/script.rpy:4064
translate english hisotria_continua_salazar_7738fd5b:

    # "Jeff ignora el cuerpo de Salazar y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Jeff ignores Salazar's body and advances towards you, his milky eyes shining in the dim light."

# game/script.rpy:4065
translate english hisotria_continua_salazar_8bb827e8:

    # "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    "You manage to run, maybe lock yourself in the bathroom or your room."

# game/script.rpy:4067
translate english hisotria_continua_salazar_041dc4c4:

    # "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    "But your wrist is held by Jeff, preventing you from moving."

# game/script.rpy:4068
translate english hisotria_continua_salazar_b5dd6c81:

    # J "Es curioso… No quiero dañarte, no como antes al menos."
    J "It's funny... I don't want to hurt you, not like before at least."

# game/script.rpy:4069
translate english hisotria_continua_salazar_b0000ffa:

    # J "¿Por qué será?"
    J "Why would that be?"

# game/script.rpy:4073
translate english hisotria_continua_salazar_a84a1a84:

    # pov "T-tal vez es porque te gusto."
    pov "M-maybe it's because you like me."

# game/script.rpy:4075
translate english hisotria_continua_salazar_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4076
translate english hisotria_continua_salazar_a56d14b5:

    # J "¿Cómo dices?"
    J "What?"

# game/script.rpy:4077
translate english hisotria_continua_salazar_801770c2:

    # pov "Ya sabes, ¿Te intereso?"
    pov "You know, you're interested in me?"

# game/script.rpy:4078
translate english hisotria_continua_salazar_0b12aa55:

    # pov "¿Tienes un crush conmigo?"
    pov "You have a crush on me?"

# game/script.rpy:4081
translate english hisotria_continua_salazar_1612e3fd:

    # pov "Quizás quieres dejarme en paz."
    pov "Maybe you want to leave me alone."

# game/script.rpy:4083
translate english hisotria_continua_salazar_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4084
translate english hisotria_continua_salazar_a781321d:

    # J "Nah, no es eso. Todo lo contrario."
    J "Nah, it's not that. Quite the opposite."

# game/script.rpy:4085
translate english hisotria_continua_salazar_9a4e417d:

    # pov "Entonces… ¿Tienes una fijación conmigo?"
    pov "So… You have a thing for me?"

# game/script.rpy:4086
translate english hisotria_continua_salazar_a713ab28:

    # J "¿Ah?"
    J "Ah?"

# game/script.rpy:4092
translate english salazar5_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4093
translate english salazar5_29180233:

    # "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    "You just said the first thing that came to mind, hoping he would stop."

# game/script.rpy:4095
translate english salazar5_50dfff11:

    # J "¡Oh, ya veo!"
    J "Oh, I see!"

# game/script.rpy:4096
translate english salazar5_be1402e7:

    # "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    "Jeff leans toward you, his smile stretched more than usual and his wide eyes fixed on you."

# game/script.rpy:4098
translate english salazar5_7071d957:

    # J "¡Te deseo!"
    J "I want you!"

# game/script.rpy:4099
translate english salazar5_6474133b:

    # J "¡A ti!"
    J "You!"

# game/script.rpy:4100
translate english salazar5_01867340:

    # "Jeff suelta una carcajada estridente."
    "Jeff lets out a shrill laugh."

# game/script.rpy:4101
translate english salazar5_c0728fa7:

    # "No sabes si sonreír u horrorizarte."
    "You don't know whether to smile or be horrified."

# game/script.rpy:4102
translate english salazar5_90770e2a:

    # J "¡Eso explica muchas cosas!"
    J "That explains a lot!"

# game/script.rpy:4104
translate english salazar5_bdec5f1d:

    # "El agarre en tu mano se hace más fuerte, y él tira de ti."
    "The grip on your hand tightens, and he pulls you closer."

# game/script.rpy:4105
translate english salazar5_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Wait, what are you doing?"

# game/script.rpy:4106
translate english salazar5_d764cb51:

    # J "Ya descubrí lo que quiero."
    J "I've already discovered what I want."

# game/script.rpy:4107
translate english salazar5_82658285:

    # J "No quiero seguir jugando contigo."
    J "I don't want to play with you anymore."

# game/script.rpy:4108
translate english salazar5_35012658:

    # "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    "A part of you felt relieved at her words, but when Jeff pulled you towards him, causing you to crash into his chest, you felt cold."

# game/script.rpy:4109
translate english salazar5_4f0b84e3:

    # J "Quiero tenerte para mí."
    J "I want to have you for myself."

# game/script.rpy:4110
translate english salazar5_bba5eefc:

    # "Entonces te das cuenta que te está guiando a la salida."
    "Then you realize he's leading you to the exit."

# game/script.rpy:4111
translate english salazar5_d27395d2:

    # "En un instante, viste el cuerpo de Salazar aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    "In an instant, you saw Salazar's body still motionless on the ground, and a pang of worry passed through you."

# game/script.rpy:4112
translate english salazar5_1276a7ba:

    # pov "¿Qué hay de-?"
    pov "What about-?"

# game/script.rpy:4113
translate english salazar5_886cf72a:

    # J "No pienses en él."
    J "Don't think about him."

# game/script.rpy:4116
translate english salazar5_279d16da:

    # "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Your cheeks are cupped in two large, cold hands, and you feel something wet splash against your skin."

# game/script.rpy:4117
translate english salazar5_2b9a40af:

    # "Por el olor, te das cuenta que es sangre."
    "By the smell, you can tell it's blood."

# game/script.rpy:4118
translate english salazar5_727428c4:

    # "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    "Jeff's bangs brush against your forehead, and all you can see are his eyes."

# game/script.rpy:4119
translate english salazar5_e83bba11:

    # J "Sólo céntrate en mí."
    J "Just focus on me."

# game/script.rpy:4120
translate english salazar5_a2a404e6:

    # "Has visto de lo que es capaz."
    "You've seen what he's capable of."

# game/script.rpy:4121
translate english salazar5_35f60b9f:

    # "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "He didn't just hurt you, he hurt everyone."

# game/script.rpy:4122
translate english salazar5_e921f59d:

    # "Eso te hizo considerar sus palabras, profundamente."
    "That made you consider his words, deeply."

# game/script.rpy:4133
translate english cindy_85122899:

    # pov "Elijo a Cindy."
    pov "I choose Cindy."

# game/script.rpy:4136
translate english cindy_de96dad9:

    # "Ella sonríe satisfecha, y él suspira decepcionado."
    "She smiles with satisfaction, and he sighs in disappointment."

# game/script.rpy:4137
translate english cindy_dee4bd4c:

    # DR "De acuerdo, comprendo."
    DR "Okay, I understand."

# game/script.rpy:4138
translate english cindy_c42bc9b2:

    # "Preferías pasar la noche con alguien a quien conoces mejor, además de que fue a la academia de policía. Eso inspira seguridad."
    "You'd rather spend the night with someone you know better, and someone who went to the police academy. That inspires confidence."

# game/script.rpy:4143
translate english cindy_31c2ce66:

    # "Salazar se dirige a la puerta, tú lo sigues para abrirle y despedirlo."
    "Salazar heads for the door, you follow him to open it and say goodbye."

# game/script.rpy:4144
translate english cindy_c98342b6:

    # pov "Gracias por venir, en serio."
    pov "Thanks for coming, really."

# game/script.rpy:4145
translate english cindy_16c87ee6:

    # pov "Creo… Que me hacía falta sentir que me cuidan."
    pov "I guess... I needed to feel cared for."

# game/script.rpy:4147
translate english cindy_2f1925a4:

    # "Salazar te mira de reojo, y sonríe levemente."
    "Salazar looks at you out of the corner of his eye, and smiles slightly."

# game/script.rpy:4148
translate english cindy_c48996a4:

    # DR "Siempre estaré para ti."
    DR "I'll always be there for you."

# game/script.rpy:4150
translate english cindy_9a81af9f:

    # "Él acaricia suavemente la parte superior de tu cabeza."
    "He gently strokes the top of your head."

# game/script.rpy:4151
translate english cindy_ed1f49d8:

    # "Salazar desaparece tras la puerta, y te quedas con Cindy."
    "Salazar disappears behind the door, and you are left with Cindy."

# game/script.rpy:4155
translate english cindy_03245aa1:

    # pov "¿Quieres cenar?"
    pov "Do you want dinner?"

# game/script.rpy:4156
translate english cindy_c4ae6c73:

    # C "Seguro."
    C "Sure."

# game/script.rpy:4157
translate english cindy_c317b3f8:

    # pov "¿Prefieres cocinar o pedir algo?"
    pov "Would you rather cook or order something?"

# game/script.rpy:4158
translate english cindy_efc83638:

    # C "Conozco un buen restaurante chino a domicilio cerca de aquí."
    C "I know a good Chinese takeout restaurant near here."

# game/script.rpy:4159
translate english cindy_ddb4b8d6:

    # "Asientes con la cabeza."
    "You nod."

# game/script.rpy:4160
translate english cindy_1cb031e6:

    # pov "De acuerdo."
    pov "Okay."

# game/script.rpy:4161
translate english cindy_afbd33e0:

    # "Ella saca su teléfono, y los adornos colgados en el aparato tintinean con cada movimiento."
    "She takes out her phone, and the ornaments hanging on it jingle with every movement."

# game/script.rpy:4162
translate english cindy_7bacd44e:

    # C "¿Alguna alergia, algo que no comas?"
    C "Any allergies, anything you don't eat?"

# game/script.rpy:4164
translate english cindy_ecc3b640:

    # pov "La opción vegana para mí, por favor."
    pov "The vegan option for me, please."

# game/script.rpy:4166
translate english cindy_19a768c6:

    # pov "Nada que reportar."
    pov "Nothing to report."

# game/script.rpy:4167
translate english cindy_d51028a4:

    # "Cindy asiente y hace el pedido."
    "Cindy nods and places the order."

# game/script.rpy:4171
translate english cindy_1557af9b:

    # "Mientras ustedes esperan en el sofá, se mantienen en silencio."
    "While you wait on the couch, you remain silent."

# game/script.rpy:4175
translate english cindy_a1a4d364:

    # pov "Así que, ¿Policía?"
    pov "So, Police?"

# game/script.rpy:4176
translate english cindy_1f540cdc:

    # pov "Honestamente, no me lo esperaba."
    pov "Honestly, I didn't expect it."

# game/script.rpy:4177
translate english cindy_a6daf0ab:

    # C "Seh, lo sé."
    C "Yeah, I know."

# game/script.rpy:4178
translate english cindy_918fb9a0:

    # C "En lo académico resaltaba, pero tenía desventaja en lo físico."
    C "I excelled academically, but I was physically weak."

# game/script.rpy:4179
translate english cindy_c2563f85:

    # C "Aún si las llaves funcionan por la gravedad, se requiere cierta cantidad de fuerza."
    C "Even if joint locks rely on leverage, you still need some strength."

# game/script.rpy:4180
translate english cindy_bb5f9ff5:

    # C "Fuerza que no tengo"
    C "Strength that I don't have"

# game/script.rpy:4183
translate english cindy_f7b8e4e1:

    # pov "Entonces, ¿Hiciste toda una investigación policial sólo por mi?"
    pov "So you did a whole police investigation just for me?"

# game/script.rpy:4184
translate english cindy_860c5ad7:

    # "Cindy te mira de reojo"
    "Cindy glares at you."

# game/script.rpy:4185
translate english cindy_bebfd7e8:

    # C "¿Cuál es tu punto?"
    C "What's your point?"

# game/script.rpy:4186
translate english cindy_34caae46:

    # pov "Oh, nada."
    pov "Oh, nothing."

# game/script.rpy:4187
translate english cindy_dcf5477d:

    # pov "Sólo que aparentemente estás dispuesta a varias cosas por mí."
    pov "It's just that you're apparently willing to do several things for me."

# game/script.rpy:4188
translate english cindy_cd2202af:

    # pov "Como pasar la noche."
    pov "Like spend the night."

# game/script.rpy:4190
translate english cindy_1b1b255f:

    # "Cindy desvía la mirada, pero notas cómo sus mejillas se encienden levemente."
    "Cindy looks away, but you notice her cheeks flush slightly."

# game/script.rpy:4191
translate english cindy_dea0df56:

    # C "No te hagas ilusiones."
    C "Don't get your hopes up."

# game/script.rpy:4197
translate english cindy2_4d1df216:

    # "Ustedes pasan los siguientes minutos esperando por el pedido, y cuando llega, se sirven en la cocina."
    "You spend the next few minutes waiting for your order, and when it arrives, you serve it in the kitchen."

# game/script.rpy:4201
translate english cindy2_4ea9e78f:

    # "Cindy come lentamente, picoteando la comida."
    "Cindy eats slowly, picking at her food."

# game/script.rpy:4202
translate english cindy2_5f75150b:

    # "Parece estar pensando en otra cosa."
    "She seems to be thinking about something else."

# game/script.rpy:4206
translate english cindy2_24c2f3f2:

    # pov "¿En qué piensas tanto?"
    pov "What’s on your mind?"

# game/script.rpy:4207
translate english cindy2_8de00294:

    # "Cindy regresa la mirada hacia ti, para después apoyar su mejilla en su mano."
    "Cindy looks back at you, then rests her cheek on her hand."

# game/script.rpy:4208
translate english cindy2_c60f3936:

    # C "Quizás no sea tan buena idea quedarnos acá."
    C "Maybe it's not such a good idea to stay here."

# game/script.rpy:4209
translate english cindy2_cc13a16b:

    # pov "¿Por qué lo dices?"
    pov "Why?"

# game/script.rpy:4210
translate english cindy2_6b9e82e8:

    # C "Ese loco puede saber dónde vives hasta este punto."
    C "That crazy guy may know where you live by now."

# game/script.rpy:4211
translate english cindy2_e218229e:

    # C "Quedarnos puede ser demasiado peligroso."
    C "Staying may be too dangerous."

# game/script.rpy:4212
translate english cindy2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4215
translate english cindy2_1691c671:

    # pov "Tienes razón, es bastante bueno."
    pov "You're right, it's pretty good."

# game/script.rpy:4216
translate english cindy2_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:4217
translate english cindy2_ba5896e3:

    # "Tu intento de charlar no funciona."
    "Your attempt at chatting isn't working."

# game/script.rpy:4218
translate english cindy2_c25a2975:

    # "Lo más probable es que siga preocupada por el asunto de Jeff."
    "She's probably still worried about the Jeff thing."

# game/script.rpy:4223
#translate english cindy3_9783d55b:

    # "Cindy era realmente elocuente, ¿No?"
    #"Cindy was really eloquent, wasn't she?"

# game/script.rpy:4224
translate english cindy3_0692b525:

    # "Parece ser el personaje con más sentido común."
    "She seems to be the character with the most common sense."

# game/script.rpy:4225
translate english cindy3_dfb6e972:

    # "Pero ese no es el tema."
    "But that's not the point."

# game/script.rpy:4226
translate english cindy3_9e950122:

    # "Jeff es un cobarde, sólo te ha atacado cuando no hay nadie."
    "Jeff is a coward, he only attacked you when no one was around."

# game/script.rpy:4227
translate english cindy3_999a9ac0:

    # "Además, el juego que tienen es entre ustedes, él no tiene por qué involucrar a Cindy."
    "Besides, the game is between you, he doesn't have to involve Cindy."

# game/script.rpy:4228
translate english cindy3_099f4a4e:

    # "Así que todo va a estar bien."
    "So everything's going to be okay."

# game/script.rpy:4229
translate english cindy3_98d38427:

    # pov "Todo va a estar bien."
    pov "Everything is going to be okay."

# game/script.rpy:4230
translate english cindy3_fdc69509:

    # "Lo dices en voz alta no sólo para asegurarte a ti, también a Cindy."
    "You say it out loud not only to reassure yourself, but also Cindy."

# game/script.rpy:4232
translate english cindy3_63c265b8:

    # "Ella te dedica una leve sonrisa desganada, pero termina por suspirar rendida."
    "She gives you a faint, reluctant smile, but ends up sighing in defeat."

# game/script.rpy:4233
translate english cindy3_01fc2712:

    # C "Tu ganas, tengamos algo de charla trivial."
    C "You win, let's have some small talk."

# game/script.rpy:4235
translate english cindy3_23163547:

    # C "¿Cómo te estabas sintiendo con el trabajo?"
    C "How were you feeling about work?"

# game/script.rpy:4236
translate english cindy3_0854763a:

    # C "Antes de todo esto."
    C "Before all this."

# game/script.rpy:4237
translate english cindy3_84dc4d63:

    # pov "Yo creo que bien."
    pov "I think it's fine."

# game/script.rpy:4238
translate english cindy3_9037e8af:

    # pov "Lo siento, pero tendré que faltar durante un tiempo."
    pov "I'm sorry, but I'll have to be away for a while."

# game/script.rpy:4239
translate english cindy3_a3fe3ae4:

    # C "No te culpo, de todas maneras cerramos temporalmente."
    C "I don't blame you, we're temporarily closed anyway."

# game/script.rpy:4240
translate english cindy3_cf3975fa:

    # C "No sé en tu caso, pero puedo vivir sin películas."
    C "I don't know about you, but I can live without movies."

# game/script.rpy:4242
translate english cindy3_fe58a779:

    # pov "Yo no podría, me encantan."
    pov "I couldn't, I love them."

# game/script.rpy:4244
translate english cindy3_04d14352:

    # pov "Seh, yo también."
    pov "Yeah, me too."

# game/script.rpy:4245
translate english cindy3_732ab2cd:

    # pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "Anyway, my last memory of there is not very pleasant."

# game/script.rpy:4246
translate english cindy3_356b26c9:

    # pov "Todavía tenía los dos ojos."
    pov "I still had both eyes."

# game/script.rpy:4248
translate english cindy3_9ba67740:

    # "Cindy hace una mueca de incomodidad, tratando de desviar la mirada de tu parche, fallando."
    "Cindy grimaces in discomfort, trying to look away from your eye patch, failing."

# game/script.rpy:4250
translate english cindy3_55043449:

    # "Viendo los platos vacíos, haces el ademán de levantarte, pero Cindy te detiene con un gesto de su mano."
    "Seeing the empty plates, you make a move to get up, but Cindy stops you with a gesture of her hand."

# game/script.rpy:4251
translate english cindy3_33d877ae:

    # C "No te esfuerces, ve a prepararte para dormir."
    C "Don't overexert yourself, go get ready for bed."

# game/script.rpy:4252
translate english cindy3_a5c191d7:

    # "Alzas las manos en derrota."
    "You raise your hands in defeat."

# game/script.rpy:4253
translate english cindy3_364f35a4:

    # pov "Lo que digas."
    pov "Whatever you say."

# game/script.rpy:4255
translate english cindy3_057629fa:

    # "Observas cómo ella se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "You watch as she gets up with the used dishes, utensils, and glasses and goes to the dishwasher, starting to maneuver with the water and detergent."

# game/script.rpy:4256
translate english cindy3_1cb1aa3f:

    # "Te quedas cerca, admirando la figura de su espalda pequeña y sus brazos moviéndose."
    "You stay close, admiring the shape of her small back and her moving arms."

# game/script.rpy:4257
translate english cindy3_afcbbbf2:

    # pov "Así que… Sólo tengo una cama."
    pov "So… I only have one bed."

# game/script.rpy:4259
translate english cindy3_4f8050ea:

    # "Cindy se detiene un segundo, dejando el agua correr."
    "Cindy pauses for a second, letting the water run."

# game/script.rpy:4260
translate english cindy3_726c6ac6:

    # C "¿...Ok?"
    C "...Okay?"

# game/script.rpy:4264
translate english cindy3_b2f861dc:

    # pov "Parece que tendremos pijamada."
    pov "Looks like we're having a sleepover."

# game/script.rpy:4267
translate english cindy3_578ee21a:

    # pov "Si quieres podemos hacer un muro de almohadas."
    pov "If you want we can make a pillow wall."

# game/script.rpy:4272
translate english cindy4_689e76fa:

    # "Cindy asiente con la cabeza y vuelve a lo suyo."
    "Cindy nods and goes back to her business."

# game/script.rpy:4274
translate english cindy4_d3bb59d0:

    # "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "You head to the bathroom, where you shower and put on your night clothes."

# game/script.rpy:4275
translate english cindy4_36efb37c:

    # "Por un momento te detienes frente al espejo."
    "For a moment you stop in front of the mirror."

# game/script.rpy:4276
translate english cindy4_947fae38:

    # "Tienes un poco de nervios por pasar la noche con Cindy."
    "You're a little nervous about spending the night with Cindy."

# game/script.rpy:4277
translate english cindy4_47b61d0b:

    # "Nunca la habías visto con otros ojos, pero ahora no podías evitar pensar que tienes algo de suerte por pasar la noche con una chica linda."
    "You’d never seen her that way before, but now you couldn’t help thinking you were kind of lucky to be spending the night with a cute girl."

# game/script.rpy:4278
translate english cindy4_a1b1e90d:

    # "Claro, no va a pasar nada."
    "Of course, nothing will happen."

# game/script.rpy:4279
translate english cindy4_9d47684d:

    # "Ella ni siquiera es tu amiga, técnicamente."
    "She's not even your friend, technically."

# game/script.rpy:4280
translate english cindy4_d3161c28:

    # "¿O podría decirse que sí?"
    "Or could you say she is?"

# game/script.rpy:4284
translate english cindy4_074d3ad5:

    # "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Cindy."
    "With that in mind, you leave the bathroom and return to the kitchen, to look for Cindy."

# game/script.rpy:4285
translate english cindy4_74fee88d:

    # pov "El baño está libre, por si quieres usarlo."
    pov "The bathroom is free, if you want to use it."

# game/script.rpy:4286
translate english cindy4_dbed95e7:

    # "Ella ya había estado aquí antes, por lo que sabía dónde estaba todo."
    "She had been here before, so she knew where everything was."

# game/script.rpy:4287
translate english cindy4_c0af09f0:

    # C "De acuerdo."
    C "Okay."

# game/script.rpy:4288
translate english cindy4_c1b51dda:

    # "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    "You nod silently and head back the way you came, this time heading to your room."

# game/script.rpy:4292
translate english cindy4_43d1e267:

    # "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Cindy."
    "You took a place on the bed, making sure to leave Cindy some space."

# game/script.rpy:4293
translate english cindy4_0bec2b3e:

    # "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "You heard from your spot the lights going off, turning on, and the water running."

# game/script.rpy:4294
translate english cindy4_49e87eee:

    # "Unos instantes después, Cindy entra a la habitación."
    "A few moments later, Cindy enters the room."

# game/script.rpy:4295
translate english cindy4_78b379bd:

    # "En silencio, ella se adentra bajo las sábanas junto a ti."
    "Silently, she slips under the sheets next to you."

# game/script.rpy:4302
translate english cindy4_505286fb:

    # "Sientes el aroma de su perfume, es dulce."
    "You smell the scent of her perfume, it's sweet."

# game/script.rpy:4303
translate english cindy4_c18f24cd:

    # "Alcanzas a ver que los ojos de ella brillan, aún con la escasa luz."
    "You can see that her eyes are shining, even in the dim light."

# game/script.rpy:4304
translate english cindy4_d4e9ed84:

    # pov "¿Por qué te preocupas tanto por mí?"
    pov "Why do you care so much about me?"

# game/script.rpy:4305
translate english cindy4_e626486c:

    # pov "¿Qué cambió?"
    pov "What changed?"

# game/script.rpy:4307
translate english cindy4_5c00b803:

    # "Inesperadamente, sientes que la mano de ella roza tu mejilla, y acaricia con su pulgar delicadamente."
    "Unexpectedly, you feel her hand brush against your cheek, gently caressing it with her thumb."

# game/script.rpy:4308
translate english cindy4_54c99404:

    # C "Me dí cuenta que eres importante para mí."
    C "I realized that you are important to me."

# game/script.rpy:4309
translate english cindy4_1d8fafcc:

    # "Ella se ríe levemente."
    "She laughs slightly."

# game/script.rpy:4310
translate english cindy4_ee7d37af:

    # C "Es extraño, siento que te conozco, pero no puedo pensar en algún momento que pasé contigo en específico."
    C "It's weird, I feel like I know you, but I can't think of a specific time I spent with you."

# game/script.rpy:4311
translate english cindy4_d26e3082:

    # C "Pero aún así, me importas"
    C "But still, I care about you."

# game/script.rpy:4313
translate english cindy4_c99d28b0:

    # "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    "Your heart races at his words, feeling the air between you two turn warm."

# game/script.rpy:4314
translate english cindy4_7d52aa18:

    # pov "B-buenas noches."
    pov "G-good night."

# game/script.rpy:4315
translate english cindy4_7ab769fb:

    # C "Descansa bien."
    C "Rest well."

# game/script.rpy:4318
translate english cindy4_b192bc49:

    # "Cierras tu ojo, concentrándote en tu respiración y la de ella para dormir."
    "You close your eyes, concentrating on your breathing and hers to fall asleep."

# game/script.rpy:4319
translate english cindy4_c71d7ef8:

    # "Pronto, lo logras."
    "Soon, you succeeded."

# game/script.rpy:4321
translate english cindy4_9ef5798e:

    # "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Cindy, te das cuenta de que no está en la cama."
    "You weren't sure if you were dreaming when you thought you heard a noise, but when you reached out to Cindy, you realized she wasn't in bed."

# game/script.rpy:4324
translate english cindy4_b0a34dc6:

    # "Te levantas y sigilosamente sales de tu habitación."
    "You got up and quietly left your room."

# game/script.rpy:4325
translate english cindy4_2c0d1dba:

    # "No escuchas nada, pero eso no te calma."
    "You heard nothing, but that didn't calm you."

# game/script.rpy:4326
translate english cindy4_6558a98d:

    # "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    "You immediately reached the living room, where you witnessed the worst-case scenario."

# game/script.rpy:4332
translate english cindy4_30487e3f:

    # "Jeff tiene sujetada a Cindy desde el cuello, tapando su boca, y apuntando la punta del cuchillo contra su cintura."
    "Jeff had Cindy held by the neck, covering her mouth, and pointing the tip of his knife at her waist."

# game/script.rpy:4333
translate english cindy4_ad48664c:

    # "¿En qué momento entró Jeff, Cindy se levantó y se enfrentaron?"
    "When did Jeff get in, and when did Cindy get up and confront him?"

# game/script.rpy:4334
translate english cindy4_1dcafc75:

    # "Eso debió producir un ruido, pero no tenías idea."
    "That must have made noise, but you had no idea."

# game/script.rpy:4335
translate english cindy4_c380c9fc:

    # "Parece que Jeff es muy bueno en lo que hace."
    "It seems Jeff was very good at what he did."

# game/script.rpy:4336
translate english cindy4_2ebc0818:

    # J "[povname]... Dije que volvería."
    J "[povname]... I said I'd be back."

# game/script.rpy:4337
translate english cindy4_ff798c78:

    # pov "… Si, puedo darme cuenta."
    pov "... Yeah, I can see that."

# game/script.rpy:4338
translate english cindy4_fdb72a44:

    # J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    J "I advise you to be careful what you say, someone could get hurt."

# game/script.rpy:4339
translate english cindy4_475ee4a1:

    # "Jeff acercó más el cuchillo a la piel de Cindy."
    "Jeff brought the knife closer to Cindy's skin."

# game/script.rpy:4342
translate english cindy4_7d652c82:

    # pov "N-no le hagas daño."
    pov "D-don't hurt her."

# game/script.rpy:4343
translate english cindy4_80f14a61:

    # J "¿Oh?"
    J "Oh?"

# game/script.rpy:4344
translate english cindy4_7a410f0f:

    # J "¿Así que te preocupas por esta perra?"
    J "So you care about this bitch?"

# game/script.rpy:4345
translate english cindy4_3a8de979:

    # pov "Hey, no le digas así."
    pov "Hey, don't call her that."

# game/script.rpy:4346
translate english cindy4_0b6f4b11:

    # J "Sigues probando mi punto."
    J "You keep proving my point."

# game/script.rpy:4348
translate english cindy4_9b0f8d89:

    # pov "¿En serio?"
    pov "Seriously?"

# game/script.rpy:4349
translate english cindy4_e95a949d:

    # pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
    pov "They're looking for you for attacking me, and now you're going to hurt another person?"

# game/script.rpy:4350
translate english cindy4_e3b99848:

    # pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
    pov "Think a little, Jeff, that means more cops looking for your head."

# game/script.rpy:4351
translate english cindy4_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4353
translate english cindy4_8320052c:

    # J "Entonces… No te importará si hago esto, ¿O sí?"
    J "So… You won’t mind if I do this, will you?"

# game/script.rpy:4355
translate english cindy4_edf1629f:

    # "Jeff hace un corte en el costado de Cindy, la cual suelta un quejido ahogado contra la mano de él."
    "Jeff made a cut on Cindy's side, and she let out a muffled groan against his hand as the blade cut her skin."

# game/script.rpy:4356
translate english cindy4_b0290aa3:

    # pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "Wait, wait! This is between us two, remember?"

# game/script.rpy:4357
translate english cindy4_fab5f323:

    # pov "No hay por qué involucrarla."
    pov "You shouldn't involve her."

# game/script.rpy:4358
translate english cindy4_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4372
translate english muerte_cindy_f489d8e9:

    # "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por el estómago de Cindy."
    "Jeff completely ignored your words and slid the knife blade into Cindy's stomach."

# game/script.rpy:4373
translate english muerte_cindy_e62bfee0:

    # "La sangre y entrañas se derramaron y Jeff la suelta."
    "Blood and guts spilled out, and Jeff let her go."

# game/script.rpy:4376
translate english muerte_cindy_38d8850f:

    # "Cindy se lleva las manos al estómago, tratando de parar la hemorragia, pero sus piernas ceden y ella cae."
    "Cindy clasped her hands to her stomach, trying to stop the bleeding, but her legs gave way and she fell."

# game/script.rpy:4377
translate english muerte_cindy_f6f45eb3:

    # "Te petrificas en tu lugar, viendo que debajo de Cindy crece un charco oscuro."
    "You froze in your spot, watching a dark puddle grow beneath Cindy."

# game/script.rpy:4380
translate english muerte_cindy_cb65dbdc:

    # J "Hah… Eres tan hipócrita."
    J "Hah... You're such a hypocrite."

# game/script.rpy:4381
translate english muerte_cindy_4eef6bc5:

    # "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Jeff advanced towards you, stepping on the pool of blood with indifference."

# game/script.rpy:4382
translate english muerte_cindy_423bd7b9:

    # "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "He grabbed you by the collar of your clothes, raising the bloody knife."

# game/script.rpy:4383
translate english muerte_cindy_6d74fe34:

    # "Tú aún no puedes desviar tu mirada atónita del cadáver de Cindy en el suelo."
    "You still couldn't tear your stunned gaze from Cindy's corpse on the floor."

# game/script.rpy:4384
translate english muerte_cindy_ac78924b:

    # J "Te advertí que me aburro fácilmente."
    J "I warned you that I get bored easily."

# game/script.rpy:4385
translate english muerte_cindy_ed84a216:

    # "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    "The last thing you saw is Jeff raising his knife high, staring at you."

# game/script.rpy:4391
translate english muerte_cindy_f4ec26fd:

    # "{b}Final V: Lo Decepcionaste{/b}"
    "{b}Ending V: You Disappointed Him{/b}"

# game/script.rpy:4401
translate english historia_continua_cindy_273ec03e:

    # "Jeff entierra lentamente la punta del cuchillo en el costado de Cindy."
    "Jeff slowly buries the tip of the knife in Cindy's side."

# game/script.rpy:4402
translate english historia_continua_cindy_de1297ee:

    # "Ella deja salir un grito acallado contra la mano de él."
    "She let out a scream that was quickly muffled by Jeff's hand."

# game/script.rpy:4405
translate english historia_continua_cindy_f5cb29b7:

    # "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo, y Cindy cae al suelo."
    "You watch as the two struggle until Jeff pulls the knife away, and Cindy falls to the ground."

# game/script.rpy:4406
translate english historia_continua_cindy_9054e9ce:

    # C "[povname]... Vete…"
    C "[povname]... Go away…"

# game/script.rpy:4409
translate english historia_continua_cindy_a80c7a6b:

    # J "No te molestes, linda."
    J "Don't bother, darling."

# game/script.rpy:4410
translate english historia_continua_cindy_a01357f1:

    # "Jeff estiró una sonrisa burlona."
    "Jeff stretched a mocking smile."

# game/script.rpy:4411
translate english historia_continua_cindy_1f8a5cca:

    # J "Hay nueva jurisdicción."
    J "There is a new jurisdiction."

# game/script.rpy:4413
translate english historia_continua_cindy_9e073087:

    # "Jeff ignora el cuerpo de Cindy y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Jeff ignores Cindy's body and walks towards you, his milky eyes shining in the dim light."

# game/script.rpy:4414
translate english historia_continua_cindy_8bb827e8:

    # "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    "You manage to run, maybe lock yourself in the bathroom or your room."

# game/script.rpy:4416
translate english historia_continua_cindy_041dc4c4:

    # "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    "But your wrist is held by Jeff, preventing you from moving."

# game/script.rpy:4417
translate english historia_continua_cindy_b5dd6c81:

    # J "Es curioso… No quiero dañarte, no como antes al menos."
    J "It's funny... I don't want to hurt you, not like before at least."

# game/script.rpy:4418
translate english historia_continua_cindy_b0000ffa:

    # J "¿Por qué será?"
    J "Why would that be?"

# game/script.rpy:4422
translate english historia_continua_cindy_a84a1a84:

    # pov "T-tal vez es porque te gusto."
    pov "M-maybe it's because you like me."

# game/script.rpy:4424
translate english historia_continua_cindy_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4425
translate english historia_continua_cindy_a56d14b5:

    # J "¿Cómo dices?"
    J "What?"

# game/script.rpy:4426
translate english historia_continua_cindy_801770c2:

    # pov "Ya sabes, ¿Te intereso?"
    pov "You know, you're interested in me?"

# game/script.rpy:4427
translate english historia_continua_cindy_0b12aa55:

    # pov "¿Tienes un crush conmigo?"
    pov "You have a crush on me?"

# game/script.rpy:4430
translate english historia_continua_cindy_1612e3fd:

    # pov "Quizás quieres dejarme en paz."
    pov "Maybe you want to leave me alone."

# game/script.rpy:4432
translate english historia_continua_cindy_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4433
translate english historia_continua_cindy_a781321d:

    # J "Nah, no es eso. Todo lo contrario."
    J "Nah, it's not that. Quite the opposite."

# game/script.rpy:4434
translate english historia_continua_cindy_9a4e417d:

    # pov "Entonces… ¿Tienes una fijación conmigo?"
    pov "So… You have a thing for me?"

# game/script.rpy:4435
translate english historia_continua_cindy_a713ab28:

    # J "¿Ah?"
    J "Ah?"

# game/script.rpy:4441
translate english cindy5_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4442
translate english cindy5_29180233:

    # "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    "You just said the first thing that came to mind, hoping he would stop."

# game/script.rpy:4444
translate english cindy5_50dfff11:

    # J "¡Oh, ya veo!"
    J "Oh, I see!"

# game/script.rpy:4445
translate english cindy5_be1402e7:

    # "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    "Jeff leans toward you, his smile stretched more than usual and his wide eyes fixed on you."

# game/script.rpy:4447
translate english cindy5_7071d957:

    # J "¡Te deseo!"
    J "I want you!"

# game/script.rpy:4448
translate english cindy5_e168bd54:

    # J "¡A tí!"
    J "You!"

# game/script.rpy:4449
translate english cindy5_01867340:

    # "Jeff suelta una carcajada estridente."
    "Jeff lets out a shrill laugh."

# game/script.rpy:4450
translate english cindy5_c0728fa7:

    # "No sabes si sonreír u horrorizarte."
    "You don't know whether to smile or be horrified."

# game/script.rpy:4451
translate english cindy5_90770e2a:

    # J "¡Eso explica muchas cosas!"
    J "That explains a lot!"

# game/script.rpy:4453
translate english cindy5_bdec5f1d:

    # "El agarre en tu mano se hace más fuerte, y él tira de ti."
    "The grip on your hand tightens, and he pulls you closer."

# game/script.rpy:4454
translate english cindy5_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Wait, what are you doing?"

# game/script.rpy:4455
translate english cindy5_d764cb51:

    # J "Ya descubrí lo que quiero."
    J "I've already discovered what I want."

# game/script.rpy:4456
translate english cindy5_82658285:

    # J "No quiero seguir jugando contigo."
    J "I don't want to play with you anymore."

# game/script.rpy:4457
translate english cindy5_35012658:

    # "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    "A part of you felt relieved at his words, but when Jeff pulled you towards him, causing you to crash into his chest, you felt cold."

# game/script.rpy:4458
translate english cindy5_4f0b84e3:

    # J "Quiero tenerte para mí."
    J "I want to have you for myself."

# game/script.rpy:4459
translate english cindy5_bba5eefc:

    # "Entonces te das cuenta que te está guiando a la salida."
    "Then you realize he's leading you to the exit."

# game/script.rpy:4460
translate english cindy5_7f401476:

    # "En un instante, viste el cuerpo de Cindy aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    "In an instant, you saw Cindy's body still motionless on the ground, and a pang of worry went through you."

# game/script.rpy:4461
translate english cindy5_1276a7ba:

    # pov "¿Qué hay de-?"
    pov "What about-?"

# game/script.rpy:4462
translate english cindy5_004bb96d:

    # J "No pienses en ella."
    J "Don't think about her."

# game/script.rpy:4465
translate english cindy5_279d16da:

    # "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Your cheeks are cupped in two large, cold hands, and you feel something wet splash against your skin."

# game/script.rpy:4466
translate english cindy5_2b9a40af:

    # "Por el olor, te das cuenta que es sangre."
    "By the smell, you can tell it's blood."

# game/script.rpy:4467
translate english cindy5_727428c4:

    # "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    "Jeff's bangs brush against your forehead, and all you can see are his eyes."

# game/script.rpy:4468
translate english cindy5_e83bba11:

    # J "Sólo céntrate en mí."
    J "Just focus on me."

# game/script.rpy:4469
translate english cindy5_a2a404e6:

    # "Has visto de lo que es capaz."
    "You've seen what he's capable of."

# game/script.rpy:4470
translate english cindy5_35f60b9f:

    # "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "He didn't just hurt you, he hurt everyone."

# game/script.rpy:4471
translate english cindy5_e921f59d:

    # "Eso te hizo considerar sus palabras, profundamente."
    "That made you consider his words, deeply."

# game/script.rpy:4491
translate english day6_16ba099f:

    # "La sensación bajo tu cuerpo es dura y áspera."
    "The sensation beneath your body was hard and rough."

# game/script.rpy:4492
translate english day6_5e27d95d:

    # "El colchón evidentemente es muy viejo y de mala calidad."
    "The mattress was evidently very old and of poor quality."

# game/script.rpy:4493
translate english day6_33578e4c:

    # "Aunque hayas despertado, mantienes tu ojo cerrado, reflexionando sobre lo que sucedió para que te llevara a donde estás."
    "Even though you had woken up, you kept your eye closed, reflecting on what had happened to bring you to where you were."

# game/script.rpy:4496
translate english day6_a076dbbd:

    # "Jeff tiró de ti, obligándote a correr con él."
    "Jeff had dragged you, forcing you to run with him."

# game/script.rpy:4497
translate english day6_79365ed4:

    # "El frío de la madrugada entraba a tus pulmones, mientras las luces de los faroles alumbraban su camino."
    "The cold of dawn entered your lungs, while the streetlights illuminated your path."

# game/script.rpy:4498
translate english day6_8e5f086f:

    # "Recorrieron muchas calles, no sabías que tan lejos te estaba llevando."
    "You traveled many streets; you didn't know how far he was taking you."

# game/script.rpy:4501
translate english day6_0269c8eb:

    # "A petición tuya, en ocasiones le pedías que se detuviera para descansar. Jeff aceptaba, y mientras tú recuperabas el aliento, él vigilaba los alrededores."
    "At your request, you occasionally asked him to stop to rest. Jeff agreed, and while you caught your breath, he watched the surroundings."

# game/script.rpy:4502
translate english day6_0e9d7eff:

    # "A penas te sentías mejor, él tomaba tu muñeca y nuevamente te arrastraba."
    "As soon as you felt better, he took your wrist and dragged you again."

# game/script.rpy:4503
translate english day6_61776a71:

    # "Finalmente habían llegado a un barrio de mala a muerte, lleno de basura, campamentos y casas en mal estado."
    "Finally, you arrived at a dilapidated neighborhood, full of trash, encampments, and houses in poor condition."

# game/script.rpy:4504
translate english day6_f4e686db:

    # "La casa de Jeff no fue la excepción."
    "Jeff's house was no exception."

# game/script.rpy:4506
translate english day6_f1a5215f:

    # "Recuerdas que él dijo que era el lugar donde se quedaba por el momento, mientras te invitaba a pasar en una pequeña casa destartalada."
    "You remembered him saying it was where he was staying for the moment, as he invited you into a small, rundown house."

# game/script.rpy:4507
translate english day6_51ff449a:

    # "Como era de noche y él no quiso encender las luces, en el caso de que tuviera electricidad, no viste bien como era el interior."
    "Since it was night and he didn't want to turn on the lights, assuming there was electricity, you couldn't see the interior well."

# game/script.rpy:4508
translate english day6_ad5e91a0:

    # "Pero por el olor a humedad y polvo, además del crujido bajo tus pies, podías asumir que el lugar no estaba en buen estado."
    "But from the smell of dampness and dust, plus the crunch under your feet, you could assume the place was not in good condition."

# game/script.rpy:4509
translate english day6_ff4372e5:

    # "Afortunadamente, Jeff ofreció la cama especialmente para ti, diciendo que tenía cosas que hacer."
    "Fortunately, Jeff offered the bed specifically for you, saying he had things to do."

# game/script.rpy:4510
translate english day6_6a8f05d2:

    # J "¿Vas a seguir fingiendo dormir?"
    J "Are you still pretending to sleep?"

# game/script.rpy:4511
translate english day6_cfc5541b:

    # "Maldices internamente ante la voz de Jeff."
    "You cursed internally at Jeff's voice."

# game/script.rpy:4516
translate english day6_7fe62379:

    # "Abres tu ojo, y te encuentras con algo que no esperabas que sería lo primero que vieras en el día."
    "You opened your eye, and found something you didn't expect to be the first thing you'd see that day."

# game/script.rpy:4517
translate english day6_18aff43c:

    # J "Buenos días, [povname]."
    J "Good morning, [povname]."

# game/script.rpy:4518
translate english day6_37ac9348:

    # "Jeff está apoyado en el borde de la cama, a centímetros de ti."
    "Jeff was leaning on the edge of the bed, inches from you."

# game/script.rpy:4519
translate english day6_d27b5198:

    # "Te mira fijamente, recorriendo cada centímetro de tu rostro."
    "He stared at you fixedly, tracing every inch of your face."

# game/script.rpy:4520
translate english day6_e208128f:

    # pov "Buenas…"
    pov "Morning..."

# game/script.rpy:4521
translate english day6_e7791ccb:

    # "Era raro estar con Jeff y que no tenga la intención de herirte."
    "It was strange to be with Jeff and for him not to intend to hurt you."

# game/script.rpy:4522
translate english day6_c448a695:

    # "Claro, sucedió lo del bar, pero aún estabas en guardia por lo que hizo anoche."
    "Sure, the bar thing happened, but you were still on guard because of what he did last night."

# game/script.rpy:4523
translate english day6_d88485c6:

    # "También era… curioso verlo sin la sudadera blanca de siempre."
    "It was also... curious to see him without his usual white hoodie."

# game/script.rpy:4524
translate english day6_9b310ba8:

    # "Ver los brazos desnudos y la silueta de la cintura de Jeff se sentía como ver los tobillos de una mujer victoriana."
    "Seeing his bare arms and the silhouette of Jeff's waist felt like seeing a Victorian woman's ankles."

# game/script.rpy:4525
translate english day6_98eceaf6:

    # "Jeff asintió levemente ante tu saludo, manteniendo su sonrisa."
    "Jeff nodded slightly at your greeting, maintaining his smile."

# game/script.rpy:4526
translate english day6_258ed24c:

    # J "No hay necesidad de tanta cautela."
    J "No need for so much caution."

# game/script.rpy:4527
translate english day6_af6dac57:

    # J "Ya no quiero matarte."
    J "I don't want to kill you anymore."

# game/script.rpy:4528
translate english day6_f771528d:

    # "Bueno, eso sonaba tranquilizador."
    "Well, that sounded reassuring."

# game/script.rpy:4529
translate english day6_41f11f90:

    # "Pero se trataba de Jeff."
    "But it was Jeff."

# game/script.rpy:4530
translate english day6_1e42b635:

    # "El tipo era todo menos confiable."
    "The guy was anything but trustworthy."

# game/script.rpy:4534
translate english day6_9b0f8d89:

    # pov "¿En serio?"
    pov "Really?"

# game/script.rpy:4539
translate english day6_11052a4e:

    # pov "No te creo."
    pov "I don't believe you."

# game/script.rpy:4544
translate english ruta_normal_31_f7332dde:

    # "Jeff ríe entre dientes, tocando la punta de tu nariz con su índice."
    "Jeff chuckled, touching the tip of your nose with his index finger."

# game/script.rpy:4545
translate english ruta_normal_31_b4f97ccb:

    # J "Vayamos a desayunar."
    J "Let's go have breakfast."

# game/script.rpy:4546
translate english ruta_normal_31_ce617998:

    # "…"
    "..."

# game/script.rpy:4547
#translate english ruta_normal_31_78ddbf00:

    # "Él evitó la pregunta, ¿Cierto?"
    #"He avoided the question, didn't he?"

# game/script.rpy:4549
translate english ruta_normal_31_d7bb31f1:

    # "Él se levanta y se mantiene de pie junto a la cama, mirándote expectante."
    "He stood up and remained standing by the bed, looking at you expectantly."

# game/script.rpy:4554
translate english ruta_normal_31_8ac00f36:

    # "Te levantas lentamente, y te ves en una habitación demasiado amplia, pero bastante destartalada."
    "You slowly stood up, and you found yourself in a very large, but quite dilapidated room."

# game/script.rpy:4555
translate english ruta_normal_31_d75f57b3:

    # "No había muebles además de la cama, pero al menos la ventana no estaba rota."
    "There was no furniture besides the bed, but at least the window wasn't broken."

# game/script.rpy:4556
translate english ruta_normal_31_ce64e646:

    # "Entonces te das cuenta que sólo estás en ropa para dormir y sin zapatos."
    "Then you realized you were only in your sleepwear and barefoot."

# game/script.rpy:4557
translate english ruta_normal_31_7778d3b1:

    # "¿Realmente corriste por varias calles sin pisar un clavo o un pedazo de vidrio?, que suerte que no te haya dado tétanos."
    "Did you really run through several streets without stepping on a nail or a piece of glass? Lucky you didn't get tetanus."

# game/script.rpy:4558
translate english ruta_normal_31_4fec3241:

    # pov "No tengo zapatos…"
    pov "I don't have shoes..."

# game/script.rpy:4560
translate english ruta_normal_31_41b05a8a:

    # "Jeff desvía la mirada pensativo."
    "Jeff looked away thoughtfully."

# game/script.rpy:4561
translate english ruta_normal_31_ef303fc2:

    # J "Espera un momento."
    J "Wait."

# game/script.rpy:4563
translate english ruta_normal_31_7cce5824:

    # "Jeff desaparece por la puerta, y escuchas movimiento desde el otro lado de la habitación."
    "Jeff disappeared through the door, and you heard movement from the other side of the room."

# game/script.rpy:4566
translate english ruta_normal_31_fee15d7d:

    # "Pronto, Jeff reaparece, con dos pantuflas, de distinto tamaño cada una."
    "Soon, Jeff reappeared, with two slippers, each of a different size."

# game/script.rpy:4567
translate english ruta_normal_31_6c8a2e83:

    # J "Es lo que encontré a mano, luego buscaremos ropa para ti."
    J "That's what I found handy, then we'll look for clothes for you."

# game/script.rpy:4568
translate english ruta_normal_31_5d253cdc:

    # "Aceptas con resignación las pantuflas."
    "You accepted the slippers with resignation."

# game/script.rpy:4569
translate english ruta_normal_31_da1c9d8c:

    # "No están rotas ni mugrosas, sólo con algo de polvo."
    "They weren't torn or dirty, just a bit dusty."

# game/script.rpy:4570
translate english ruta_normal_31_b0e8de99:

    # "Son de distinta talla, una te queda bien y la otra te queda suelta, pero era mejor que andar pisando tétanos."
    "They were mismatched sizes, one fit you well and the other was loose, but it was better than walking on tetanus."

# game/script.rpy:4571
translate english ruta_normal_31_d1e890a4:

    # pov "Gracias."
    pov "Thanks."

# game/script.rpy:4573
translate english ruta_normal_31_de9b7ba1:

    # "Jeff sonrió ampliamente ante tu agradecimiento, incluso pudiste ver como el color subía a su rostro."
    "Jeff smiled broadly at your gratitude; you could even see a blush creep up his face."

# game/script.rpy:4574
translate english ruta_normal_31_9de67b00:

    # J "Ven."
    J "Come."

# game/script.rpy:4576
translate english ruta_normal_31_371f22b9:

    # "Jeff tomó tu muñeca, el agarre era firme, pero no te hacía daño. Él tiró de ti, pero a diferencia de otras veces, fue suave y calmo."
    "Jeff took your wrist, his grip firm, but it didn't hurt. He pulled you along, but unlike other times, it was gentle and calm."

# game/script.rpy:4578
translate english ruta_normal_31_2fbd8868:

    # "Te guió por el interior de la casa, hasta llegar a lo que sería un comedor, por la mesa y dos sillas. Había un minirefri y una cocina en la habitación contigua, pero dudabas de que funcionaran."
    "He led you through the house, to what would be a dining area, with a table and two chairs. There was a mini-fridge and a kitchen in the adjacent room, but you doubted they worked."

# game/script.rpy:4581
translate english ruta_normal_31_64b40913:

    # J "Traje el desayuno."
    J "I brought breakfast."

# game/script.rpy:4586
translate english ruta_normal_31_d89112bb:

    # J "Un latte con leche de soya."
    J "A soy milk latte."

# game/script.rpy:4588
translate english ruta_normal_31_8d233d3d:

    # J "Un latte con leche descremada."
    J "A skim milk latte."

# game/script.rpy:4589
translate english ruta_normal_31_a87c16fe:

    # "Él te extiende un vaso de cartón, y tu lo recibes entre tus manos, está tibio."
    "He extended a paper cup to you, and you took it; it was warm."

# game/script.rpy:4591
translate english ruta_normal_31_46b605bc:

    # pov "¿Cómo-?"
    pov "How—?"

# game/script.rpy:4592
translate english ruta_normal_31_6d7d8495:

    # J "¿Supe tu preferencia?"
    J "Did I know your preference?"

# game/script.rpy:4594
translate english ruta_normal_31_114eee96:

    # "La sonrisa de él se tornó burlona."
    "His smile turned mocking."

# game/script.rpy:4595
translate english ruta_normal_31_e950be2e:

    # J "Vamos, [povname], eres inteligente."
    J "Come on, [povname], you're smart."

# game/script.rpy:4596
translate english ruta_normal_31_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4597
translate english ruta_normal_31_1c6bb11a:

    # "Por supuesto, es porque te siguió durante días."
    "Of course, it was because he had been following you for days."

# game/script.rpy:4598
translate english ruta_normal_31_24e12323:

    # "Seguramente averiguó esas cosas tras vigilarte."
    "He surely found out those things by watching you."

# game/script.rpy:4599
translate english ruta_normal_31_725b544e:

    # J "No creas que olvidé lo comestible."
    J "Don't think I forgot the edible stuff."

# game/script.rpy:4604
translate english ruta_normal_31_841d20fd:

    # J "También te traje un muffin."
    J "I also brought you a muffin."

# game/script.rpy:4609
translate english ruta_normal_31_78d74fa2:

    # J "Te conseguí un sandwich."
    J "I got you a sandwich."

# game/script.rpy:4611
translate english ruta_normal_31_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:4612
translate english ruta_normal_31_93a90f6b:

    # pov "Ok, iré al grano."
    pov "Okay, I'll get to the point."

# game/script.rpy:4613
translate english ruta_normal_31_6e532a75:

    # pov "¿Estás intentando ser algo así como un novio atento?"
    pov "Are you trying to be an attentive boyfriend or something?"

# game/script.rpy:4615
translate english ruta_normal_31_80e50a4a:

    # "Jeff ladeó la cabeza interrogativamente."
    "Jeff tilted his head interrogatively."

# game/script.rpy:4616
translate english ruta_normal_31_13024660:

    # J "¿De qué hablas?"
    J "What are you talking about?"

# game/script.rpy:4617
translate english ruta_normal_31_1f4faf37:

    # pov "Me arrancaste un ojo, te colaste a mi habitación de hospital, te metiste en mi casa, ¿Quieres que olvide todo eso?"
    pov "You ripped out my eye, you snuck into my hospital room, you broke into my house. Do you want me to forget all that?"

# game/script.rpy:4618
translate english ruta_normal_31_22cf5fca:

    # pov "¿Cómo se supone que yo crea que me amas si me has hecho pasar un infierno?"
    pov "How am I supposed to believe you love me if you've put me through hell?"

# game/script.rpy:4621
translate english ruta_normal_31_fd817c26:

    # "Jeff te mira con curiosidad, para luego dirigirse al minirefri."
    "Jeff looked at you with curiosity, then headed to the mini-fridge."

# game/script.rpy:4622
translate english ruta_normal_31_fa265151:

    # J "No quiero que olvides lo que hice."
    J "I don't want you to forget what I did."

# game/script.rpy:4623
translate english ruta_normal_31_77916e09:

    # "Él musitó suavemente, sacando un frasco del mini refri."
    "He mumbled softly, pulling a jar from the mini-fridge."

# game/script.rpy:4624
translate english ruta_normal_31_ebdadfbd:

    # J "Sólo que lo veas desde una perspectiva diferente."
    J "Just see it from a different perspective."

# game/script.rpy:4631
translate english ruta_normal_31_63ce932d:

    # "Él puso el fresco frente a ti."
    "He placed the jar in front of you."

# game/script.rpy:4632
translate english ruta_normal_31_d6c2f881:

    # "Dentro, había un líquido transparente espeso, que rozaba con el amarillo. En el interior, al fondo, ves una mancha de color rojo oscuro mezclado con negro."
    "Inside, there was a thick, transparent liquid, yellowish. Inside, at the bottom, you saw a dark red stain mixed with black."

# game/script.rpy:4633
translate english ruta_normal_31_823b8798:

    # "Entonces, él lo gira."
    "Then, he turned it."

# game/script.rpy:4641
translate english ruta_normal_31_2571b751:

    # "Es tu ojo."
    "It was your eye."

# game/script.rpy:4642
translate english ruta_normal_31_2aa646a4:

    # "Sientes frío."
    "You felt cold."

# game/script.rpy:4645
translate english ruta_normal_31_1a0e26a1:

    # J "Tu ojo es tan lindo… No pude evitar guardarlo."
    J "Your eye is so pretty... I couldn't help but keep it."

# game/script.rpy:4649
translate english ruta_normal_31_05f357bd:

    # "Jeff se dirige a ti, sujetando tus mejillas entre sus manos."
    "Jeff came towards you, holding your cheeks between his hands."

# game/script.rpy:4650
translate english ruta_normal_31_f8f0edeb:

    # J "Pero ahora tengo algo mejor, a ti."
    J "But now I have something better, you."

# game/script.rpy:4651
translate english ruta_normal_31_53b5cb31:

    # "Él acaricia tu piel con sus pulgares, bajando los ojos hacia tus labios."
    "He caressed your skin with his thumbs, lowering his eyes to your lips."

# game/script.rpy:4652
translate english ruta_normal_31_90387985:

    # J "Lo que tenemos es especial… Y me aseguraré de que también lo veas."
    J "What we have is special... And I'll make sure you see it too."

# game/script.rpy:4653
translate english ruta_normal_31_e213b787:

    # "Sientes que un escalofrío te atraviesa. Llegas a la conclusión de que no tienes escapatoria."
    "You felt a shiver run through you. You came to the conclusion that you had no escape."

# game/script.rpy:4654
translate english ruta_normal_31_411f3080:

    # "Físicamente, es casi imposible escapar de Jeff. Incluso si lo intentas, por cómo él se expresa, no crees que dude en encadenarte a su lado o cortarte las piernas para que no huyas."
    "Physically, it was almost impossible to escape Jeff. Even if you tried, by the way he expressed himself, you didn't think he would hesitate to chain you to his side or cut off your legs so you wouldn't run."

# game/script.rpy:4655
translate english ruta_normal_31_3fa08942:

    # "Tampoco puedes pedir ayuda, Jeff mataría a cualquiera que se acerque a ti. Lo sabes por experiencia."
    "You couldn't ask for help either; Jeff would kill anyone who approached you. You knew that from experience."

# game/script.rpy:4661
translate english ruta_normal_31_fde358df:

    # pov "Estás demente…"
    pov "You're crazy..."

# game/script.rpy:4663
translate english ruta_normal_31_b681b637:

    # "Jeff suelta una carcajada estridente, bajando sus manos a tus hombros."
    "Jeff let out a strident laugh, lowering his hands to your shoulders."

# game/script.rpy:4664
translate english ruta_normal_31_d35a1ad6:

    # J "Completamente."
    J "Completely."

# game/script.rpy:4667
translate english ruta_normal_31_d51b3aa1:

    # pov "Seh, entiendo lo que dices."
    pov "Yeah, I understand what you're saying."

# game/script.rpy:4669
translate english ruta_normal_31_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4670
translate english ruta_normal_31_71a1df4f:

    # J "Me sorprende que lo aceptes tan fácilmente."
    J "I'm surprised you accept it so easily."

# game/script.rpy:4675
translate english ruta_normal_32_1d5838c0:

    # pov "Ok, ok."
    pov "Okay, okay."

# game/script.rpy:4676
translate english ruta_normal_32_3e6fe275:

    # pov "Tomaré tu tonto desayuno."
    pov "I'll eat your stupid breakfast."

# game/script.rpy:4678
translate english ruta_normal_32_6ece30ea:

    # "Jeff sonrió ampliamente, inclinándose hacia ti."
    "Jeff smiled broadly, leaning towards you."

# game/script.rpy:4679
translate english ruta_normal_32_08b0726f:

    # "En un momento pensaste que te iba a besar, por lo que cerraste tu ojo, pero entonces sentiste un toque ligero en tu frente."
    "For a moment you thought he was going to kiss you, so you closed your eye, but then you felt a light touch on your forehead."

# game/script.rpy:4681
translate english ruta_normal_32_4239d584:

    # "Jeff besa tu frente por unos segundos, para después liberarte y tomar asiento en la mesa."
    "Jeff kissed your forehead for a few seconds, then released you and sat at the table."

# game/script.rpy:4684
translate english ruta_normal_32_69771d33:

    # "Sigues su ejemplo y tomas asiento."
    "You followed his example and sat down."

# game/script.rpy:4685
translate english ruta_normal_32_0169e7f5:

    # "En silencio, bebes el latte y comes el bocadillo que te trajo."
    "In silence, you drank the latte and ate the snack he brought you."

# game/script.rpy:4686
translate english ruta_normal_32_16773c69:

    # pov "¿De dónde sacaste esto?"
    pov "Where did you get this?"

# game/script.rpy:4687
translate english ruta_normal_32_5dca7d2e:

    # J "¿Crees que no sé sobre las cadenas de comida?"
    J "Don't you think I know about food chains?"

# game/script.rpy:4688
translate english ruta_normal_32_64c58861:

    # J "A varias calles de aquí hay una sucursal de una cafetería."
    J "There's a coffee shop branch a few blocks from here."

# game/script.rpy:4689
translate english ruta_normal_32_994f58f1:

    # pov "¿Tú tomaste desayuno?"
    pov "Did you have breakfast?"

# game/script.rpy:4691
translate english ruta_normal_32_d0cbca46:

    # "Jeff se sonroja levemente, sonriendo afectuosamente."
    "Jeff blushed slightly, smiling affectionately."

# game/script.rpy:4692
translate english ruta_normal_32_cea94b78:

    # J "Si, hace horas."
    J "Yeah, hours ago."

# game/script.rpy:4693
translate english ruta_normal_32_e1a49023:

    # J "Lamento no acompañarte, pero nuestros horarios son diferentes."
    J "I'm sorry I didn't join you, but our schedules are different."

# game/script.rpy:4697
translate english ruta_normal_32_f9f09698:

    # pov "¿Y eso por qué?"
    pov "And why is that?"

# game/script.rpy:4699
translate english ruta_normal_32_7c52190c:

    # J "Al ser un fugitivo, suelo comprar y comer en la madrugada."
    J "As a fugitive, I usually buy and eat late at night."

# game/script.rpy:4700
translate english ruta_normal_32_2d9a03fe:

    # J "Los empleados están cansados y malhumorados, así que no me prestan atención."
    J "Employees are tired and grumpy, so they don't pay attention to me."

# game/script.rpy:4705
translate english ruta_normal_32_cb9dbbbe:

    # pov "¿Y si en la cena te unes a mí?"
    pov "What if you join me for dinner?"

# game/script.rpy:4707
translate english ruta_normal_32_9ac12320:

    # J "Oh, eso me encantaría."
    J "Oh, I'd love that."

# game/script.rpy:4708
translate english ruta_normal_32_b539c844:

    # "Escuchas cómo él suspira levemente."
    "You heard him sigh softly."

# game/script.rpy:4713
translate english ruta_normal_33_6d631ceb:

    # pov "Espera, ¿Pagaste esto con dinero?"
    pov "Wait, did you pay for this with money?"

# game/script.rpy:4715
translate english ruta_normal_33_c772f825:

    # "Jeff ladea la cabeza, como si estuviera alzando una ceja que no tiene."
    "Jeff tilted his head, as if raising an eyebrow he didn't have."

# game/script.rpy:4716
translate english ruta_normal_33_35a88c7e:

    # J "¿De qué otra forma pude haberlo conseguido?"
    J "How else could I have gotten it?"

# game/script.rpy:4717
translate english ruta_normal_33_607291cb:

    # pov "No sé, robo a mano armada."
    pov "I don't know, armed robbery."

# game/script.rpy:4719
translate english ruta_normal_33_c0eecd4e:

    # J "Tch, no soy tan descuidado."
    J "Tch, I'm not that careless."

# game/script.rpy:4720
translate english ruta_normal_33_acba4af7:

    # J "Ya me buscan por asesinato e incendio provocado, no voy a agregar robo a esa lista."
    J "They're already looking for me for murder and arson, I'm not adding robbery to that list."

# game/script.rpy:4721
translate english ruta_normal_33_ac8ebcf9:

    # pov "¿Y de donde sacas el dinero?"
    pov "And where do you get the money?"

# game/script.rpy:4723
translate english ruta_normal_33_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4724
translate english ruta_normal_33_22ca5f90:

    # J "Bueno, sería un desperdicio no quedarse con el dinero de algunas de las personas que mato."
    J "Well, it would be a waste not to keep the money from some of the people I kill."

# game/script.rpy:4725
translate english ruta_normal_33_83521234:

    # "La manera en que él admite matar gente tan relajado es escalofriante."
    "The way he calmly admitted to killing people was chilling."

# game/script.rpy:4726
translate english ruta_normal_33_933d1ccf:

    # pov "Geez, eres patético. No te vale con matar gente, también le robas."
    pov "Geez, you're pathetic. It's not enough for you to kill people, you rob them too."

# game/script.rpy:4727
translate english ruta_normal_33_b8252e52:

    # J "Hey, al menos esos asesinatos no son atribuidos a mí. Se alejan de mi modus operandi, y pasan a considerarse robo."
    J "Hey, at least those murders aren't attributed to me. They're outside my modus operandi, and they're considered robbery."

# game/script.rpy:4728
translate english ruta_normal_33_f6f67e20:

    # pov "Eso no es razón de estar orgulloso, Jeff."
    pov "That's no reason to be proud, Jeff."

# game/script.rpy:4729
translate english ruta_normal_33_fa773a75:

    # pov "Nada de lo que dices es razón para estarlo."
    pov "Nothing you say is a reason to be proud."

# game/script.rpy:4730
translate english ruta_normal_33_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4732
translate english ruta_normal_33_dce8af4b:

    # J "Eres adorable cuando me juzgas."
    J "You're adorable when you judge me."

# game/script.rpy:4733
translate english ruta_normal_33_fbe721e8:

    # "Oh no, ha caído por completo."
    "Oh no, he's completely fallen."

# game/script.rpy:4734
translate english ruta_normal_33_63c7759e:

    # "Pero no puedes bajar la guardia, tampoco tomar ventaja de eso."
    "But you couldn't let your guard down, nor take advantage of it."

# game/script.rpy:4735
translate english ruta_normal_33_bfa8cd89:

    # "Por más tonto de amor que se vea, sigue siendo un desquiciado que, por lo que has aprendido recientemente, es más calculador de lo que aparenta."
    "However foolishly in love he may seem, he was still a maniac who, from what you'd recently learned, was more calculating than he appeared."

# game/script.rpy:4736
translate english ruta_normal_33_510ce023:

    # pov "¿Nunca te habías enamorado antes?"
    pov "Have you ever been in love before?"

# game/script.rpy:4738
translate english ruta_normal_33_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4739
translate english ruta_normal_33_7932a8d4:

    # J "Creo que una vez, si se le puede llamar así."
    J "I think once, if you can call it that."

# game/script.rpy:4740
translate english ruta_normal_33_1328bb2c:

    # pov "Oh, ¿De quién?"
    pov "Oh, with whom?"

# game/script.rpy:4742
translate english ruta_normal_33_5982e346:

    # J "Una mujer con la que pasé tres noches."
    J "A woman I spent three nights with."

# game/script.rpy:4743
translate english ruta_normal_33_f60c587f:

    # pov "Asco."
    pov "Gross."

# game/script.rpy:4745
translate english ruta_normal_33_03fedf7b:

    # J "¡No de esa forma!, Fue íntimo de otra manera."
    J "Not that way! It was intimate in another way."

# game/script.rpy:4747
translate english ruta_normal_33_a41793da:

    # J "Hablamos todo el tiempo. Sentí que ella me comprendía."
    J "We talked all the time. I felt she understood me."

# game/script.rpy:4749
translate english ruta_normal_33_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:4750
translate english ruta_normal_33_f8201474:

    # J "¿Qué me dices de ti?"
    J "What about you?"

# game/script.rpy:4751
translate english ruta_normal_33_0b838cd8:

    # J "¿Te has enamorado antes?"
    J "Have you ever been in love before?"

# game/script.rpy:4755
translate english ruta_normal_33_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:4756
translate english ruta_normal_33_f24ea46c:

    # J "Pero eso ya pasó, ¿No?"
    J "But that's in the past, right?"

# game/script.rpy:4757
translate english ruta_normal_33_5e8dbdaf:

    # "Cierto, él es el tipo celoso."
    "Right, he's the jealous type."

# game/script.rpy:4758
translate english ruta_normal_33_97f17220:

    # pov "Obviamente."
    pov "Obviously."

# game/script.rpy:4762
translate english ruta_normal_33_adb437bd:

    # "Jeff amplió su sonrisa"
    "Jeff broadened his smile."

# game/script.rpy:4768
translate english character_8_a6d414ee:

    # J "¿Entonces cuál es tu preferencia?"
    J "So what's your preference?"

# game/script.rpy:4769
translate english character_8_d730ab6e:

    # J "¿Hombre, mujer, ambos?"
    J "Man, woman, both?"

# game/script.rpy:4774
translate english character_8_eef15567:

    # J "Me aseguraré de que no pienses en ninguno más que yo."
    J "I'll make sure you don't think of anyone but me."

# game/script.rpy:4777
translate english character_8_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4779
translate english character_8_20fad819:

    # J "No puedo evitar ser un hombre."
    J "I can't help being a man."

# game/script.rpy:4781
translate english character_8_380d298b:

    # J "Pero no te dejaré ir sólo por eso."
    J "But I won't let you go just for that."

# game/script.rpy:4785
translate english character_8_f0f85b68:

    # J "Ah, tengo doble competencia."
    J "Ah, I have double competition."

# game/script.rpy:4786
translate english character_8_6fe70448:

    # J "Te aseguro que no suelo perder."
    J "I assure you I don't usually lose."

# game/script.rpy:4790
translate english character_8_6fe96c38:

    # "Jef se ríe levemente, contento."
    "Jeff chuckled softly, pleased."

# game/script.rpy:4791
translate english character_8_e3a88074:

    # J "Eres como yo."
    J "You're like me."

# game/script.rpy:4792
translate english character_8_19dd0302:

    # J "A mí tampoco me importa."
    J "I don't care either."

# game/script.rpy:4793
translate english character_8_bd4ba19a:

    # J "A ti te amo porque eres tú."
    J "I love you because you're you."

# game/script.rpy:4797
translate english character_8_8a93848e:

    # J "Huh."
    J "Huh."

# game/script.rpy:4798
translate english character_8_dffe318c:

    # "La sonrisa de él se volvió traviesa."
    "His smile turned mischievous."

# game/script.rpy:4799
translate english character_8_f26d8ce2:

    # J "Haré que me consideres a mí, y sólo a mí."
    J "I'll make you consider me, and only me."

# game/script.rpy:4804
translate english character_9_db2102ac:

    # J "Mientras más sé cosas sobre ti, más me gustas."
    J "The more I know about you, the more I like you."

# game/script.rpy:4805
translate english character_9_95a61e2b:

    # pov "¿Puedo saber cosas de ti también?"
    pov "Can I know things about you too?"

# game/script.rpy:4806
translate english character_9_fac559cf:

    # J "Por supuesto."
    J "Of course."

# game/script.rpy:4812
translate english character_9_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4813
translate english character_9_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Obviously I had it at the beginning."

# game/script.rpy:4814
translate english character_9_6dfaad92:

    # J "Una madre, un padre."
    J "A mother, a father."

# game/script.rpy:4815
translate english character_9_4b5c3a9e:

    # J "… Un hermano."
    J "... A brother."

# game/script.rpy:4816
translate english character_9_424f497b:

    # J "Pero los perdí."
    J "But I lost them."

# game/script.rpy:4821
translate english character_9_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4823
translate english character_9_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Jeff let out a dispirited chuckle."

# game/script.rpy:4824
translate english character_9_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "You know me better than I thought."

# game/script.rpy:4827
translate english character_9_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4828
translate english character_9_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], you're smart, I'm sure you know the answer."

# game/script.rpy:4832
translate english character_9_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "There was a time when I lived with some guys."

# game/script.rpy:4833
translate english character_9_a5531769:

    # J "Era una casa grande, éramos varios."
    J "It was a big house, there were several of us."

# game/script.rpy:4834
translate english character_9_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "Each had... their peculiarities."

# game/script.rpy:4836
translate english character_9_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "But they're the closest thing I can call friends."

# game/script.rpy:4839
translate english character_9_becae388:

    # J "No lo eran, créeme."
    J "They weren't, believe me."

# game/script.rpy:4840
translate english character_9_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Why do you think they lived with a killer like me?"

# game/script.rpy:4841
translate english character_9_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4842
translate english character_9_37b98de6:

    # J "Así es, mataban gente también."
    J "That's right, they killed people too."

# game/script.rpy:4847
translate english character_9_a46e5454:

    # J "Hah, lo eran."
    J "Hah, they were."

# game/script.rpy:4849
translate english character_9_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "The owner of the house was... expressionless."

# game/script.rpy:4850
translate english character_9_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "One of them was a cannibal... I think you can call him that?"

# game/script.rpy:4851
translate english character_9_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Another spent his time playing video games."

# game/script.rpy:4852
translate english character_9_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "One dressed as a clown, and a couple spent their time filming."

# game/script.rpy:4853
translate english character_9_af0d79a7:

    # J "Así que sí, son raros."
    J "So yes, they are weird."

# game/script.rpy:4857
translate english character_9_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:4858
translate english character_9_d5ff44d8:

    # J "No te diré."
    J "I won't tell you."

# game/script.rpy:4859
translate english character_9_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Oh, come on!"

# game/script.rpy:4860
translate english character_9_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "At least give me a range?"

# game/script.rpy:4861
translate english character_9_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:4862
translate english character_9_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "How old are you?"

# game/script.rpy:4865
translate english character_9_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:4866
translate english character_9_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "But you're of legal age, right?"

# game/script.rpy:4867
translate english character_9_97bf5def:

    # pov "Por supuesto."
    pov "Of course."

# game/script.rpy:4868
translate english character_9_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Good, I don't date minors."

# game/script.rpy:4869
translate english character_9_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "That's... good, I guess?"

# game/script.rpy:4870
translate english character_9_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "How many positive things can there be about a murderer?"

# game/script.rpy:4871
translate english character_9_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "… But, I'm considerably older."

# game/script.rpy:4872
translate english character_9_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Don't worry, I can handle mature men."

# game/script.rpy:4875
translate english character_9_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Alright, I'm older than you."

# game/script.rpy:4876
translate english character_9_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "You really are not going to tell me how much?"

# game/script.rpy:4877
translate english character_9_290da55e:

    # "Jeff refunfuñó."
    "Jeff grumbled."

# game/script.rpy:4878
translate english character_9_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "So older, huh?"

# game/script.rpy:4881
translate english character_9_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "We're about the same age, happy?"

# game/script.rpy:4882
translate english character_9_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "So thirtysomething, huh?"

# game/script.rpy:4884
translate english character_9_dbe4fbfd:

    # J "Cállate."
    J "Shut up."

# game/script.rpy:4889
translate english character_9_ffcd567a:

    # pov "Estás en buena forma."
    pov "You're in good shape."

# game/script.rpy:4891
translate english character_9_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Even if you're not that young, you look good."

# game/script.rpy:4893
translate english character_9_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Ignoring how messed up his face was, of course."

# game/script.rpy:4894
translate english character_9_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Jeff said nothing, but you noticed his cheeks flush."

# game/script.rpy:4897
translate english character_9_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "To be so old, you look good."

# game/script.rpy:4898
translate english character_9_b1bf0aaa:

    # "Jeff resopla."
    "Jeff snorted."

# game/script.rpy:4910
translate english familia0_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "There was a time when I lived with some guys."

# game/script.rpy:4911
translate english familia0_a5531769:

    # J "Era una casa grande, éramos varios."
    J "It was a big house, there were several of us."

# game/script.rpy:4912
translate english familia0_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "Each had... their peculiarities."

# game/script.rpy:4914
translate english familia0_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "But they're the closest thing I can call friends."

# game/script.rpy:4917
translate english familia0_becae388:

    # J "No lo eran, créeme."
    J "They weren't, believe me."

# game/script.rpy:4918
translate english familia0_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Why do you think they lived with a killer like me?"

# game/script.rpy:4919
translate english familia0_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4920
translate english familia0_37b98de6:

    # J "Así es, mataban gente también."
    J "That's right, they killed people too."

# game/script.rpy:4925
translate english familia0_a46e5454:

    # J "Hah, lo eran."
    J "Hah, they were."

# game/script.rpy:4927
translate english familia0_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "The owner of the house was... expressionless."

# game/script.rpy:4928
translate english familia0_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "One of them was a cannibal... I think you can call him that?"

# game/script.rpy:4929
translate english familia0_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Another spent his time playing video games."

# game/script.rpy:4930
translate english familia0_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "One dressed as a clown, and a couple spent their time filming."

# game/script.rpy:4931
translate english familia0_af0d79a7:

    # J "Así que sí, son raros."
    J "So yes, they are weird."

# game/script.rpy:4935
translate english familia0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4936
translate english familia0_d5ff44d8:

    # J "No te diré."
    J "I won't tell you."

# game/script.rpy:4937
translate english familia0_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Oh, come on!"

# game/script.rpy:4938
translate english familia0_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "At least give me a range?"

# game/script.rpy:4939
translate english familia0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4940
translate english familia0_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "How old are you?"

# game/script.rpy:4943
translate english familia0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4944
translate english familia0_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "But you're of legal age, right?"

# game/script.rpy:4945
translate english familia0_97bf5def:

    # pov "Por supuesto."
    pov "Of course."

# game/script.rpy:4946
translate english familia0_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Good, I don't date minors."

# game/script.rpy:4947
translate english familia0_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "That's... good, I guess?"

# game/script.rpy:4948
translate english familia0_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "How many positive things can there be about a murderer?"

# game/script.rpy:4949
translate english familia0_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "… But, I'm considerably older."

# game/script.rpy:4950
translate english familia0_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Don't worry, I can handle mature men."

# game/script.rpy:4952
translate english familia0_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Alright, I'm older than you."

# game/script.rpy:4953
translate english familia0_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "You really are not going to tell me how much?"

# game/script.rpy:4954
translate english familia0_290da55e:

    # "Jeff refunfuñó."
    "Jeff grumbled."

# game/script.rpy:4955
translate english familia0_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "So older, huh?"

# game/script.rpy:4957
translate english familia0_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "We're about the same age, happy?"

# game/script.rpy:4958
translate english familia0_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "So thirtysomething, huh?"

# game/script.rpy:4960
translate english familia0_dbe4fbfd:

    # J "Cállate."
    J "Shut up."

# game/script.rpy:4965
translate english familia0_ffcd567a:

    # pov "Estás en buena forma."
    pov "You're in good shape."

# game/script.rpy:4967
translate english familia0_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Even if you're not that young, you look good."

# game/script.rpy:4969
translate english familia0_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Ignoring how messed up his face was, of course."

# game/script.rpy:4970
translate english familia0_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Jeff said nothing, but you noticed his cheeks flush."

# game/script.rpy:4973
translate english familia0_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "To be so old, you look good."

# game/script.rpy:4974
translate english familia0_b1bf0aaa:

    # "Jeff resopla."
    "Jeff snorted."

# game/script.rpy:4984
translate english amigos0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4985
translate english amigos0_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Obviously I had it at the beginning."

# game/script.rpy:4986
translate english amigos0_6dfaad92:

    # J "Una madre, un padre."
    J "A mother, a father."

# game/script.rpy:4987
translate english amigos0_4b5c3a9e:

    # J "… Un hermano."
    J "... A brother."

# game/script.rpy:4988
translate english amigos0_424f497b:

    # J "Pero los perdí."
    J "But I lost them."

# game/script.rpy:4993
translate english amigos0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4995
translate english amigos0_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Jeff let out a dispirited chuckle."

# game/script.rpy:4996
translate english amigos0_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "You know me better than I thought."

# game/script.rpy:4999
translate english amigos0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5000
translate english amigos0_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], you're smart, I'm sure you know the answer."

# game/script.rpy:5004
translate english amigos0_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:5005
translate english amigos0_d5ff44d8:

    # J "No te diré."
    J "I won't tell you."

# game/script.rpy:5006
translate english amigos0_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Oh, come on!"

# game/script.rpy:5007
translate english amigos0_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "At least give me a range?"

# game/script.rpy:5008
translate english amigos0_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:5009
translate english amigos0_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "How old are you?"

# game/script.rpy:5012
translate english amigos0_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:5013
translate english amigos0_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "But you're of legal age, right?"

# game/script.rpy:5014
translate english amigos0_97bf5def:

    # pov "Por supuesto."
    pov "Of course."

# game/script.rpy:5015
translate english amigos0_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Good, I don't date minors."

# game/script.rpy:5016
translate english amigos0_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "That's... good, I guess?"

# game/script.rpy:5017
translate english amigos0_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "How many positive things can there be about a murderer?"

# game/script.rpy:5018
translate english amigos0_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "… But, I'm considerably older."

# game/script.rpy:5019
translate english amigos0_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Don't worry, I can handle mature men."

# game/script.rpy:5022
translate english amigos0_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Alright, I'm older than you."

# game/script.rpy:5023
translate english amigos0_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "You really are not going to tell me how much?"

# game/script.rpy:5024
translate english amigos0_290da55e:

    # "Jeff refunfuñó."
    "Jeff grumbled."

# game/script.rpy:5025
translate english amigos0_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "So older, huh?"

# game/script.rpy:5028
translate english amigos0_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "We're about the same age, happy?"

# game/script.rpy:5029
translate english amigos0_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "So thirtysomething, huh?"

# game/script.rpy:5031
translate english amigos0_dbe4fbfd:

    # J "Cállate."
    J "Shut up."

# game/script.rpy:5036
translate english amigos0_ffcd567a:

    # pov "Estás en buena forma."
    pov "You're in good shape."

# game/script.rpy:5038
translate english amigos0_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Even if you're not that young, you look good."

# game/script.rpy:5040
translate english amigos0_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Ignoring how messed up his face was, of course."

# game/script.rpy:5041
translate english amigos0_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Jeff said nothing, but you noticed his cheeks flush."

# game/script.rpy:5044
translate english amigos0_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "To be so old, you look good."

# game/script.rpy:5045
translate english amigos0_b1bf0aaa:

    # "Jeff resopla."
    "Jeff snorted."

# game/script.rpy:5055
translate english edad0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5056
translate english edad0_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Obviously I had it at the beginning."

# game/script.rpy:5057
translate english edad0_6dfaad92:

    # J "Una madre, un padre."
    J "A mother, a father."

# game/script.rpy:5058
translate english edad0_4b5c3a9e:

    # J "… Un hermano."
    J "… A brother."

# game/script.rpy:5059
translate english edad0_424f497b:

    # J "Pero los perdí."
    J "But I lost them."

# game/script.rpy:5064
translate english edad0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5066
translate english edad0_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Jeff let out a dispirited chuckle."

# game/script.rpy:5067
translate english edad0_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "You know me better than I thought."

# game/script.rpy:5070
translate english edad0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5071
translate english edad0_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], you're smart, I'm sure you know the answer."

# game/script.rpy:5076
translate english edad0_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "There was a time when I lived with some guys."

# game/script.rpy:5077
translate english edad0_a5531769:

    # J "Era una casa grande, éramos varios."
    J "It was a big house, there were several of us."

# game/script.rpy:5078
translate english edad0_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "Each had... their peculiarities."

# game/script.rpy:5080
translate english edad0_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "But they're the closest thing I can call friends."

# game/script.rpy:5083
translate english edad0_becae388:

    # J "No lo eran, créeme."
    J "They weren't, believe me."

# game/script.rpy:5084
translate english edad0_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Why do you think they lived with a killer like me?"

# game/script.rpy:5085
translate english edad0_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5086
translate english edad0_37b98de6:

    # J "Así es, mataban gente también."
    J "That's right, they killed people too."

# game/script.rpy:5091
translate english edad0_a46e5454:

    # J "Hah, lo eran."
    J "Hah, they were."

# game/script.rpy:5093
translate english edad0_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "The owner of the house was... expressionless."

# game/script.rpy:5094
translate english edad0_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "One of them was a cannibal... I think you can call him that?"

# game/script.rpy:5095
translate english edad0_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Another spent his time playing video games."

# game/script.rpy:5096
translate english edad0_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "One dressed as a clown, and a couple spent their time filming."

# game/script.rpy:5097
translate english edad0_af0d79a7:

    # J "Así que sí, son raros."
    J "So yes, they are weird."

# game/script.rpy:5109
translate english familia1_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5110
translate english familia1_1_d5ff44d8:

    # J "No te diré."
    J "I won't tell you."

# game/script.rpy:5111
translate english familia1_1_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Oh, come on!"

# game/script.rpy:5112
translate english familia1_1_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "At least give me a range?"

# game/script.rpy:5113
translate english familia1_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5114
translate english familia1_1_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "How old are you?"

# game/script.rpy:5117
translate english familia1_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5118
translate english familia1_1_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "But you're of legal age, right?"

# game/script.rpy:5119
translate english familia1_1_97bf5def:

    # pov "Por supuesto."
    pov "Of course."

# game/script.rpy:5120
translate english familia1_1_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Good, I don't date minors."

# game/script.rpy:5121
translate english familia1_1_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "That's... good, I guess?"

# game/script.rpy:5122
translate english familia1_1_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "How many positive things can there be about a murderer?"

# game/script.rpy:5123
translate english familia1_1_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "… But, I'm considerably older."

# game/script.rpy:5124
translate english familia1_1_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Don't worry, I can handle mature men."

# game/script.rpy:5127
translate english familia1_1_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Alright, I'm older than you."

# game/script.rpy:5128
translate english familia1_1_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "You really are not going to tell me how much?"

# game/script.rpy:5129
translate english familia1_1_290da55e:

    # "Jeff refunfuñó."
    "Jeff grumbled."

# game/script.rpy:5130
translate english familia1_1_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "So older, huh?"

# game/script.rpy:5133
translate english familia1_1_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "We're about the same age, happy?"

# game/script.rpy:5134
translate english familia1_1_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "So thirtysomething, huh?"

# game/script.rpy:5136
translate english familia1_1_dbe4fbfd:

    # J "Cállate."
    J "Shut up."

# game/script.rpy:5141
translate english familia1_1_ffcd567a:

    # pov "Estás en buena forma."
    pov "You're in good shape."

# game/script.rpy:5143
translate english familia1_1_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Even if you're not that young, you look good."

# game/script.rpy:5145
translate english familia1_1_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Ignoring how messed up his face was, of course."

# game/script.rpy:5146
translate english familia1_1_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Jeff said nothing, but you noticed his cheeks flush."

# game/script.rpy:5149
translate english familia1_1_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "To be so old, you look good."

# game/script.rpy:5150
translate english familia1_1_b1bf0aaa:

    # "Jeff resopla."
    "Jeff snorted."

# game/script.rpy:5160
translate english familia1_2_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "There was a time when I lived with some guys."

# game/script.rpy:5161
translate english familia1_2_a5531769:

    # J "Era una casa grande, éramos varios."
    J "It was a big house, there were several of us."

# game/script.rpy:5162
translate english familia1_2_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "Each had... their peculiarities."

# game/script.rpy:5164
translate english familia1_2_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "But they're the closest thing I can call friends."

# game/script.rpy:5167
translate english familia1_2_becae388:

    # J "No lo eran, créeme."
    J "They weren't, believe me."

# game/script.rpy:5168
translate english familia1_2_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Why do you think they lived with a killer like me?"

# game/script.rpy:5169
translate english familia1_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5170
translate english familia1_2_37b98de6:

    # J "Así es, mataban gente también."
    J "That's right, they killed people too."

# game/script.rpy:5175
translate english familia1_2_a46e5454:

    # J "Hah, lo eran."
    J "Hah, they were."

# game/script.rpy:5177
translate english familia1_2_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "The owner of the house was... expressionless."

# game/script.rpy:5178
translate english familia1_2_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "One of them was a cannibal... I think you can call him that?"

# game/script.rpy:5179
translate english familia1_2_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Another spent his time playing video games."

# game/script.rpy:5180
translate english familia1_2_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "One dressed as a clown, and a couple spent their time filming."

# game/script.rpy:5181
translate english familia1_2_af0d79a7:

    # J "Así que sí, son raros."
    J "So yes, they are weird."

# game/script.rpy:5194
translate english amigos1_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5195
translate english amigos1_1_d5ff44d8:

    # J "No te diré."
    J "I won't tell you."

# game/script.rpy:5196
translate english amigos1_1_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Oh, come on!"

# game/script.rpy:5197
translate english amigos1_1_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "At least give me a range?"

# game/script.rpy:5198
translate english amigos1_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5199
translate english amigos1_1_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "How old are you?"

# game/script.rpy:5202
translate english amigos1_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5203
translate english amigos1_1_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "But you're of legal age, right?"

# game/script.rpy:5204
translate english amigos1_1_97bf5def:

    # pov "Por supuesto."
    pov "Of course."

# game/script.rpy:5205
translate english amigos1_1_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Good, I don't date minors."

# game/script.rpy:5206
translate english amigos1_1_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "That's... good, I guess?"

# game/script.rpy:5207
translate english amigos1_1_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "How many positive things can there be about a murderer?"

# game/script.rpy:5208
translate english amigos1_1_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "… But, I'm considerably older."

# game/script.rpy:5209
translate english amigos1_1_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Don't worry, I can handle mature men."

# game/script.rpy:5212
translate english amigos1_1_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Alright, I'm older than you."

# game/script.rpy:5213
translate english amigos1_1_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "You really are not going to tell me how much?"

# game/script.rpy:5214
translate english amigos1_1_290da55e:

    # "Jeff refunfuñó."
    "Jeff grumbled."

# game/script.rpy:5215
translate english amigos1_1_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "So older, huh?"

# game/script.rpy:5218
translate english amigos1_1_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "We're about the same age, happy?"

# game/script.rpy:5219
translate english amigos1_1_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "So thirtysomething, huh?"

# game/script.rpy:5221
translate english amigos1_1_dbe4fbfd:

    # J "Cállate."
    J "Shut up."

# game/script.rpy:5226
translate english amigos1_1_ffcd567a:

    # pov "Estás en buena forma."
    pov "You're in good shape."

# game/script.rpy:5228
translate english amigos1_1_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Even if you're not that young, you look good."

# game/script.rpy:5230
translate english amigos1_1_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Ignoring how messed up his face was, of course."

# game/script.rpy:5231
translate english amigos1_1_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Jeff said nothing, but you noticed his cheeks flush."

# game/script.rpy:5234
translate english amigos1_1_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "To be so old, you look good."

# game/script.rpy:5235
translate english amigos1_1_b1bf0aaa:

    # "Jeff resopla."
    "Jeff snorted."

# game/script.rpy:5245
translate english amigos1_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5246
translate english amigos1_2_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Obviously I had it at the beginning."

# game/script.rpy:5247
translate english amigos1_2_6dfaad92:

    # J "Una madre, un padre."
    J "A mother, a father."

# game/script.rpy:5248
translate english amigos1_2_4b5c3a9e:

    # J "… Un hermano."
    J "… A brother."

# game/script.rpy:5249
translate english amigos1_2_424f497b:

    # J "Pero los perdí."
    J "But I lost them."

# game/script.rpy:5254
translate english amigos1_2_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5256
translate english amigos1_2_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Jeff let out a dispirited chuckle."

# game/script.rpy:5257
translate english amigos1_2_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "You know me better than I thought."

# game/script.rpy:5260
translate english amigos1_2_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5261
translate english amigos1_2_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], you're smart, I'm sure you know the answer."

# game/script.rpy:5274
translate english edad1_1_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "There was a time when I lived with some guys."

# game/script.rpy:5275
translate english edad1_1_a5531769:

    # J "Era una casa grande, éramos varios."
    J "It was a big house, there were several of us."

# game/script.rpy:5276
translate english edad1_1_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "Each had... their peculiarities."

# game/script.rpy:5278
translate english edad1_1_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "But they're the closest thing I can call friends."

# game/script.rpy:5281
translate english edad1_1_becae388:

    # J "No lo eran, créeme."
    J "They weren't, believe me."

# game/script.rpy:5282
translate english edad1_1_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Why do you think they lived with a killer like me?"

# game/script.rpy:5283
translate english edad1_1_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5284
translate english edad1_1_37b98de6:

    # J "Así es, mataban gente también."
    J "That's right, they killed people too."

# game/script.rpy:5289
translate english edad1_1_a46e5454:

    # J "Hah, lo eran."
    J "Hah, they were."

# game/script.rpy:5291
translate english edad1_1_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "The owner of the house was... expressionless."

# game/script.rpy:5292
translate english edad1_1_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "One of them was a cannibal... I think you can call him that?"

# game/script.rpy:5293
translate english edad1_1_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Another spent his time playing video games."

# game/script.rpy:5294
translate english edad1_1_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "One dressed as a clown, and a couple spent their time filming."

# game/script.rpy:5295
translate english edad1_1_af0d79a7:

    # J "Así que sí, son raros."
    J "So yes, they are weird."

# game/script.rpy:5306
translate english edad1_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5307
translate english edad1_2_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Obviously I had it at the beginning."

# game/script.rpy:5308
translate english edad1_2_6dfaad92:

    # J "Una madre, un padre."
    J "A mother, a father."

# game/script.rpy:5309
translate english edad1_2_4b5c3a9e:

    # J "… Un hermano."
    J "… A brother."

# game/script.rpy:5310
translate english edad1_2_424f497b:

    # J "Pero los perdí."
    J "But I lost them."

# game/script.rpy:5315
translate english edad1_2_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5317
translate english edad1_2_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Jeff let out a dispirited chuckle."

# game/script.rpy:5318
translate english edad1_2_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "You know me better than I thought."

# game/script.rpy:5321
translate english edad1_2_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5322
translate english edad1_2_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], you're smart, I'm sure you know the answer."

# game/script.rpy:5330
translate english ruta_normal_36_f0bc6ff2:

    # J "¿Estás feliz con todo lo que preguntaste?"
    J "Are you happy with everything you asked?"

# game/script.rpy:5331
translate english ruta_normal_36_1fa7d4ad:

    # pov "Depende, tengo una pregunta más."
    pov "It depends, I have one more question."

# game/script.rpy:5332
translate english ruta_normal_36_604a6d99:

    # pov "¿Por qué matas?"
    pov "Why do you kill?"

# game/script.rpy:5334
translate english ruta_normal_36_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5336
translate english ruta_normal_36_704f299d:

    # "Jeff desvía la mirada, pensativo."
    "Jeff looked away, thoughtfully."

# game/script.rpy:5337
translate english ruta_normal_36_edf26648:

    # J "A este punto… Es como preguntarle a un pájaro por qué vuela."
    J "At this point... It's like asking a bird why it flies."

# game/script.rpy:5339
translate english ruta_normal_36_6a86aba2:

    # J "Es lo que soy."
    J "It's what I am."

# game/script.rpy:5340
translate english ruta_normal_36_22bd8e25:

    # pov "Pero empezó por algo, ¿No?, ¿Qué pasó?"
    pov "But it started with something, didn't it? What happened?"

# game/script.rpy:5341
translate english ruta_normal_36_5156b7fa:

    # "Jeff se encoge de hombros."
    "Jeff shrugged."

# game/script.rpy:5342
translate english ruta_normal_36_b65db1f2:

    # J "Era un niño cuando empezó."
    J "I was a kid when I started."

# game/script.rpy:5343
translate english ruta_normal_36_157de133:

    # J "El mundo era un lugar sin sentido, y los humanos me parecen desagradables, en general."
    J "The world was meaningless, and I hate humans, in general."

# game/script.rpy:5344
translate english ruta_normal_36_8b78ef51:

    # J "Quería hacer del mundo un lugar hermoso."
    J "I wanted to make the world a beautiful place."

# game/script.rpy:5345
translate english ruta_normal_36_3f1585ed:

    # J "Y fue así durante años."
    J "And it was like that for years."

# game/script.rpy:5349
translate english ruta_normal_36_cdb64694:

    # pov "Que rara razón para matar."
    pov "What a strange reason to kill."

# game/script.rpy:5350
translate english ruta_normal_36_4b21052d:

    # pov "Yo pensaba que tenías una vida trágica."
    pov "I thought you had a tragic life."

# game/script.rpy:5352
translate english ruta_normal_36_22166c46:

    # J "Heh, lamento decepcionarte, amor."
    J "Heh, I'm sorry to disappoint you, love."

# game/script.rpy:5357
translate english ruta_normal_36_bb0baae6:

    # pov "Vaya, eso es jodido."
    pov "Wow, that's fucked up."

# game/script.rpy:5359
translate english ruta_normal_36_ba8ba4be:

    # J "Ni me lo digas."
    J "Don't even tell me."

# game/script.rpy:5360
translate english ruta_normal_36_ee881a55:

    # pov "Con razón estás tan mal de la cabeza."
    pov "No wonder you're so messed in the head."

# game/script.rpy:5361
translate english ruta_normal_36_5adf6b79:

    # J "Heh, que halago, amor."
    J "Heh, flattery, love."

# game/script.rpy:5367
translate english ruta_normal_37_1c80fb09:

    # J "Pero cuando te conocí… Empecé a sentir cosas que pensé que había olvidado."
    J "But when I met you... I started to feel things I thought I had forgotten."

# game/script.rpy:5368
translate english ruta_normal_37_6f0a8a15:

    # "Las palabras querían escapar de tu boca."
    "The words wanted to escape your mouth."

# game/script.rpy:5369
translate english ruta_normal_37_38200748:

    # pov "¿Considerarías dejar de matar?"
    pov "Would you consider stopping killing?"

# game/script.rpy:5370
translate english ruta_normal_37_73f8d438:

    # pov "¿Por mí?"
    pov "For me?"

# game/script.rpy:5371
translate english ruta_normal_37_c644c935:

    # "Era tarde, lo dijiste."
    "It was late, you said it."

# game/script.rpy:5372
translate english ruta_normal_37_f5f36885:

    # "Nuevamente, no eres una santidad que quiere dar una lección moral a una persona evidentemente inmoral, pero era una pregunta hecha por genuina curiosidad."
    "Again, you weren't a saint wanting to give a moral lesson to an obviously immoral person, but it was a question asked out of genuine curiosity."

# game/script.rpy:5373
translate english ruta_normal_37_065221ab:

    # "No era una petición, sólo querías saber."
    "It wasn't a request, you just wanted to know."

# game/script.rpy:5374
translate english ruta_normal_37_8f49a284:

    # "Y afortunadamente, parece que Jeff no se lo tomó mal."
    "And fortunately, Jeff didn't seem to take it badly."

# game/script.rpy:5376
translate english ruta_normal_37_f4c15bb9:

    # J "Podría llegar a un consenso… Sólo en caso de."
    J "We could reach a compromise... Just in case."

# game/script.rpy:5378
translate english ruta_normal_37_4400accd:

    # "No puedes evitar sentir que tu corazón se acelera."
    "You couldn't help but feel your heart race."

# game/script.rpy:5379
translate english ruta_normal_37_e286b4e9:

    # "De acuerdo, debías admitir que hasta el momento, dudabas que realmente Jeff estuviera enamorado de ti."
    "Okay, you had to admit that until now, you doubted Jeff was really in love with you."

# game/script.rpy:5380
translate english ruta_normal_37_a96bc368:

    # "Pero si este tipo demente dice que podría considerar cambiar sólo por ti, era imposible no conmoverte, aunque sea un poco."
    "But if this madman said he might consider changing just for you, it was impossible not to be moved, even a little."

# game/script.rpy:5381
translate english ruta_normal_37_a41ea3e0:

    # pov "Eso es muy dulce, gracias."
    pov "That's very sweet, thank you."

# game/script.rpy:5382
translate english ruta_normal_37_fe5b6d5e:

    # "Era mejor estar en su lado bueno de todas maneras."
    "It was better to be on his good side anyway."

# game/script.rpy:5383
translate english ruta_normal_37_d9737b3c:

    # "Quien sabría lo que pasaría si lo tratabas mal o le rompías el corazón."
    "Who knew what would happen if you treated him badly or broke his heart?"

# game/script.rpy:5384
translate english ruta_normal_37_ae484c0a:

    # "Algo te dice que él es muy rencoroso."
    "Something told you he was very vindictive."

# game/script.rpy:5386
translate english ruta_normal_37_a60fb46a:

    # "De repente, se escucha un golpe en la puerta."
    "Suddenly, there was a knock at the door."

# game/script.rpy:5390
translate english ruta_normal_37_3c8eefc4:

    # "Jeff se torna serio y va a la ventana, asomándose levemente."
    "Jeff grew serious and went to the window, peering out slightly."

# game/script.rpy:5391
translate english ruta_normal_37_19a7a658:

    # J "Es un policía."
    J "It's a cop."

# game/script.rpy:5392
translate english ruta_normal_37_e5508114:

    # pov "¿Se te olvidó pagar la renta?"
    pov "Did you forget to pay rent?"

# game/script.rpy:5393
translate english ruta_normal_37_41b29ebc:

    # "Jeff se mordió la punta de los dedos, pensativo."
    "Jeff bit his fingertips, thoughtful."

# game/script.rpy:5394
translate english ruta_normal_37_68220c72:

    # J "No pago renta."
    J "I don't pay rent."

# game/script.rpy:5395
translate english ruta_normal_37_cc6d045d:

    # pov "Ah, eres un ocupa."
    pov "Ah, you're a squatter."

# game/script.rpy:5397
translate english ruta_normal_37_707998f3:

    # J "Ya- deja de bromear."
    J "I—stop joking."

# game/script.rpy:5399
translate english ruta_normal_37_30d54e91:

    # "El llamado a la puerta se torna insistente."
    "The knocking on the door became insistent."

# game/script.rpy:5401
translate english ruta_normal_37_257bec56:

    # J "Responde tú."
    J "You answer it."

# game/script.rpy:5402
translate english ruta_normal_37_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:5403
translate english ruta_normal_37_708da300:

    # J "Estoy siendo buscado, no pueden verme."
    J "I'm being looked for, they can't see me."

# game/script.rpy:5404
translate english ruta_normal_37_2d5567bd:

    # J "Tendrás que hablar con él."
    J "You'll have to talk to him."

# game/script.rpy:5405
translate english ruta_normal_37_7d62c96a:

    # pov "Pero yo-"
    pov "But I—"

# game/script.rpy:5406
translate english ruta_normal_37_ff89448d:

    # J "Confiaré en ti."
    J "I'll trust you."

# game/script.rpy:5409
translate english ruta_normal_37_d9c604af:

    # "Sin esperar una respuesta, Jeff desapareció tras adentrarse en la casa."
    "Without waiting for an answer, Jeff disappeared into the house."

# game/script.rpy:5410
translate english ruta_normal_37_d252a13e:

    # "Te removiste en tu lugar con nervios, dirigiéndote a la puerta."
    "You shifted uncomfortably, heading for the door."

# game/script.rpy:5411
translate english ruta_normal_37_efe30f99:

    # "Todo va a estar bien, [povname], ya le has mentido a la policía antes. Será pan comido."
    "Everything's going to be fine, [povname], you've lied to the police before. It'll be a piece of cake."

# game/script.rpy:5413
translate english ruta_normal_37_7474732d:

    # "Abres la puerta y frente a ti está un policía uniformado."
    "You opened the door and in front of you stood a uniformed police officer."

# game/script.rpy:5414
translate english ruta_normal_37_c24ae79f:

    # P "Buenos días, siento molestar tan temprano."
    P "Good morning, sorry to bother you so early."

# game/script.rpy:5415
translate english ruta_normal_37_ee04b04d:

    # pov "No importa…"
    pov "It's okay..."

# game/script.rpy:5416
translate english ruta_normal_37_88d9f83e:

    # P "Estamos monitoreando la zona, es sólo rutina. ¿Has presenciado actividad inusual últimamente?"
    P "We're monitoring the area, it's just routine. Have you witnessed any unusual activity lately?"

# game/script.rpy:5420
translate english ruta_normal_37_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5421
translate english ruta_normal_37_437ca9c0:

    # pov "La verdad… "
    pov "The truth is..."

# game/script.rpy:5422
translate english ruta_normal_37_13203473:

    # "Bajas el volumen de tu voz."
    "You lowered your voice."

# game/script.rpy:5423
translate english ruta_normal_37_917931b2:

    # pov "Me secuestraron."
    pov "I was kidnapped."

# game/script.rpy:5424
translate english ruta_normal_37_ce801928:

    # pov "Él… está dentro de la casa."
    pov "He... is inside the house."

# game/script.rpy:5425
translate english ruta_normal_37_221f4e65:

    # "El policía te miró en silencio por unos segundos, analizando si estabas diciendo la verdad."
    "The police officer looked at you in silence for a few seconds, analyzing if you were telling the truth."

# game/script.rpy:5426
translate english ruta_normal_37_eb0eea22:

    # "Entonces, él desenfundó su arma y abrió la puerta."
    "Then, he drew his weapon and opened the door."

# game/script.rpy:5427
translate english ruta_normal_37_8fe7dce3:

    # P "Espera aquí."
    P "Wait here."

# game/script.rpy:5428
translate english ruta_normal_37_aabb9b54:

    # "Él entra sigilosamente, apoyando su hombro contra las superficies a medida que entraba a la casa."
    "He entered stealthily, leaning his shoulder against the surfaces as he went into the house."

# game/script.rpy:5429
translate english ruta_normal_37_d879d0d6:

    # "Esperaste en la puerta principal, el silencio pesado en el aire."
    "You waited at the main door, a heavy silence in the air."

# game/script.rpy:5431
translate english ruta_normal_37_0328c4cd:

    # "De repente escuchas el primer disparo."
    "Suddenly you heard the first gunshot."

# game/script.rpy:5435
translate english ruta_normal_37_a3959b3c:

    # "Luego el segundo y el tercero."
    "Then the second and third."

# game/script.rpy:5437
translate english ruta_normal_37_1f027b95:

    # "Por la sopresa e incertidumbre, te congelas en tu lugar."
    "From surprise and uncertainty, you froze in place."

# game/script.rpy:5438
translate english ruta_normal_37_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:5439
translate english ruta_normal_37_74aee10f:

    # "El alarido de Jeff te hace temblar."
    "Jeff's scream made you tremble."

# game/script.rpy:5442
translate english ruta_normal_37_7b67c4af:

    # "Él aparece por el pasillo, apoyado contra la pared y con una herida en el costado."
    "He appeared from the hallway, leaning against the wall with a wound in his side."

# game/script.rpy:5445
translate english ruta_normal_37_6d1a183c:

    # "Jeff se abalanza hacia ti, aplastandote con su cuerpo."
    "Jeff lunged at you, crushing you with his body."

# game/script.rpy:5446
translate english ruta_normal_37_b823f5fb:

    # J "¡Te vas a ir conmigo!"
    J "You're coming with me!"

# game/script.rpy:5447
translate english ruta_normal_37_426efe63:

    # "Sonaba molesto, pero más que eso, se veía dolido, seguramente por haberlo delatado."
    "He sounded angry, but more than that, he looked hurt, surely because you betrayed him."

# game/script.rpy:5450
translate english ruta_normal_37_4adc1fb1:

    # "Él sujetó tu cabeza con fuerza, y enterró su pulgar en tu ojo restante."
    "He gripped your head tightly, and buried his thumb into your remaining eye."

# game/script.rpy:5451
translate english ruta_normal_37_fad995a0:

    # "Soltaste un alarido de agonía, sintiendo que la punzada de dolor te invadía de la cabeza a los pies."
    "You let out a scream of agony, feeling the pang of pain invade you from head to toe."

# game/script.rpy:5452
translate english ruta_normal_37_77bac699:

    # "Tus brazos se sacudieron contra él, pero eso no evitó nada."
    "Your arms thrashed against him, but it did nothing."

# game/script.rpy:5453
translate english ruta_normal_37_95ab12a1:

    # "Sientes que el dedo de él se entierra más, atravesando tu cuenca."
    "You felt his thumb dig deeper, piercing your eye socket."

# game/script.rpy:5454
translate english ruta_normal_37_238b3be2:

    # "No te queda fuerza para seguir luchando, tu voz se ahoga ante el dolor."
    "You had no strength left to fight, your voice choked with pain."

# game/script.rpy:5456
translate english ruta_normal_37_7cac2ea6:

    # "Lo último que escuchas es un último disparo."
    "The last thing you heard was one final gunshot."

# game/script.rpy:5460
#translate english ruta_normal_37_eb2373c5:

    # "{b}Final VI: Lo Decepcionaste{/b}"
    #"{b}Ending VI: You Disappointed Him{/b}"

# game/script.rpy:5465
translate english ruta_normal_37_8e6d1651:

    # pov "No he visto nada."
    pov "I haven't seen anything."

# game/script.rpy:5466
translate english ruta_normal_37_5b31f7d1:

    # P "…"
    P "..."

# game/script.rpy:5467
translate english ruta_normal_37_672edfc0:

    # P "De acuerdo."
    P "Alright."

# game/script.rpy:5468
translate english ruta_normal_37_497fff62:

    # P "Intenta tener cuidado, este barrio es peligroso."
    P "Try to be careful, this neighborhood is dangerous."

# game/script.rpy:5469
translate english ruta_normal_37_613711b3:

    # "Quizás notó que no eres precisamente de ahí."
    "He probably noticed you weren't exactly from around here."

# game/script.rpy:5470
translate english ruta_normal_37_66a56d4a:

    # P "Cierra bien todas las ventanas y puertas."
    P "Close all windows and doors tightly."

# game/script.rpy:5471
translate english ruta_normal_37_9336b9bb:

    # "El policía hace un ademán con su gorra."
    "The police officer made a gesture with his cap."

# game/script.rpy:5472
translate english ruta_normal_37_fd8a2a77:

    # P "Siento de nuevo la molestia."
    P "I apologize again for the inconvenience."

# game/script.rpy:5478
translate english historia_continúa_3_38_65457d11:

    # "Ves que el policía se retira, y cuando no lo ves más, cierras la puerta."
    "You saw the police officer leave, and when you no longer saw him, you closed the door."

# game/script.rpy:5480
translate english historia_continúa_3_38_5c3bbe3d:

    # "Suspiras pesadamente, y te giras hacia la dirección en la que se fue Jeff."
    "You sighed heavily, and turned towards the direction Jeff had gone."

# game/script.rpy:5481
translate english historia_continúa_3_38_b83a5758:

    # pov "¿Jeff?, Ya puedes salir."
    pov "Jeff? You can come out now."

# game/script.rpy:5482
translate english historia_continúa_3_38_c51f422f:

    # "No obtienes respuesta, por lo que das unos pasos adelante."
    "You received no answer, so you took a few steps forward."

# game/script.rpy:5485
translate english historia_continúa_3_38_341255e7:

    # "De la oscuridad, Jeff se acerca a ti corriendo, y te estrecha contra sus brazos."
    "From the darkness, Jeff ran towards you, and embraced you tightly."

# game/script.rpy:5486
translate english historia_continúa_3_38_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:5491
translate english historia_continúa_3_38_afc59af7:

    # "Él te envuelve en un fuerte abrazo, incluso se inclina a un lado para elevarte del suelo unos centímetros."
    "He wrapped you in a tight hug, even leaning to one side to lift you a few inches off the ground."

# game/script.rpy:5492
translate english historia_continúa_3_38_eea060a2:

    # J "¡Eres genial!"
    J "You're amazing!"

# game/script.rpy:5493
translate english historia_continúa_3_38_0e8d543d:

    # pov "Oh, eh, si, intento serlo."
    pov "Oh, uh, yeah, I try to be."

# game/script.rpy:5494
translate english historia_continúa_3_38_c1787262:

    # "No sabes si tomarte bien los elogios, ya que acabas de romper la ley."
    "You didn't know whether to take the compliments well, as you had just broken the law."

# game/script.rpy:5495
translate english historia_continúa_3_38_f16c345c:

    # J "¡Tuviste la oportunidad de delatarme, pero me encubriste!"
    J "You had the chance to turn me in, but you covered for me!"

# game/script.rpy:5501
translate english historia_continúa_3_38_bf8bc422:

    # pov "Sí, sí, estuve ahí."
    pov "Yeah, yeah, I was there."

# game/script.rpy:5502
translate english historia_continúa_3_38_1e39ce0d:

    # J "No me importa que me trates fríamente, ¡Igual te adoro!"
    J "I don't care if you treat me coldly, I adore you anyway!"

# game/script.rpy:5503
translate english historia_continúa_3_38_e5eb9f4f:

    # pov "Yo no estaba- Espera, ¿Qué?"
    pov "I wasn't—Wait, what?"

# game/script.rpy:5506
translate english historia_continúa_3_38_8a340a12:

    # pov "No soy capaz de entregarte."
    pov "I'm not capable of turning you in."

# game/script.rpy:5507
translate english historia_continúa_3_38_bb01a050:

    # J "¡Te lo compensaré por completo!"
    J "I'll make it up to you completely!"

# game/script.rpy:5508
translate english historia_continúa_3_38_7254d0cf:

    # pov "… ¿Cómo, precisamente?"
    pov "... How, precisely?"

# game/script.rpy:5509
translate english historia_continúa_3_38_c6164375:

    # J "Lo que sea."
    J "I'll do anything."

# game/script.rpy:5515
translate english ruta_normal_39_036040fe:

    # "Jeff te deposita en el suelo y se distancia de ti, pero sus manos se mantienen sobre ti."
    "Jeff placed you on the ground and distanced himself from you, but his hands remained on you."

# game/script.rpy:5516
translate english ruta_normal_39_02a24a4d:

    # pov "No te tomaba por un arrastrado."
    pov "I didn't take you for a pushover."

# game/script.rpy:5517
translate english ruta_normal_39_e6d0c30a:

    # J "Lameré tus pies si quieres."
    J "I'll lick your feet if you want."

# game/script.rpy:5518
translate english ruta_normal_39_ba25fb0e:

    # pov "¡Asco!, entiendo la idea, eso no fue necesario."
    pov "Gross! I get the idea, that wasn't necessary."

# game/script.rpy:5521
translate english ruta_normal_39_9382a593:

    # "Jeff ríe entre dientes, subiendo sus manos hacia tu cuello."
    "Jeff chuckled, raising his hands to your neck."

# game/script.rpy:5522
translate english ruta_normal_39_3eb547ea:

    # "Él ladea la cabeza, mirando con atención las marcas de sus dedos en tu cuello, que se habían estado borrado con el pasar de los días."
    "He tilted his head, looking intently at the marks his fingers had left on your neck, which had faded over the days."

# game/script.rpy:5523
translate english ruta_normal_39_4c695437:

    # "Te abstienes de decir algo, pues sientes que el aire cambia a uno… más íntimo."
    "You refrained from saying anything, feeling the air change to something... more intimate."

# game/script.rpy:5524
translate english ruta_normal_39_6ce16d0c:

    # "Tus ojos se encuentran por un instante con los de Jeff, sus pupilas normalmente pequeñas estaban ligeramente dilatadas."
    "Your eyes met Jeff's for an instant, his normally small pupils were slightly dilated."

# game/script.rpy:5525
translate english ruta_normal_39_59480a89:

    # "Él se acerca y agacha la cabeza a la altura de tu cuello."
    "He leaned in and lowered his head to your neck."

# game/script.rpy:5526
translate english ruta_normal_39_df8e40d0:

    # "Lo único que ves es el cabello negro de él sobre tu frente."
    "All you saw was his black hair over your forehead."

# game/script.rpy:5530
translate english ruta_normal_39_037db52c:

    # "Retrocedes levemente, pero él te sujeta firmemente."
    "You pulled back slightly, but he held you firmly."

# game/script.rpy:5531
translate english ruta_normal_39_2d00ae3d:

    # "Incluso si no quieres, él lo hará de todas maneras."
    "Even if you don't want it, he'll do it anyway."

# game/script.rpy:5541
translate english ruta_normal_40_b20398f7:

    # "Sientes que el primer beso sobre tu cuello te produce un escalofrío, y el segundo lo hace peor."
    "You felt the first kiss on your neck send a shiver down your spine, and the second made it worse."

# game/script.rpy:5543
translate english ruta_normal_40_178b3cb8:

    # "Jeff se toma su tiempo, lentamente y con calma, besa tu cuello de un extremo a otro, acariciando la piel de tu garganta con sus labios suavemente."
    "Jeff took his time, slowly and calmly, kissing your neck from one end to the other, caressing the skin of your throat with his lips softly."

# game/script.rpy:5544
translate english ruta_normal_40_5edde5db:

    # "Aprietas los labios, para no emitir ni un sonido."
    "You clenched your lips, to make no sound."

# game/script.rpy:5545
translate english ruta_normal_40_00d18571:

    # "Tal vez toda la situación está jugando con tu mente, porque una casa destartalada no te parece el peor lugar para hacer esto."
    "Perhaps the whole situation was playing tricks on your mind, because a dilapidated house didn't seem like the worst place for this to happen."

# game/script.rpy:5551
translate english ruta_normal_40_b2dadfd9:

    # "Sientes cómo él se separa pausadamente y se inclina sobre tu rostro."
    "You felt him slowly pull away and lean over your face."

# game/script.rpy:5552
translate english ruta_normal_40_69677d7d:

    # "Su cabello largo y desordenado impide tu visión, pero por la cercanía, puedes ver los ojos brillantes y el corte de su boca cerca de ti."
    "His long, messy hair obstructed your view, but due to the closeness, you could see his bright eyes and the cut of his mouth near you."

# game/script.rpy:5554
translate english ruta_normal_40_0112d28c:

    # "Ves cómo los ojos de él están fijos en tus labios, por lo que no te sorprendes cuando él finalmente te besa."
    "You saw his eyes fixed on your lips, so you weren't surprised when he finally kissed you."

# game/script.rpy:5555
translate english ruta_normal_40_a86c36ea:

    # "El toque era suave, pero podías sentir que los labios estaban secos y fríos."
    "The touch was soft, but you could feel his lips were dry and cold."

# game/script.rpy:5556
translate english ruta_normal_40_676a1e17:

    # "Aún así, no era tan malo."
    "Even so, it wasn't that bad."

# game/script.rpy:5557
translate english ruta_normal_40_a393b374:

    # "Las manos de él subieron a tu mandíbula, sujetándote firmemente, como si quisiera evitar darte oportunidad para escapar."
    "His hands moved up to your jaw, holding you firmly, as if he wanted to prevent you from escaping."

# game/script.rpy:5558
translate english ruta_normal_40_45e2eede:

    # "Sentías la posesividad en su toque, pero no era agresivo."
    "You felt the possessiveness in his touch, but it wasn't aggressive."

# game/script.rpy:5559
translate english ruta_normal_40_df6c133c:

    # "Más bien, parecía tener cuidado."
    "Rather, he seemed careful."

# game/script.rpy:5560
translate english ruta_normal_40_7289ed19:

    # "Tomando valentía, alzas tus manos y envuelves los hombros de él."
    "Gathering courage, you raised your hands and wrapped them around his shoulders."

# game/script.rpy:5564
translate english ruta_normal_40_7ec8b15a:

    # "Jeff gime suavemente contra tus labios al sentir que tus dedos se enredan en su cabello, separándose un instante sólo para volver a besarte, necesitado."
    "Jeff groaned softly against your lips as he felt your fingers entangle in his hair, breaking away for an instant only to kiss you again, desperately."

# game/script.rpy:5566
translate english ruta_normal_40_90f1a7e8:

    # "Él baja sus manos a tu cintura y te sujeta firmemente."
    "He lowered his hands to your waist and held you firmly."

# game/script.rpy:5570
translate english ruta_normal_40_973a400c:

    # "Sacas la lengua y lames ligeramente el labio inferior de Jeff."
    "You stuck out your tongue and lightly licked Jeff's lower lip."

# game/script.rpy:5571
translate english ruta_normal_40_1b7b81fd:

    # "Él suspira y abre los labios, dándote camino."
    "He sighed and opened his lips, giving you access."

# game/script.rpy:5573
translate english ruta_normal_40_cfdcb93d:

    # "Profundizas el beso, y sientes que Jeff se derrite contra ti."
    "You deepened the kiss, and felt Jeff melt against you."

# game/script.rpy:5574
translate english ruta_normal_40_7b230679:

    # "Sus dedos en tu cintura y sus labios contra los tuyos tiemblan."
    "His fingers on your waist and his lips against yours trembled."

# game/script.rpy:5576
translate english ruta_normal_40_f272ae48:

    # "Acaricias su lengua con la tuya, el toque es suave y tibio, húmedo."
    "You caressed his tongue with yours; the touch was soft and warm, wet."

# game/script.rpy:5577
translate english ruta_normal_40_db91c878:

    # "Sientes que tu respiración se entrelaza con la de él."
    "You felt your breath intertwine with his."

# game/script.rpy:5578
translate english ruta_normal_40_12d03c9d:

    # "Él te acerca más, el roce de sus manos sintiéndose caliente sobre tu cuerpo."
    "He pulled you closer, the brush of his hands feeling warm on your body."

# game/script.rpy:5579
translate english ruta_normal_40_df200623:

    # "Hasta que sientes que él sube la mano a tu pecho."
    "Until you felt him move his hand up to your chest."

# game/script.rpy:5580
translate english ruta_normal_40_f6169bee:

    # "No te importaría normalmente, ustedes estaban besándose, no era raro que él se entusiasmara."
    "Normally you wouldn't care, you two were kissing, it wasn't strange that he was getting excited."

# game/script.rpy:5581
translate english ruta_normal_40_43e01031:

    # "Pero cuando sentiste una punzada en tu muslo, decidiste parar."
    "But when you felt a poke in your thigh, you decided to stop."

# game/script.rpy:5582
translate english ruta_normal_40_e0e32284:

    # "Una casa en ruinas no es el mejor lugar para… eso."
    "A dilapidated house wasn't the best place for... that."

# game/script.rpy:5583
translate english ruta_normal_40_e34315d1:

    # "Incluso si tu estado de ánimo es cachondo, tienes estándares."
    "Even if you were in a horny mood, you had standards."

# game/script.rpy:5589
translate english ruta_normal_40_dab0d790:

    # "Te separas lentamente, tu boca y la de él siendo unidas por un hilo de saliva."
    "You slowly pulled away, your mouth and his joined by a string of saliva."

# game/script.rpy:5590
translate english ruta_normal_40_5a42d2ae:

    # "Los ojos de él se ven nublados, y su respiración está agitada."
    "His eyes were blurry, and his breathing was ragged."

# game/script.rpy:5594
translate english ruta_normal_40_200c202f:

    # "Te separas lentamente, creando distancia entre él y tú."
    "You slowly pulled away, creating distance between him and you."

# game/script.rpy:5600
translate english beso_1_07c46601:

    # pov "De acuerdo, suficiente por hoy."
    pov "Okay, that's enough for today."

# game/script.rpy:5602
translate english beso_1_0f0f68fc:

    # "Jeff deja escapar un quejido lastimero, sin querer soltarte."
    "Jeff let out a whimpering groan, not wanting to let go."

# game/script.rpy:5603
translate english beso_1_c5fc0cbf:

    # J "¿Qué?, ¿Por qué?"
    J "What? Why?"

# game/script.rpy:5604
translate english beso_1_8caaba43:

    # pov "No pienso llegar más lejos contigo en este lugar."
    pov "I'm not going to go any further with you in this place."

# game/script.rpy:5605
translate english beso_1_41b532e0:

    # pov "Pueden haber cucarachas, ratas… o tétanos."
    pov "There might be cockroaches, rats... or tetanus."

# game/script.rpy:5607
translate english beso_1_a1c478e7:

    # J "Tch, ok."
    J "Tch, okay."

# game/script.rpy:5610
translate english beso_1_d1992693:

    # "Jeff te libera de su abrazo, pero se mantiene cerca."
    "Jeff released you from his hug, but remained close."

# game/script.rpy:5611
translate english beso_1_f5156207:

    # J "Quería demostrarte lo agradecido que estoy."
    J "I wanted to show you how grateful I am."

# game/script.rpy:5612
translate english beso_1_fae6f35b:

    # pov "Puedes agradecerme de otra forma."
    pov "You can thank me in other ways."

# game/script.rpy:5614
translate english beso_1_f4cf20c4:

    # "El rostro de Jeff se ilumina."
    "Jeff's face lit up."

# game/script.rpy:5615
translate english beso_1_35bea974:

    # J "¿Puedo lamer tu-?"
    J "Can I lick your—?"

# game/script.rpy:5616
translate english beso_1_cd78d3e4:

    # pov "¡No!, ¡Consígueme ropa!"
    pov "No! Get me some clothes!"

# game/script.rpy:5617
translate english beso_1_b8c4f232:

    # J "Oh, cierto."
    J "Oh, right."

# game/script.rpy:5618
translate english beso_1_53fa0ff0:

    # "Niegas con la cabeza, en desaprobación por las ocurrencias de él."
    "You shook your head, disapproving of his antics."

# game/script.rpy:5621
translate english beso_1_e7392379:

    # "Jeff se dirige a un rincón de la sala y recoge algo."
    "Jeff went to a corner of the room and picked something up."

# game/script.rpy:5622
translate english beso_1_bfe1c5f5:

    # J "Ten, mientras consigo ropa para ti."
    J "Here, while I get you some clothes."

# game/script.rpy:5623
translate english beso_1_eaa80d37:

    # "Él te ofrece su sudadera blanca… demasiado blanca."
    "He offered you his white hoodie... too white."

# game/script.rpy:5624
translate english beso_1_b9a546e9:

    # pov "¿Cómo haces para mantenerla tan limpia si te la pasas matando?"
    pov "How do you keep it so clean if you're always killing people?"

# game/script.rpy:5625
translate english beso_1_825602ef:

    # pov "¿No debería mancharse con la sangre?"
    pov "Shouldn't it be stained with blood?"

# game/script.rpy:5626
translate english beso_1_45e58b3a:

    # "Si resulta que también tiene la habilidad sobrehumana de no mancharse, esta historia se va a catalogar como fantasía."
    "If it turns out he also has the superhuman ability not to get stained, this story will be classified as fantasy."

# game/script.rpy:5627
translate english beso_1_a602bf7c:

    # J "Tengo varias de esas."
    J "I have several of those."

# game/script.rpy:5628
translate english beso_1_4e19b462:

    # J "No soy estúpido, sé que no puedo andar con la misma sudadera ensangrentada a todas partes."
    J "I'm not stupid, I know I can't walk around with the same bloody hoodie everywhere."

# game/script.rpy:5629
translate english beso_1_3690b86f:

    # pov "¿Pero porqué blancas?"
    pov "But why white ones?"

# game/script.rpy:5630
translate english beso_1_29e8c837:

    # pov "¿No sería mejor ropa roja, o negra?"
    pov "Wouldn't red or black clothes be better?"

# game/script.rpy:5631
translate english beso_1_627a29af:

    # J "Tengo una marca."
    J "I have a brand."

# game/script.rpy:5632
translate english beso_1_f28b1970:

    # pov "¿Una marca?"
    pov "A brand?"

# game/script.rpy:5634
translate english beso_1_9983d8d0:

    # J "Claro, ¿Cómo la gente va a saber que se trata de mi si uso ropa diferente?"
    J "Yeah, how else would people know it's me if I wear different clothes?"

# game/script.rpy:5635
translate english beso_1_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5636
translate english beso_1_13af4a5f:

    # pov "Dejemos el tema, que me va a dar una embolia."
    pov "Let's drop the subject, it's going to give me an embolism."

# game/script.rpy:5638
translate english beso_1_e3e59d8a:

    # J "Haha, eres adorable."
    J "Haha, you're adorable."

# game/script.rpy:5640
translate english beso_1_5c19e81b:

    # "Te pones la sudadera encima de tu ropa de pijama, y es una fortuna que no te queda ajustada."
    "You put the hoodie over your pajama clothes, and fortunately, it didn't fit you snugly."

# game/script.rpy:5641
translate english beso_1_43df32cf:

    # "Jeff se ve delgado, pero sus hombros y pecho son más anchos de lo que parecen."
    "Jeff looked thin, but his shoulders and chest were wider than they appeared."

# game/script.rpy:5642
translate english beso_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5643
translate english beso_1_29f9a752:

    # J "¿Te gusta lo que ves?"
    J "Like what you see?"

# game/script.rpy:5644
translate english beso_1_ae25903e:

    # "Ah, te quedaste mirándolo fijamente por un momento."
    "Ah, you were staring at him for a moment."

# game/script.rpy:5648
translate english beso_1_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:5649
translate english beso_1_63ac03c2:

    # pov "Un tipo con la cara quemada y la boca cortada es sexy."
    pov "A guy with a burned face and a cut mouth is hot."

# game/script.rpy:5651
translate english beso_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5652
translate english beso_1_d7be0c77:

    # J "Incluso si lo dices para burlarte, no me afecta."
    J "Even if you say it to make fun of me, it doesn't affect me."

# game/script.rpy:5653
translate english beso_1_777d1ae6:

    # J "Me gusta cómo me veo."
    J "I like how I look."

# game/script.rpy:5654
translate english beso_1_db145382:

    # pov "Un hombre con confianza, eso si es atractivo."
    pov "A man with confidence, now that's hot."

# game/script.rpy:5656
translate english beso_1_90bba925:

    # "Jeff se queda en silencio, pero alcanzas a ver que sus mejillas se sonrojan."
    "Jeff remained silent, but you managed to see his cheeks blush."

# game/script.rpy:5659
translate english beso_1_7e856319:

    # pov "Nah, no realmente."
    pov "Nah, not really."

# game/script.rpy:5661
translate english beso_1_4b1b161b:

    # J "¡¿Qué?!, ¡¿Por qué no?!"
    J "What?! Why not?!"

# game/script.rpy:5662
translate english beso_1_ce640427:

    # pov "Eres muy flacucho para mi gusto."
    pov "You're too scrawny for my taste."

# game/script.rpy:5663
translate english beso_1_d669e20d:

    # J "¡¿Acaso te gustan más musculosos?!"
    J "Do you like more muscular guys?!"

# game/script.rpy:5664
translate english beso_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5665
translate english beso_1_098527da:

    # J "¿O más rellenos?"
    J "Or thick ones?"

# game/script.rpy:5666
translate english beso_1_f3f60a7a:

    # pov "Ok, creo que deberíamos dejarlo hasta ahí."
    pov "Okay, I think we should leave it at that."

# game/script.rpy:5675
translate english character_10_6344afd2:

    # "El saca una sudadera idéntica a la que ya tienes y se cubre el rostro con la bandana y la capucha."
    "He pulled out an identical hoodie to the one you were wearing and covered his face with the bandana and hood."

# game/script.rpy:5676
translate english character_10_5d7f1047:

    # pov "¿Vamos a una tienda?"
    pov "We're going to a store?"

# game/script.rpy:5677
translate english character_10_b96bbdb9:

    # J "Mejor."
    J "Better."

# game/script.rpy:5678
translate english character_10_12d288fb:

    # pov "¿Un mall?"
    pov "A mall?"

# game/script.rpy:5679
translate english character_10_61a252d8:

    # "Estabas jodiendo, sabías que ustedes no podían salir así como así."
    "You were kidding, you knew you couldn't go out like that."

# game/script.rpy:5680
translate english character_10_22c7271a:

    # J "Un tipo que recolecta objetos tiene mucha ropa. Va a dar lo que sea por un poco de brandy."
    J "A guy who collect trash has a lot of clothes. He'll give anything for a bit of brandy."

# game/script.rpy:5681
translate english character_10_f60c587f:

    # pov "Asco."
    pov "Gross."

# game/script.rpy:5682
translate english character_10_71bfccc6:

    # J "Relájate, la vamos a lavar… no sé, 5 veces, para que estés en paz."
    J "Relax, we'll wash it... I don't know, 5 times, so you're at peace."

# game/script.rpy:5683
translate english character_10_8f3e2754:

    # "Que estilo de vida tan precario…"
    "What a precarious lifestyle..."

# game/script.rpy:5684
translate english character_10_2f117fe5:

    # "¿Qué esperabas de un criminal?"
    "What did you expect from a criminal?"

# game/script.rpy:5702
translate english character_10_bdb51e48:

    # "Como lo prometió, Jeff lavó varias veces toda la ropa que se consiguió con un alcohólico de la calle."
    "As he promised, Jeff washed all the clothes he got from an alcoholic on the street several times."

# game/script.rpy:5703
translate english character_10_fa33ab5f:

    # "Así que ahora contabas con una camiseta, una sudadera propia, pantalones de chándal y zapatillas, que a pesar de ser de tu talla, eran de diferente par."
    "So now you had a T-shirt, your own hoodie, sweatpants, and sneakers, which, despite being your size, were mismatched."

# game/script.rpy:5704
translate english character_10_902c7dbd:

    # "¿Quién pensaría que irías en picada en una trama de romance-terror?"
    "Who would have thought you'd get a downgrade in a horror-romance plot?"

# game/script.rpy:5705
translate english character_10_6460e6b1:

    # "Pero al menos, pasar el tiempo con Jeff se volvió algo ameno."
    "But at least, spending time with Jeff became enjoyable."

# game/script.rpy:5706
translate english character_10_6528e4cc:

    # "Ustedes se la pasaban hablando, reflexionando sobre cosas, aprendiendo uno del otro."
    "You both spent time talking, reflecting on things, learning from each other."

# game/script.rpy:5707
translate english character_10_dada0de3:

    # "Incluso se quedaron dormidos mientras hablaban."
    "You even fell asleep while talking."

# game/script.rpy:5712
translate english character_10_2eea4d95:

    # "Así que no fue raro que él sea lo primero que ves apenas despiertas."
    "So it wasn't strange that he was the first thing you saw when you woke up."

# game/script.rpy:5713
translate english character_10_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5714
translate english character_10_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5715
translate english character_10_41c1c0a1:

    # pov "¿Hace cuánto que me estás mirando?"
    pov "How long have you been looking at me?"

# game/script.rpy:5716
translate english character_10_f39beda9:

    # J "Desde que desperté."
    J "Since I woke up."

# game/script.rpy:5717
translate english character_10_ba49a443:

    # "Lo miras expectante."
    "You looked at him expectantly."

# game/script.rpy:5718
translate english character_10_b72bea62:

    # J "Hace 5 horas."
    J "5 hours."

# game/script.rpy:5719
translate english character_10_a065aa59:

    # "Ok, esto se estaba saliendo de control."
    "Okay, this was getting out of control."

# game/script.rpy:5720
translate english character_10_1fa594a8:

    # "No esperabas llamar la atención de un asesino que se volvería en tu acosador de un día para otro."
    "You didn't expect to attract the attention of a killer who would become your stalker overnight."

# game/script.rpy:5721
translate english character_10_ca7cbd8b:

    # "De hecho, eso te abrumaba."
    "In fact, it overwhelmed you."

# game/script.rpy:5722
translate english character_10_6d80ef65:

    # pov "… ¿De verdad te tomó una semana amarme?"
    pov "... Did it really take you a week to love me?"

# game/script.rpy:5723
translate english character_10_9f01fa29:

    # J "¿Es tan difícil de creer?"
    J "Is that so hard to believe?"

# game/script.rpy:5724
translate english character_10_beca56bf:

    # J "No sé mucho de romance, pero eres la primera persona que me produce esto."
    J "I don't know much about romance, but you're the first person to make me feel this."

# game/script.rpy:5725
translate english character_10_d2372116:

    # J "Quiero estar a tu lado siempre, odio a cualquiera que se te acerque, no soporto la idea que alguien más te haga daño-"
    J "I want to be by your side always, I hate anyone who comes near you, I can't stand the idea of anyone else hurting you—"

# game/script.rpy:5726
translate english character_10_baa18d07:

    # pov "¿Sigues queriendo hacerme daño, Jeff?"
    pov "You still want to hurt me, Jeff?"

# game/script.rpy:5727
translate english character_10_1aca37bc:

    # "La sonrisa de Jeff se tensa ante tus palabras, y el aire se vuelve pesado."
    "Jeff's smile tensed at your words, and the air grew heavy."

# game/script.rpy:5728
translate english character_10_f1736163:

    # "Esa era una pregunta que necesitaba ser respondida."
    "That was a question that needed to be answered."

# game/script.rpy:5729
translate english character_10_028d857c:

    # "La idea de estar con Jeff y que él quiera dañarte… Te da mal sabor de boca."
    "The thought of being with Jeff and him wanting to hurt you... It left a bad taste in your mouth."

# game/script.rpy:5730
translate english character_10_abf71705:

    # J "Ahora que estamos bien, no tengo porqué."
    J "Now that we're good, I have no reason to."

# game/script.rpy:5731
translate english character_10_a226aabc:

    # "¿Eso quería decir que si estuvieran mal, te lastimaría?"
    "Did that mean that if things were bad, he would hurt you?"

# game/script.rpy:5732
translate english character_10_3088a824:

    # "Jeff alza una mano a tu mejilla y la acaricia con la punta de sus dedos, recorriendo con sus ojos cada rincón de tu rostro."
    "Jeff raised a hand to your cheek and caressed it with his fingertips, his eyes scanning every corner of your face."

# game/script.rpy:5733
translate english character_10_d618ad07:

    # pov "¿Y qué hay de lo que le hiciste a mi ojo?"
    pov "And what about what you did to my eye?"

# game/script.rpy:5734
translate english character_10_6d1c8e3f:

    # "Jeff se ríe entre dientes, y sientes frustración al sentir que no te toma en serio."
    "Jeff chuckled, and you felt frustrated that he wasn't taking you seriously."

# game/script.rpy:5735
translate english character_10_8bde55a3:

    # J "¿De qué serviría una disculpa cuando el daño ya está hecho?"
    J "What would an apology be good for when the damage is already done?"

# game/script.rpy:5736
translate english character_10_5387222b:

    # "Eso… Tenía cierta lógica, pero eso no significaba que no sientas rencor."
    "That... had some logic, but it didn't mean you didn't feel resentment."

# game/script.rpy:5738
translate english character_10_307c466b:

    # "Él deslizó sus dedos por debajo de los elásticos del parche, tirando sutilmente hasta desengancharlo de tu cabeza."
    "He slid his fingers under the elastic straps of the patch, gently pulling until he unhooked it from your head."

# game/script.rpy:5739
translate english character_10_1fdb99cc:

    # "Te habías quitado el parche adhesivo y la gasa, por lo que cuando él retiró tu parche, dejó al descubierto tu cuenca vacía."
    "You had removed the adhesive patch and gauze, so when he removed your patch, he exposed your empty eye socket."

# game/script.rpy:5740
translate english character_10_731cb36d:

    # J "Además, creo que te ves mejor así."
    J "Besides, I think you look better this way."

# game/script.rpy:5741
translate english character_10_3a57111d:

    # "No sabías si sentir que te elogia o que te está manipulando."
    "You didn't know whether to feel complimented or manipulated."

# game/script.rpy:5742
translate english character_10_994eb0d2:

    # "De cualquier forma, su toque era suave y delicado, rozando con la yema de sus dedos la zona alrededor de tu párpado izquierdo."
    "Either way, his touch was soft and delicate, his fingertips caressing the area around your left eyelid."

# game/script.rpy:5743
translate english character_10_935dcc7e:

    # J "Es uno de mis mejores trabajos."
    J "It's one of my best works."

# game/script.rpy:5744
translate english character_10_4133970e:

    # "Sus palabras te producen un escalofrío."
    "His words sent a shiver down your spine."

# game/script.rpy:5745
translate english character_10_af75e5a6:

    # "Sientes que tu mente está confusa."
    "You felt your mind was confused."

# game/script.rpy:5746
translate english character_10_2ebc5031:

    # "No sabes lo que está bien o que está mal a este punto."
    "You didn't know what was right or wrong at this point."

# game/script.rpy:5752
translate english character_10_93dc128a:

    # pov "¿Estoy… perdiendo la cabeza, Jeff?"
    pov "Am I... losing my mind, Jeff?"

# game/script.rpy:5753
translate english character_10_58c83c7b:

    # "Jeff sonríe afectuosamente, acariciando con su pulgar tu labio inferior."
    "Jeff smiled affectionately, caressing your lower lip with his thumb."

# game/script.rpy:5754
translate english character_10_6a0a4c54:

    # J "¿Qué mejor que enloquecer juntos, [povname]?"
    J "What's better than going crazy together, [povname]?"

# game/script.rpy:5757
translate english character_10_b1714a5a:

    # "Él no tiene por qué saberlo."
    "He didn't have to know."

# game/script.rpy:5758
translate english character_10_b77db6f7:

    # "Puede que alimente más la locura de él."
    "It might feed his madness."

# game/script.rpy:5763
translate english ruta_normal_41_028ab570:

    # "Te mantienes en silencio, bajo la mirada fija de Jeff."
    "You remained silent, under Jeff's fixed gaze."

# game/script.rpy:5764
translate english ruta_normal_41_afac89f3:

    # "Te estabas acostumbrando a que él se la pase observándote y que no parpadee."
    "You were getting used to him observing you and not blinking."

# game/script.rpy:5765
translate english ruta_normal_41_6f0b4b98:

    # "De hecho, te preguntas si siquiera tiene párpados."
    "In fact, you wondered if he even had eyelids."

# game/script.rpy:5771
translate english ruta_normal_41_7f0db406:

    # pov "De casualidad… ¿Tienes insomnio?"
    pov "By any chance... are you an insomniac?"

# game/script.rpy:5772
translate english ruta_normal_41_43ea234c:

    # "Jeff parece contentarse con tu pregunta."
    "Jeff seemed content with your question."

# game/script.rpy:5773
translate english ruta_normal_41_a2c2926c:

    # J "¿Lo notaste?"
    J "Did you notice?"

# game/script.rpy:5776
translate english ruta_normal_41_6756b687:

    # pov "¿Qué onda con tus ojos?"
    pov "What's with your eyes?"

# game/script.rpy:5777
translate english ruta_normal_41_1434765a:

    # J "¿Qué hay con ellos?"
    J "What about them?"

# game/script.rpy:5778
translate english ruta_normal_41_be82e546:

    # pov "Eso negro alrededor."
    pov "Those dark circles around them."

# game/script.rpy:5779
translate english ruta_normal_41_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5784
translate english ruta_normal_42_24a44f96:

    # J "Hace años que tengo insomnio."
    J "I've had insomnia for years."

# game/script.rpy:5785
translate english ruta_normal_42_0bf95f64:

    # J "Por lo que se me formaron estas ojeras."
    J "That's why these dark circles formed."

# game/script.rpy:5786
translate english ruta_normal_42_724afac0:

    # pov "… Oh."
    pov "… Oh."

# game/script.rpy:5787
translate english ruta_normal_42_95352187:

    # pov "Entonces, ¿Tienes párpados?"
    pov "So, you have eyelids?"

# game/script.rpy:5788
translate english ruta_normal_42_af96c346:

    # "Jeff resopla, sarcástico."
    "Jeff snorted sarcastically."

# game/script.rpy:5789
translate english ruta_normal_42_cf8545b5:

    # J "¿Por qué todos piensan que no tengo párpados?"
    J "Why does everyone think I don't have eyelids?"

# game/script.rpy:5790
translate english ruta_normal_42_4ebe7c36:

    # pov "Bueno, por mi parte es porque nunca te he visto parpadear."
    pov "Well, for my part it's because I've never seen you blink."

# game/script.rpy:5791
translate english ruta_normal_42_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5795
translate english ruta_normal_42_c410a1d0:

    # J "¿Feliz?"
    J "Happy?"

# game/script.rpy:5796
translate english ruta_normal_42_e2a98fa8:

    # pov "Sip, definitivamente ya no tengo dudas."
    pov "Yep, definitely no doubts now."

# game/script.rpy:5797
translate english ruta_normal_42_ab28d806:

    # "Claro, verlo parpadear lo hacía parecer más… normal."
    "Of course, seeing him blink made him seem more... normal."

# game/script.rpy:5798
translate english ruta_normal_42_0aca7133:

    # pov "Mírate, tan obediente."
    pov "Look at you, so obedient."

# game/script.rpy:5799
translate english ruta_normal_42_889681aa:

    # pov "Pensé que te gustaba dar órdenes más que recibirlas."
    pov "I thought you liked giving orders more than receiving them."

# game/script.rpy:5800
translate english ruta_normal_42_68aea31a:

    # J "No tengo preferencia."
    J "I have no preference."

# game/script.rpy:5801
translate english ruta_normal_42_ef3e2083:

    # J "Sé lo que quiero, y hago lo que sea por conseguirlo."
    J "I know what I want, and I'll do anything to get it."

# game/script.rpy:5802
translate english ruta_normal_42_f681bef1:

    # J "Pero estoy dispuesto a recibir lo que me des."
    J "But I'm willing to receive whatever you give me."

# game/script.rpy:5808
translate english ruta_normal_42_9e27ebdf:

    # pov "¿Estamos hablando de otra cosa?"
    pov "Are we talking about something else?"

# game/script.rpy:5810
translate english ruta_normal_42_26ca1c02:

    # "Las mejillas de Jeff se encienden, y su mirada baja."
    "Jeff's cheeks flushed, and his gaze dropped."

# game/script.rpy:5811
translate english ruta_normal_42_bf708034:

    # J "Tómalo como quieras."
    J "Take it however you want."

# game/script.rpy:5815
translate english ruta_normal_42_82ad5714:

    # pov "¿Si te digo que ladres como perro, lo harás?"
    pov "If I tell you to bark like a dog, will you do it?"

# game/script.rpy:5816
translate english ruta_normal_42_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5817
translate english ruta_normal_42_bf79647c:

    # J "Hay límites."
    J "There are limits."

# game/script.rpy:5822
translate english ruta_normal_43_e4b00b8e:

    # "Te ríes entre dientes ante la respuesta de él, y al menos Jeff parece satisfecho con tu reacción."
    "You chuckled at his answer, and at least Jeff seemed satisfied with your reaction."

# game/script.rpy:5823
translate english ruta_normal_43_5ffc6a70:

    # "Alzas tu mano y recorres con suavidad el brazo izquierdo de él, acariciando las marcas y cicatrices a través de la tela."
    "You raised your hand and gently ran it over his left arm, caressing the marks and scars through the fabric."

# game/script.rpy:5824
translate english ruta_normal_43_c5681539:

    # pov "¿Qué te sucedió?"
    pov "What happened to you?"

# game/script.rpy:5825
translate english ruta_normal_43_aeac4663:

    # "Jeff suspira despreocupado."
    "Jeff sighed, unconcerned."

# game/script.rpy:5826
translate english ruta_normal_43_3ac3b774:

    # J "Una mezcla de ocasiones. Algunas son quemaduras por el fuego y ácido, otras son cortes por peleas."
    J "A mix of occasions. Some are burns from fire and acid, others are cuts from fights."

# game/script.rpy:5827
translate english ruta_normal_43_35f3e6e7:

    # pov "¿Peleas?, Jeff, no te tomé como uno de esos."
    pov "Fights? Jeff, I didn't take you for that kind of guy."

# game/script.rpy:5828
translate english ruta_normal_43_483bfc5e:

    # J "¿Qué esperabas que hiciera?, ¿Dejarme apuñalar?, No gracias."
    J "What did you expect me to do? Let myself be stabbed? No thanks."

# game/script.rpy:5829
translate english ruta_normal_43_a6b59414:

    # pov "¿Y con quién pelearías tú?"
    pov "And who would you fight with?"

# game/script.rpy:5830
translate english ruta_normal_43_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5831
translate english ruta_normal_43_6c4c91a4:

    # J "Muchos enemigos."
    J "Many enemies."

# game/script.rpy:5832
translate english ruta_normal_43_3a63e933:

    # pov "¿Así que has dejado con vida a aún más personas?"
    pov "So you've left even more people alive?"

# game/script.rpy:5833
translate english ruta_normal_43_0a4069b3:

    # J "Solo te dejé a ti y la chica que mencioné antes."
    J "I only left you and the girl I mentioned before."

# game/script.rpy:5834
translate english ruta_normal_43_797998e1:

    # J "Los demás lograron escapar o simplemente buscan venganza."
    J "The others either escaped or are simply seeking revenge."

# game/script.rpy:5835
translate english ruta_normal_43_8f3a4ba3:

    # pov "Vaya, eres todo un chico malo."
    pov "Wow, you're quite the bad boy."

# game/script.rpy:5836
translate english ruta_normal_43_64bcdad3:

    # "Jeff se ríe levemente, su voz es vibrante."
    "Jeff chuckled softly, his voice vibrant."

# game/script.rpy:5837
translate english ruta_normal_43_292040c6:

    # "Que bueno que se lo tome con humor."
    "Good thing he took it with humor."

# game/script.rpy:5838
translate english ruta_normal_43_62c0c923:

    # "Ya que técnicamente, él es todo lo que está mal en el mundo."
    "Since technically, he was everything wrong with the world."

# game/script.rpy:5839
translate english ruta_normal_43_34f5eeda:

    # J "Hey, [povname]."
    J "Hey, [povname]."

# game/script.rpy:5840
translate english ruta_normal_43_d44ab9be:

    # pov "¿Sí?"
    pov "Yeah?"

# game/script.rpy:5841
translate english ruta_normal_43_5daf6a2f:

    # J "¿Te gusto?"
    J "Do you like me?"

# game/script.rpy:5842
translate english ruta_normal_43_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5843
translate english ruta_normal_43_30259b8b:

    # pov "Jeff, no me ando besando con cualquiera."
    pov "Jeff, I don't go around kissing just anyone."

# game/script.rpy:5844
translate english ruta_normal_43_88a8bea5:

    # "Él suspira, aliviado."
    "He sighed, relieved."

# game/script.rpy:5845
translate english ruta_normal_43_c02cbc0c:

    # "Jeff hace círculos con su dedo sobre las sábanas, mientras formaba un puchero."
    "Jeff made circles with his finger on the sheets, while pouting."

# game/script.rpy:5846
translate english ruta_normal_43_602ff6f0:

    # J "¿Te seguiría gustando si fuera un gusano?"
    J "Would you still like me if I were a worm?"

# game/script.rpy:5847
translate english ruta_normal_43_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:5848
translate english ruta_normal_43_1c6f43bf:

    # "Vaya, parece que él es el tipo de alto mantenimiento."
    "Wow, it seems he's the high-maintenance type."

# game/script.rpy:5854
translate english ruta_normal_43_1ec485bf:

    # pov "Por supuesto, adoro los gusanos."
    pov "Of course, I adore worms."

# game/script.rpy:5855
translate english ruta_normal_43_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5856
translate english ruta_normal_43_8adc974b:

    # J "No-"
    J "I-"

# game/script.rpy:5857
translate english ruta_normal_43_3632f87e:

    # pov "No aprecias mi sarcasmo, lo sé."
    pov "Don't appreciate my sarcasm, I know."

# game/script.rpy:5858
translate english ruta_normal_43_ef35999a:

    # pov "Nunca lo haces, y aún así me amas."
    pov "You never do, and you still love me."

# game/script.rpy:5861
translate english ruta_normal_43_9cdd4d20:

    # pov "Ew."
    pov "Ew."

# game/script.rpy:5862
translate english ruta_normal_43_c37db486:

    # J " … Oh."
    J "… Oh."

# game/script.rpy:5863
translate english ruta_normal_43_69e5f06c:

    # pov "Me gustas porque eres humano, no me aprovecharé de un gusano."
    pov "I like you because you're human, I won't take advantage of a worm."

# game/script.rpy:5864
translate english ruta_normal_43_2c03d4d3:

    # J "… No era literal."
    J "... It wasn't literal."

# game/script.rpy:5865
translate english ruta_normal_43_cbde89b1:

    # pov "¿Qué dices?"
    pov "What?"

# game/script.rpy:5866
translate english ruta_normal_43_033a96fb:

    # J "Nada."
    J "Nothing."

# game/script.rpy:5871
translate english ruta_normal_44_440481b4:

    # "Jeff se endereza de la cama y estira la espalda. Él suelta un quejido satisfecho, y se pone de pie."
    "Jeff straightened up from the bed and stretched his back. He let out a satisfied groan, and stood up."

# game/script.rpy:5872
translate english ruta_normal_44_425d692c:

    # J "Voy a bañarme."
    J "I'm going to shower."

# game/script.rpy:5877
translate english ruta_normal_44_a141d50b:

    # "Una de las cosas buenas de esa casa, es que tenía agua, aunque de manera algo ilegal."
    "One of the good things about that house was that it had water, albeit somewhat illegally."

# game/script.rpy:5878
translate english ruta_normal_44_6a143d0d:

    # "Jeff mencionó algo sobre bypass al contador."
    "Jeff mentioned something about bypassing the meter."

# game/script.rpy:5879
translate english ruta_normal_44_8596bc29:

    # "Con que ustedes tuvieran agua, te bastaba."
    "The fact that you had water was enough for you."

# game/script.rpy:5885
translate english ruta_normal_44_22416464:

    # pov "Voy contigo."
    pov "I'm coming with you."

# game/script.rpy:5887
translate english ruta_normal_44_21bc3e19:

    # "Te pones de pie también, pero pronto unas manos sobre tus hombros te detienen."
    "You also stood up, but hands on your shoulders stopped you."

# game/script.rpy:5889
translate english ruta_normal_44_a3989ea4:

    # J "Si vas conmigo, será un infierno para mí."
    J "If you come with me, it'll be hell for me."

# game/script.rpy:5890
translate english ruta_normal_44_5d1b697d:

    # pov "Pero pensé-"
    pov "But I thought—"

# game/script.rpy:5891
translate english ruta_normal_44_673097c7:

    # J "¡Un infierno!"
    J "Hell!"

# game/script.rpy:5892
translate english ruta_normal_44_1f741ba3:

    # pov "¡Ok, geez!"
    pov "Okay, geez!"

# game/script.rpy:5893
translate english ruta_normal_44_ee6bcdc0:

    # "Él te suelta, y notas cómo sus manos tiemblan levemente y su respiración está agitada."
    "He let go of you, and you noticed his hands trembling slightly and his breathing was agitated."

# game/script.rpy:5894
translate english ruta_normal_44_8a5959e9:

    # "Ah, esa clase de infierno."
    "Ah, that kind of hell."

# game/script.rpy:5901
translate english ruta_normal_45_7540a646:

    # "Te quedas donde estás, en la habitación."
    "You stay where you are, in the room."

# game/script.rpy:5903
translate english ruta_normal_45_4257e3ed:

    # "Jeff te da una última mirada antes de salir."
    "Jeff gave you one last look before leaving."

# game/script.rpy:5904
translate english ruta_normal_45_d0edd404:

    # "Miras el alrededor, buscando alguna forma de detenerte."
    "You looked around, trying to find a way to stop him."

# game/script.rpy:5905
translate english ruta_normal_45_b7bf9cfa:

    # "No tenías tu teléfono contigo, y la casa no tenía wifi."
    "You didn't have your phone with you, and the house had no Wi-Fi."

# game/script.rpy:5906
translate english ruta_normal_45_f3330be2:

    # "Con suerte tenía luz."
    "Fortunately, it had electricity."

# game/script.rpy:5907
translate english ruta_normal_45_41fb8839:

    # "Así que decides recorrer el lugar."
    "So you decided to explore the place."

# game/script.rpy:5918
translate english habitacion_j_58816021:

    # "Paseas por el lugar, evitando los escombros."
    "You walked around, avoiding the debris."

# game/script.rpy:5919
translate english habitacion_j_a246a1c8:

    # "No hay nada además de la cama."
    "There was nothing besides the bed."

# game/script.rpy:5924
translate english sala_j_4038f2d9:

    # "Vas a la sala, e inspeccionas los muebles."
    "You went to the living room, and inspected the furniture."

# game/script.rpy:5925
translate english sala_j_495b13e4:

    # "El sofá es duro, y el cable de la TV está rota."
    "The sofa was hard, and the TV cable was broken."

# game/script.rpy:5926
translate english sala_j_a44dcc50:

    # "No tienes mucho qué hacer aquí."
    "You didn't have much to do here."

# game/script.rpy:5932
translate english cocina_j_76985f8a:

    # "Revisas el minirefri."
    "You checked the mini-fridge."

# game/script.rpy:5933
translate english cocina_j_f8143131:

    # "Hay muchas bebidas energéticas."
    "There were many energy drinks."

# game/script.rpy:5934
translate english cocina_j_ce617998:

    # "…"
    "..."

# game/script.rpy:5935
translate english cocina_j_4caf3340:

    # "Eso explica el insomnio."
    "That explained the insomnia."

# game/script.rpy:5940
translate english baño_j_df58c92c:

    # "Te quedas junto a la puerta, escuchando el sonido de la ducha."
    "You stayed by the door, listening to the sound of the shower."

# game/script.rpy:5941
translate english baño_j_696ae31a:

    # "Hay un leve tarareo del otro lado de la puerta."
    "There was a faint hum from the other side of the door."

# game/script.rpy:5942
translate english baño_j_00ef1359:

    # "Sólo tienes tu imaginación contigo, por lo que te resignas."
    "You only had your imagination with you, so you resigned yourself."

# game/script.rpy:5948
translate english sotano_7e6b1a6d:

    # "Hay una puerta de la que no sabes a dónde va."
    "There was a door you didn't know where it led."

# game/script.rpy:5949
translate english sotano_3861cc6a:

    # "Considerando que esta es una casa prácticamente abandonada, algo te decía que entrar no sería lindo."
    "Considering this was a practically abandoned house, something told you it wouldn't be nice to go in."

# game/script.rpy:5950
translate english sotano_db2822eb:

    # "Pero la curiosidad era más grande."
    "But curiosity was stronger."

# game/script.rpy:5952
translate english sotano_63b3e76e:

    # "Abres la puerta y el crujido retumba entre las paredes."
    "You opened the door and the creaking echoed through the walls."

# game/script.rpy:5954
translate english sotano_35fcbe5c:

    # "Está oscuro, pero por suerte hay un interruptor al costado, por lo que lo apretas y el lugar se alumbra."
    "It was dark, but luckily there was a switch nearby, so you pressed it and the place lit up."

# game/script.rpy:5957
translate english sotano_62aa1bfe:

    # "Frente a ti, se extienden hacia abajo unas escaleras."
    "In front of you, some stairs extended downward"

# game/script.rpy:5958
translate english sotano_7b5feef2:

    # "Por supuesto, no faltaba el sótano escalofriante."
    "Of course, the creepy basement wasn't missing."

# game/script.rpy:5959
translate english sotano_0a62672d:

    # "Tenías la fortuna que Jeff no era de esos que encadenaba en el sótano a prueba de ruido."
    "You were lucky that Jeff wasn't one of those who chained people in the soundproof basement."

# game/script.rpy:5960
translate english sotano_ce617998:

    # "…"
    "..."

# game/script.rpy:5961
translate english sotano_736116c3:

    # "Por ahora."
    "For now."

# game/script.rpy:5962
translate english sotano_860c1880:

    # "Bajas en silencio, apoyándote en el barandal ante los escalones desgastados."
    "You went down quietly, leaning on the railing as you descended the worn steps."

# game/script.rpy:5963
translate english sotano_9b19232d:

    # "El silencio abunda en el lugar, tus pasos resuenan en el cemento."
    "Silence filled the place, your footsteps echoing on the cement."

# game/script.rpy:5965
translate english sotano_3365f661:

    # "La luz también se encendió abajo, por lo que puedes ver con claridad el lugar."
    "The light also came on downstairs, so you could see the place clearly."

# game/script.rpy:5966
translate english sotano_db32a922:

    # "Es espacioso y frío."
    "It was spacious and cold."

# game/script.rpy:5967
translate english sotano_2e22a5b3:

    # "Las paredes son de piedra y hay algunas tuberías descubiertas, lo que explica el olor a humedad."
    "The walls were stone and there were some exposed pipes, which explained the damp smell."

# game/script.rpy:5968
translate english sotano_359dd3ad:

    # "Pero hay otro olor en el aire."
    "But there was another smell in the air."

# game/script.rpy:5969
translate english sotano_9864e2e8:

    # "No lo reconoces al inicio, pero te diriges a un rincón donde hay un mueble destartalado."
    "You didn't recognize it at first, but you went to a corner where there was a dilapidated piece of furniture."

# game/script.rpy:5970
translate english sotano_70afdb12:

    # "Te asomas para ver mejor."
    "You leaned in to get a better look."

# game/script.rpy:5982
translate english sotano_0ce5cfbc:

    # pov "¡Mierda!"
    pov "Fuck!"

# game/script.rpy:5983
translate english sotano_58ea36d8:

    # "Retrocedes con horror, presenciando un cadáver."
    "You recoiled in horror, witnessing a corpse."

# game/script.rpy:5984
translate english sotano_42034897:

    # "Con valentía, lo miras a una distancia prudente, porque la escena es demasiado horrible como para verlo de cerca."
    "With courage, you looked at it from a safe distance, because the scene was too horrible to view up close."

# game/script.rpy:5985
translate english sotano_95baf862:

    # "Reconoces por el cabello corto y el tamaño que es un hombre, pero su rostro es totalmente irreconocible. Está hinchado y con la piel verdosa."
    "You recognized from the short hair and size that it was a man, but his face was totally unrecognizable. It was swollen and with greenish skin."

# game/script.rpy:5986
translate english sotano_13c6a55c:

    # "Notas el polvo blanco que tiene encima, y no te cuesta entender que se trata de cal."
    "You noticed the white powder on it, and it wasn't hard to understand that it was lime."

# game/script.rpy:5987
translate english sotano_41ec417b:

    # "Si no fuera por la cal, hubieras notado el olor desde el principio."
    "If it weren't for the lime, you would have noticed the smell from the beginning."

# game/script.rpy:5988
translate english sotano_314d278e:

    # "Sientes que la bilis sube por tu garganta, pero tapas la boca como reflejo para evitarlo."
    "You felt bile rise in your throat, but you covered your mouth instinctively to prevent it."

# game/script.rpy:5989
translate english sotano_89464ceb:

    # "Te alejas de la escena para tomar aire."
    "You walked away from the scene to get some air."

# game/script.rpy:5990
translate english sotano_67c38527:

    # "¿Qué mierda?"
    "What the fuck?"

# game/script.rpy:5991
translate english sotano_a22c5403:

    # "Jeff… ¿Hizo eso?"
    "Jeff... Did he do that?"

# game/script.rpy:5992
translate english sotano_5da50264:

    # "Sería lo ideal que él no tuviera nada que ver, pero siendo realistas, lo más probable es que fuera Jeff."
    "It would be ideal if he had nothing to do with it, but realistically, it was most likely Jeff."

# game/script.rpy:5993
translate english sotano_d5463930:

    # "Ese… ¿Era el dueño original de la casa?"
    "Was that... the original owner of the house?"

# game/script.rpy:5994
translate english sotano_4404d30b:

    # "Jeff había admitido que consigue dinero en sus asesinatos, por lo que no sería raro que hiciera lo mismo con el alojamiento."
    "Jeff had admitted to getting money from his murders, so it wouldn't be strange for him to do the same with accommodation."

# game/script.rpy:5995
translate english sotano_2d25bcb7:

    # "Él escogió ese barrio peligroso a propósito, porque si la policía aparecía, estarían más ocupados en otras actividades sospechosas típicas del lugar."
    "He chose that dangerous neighborhood on purpose, because if the police showed up, they'd be more occupied with other suspicious activities typical of the area."

# game/script.rpy:5996
translate english sotano_9dff71b8:

    # "Era un claro escondite a plena vista."
    "It was a clear hideout in plain sight."

# game/script.rpy:5997
translate english sotano_7e1bd2c8:

    # "¿Pero qué hay con el tema de que Jeff mató al dueño de la casa y lo puso en el sótano?"
    "But what about Jeff killing the homeowner and putting him in the basement?"

# game/script.rpy:5998
translate english sotano_b83cb598:

    # "Era horrible, lo miraras donde lo miraras."
    "It was horrible, no matter how you looked at it."

# game/script.rpy:5999
translate english sotano_2721fb1a:

    # "Jeff mató a mucha gente, entre ellos… gente inocente."
    "Jeff killed many people, among them... innocent people."

# game/script.rpy:6000
translate english sotano_c5a7acb6:

    # "Nunca viste un ápice de remordimiento de su parte y tú…"
    "You never saw a hint of remorse from him, and you..."

# game/script.rpy:6001
translate english sotano_b1d6c981:

    # "Te volviste su cómplice."
    "You became his accomplice."

# game/script.rpy:6002
translate english sotano_bccf3662:

    # "Sabías que no eras responsable por las acciones de Jeff."
    "You knew you weren't responsible for Jeff's actions."

# game/script.rpy:6003
translate english sotano_77078515:

    # "Pero si tú no las cuestionabas, ¿No eras igual de horrible que él?"
    "But if you didn't question them, weren't you just as horrible as him?"

# game/script.rpy:6004
translate english sotano_eff37787:

    # "Deberías sentir un rechazo absoluto hacia alguien así."
    "You should feel absolute rejection towards someone like that."

# game/script.rpy:6005
translate english sotano_beb3fc98:

    # "Deberías ser incapaz de charlar amenamente con alguién así."
    "You should be incapable of chatting pleasantly with someone like that."

# game/script.rpy:6006
translate english sotano_6c1e2681:

    # "Pero… "
    "But..."

# game/script.rpy:6008
translate english sotano_d7cb26f8:

    # "¿Por qué… No puedes odiarlo?"
    "Why... can't you hate him?"

# game/script.rpy:6013
translate english sotano_36c65282:

    # "No puede ser…"
    "It couldn't be...
"

# game/script.rpy:6014
translate english sotano_86fb24a7:

    # "De verdad caíste tan bajo como para enamorarte de un asesino despiadado."
    "You really fell so low as to fall in love with a ruthless killer."

# game/script.rpy:6015
translate english sotano_42675485:

    # "Habías perdido realmente la cabeza."
    "You had truly lost your mind."

# game/script.rpy:6019
translate english sotano_5e953f46:

    # "Él… Es algo así como un amigo."
    "He... He's kind of like a friend."

# game/script.rpy:6020
translate english sotano_4b0f2cd4:

    # "Si, ustedes se besaron, pero fue sólo eso."
    "Yes, you two kissed, but that was all."

# game/script.rpy:6021
translate english sotano_87b79c32:

    # "No tenías fuertes sentimientos por él."
    "You had no strong feelings for him."

# game/script.rpy:6027
translate english charcater_11_01ffbca1:

    # "De cualquier forma, no podías quedarte en el sótano."
    "Anyway, you couldn't stay in the basement."

# game/script.rpy:6028
translate english charcater_11_05428cbd:

    # "Seguramente Jeff se pregunte dónde estás si no te ve, y quizás se moleste por tu descubrimiento."
    "Jeff would surely wonder where you were if he didn't see you, and he might get upset about your discovery."

# game/script.rpy:6030
translate english charcater_11_8a4ecddf:

    # "Subes las escaleras con rapidez, pero conservando precaución ante el deterioro de los escalones."
    "You went up the stairs quickly, but carefully, given the deterioration of the steps."

# game/script.rpy:6032
translate english charcater_11_cbd2d027:

    # "Llegas al pasillo en el momento en que Jeff sale del baño."
    "You reached the hallway just as Jeff came out of the bathroom."

# game/script.rpy:6035
translate english charcater_11_0b7eb8c2:

    # "Su cabello sigue húmedo, por lo que se lo seca con una toalla."
    "His hair was still wet, so he was drying it with a towel."

# game/script.rpy:6036
translate english charcater_11_e09a5cff:

    # J "Ahí estabas, te estaba buscando."
    J "There you were, I was looking for you."

# game/script.rpy:6037
translate english charcater_11_12033b61:

    # pov "Seh…"
    pov "Yeah..."

# game/script.rpy:6038
translate english charcater_11_53014a86:

    # "Él frota un extremo de la toalla contra su cabeza y su cabello largo se sacude."
    "He rubbed one end of the towel against his head and shook his long hair."

# game/script.rpy:6039
translate english charcater_11_ea6bfa3e:

    # J "¿Ya te aburriste de mí?"
    J "Are you bored of me yet?"

# game/script.rpy:6040
translate english charcater_11_a5d1560d:

    # "La sonrisa de él es divertida, acentuando su sarcasmo."
    "His smile was amused, accentuating his sarcasm."

# game/script.rpy:6046
translate english charcater_11_af350310:

    # pov "Nunca me aburriría de ti, Jeff."
    pov "I would never get bored of you, Jeff."

# game/script.rpy:6048
translate english charcater_11_34fd9c69:

    # "No lo dices precisamente por sus aspectos buenos."
    "You're not saying that because of his good qualities."

# game/script.rpy:6049
translate english charcater_11_0ce2a2a3:

    # "Que son muy pocos, o inexistentes."
    "Which are very few, or nonexistent."

# game/script.rpy:6050
translate english charcater_11_07925450:

    # "Pero al menos Jeff parece feliz con tu respuesta."
    "But at least Jeff seemed happy with your answer."

# game/script.rpy:6053
translate english charcater_11_243ed617:

    # pov "Bueno, tenía que entretenerme de alguna forma."
    pov "Well, I had to entertain myself somehow."

# game/script.rpy:6055
translate english charcater_11_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6056
translate english charcater_11_adeba0fa:

    # "Jeff te mira atentamente, como si quisiera comprenderte."
    "Jeff looked at you intently, as if trying to understand you."

# game/script.rpy:6063
translate english ruta_normal_46_d78b7533:

    # "Él siguió frotándose el cabello mojado, que no parecía estar cerca de estar seco."
    "He kept rubbing his wet hair, which didn't seem close to being dry."

# game/script.rpy:6064
translate english ruta_normal_46_a4d452f7:

    # pov "… ¿Es muy optimista pensar que podría haber una secadora de pelo aquí?"
    pov "Is it too optimistic to think there might be a hairdryer here?"

# game/script.rpy:6066
translate english ruta_normal_46_bff58889:

    # "Jeff te mira con sarcasmo."
    "Jeff looked at you with sarcasm."

# game/script.rpy:6067
translate english ruta_normal_46_de9e1b01:

    # J "¿En este chiquero?, Obvio que no."
    J "In this dump? Obviously not."

# game/script.rpy:6068
translate english ruta_normal_46_ed4ac059:

    # pov "Entonces déjamelo a mí."
    pov "Then leave it to me."

# game/script.rpy:6070
translate english ruta_normal_46_061546f2:

    # "Extiendes tus manos hacia él, apuntando la toalla."
    "You held out your hands to him, pointing at the towel."

# game/script.rpy:6071
translate english ruta_normal_46_542cf12a:

    # "Él te miró en silencio por unos segundos, interrogativo."
    "He looked at you in silence for a few seconds, questioning."

# game/script.rpy:6073
translate english ruta_normal_46_72f05f46:

    # "Pero después pareció entender y su expresión se iluminó."
    "But then he seemed to understand and his expression brightened."

# game/script.rpy:6074
translate english ruta_normal_46_183a85f4:

    # J "¡Por supuesto!"
    J "Of course!"

# game/script.rpy:6079
translate english ruta_normal_46_da0e6ee7:

    # "Jeff te extiende la toalla y se apresura a tomar asiento en la sala, mirándote expectante."
    "Jeff handed you the towel and hurried to sit in the living room, looking at you expectantly."

# game/script.rpy:6080
translate english ruta_normal_46_b0f294cf:

    # "Te acercas y te colocas detrás de él. Él se gira, para darte la espalda."
    "You approached and stood behind him. He turned, to give you his back."

# game/script.rpy:6081
translate english ruta_normal_46_6c431272:

    # "El cabello de él se extiende frente a ti, brillante y lacio."
    "His hair flowed before you, shiny and straight."

# game/script.rpy:6082
translate english ruta_normal_46_d0cbc585:

    # "Empiezas a frotar las puntas suavemente, algunas veces apretando la toalla para quitar el exceso de agua."
    "You began to rub the ends gently, sometimes squeezing the towel to remove excess water."

# game/script.rpy:6083
translate english ruta_normal_46_1fb1acb5:

    # pov "Tienes el pelo muy liso."
    pov "Your hair is very straight."

# game/script.rpy:6085
translate english ruta_normal_46_4bf5080e:

    # J "Antes lo tenía un poco ondulado, pero desde el accidente, quedó así."
    J "Before, it was a bit wavy, but after the accident, it stayed like this."

# game/script.rpy:6086
translate english ruta_normal_46_8c51242e:

    # "Ah, claro. No tenías en claro cómo fue exactamente lo que pasó, pero te haces una idea general."
    "Ah, right. You weren't clear on exactly what happened, but you have a general idea."

# game/script.rpy:6088
translate english ruta_normal_46_f93a9143:

    # J "También era castaño."
    J "It was also brown."

# game/script.rpy:6089
translate english ruta_normal_46_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6090
translate english ruta_normal_46_92856fbf:

    # pov "¿Tienes fotos?"
    pov "Do you have photos?"

# game/script.rpy:6092
translate english ruta_normal_46_fa027063:

    # "Jeff resopla divertido."
    "Jeff snorted, amused."

# game/script.rpy:6093
translate english ruta_normal_46_5c81b105:

    # J "¿De esa época?, Para nada."
    J "From that time? Not at all."

# game/script.rpy:6094
translate english ruta_normal_46_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6095
translate english ruta_normal_46_4f0096fb:

    # J "Quizás en mi vieja cuenta de tumblr."
    J "Maybe on my old Tumblr account."

# game/script.rpy:6096
translate english ruta_normal_46_e8d55127:

    # pov "Eres tan emo."
    pov "You're so emo."

# game/script.rpy:6098
translate english ruta_normal_46_c14a5cfa:

    # J "¡No lo-!, ugh."
    J "I don't—! Ugh."

# game/script.rpy:6099
translate english ruta_normal_46_b7bb16b9:

    # "Te ríes ante la protesta de Jeff."
    "You chuckled at Jeff's protest."

# game/script.rpy:6102
translate english ruta_normal_46_facdf4d3:

    # "Él alza la cabeza, y te mira desde su lugar."
    "He raised his head, and looked at you from his spot."

# game/script.rpy:6103
translate english ruta_normal_46_dfdffcd7:

    # "Su mirada, comúnmente ida, te mira con suavidad. Una humanidad que ves por primera vez en él. "
    "His gaze, usually distant, looked at you with tenderness. A humanity you saw for the first time in him."

# game/script.rpy:6104
translate english ruta_normal_46_ae795372:

    # "Continuas frotando su cabello, esta vez en la parte superior de su cabeza."
    "You continued rubbing his hair, this time on the top of his head."

# game/script.rpy:6105
translate english ruta_normal_46_d51b83de:

    # J "De todas formas, me veo mejor ahora."
    J "Anyway, I look better now."

# game/script.rpy:6106
translate english ruta_normal_46_9b0f8d89:

    # pov "¿En serio?"
    pov "Really?"

# game/script.rpy:6107
translate english ruta_normal_46_651fab21:

    # J "Si, en ese entonces era muy soso. Me comparaban mucho con mi hermano, decían que nos parecíamos mucho."
    J "Yes, back then I was very plain. They compared me a lot to my brother, they said we looked a lot alike."

# game/script.rpy:6108
translate english ruta_normal_46_b579d4e6:

    # pov "Tiene sentido, si son hermanos."
    pov "That makes sense, if you're brothers."

# game/script.rpy:6109
translate english ruta_normal_46_19e74d20:

    # pov "… ¿Ustedes eran cercanos?"
    pov "... Were you two close?"

# game/script.rpy:6110
translate english ruta_normal_46_679d76c4:

    # J "Si, lo éramos."
    J "Yeah, we were."

# game/script.rpy:6112
translate english ruta_normal_46_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6114
translate english ruta_normal_46_6f73e40b:

    # J "La verdad, es que ni siquiera sé si está vivo."
    J "Actually, I don't even know if he's alive."

# game/script.rpy:6115
translate english ruta_normal_46_c584c7ef:

    # pov "¿Pensé que tu familia estaba muerta?"
    pov "I thought your family was dead?"

# game/script.rpy:6116
translate english ruta_normal_46_c3c2e2da:

    # J "Mis padres lo están, estoy seguro de eso."
    J "My parents are, I'm sure of that."

# game/script.rpy:6117
translate english ruta_normal_46_ca0c1a54:

    # J "Pero de Liu… No tanto."
    J "But Liu... Not so much."

# game/script.rpy:6118
translate english ruta_normal_46_f9e4d6ea:

    # pov "¿Cómo lo sabes?"
    pov "How do you know?"

# game/script.rpy:6120
translate english ruta_normal_46_46cbb9c8:

    # J "Es… complicado."
    J "It's... complicated."

# game/script.rpy:6121
translate english ruta_normal_46_b2668f41:

    # pov "Entiendo, ¿Es otra de tus aventuras?"
    pov "I understand, is this another one of your adventures?"

# game/script.rpy:6122
translate english ruta_normal_46_5b2d8bf1:

    # J "Se podría decir."
    J "You could say that."

# game/script.rpy:6123
translate english ruta_normal_46_ed8953f8:

    # pov "Hay tanto sobre ti que me está costando seguir el hilo."
    pov "There's so much about you that I'm having trouble keeping track."

# game/script.rpy:6125
translate english ruta_normal_46_3f1e8453:

    # "Jeff ríe entre dientes."
    "Jeff chuckled."

# game/script.rpy:6126
translate english ruta_normal_46_3a1294f8:

    # J "No es necesario que sepas cada detalle de mí."
    J "You don't need to know every detail about me."

# game/script.rpy:6127
translate english ruta_normal_46_54cc20a1:

    # J "Mejor enfócate en disfrutarme."
    J "Better focus on enjoying me."

# game/script.rpy:6129
translate english ruta_normal_46_a360b242:

    # "Él se endereza y se gira para enfrentarte."
    "He straightened up and turned to face you."

# game/script.rpy:6130
translate english ruta_normal_46_9f060a3f:

    # J "¿Qué parte de mí te gusta más?"
    J "Which part of me do you like the most?"

# game/script.rpy:6135
translate english ruta_normal_46_e890d35d:

    # J "¿Mis ojos?"
    J "My eyes?"

# game/script.rpy:6136
translate english ruta_normal_46_02fce65a:

    # J "Sí que sabes halagar."
    J "You sure know how to flatter."

# game/script.rpy:6140
translate english ruta_normal_46_3212c2bc:

    # J "¿De verdad te gusta?"
    J "You really like it?"

# game/script.rpy:6142
translate english ruta_normal_46_7feba57b:

    # J "¡Eso me hace tan feliz!"
    J "That makes me so happy!"

# game/script.rpy:6146
translate english ruta_normal_46_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:6147
translate english ruta_normal_46_65e31fd2:

    # J "Ten cuidado, [povname]."
    J "Be careful, [povname]."

# game/script.rpy:6151
translate english ruta_normal_46_c487c8bb:

    # J "¡Yo no tengo-!"
    J "I don't have—!"

# game/script.rpy:6152
translate english ruta_normal_46_008e23e3:

    # "Él se lleva una mano a la cabeza, sintiendo la parte que no tiene cabello."
    "He brought a hand to his head, feeling the part where he had no hair."

# game/script.rpy:6154
translate english ruta_normal_46_3cbd7e72:

    # J "Eso no es calva."
    J "That's not a bald spot."

# game/script.rpy:6155
translate english ruta_normal_46_06bd3670:

    # pov "De acuerdo, entradas."
    pov "Okay, hairline."

# game/script.rpy:6156
translate english ruta_normal_46_3865c1f7:

    # J "¡Tampoco!; ¡Es parte de mis cicatrices!"
    J "Not that either! It's part of my scars!"

# game/script.rpy:6157
translate english ruta_normal_46_6f714354:

    # "Jeff refunfuña, con un puchero."
    "Jeff grumbled, pouting."

# game/script.rpy:6163
translate english favorito_d77317d6:

    # pov "Eres alguien muy vanidoso, ¿No?"
    pov "You're very vain, aren't you?"

# game/script.rpy:6164
translate english favorito_5156b7fa:

    # "Jeff se encoge de hombros."
    "Jeff shrugged."

# game/script.rpy:6168
translate english favorito_38c599db:

    # "Rodeas la cabeza de él con la toalla, y tiras suavemente, haciendo que él se incline levemente hacia ti."
    "You wrapped the towel around his head, and gently pulled, making him lean slightly towards you."

# game/script.rpy:6170
translate english favorito_1fc7ba55:

    # "Lo miras en silencio, y ves que causa una reacción en él."
    "You looked at him in silence, and saw that it caused a reaction in him."

# game/script.rpy:6171
translate english favorito_a1f63eb0:

    # "Sus mejillas se encienden y él desvía la mirada brevemente con timidez."
    "His cheeks flushed and he briefly looked away shyly."

# game/script.rpy:6172
translate english favorito_2089e5d2:

    # "Él… realmente está rendido a ti."
    "He... he really fall for you."

# game/script.rpy:6173
translate english favorito_14e691a5:

    # "Puedes… casi confiar en él."
    "You can... almost trust him."

# game/script.rpy:6178
translate english favorito_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6179
translate english favorito_11ca74aa:

    # J "Así que te diste cuenta."
    J "So you noticed."

# game/script.rpy:6180
translate english favorito_0eb4316e:

    # J "Ya te lo dije, no tienes que actuar con tanta cautela conmigo."
    J "I told you, you don't have to act so cautious with me."

# game/script.rpy:6186
translate english favorito_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6187
translate english favorito_119fc079:

    # J "¿Bajaste?"
    J "Did you go to the basement?"

# game/script.rpy:6188
translate english favorito_28750f70:

    # "No sabes si suena molesto o no."
    "You couldn't tell if he sounded angry or not."

# game/script.rpy:6189
translate english favorito_7f51411b:

    # "Pero su tono se había endurecido, lo que te traía malos recuerdos de tus encuentros anteriores con él."
    "But his tone had hardened, which brought back bad memories of your previous encounters with him."

# game/script.rpy:6194
translate english ruta_normal_47_29313ebd:

    # pov "Así que lo mataste."
    pov "So you killed him."

# game/script.rpy:6195
translate english ruta_normal_47_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6196
translate english ruta_normal_47_cf879ae8:

    # J "¿Realmente te extraña?"
    J "Is that really news to you?"

# game/script.rpy:6197
#translate english ruta_normal_47_33b4d816:

    # pov "No me extraña… Es sólo que… Es lo más horrible que he visto hasta el momento."
    #pov "It's not... It's just that... It's the most horrible thing I've seen so far."

# game/script.rpy:6198
translate english ruta_normal_47_0cf214ce:

    # pov "Me sorprendió, eso es todo."
    pov "It surprised me, that's all."

# game/script.rpy:6199
translate english ruta_normal_47_5bbf4168:

    # "Jeff te mira en silencio, pensativo."
    "Jeff looked at you in silence, thoughtful."

# game/script.rpy:6200
translate english ruta_normal_47_ae6b2b34:

    # "Su expresión, comúnmente sonriente y maníaca, es extrañamente calma."
    "His expression, usually smiling and maniacal, was strangely calm."

# game/script.rpy:6201
translate english ruta_normal_47_cf4891b9:

    # "De hecho, él daba un poco más de miedo cuando era serio."
    "In fact, he was a little scarier when he was serious."

# game/script.rpy:6202
translate english ruta_normal_47_dc1280b1:

    # pov "Jeff… ¿Has pensado realmente en la situación?"
    pov "Jeff... Have you really thought about the situation?"

# game/script.rpy:6203
translate english ruta_normal_47_13024660:

    # J "¿De qué hablas?"
    J "What are you talking about?"

# game/script.rpy:6204
translate english ruta_normal_47_ea180864:

    # pov "Hablo de esto."
    pov "I'm talking about this."

# game/script.rpy:6205
translate english ruta_normal_47_fdd3f91f:

    # "Señalas todo el lugar, las paredes rotas, el suelo lleno de escombros y polvo, los muebles rotos. Ustedes."
    "You pointed to the whole place, the broken walls, the floor covered in rubble and dust, the broken furniture. You two."

# game/script.rpy:6206
translate english ruta_normal_47_5283e120:

    # pov "También lo de ayer, con el policía."
    pov "Also what happened yesterday, with the police."

# game/script.rpy:6208
translate english ruta_normal_47_dd52a775:

    # pov "Si me quedo contigo, ¿Vamos a vivir así?"
    pov "If I stay with you, are we going to live like this?"

# game/script.rpy:6211
translate english ruta_normal_47_495ced28:

    # "Los ojos de Jeff se inyectan en sangre, y su boca forma una mueca."
    "Jeff's eyes became bloodshot, and his mouth twisted into a grimace."

# game/script.rpy:6213
translate english ruta_normal_47_1edee679:

    # "Antes de que te des cuenta, él atrapa tus mejillas entre sus dedos y aprieta, atrayéndote hacia él bruscamente."
    "Before you even realized it, he trapped your cheeks between his fingers and squeezed, pulling you towards him abruptly."

# game/script.rpy:6214
translate english ruta_normal_47_e5c9fde9:

    # "… Duele."
    "... It hurts."

# game/script.rpy:6215
translate english ruta_normal_47_6c587242:

    # J "No hay ninguna condicional en esto, no hay ningún “Si”. Vas a estar conmigo, y punto."
    J "There are no conditions for this, no 'if'. You're going to be with me, period."

# game/script.rpy:6216
translate english ruta_normal_47_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6217
translate english ruta_normal_47_9dbd1192:

    # "Jeff entierra sus uñas en tu piel, lo que te hace sisear."
    "Jeff dug his nails into your skin, making you hiss."

# game/script.rpy:6218
translate english ruta_normal_47_6c6e2e87:

    # "Él realmente seguía siendo el mismo."
    "He really was still the same."

# game/script.rpy:6219
translate english ruta_normal_47_f4bd6119:

    # J "¿Debería arrancarte el otro ojo para que entiendas?"
    J "Should I rip out your other eye so you understand?"

# game/script.rpy:6223
translate english ruta_normal_47_9d83cecf:

    # pov "T-tienes razón."
    pov "Y-you're right."

# game/script.rpy:6224
translate english ruta_normal_47_beaff3f6:

    # pov "Me equivoqué."
    pov "I was wrong."

# game/script.rpy:6225
translate english ruta_normal_47_75fab125:

    # pov "Sólo quería saber cómo viviríamos, eso es todo."
    pov "I just wanted to know how we would live, that's all."

# game/script.rpy:6230
translate english ruta_normal_47_5df5ec0e:

    # pov "No pretendía nada con lo que dije, sólo quería visualizar nuestra vida juntos."
    pov "I didn't mean anything by what I said, I just wanted to visualize our life together."

# game/script.rpy:6235
translate english ruta_normal_48_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6239
translate english ruta_normal_48_00faa907:

    # "Jeff te suelta y guarda distancia."
    "Jeff released you and kept his distance."

# game/script.rpy:6240
translate english ruta_normal_48_4a6d70db:

    # "Sientes que vuelves a respirar y que tu corazón se calma."
    "You felt yourself breathe again and your heart calmed."

# game/script.rpy:6241
translate english ruta_normal_48_751bb5f6:

    # J "Vamos a tener que movernos constantemente, para evitar a la policía."
    J "We're going to have to move constantly to avoid the police."

# game/script.rpy:6242
translate english ruta_normal_48_aecf51ec:

    # J "Supongo que podría mejorar los lugares en los que nos quedemos."
    J "I guess I could improve the places we stay."

# game/script.rpy:6243
translate english ruta_normal_48_c8536b52:

    # "Él se llevó un dedo a la barbilla, pensativamente."
    "He brought a finger to his chin, thoughtfully."

# game/script.rpy:6244
translate english ruta_normal_48_2b8ecbb7:

    # J "Quizás intercalar entre casas y hoteles."
    J "Maybe alternate between houses and hotels."

# game/script.rpy:6245
translate english ruta_normal_48_8d6b3a05:

    # J "Pero no te puedo prometer lujos."
    J "But I can't promise you luxury."

# game/script.rpy:6247
translate english ruta_normal_48_cca6d967:

    # pov "Entiendo completamente."
    pov "I understand completely."

# game/script.rpy:6250
translate english ruta_normal_48_8f1697b2:

    # "Jeff sonríe satisfecho con tu respuesta, levantándose del sofá."
    "Jeff smiled, satisfied with your answer, standing up from the sofa."

# game/script.rpy:6252
translate english ruta_normal_48_20dfd0e2:

    # J "¿Qué te parece desayunar?"
    J "What do you say about breakfast?"

# game/script.rpy:6253
translate english ruta_normal_48_6a4f327d:

    # pov "Seguro, ¿Pero qué?"
    pov "Sure, but what?"

# game/script.rpy:6255
translate english ruta_normal_48_f7deeb09:

    # J "Conseguí algo de avena y fruta para ti."
    J "I got you some oats and fruit."

# game/script.rpy:6257
translate english ruta_normal_48_9ca74f67:

    # J "Conseguí unos huevos. Ya cocí algunos."
    J "I got some eggs. I cooked some already."

# game/script.rpy:6258
translate english ruta_normal_48_7a29add9:

    # pov "Ah, gracias. ¿Vas a comer conmigo?"
    pov "Oh, thanks. Are you going to eat with me?"

# game/script.rpy:6260
translate english ruta_normal_48_c7de1e5a:

    # "Jeff ríe entre dientes, rodeando tus hombros con su brazo y te guió a la cocina."
    "Jeff chuckled, putting his arm around your shoulders and leading you to the kitchen."

# game/script.rpy:6264
translate english ruta_normal_48_8fbcdb35:

    # J "Has alterado por completo mi horario, por lo que sí, me uniré a ti."
    J "You've completely messed up my schedule, so yes, I'll join you."

# game/script.rpy:6265
translate english ruta_normal_48_b8ba81dd:

    # "Ustedes llegan a la cocina, y él se dirige al minirefri."
    "You arrived in the kitchen, and he went to the mini-fridge."

# game/script.rpy:6266
translate english ruta_normal_48_b388df6b:

    # "Él se agacha, en consecuencia, su camiseta se levanta ligeramente, dejando ver la piel de su espalda baja."
    "He bent down; consequently, his shirt lifted slightly, revealing the skin of his lower back."

# game/script.rpy:6267
translate english ruta_normal_48_b4cc560b:

    # "A diferencia del resto de su piel pálida, está libre de cicatrices, o por lo que puedes ver."
    "Unlike the rest of his pale skin, it was free of scars, or so you could see."

# game/script.rpy:6268
translate english ruta_normal_48_abaab087:

    # "Alzas tu mano y tiras del borde de la camiseta, tratando de regresarla a su lugar."
    "You raised your hand and pulled at the hem of his shirt, trying to put it back in place."

# game/script.rpy:6270
translate english ruta_normal_48_f300f6a6:

    # "El cuerpo de Jeff se tensa, y se levanta lentamente."
    "Jeff's body tensed, and he slowly straightened up."

# game/script.rpy:6271
translate english ruta_normal_48_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6272
translate english ruta_normal_48_e7bee6f0:

    # pov "¿Qué?"
    pov "What?"

# game/script.rpy:6273
translate english ruta_normal_48_ad8d83d6:

    # "Jeff está con las manos vacías, y te mira expectante."
    "Jeff was empty-handed, and looked at you expectantly."

# game/script.rpy:6275
translate english ruta_normal_48_9d0df218:

    # J "… ¿Tienes hambre de otra cosa, [povname]?"
    J "... Are you hungry for something else, [povname]?"

# game/script.rpy:6276
translate english ruta_normal_48_b274b83f:

    # "Te alarmas en tu lugar."
    "You were alarmed in your spot."

# game/script.rpy:6277
translate english ruta_normal_48_ac3520ad:

    # pov "¡Estaba arreglando tu ropa!"
    pov "I was fixing your clothes!"

# game/script.rpy:6279
translate english ruta_normal_48_f1eec89d:

    # "Jeff te mira en silencio, para después desviar la mirada a un lado."
    "Jeff looked at you in silence, then looked away."

# game/script.rpy:6280
translate english ruta_normal_48_0347e6d3:

    # "Es tu idea… ¿O está decepcionado?"
    "Is that your idea... Or is he disappointed?"

# game/script.rpy:6284
translate english ruta_normal_48_9b0f8d89:

    # pov "¿En serio?"
    pov "Seriously?"

# game/script.rpy:6285
translate english ruta_normal_48_29bc5504:

    # pov "¿Estás tan ansioso de contacto físico?"
    pov "Are you that eager for physical contact?"

# game/script.rpy:6287
translate english ruta_normal_48_ea07f538:

    # "Jeff se remueve en su lugar, con incomodidad."
    "Jeff shifted uncomfortably in his spot."

# game/script.rpy:6292
translate english ruta_normal_48_78cb5281:

    # pov "Vaya, no me lo esperaba."
    pov "Wow, I didn't expect that."

# game/script.rpy:6293
translate english ruta_normal_48_213b2681:

    # pov "¿Tanto quieres que te toque?"
    pov "Do you want me to touch you that much?"

# game/script.rpy:6295
translate english ruta_normal_48_666e01f3:

    # "Jeff se remueve en su lugar, con timidez."
    "Jeff shifted uncomfortably in his spot, shyly."

# game/script.rpy:6300
translate english ruta_normal_49_065d72e0:

    # "Niegas levemente con la cabeza, acercándote a él."
    "You shook your head slightly, approaching him."

# game/script.rpy:6301
translate english ruta_normal_49_eaf43915:

    # "Jeff se apoya en el borde de la encimera, mirándote con atención, esperando algo."
    "Jeff leaned on the edge of the counter, watching you intently, waiting for something."

# game/script.rpy:6303
translate english ruta_normal_49_e1e03dd7:

    # "Apoyas ambas manos a ambos lados del cuerpo de él, mirándolo desde tu lugar con una sonrisa ladina."
    "You placed both hands on either side of his body, looking at him from your spot with a sly smile."

# game/script.rpy:6304
translate english ruta_normal_49_4b267e6d:

    # pov "¿Estás siendo tímido?"
    pov "Are you being shy?"

# game/script.rpy:6306
translate english ruta_normal_49_14360a18:

    # J "…"
    J ".."

# game/script.rpy:6307
translate english ruta_normal_49_8b988325:

    # J "No, sólo quiero recibir lo que me des."
    J "No, I just want to receive what you give me."

# game/script.rpy:6312
translate english ruta_normal_49_c7310925:

    # "Tu sonrisa se suaviza, acercándote a él, la distancia entre ustedes es demasiado pequeña como para mantenerla así."
    "Your smile softened as you approached him; the distance between you was too small to maintain."

# game/script.rpy:6313
translate english ruta_normal_49_812b8061:

    # "Él te mira por unos segundos, para después inclinarse sobre ti."
    "He looked at you for a few seconds, then leaned towards you."

# game/script.rpy:6315
translate english ruta_normal_49_4176c709:

    # "Recibes el beso con calma, habiéndolo esperado."
    "You received the kiss calmly, having expected it."

# game/script.rpy:6316
translate english ruta_normal_49_ed433225:

    # "Los labios de Jeff se sienten un poco más suaves contra los tuyos, pero siguen siendo fríos."
    "Jeff's lips felt a little softer against yours, but they were still cold."

# game/script.rpy:6317
translate english ruta_normal_49_63516907:

    # "La mano de él sube y sujeta tu mandíbula con delicadeza, rozando la yema de sus dedos con la piel de tu mejilla."
    "His hand rose and gently held your jaw, his fingertips grazing the skin of your cheek."

# game/script.rpy:6319
translate english ruta_normal_49_97a7e07d:

    # "Sientes que la respiración se agita levemente, y él te muerde ligeramente el labio inferior, profundizando el beso."
    "You felt your breathing quicken slightly, and he gently bit your lower lip, deepening the kiss."

# game/script.rpy:6330
translate english ruta_normal_49_52a0e209:

    # "Deslizas lentamente tu mano bajo la camiseta de Jeff, sintiendo la tibia piel de él bajo tus dedos."
    "You slowly slid your hand under Jeff's shirt, feeling his warm skin under your fingers."

# game/script.rpy:6331
translate english ruta_normal_49_cf5ac177:

    # "Acaricias suavemente, sintiendo leves relieves."
    "You caressed softly, feeling faint ridges."

# game/script.rpy:6332
translate english ruta_normal_49_b6176fae:

    # J "!!"
    J "!!"

# game/script.rpy:6333
translate english ruta_normal_49_1b777edf:

    # J "[povname]..."
    J "[povname]..."

# game/script.rpy:6334
translate english ruta_normal_49_9714902f:

    # "Él se separa unos centímetros de ti, mirándote con necesidad."
    "He pulled away a few inches from you, looking at you with need."

# game/script.rpy:6335
translate english ruta_normal_49_a1f10a9d:

    # pov "Sólo estoy tanteando el terreno."
    pov "I'm just testing the waters."

# game/script.rpy:6336
translate english ruta_normal_49_96909498:

    # "Acompañado de tus palabras, deslizas tu mano hacia la espalda de él, apretando suavemente la piel, acariciando el hundimiento de su zona lumbar."
    "Accompanied by your words, you slid your hand towards his back, gently squeezing his skin, caressing the hollow of his lower back."

# game/script.rpy:6337
translate english ruta_normal_49_eef83ad6:

    # J "Ngh… "
    J "Ngh..."

# game/script.rpy:6338
translate english ruta_normal_49_021795b6:

    # pov "¿Te gustan los simples toques?"
    pov "You like simple touches?"

# game/script.rpy:6339
translate english ruta_normal_49_08b4fe06:

    # pov "No puedo imaginar cómo te pondrías haciendo otras cosas."
    pov "I can't imagine what you'd be like doing other things."

# game/script.rpy:6340
translate english ruta_normal_49_d3c27360:

    # J "Ah~... [povname]..."
    J "Ah~... [povname]..."

# game/script.rpy:6341
translate english ruta_normal_49_e6619cfd:

    # "Su voz, generalmente rasposa, se suaviza ante tu toque."
    "His voice, generally raspy, softened at your touch."

# game/script.rpy:6352
translate english beso_2_da12b541:

    # "Considerando que con eso tuvo suficiente, recoges tus manos y retrocedes un par de pasos."
    "Considering that was enough for him, you took your hands away and stepped back a couple of paces."

# game/script.rpy:6353
translate english beso_2_ac9751e6:

    # "Miras la condición en la que él está, y te sorprende ver que está ligeramente agitado."
    "You looked at his condition, and were surprised to see he was slightly agitated."

# game/script.rpy:6354
translate english beso_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6355
translate english beso_2_9a7aefd9:

    # pov "¿Tienes experiencia en esto, Jeff?"
    pov "Do you have experience with this, Jeff?"

# game/script.rpy:6357
translate english beso_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6359
translate english beso_2_69a9639f:

    # J "Muy poca."
    J "Not much"

# game/script.rpy:6360
translate english beso_2_dc602a60:

    # pov "Ya veo…"
    pov "I see..."

# game/script.rpy:6362
translate english beso_2_083081af:

    # J "¿Qué hay de ti?"
    J "What about you?"

# game/script.rpy:6366
translate english beso_2_0c2ade1b:

    # pov "Claro, si tengo."
    pov "Of course, I do."

# game/script.rpy:6369
translate english beso_2_a50e68bd:

    # pov "Nop, pero la imaginación me ayuda."
    pov "Nope, but imagination helps."

# game/script.rpy:6374
translate english character_11_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6375
translate english character_11_58ac9dc1:

    # "Jeff suspira, enderezándose."
    "Jeff sighed, straightening up."

# game/script.rpy:6377
translate english character_11_f4af70bd:

    # "Se acerca a ti y besa suavemente tu frente."
    "He approached you and gently kissed your forehead."

# game/script.rpy:6378
translate english character_11_15ea199c:

    # J "Desayunemos de una vez."
    J "Let's have breakfast already."

# game/script.rpy:6380
translate english character_11_3c4187ad:

    # "Tomas asiento en el comedor, esperando a que él vuelva."
    "You sat at the table, waiting for him to return."

# game/script.rpy:6381
translate english character_11_b0b87a03:

    # "En realidad, ves que te estás acostumbrando de a poco a la compañía de Jeff."
    "In reality, you found yourself slowly getting used to Jeff's company."

# game/script.rpy:6382
translate english character_11_70388fe1:

    # "Cuando él estaba de buen humor, te trataba bien, pero… Cuando se enojaba, realmente sacaba lo peor."
    "When he was in a good mood, he treated you well, but... when he got angry, he really brought out the worst."

# game/script.rpy:6383
translate english character_11_3f9a5aa5:

    # "Eso… Era una razón para preocuparte."
    "That... was a reason to worry."

# game/script.rpy:6386
translate english character_11_f4cdc579:

    # "Jeff se acerca y deja frente a ti un plato con tu desayuno."
    "Jeff approached and placed a plate with your breakfast in front of you."

# game/script.rpy:6387
translate english character_11_45294cf0:

    # "La mesa sigue estando algo sucia, pero los platos y utensilios estaban limpios."
    "The table was still a bit dirty, but the plates and utensils were clean."

# game/script.rpy:6388
translate english character_11_8a3b5b7e:

    # "Miras cómo él comía en silencio."
    "You watched him eat in silence."

# game/script.rpy:6389
translate english character_11_c02cbca0:

    # "… Podías ver como un poco de comida se asomaba desde la herida de su boca."
    "... You could see a bit of food poking out from the wound in his mouth."

# game/script.rpy:6392
translate english character_11_826d9368:

    # pov "Tienes algo de comida ahí."
    pov "You have some food there."

# game/script.rpy:6394
translate english character_11_014710ac:

    # "Llamas su atención y apuntas a tu propia boca, para darle la señal."
    "You caught his attention and pointed to your own mouth, to signal it to him."

# game/script.rpy:6395
translate english character_11_3487469e:

    # "Jeff se lleva una mano a la cara, y nota el pequeño desastre que tiene."
    "Jeff brought a hand to his face, and noticed the small mess he had."

# game/script.rpy:6397
translate english character_11_ac7937bf:

    # J "Oh, esto pasa."
    J "Oh, this happens."

# game/script.rpy:6398
translate english character_11_ce617998:

    # "…"
    "..."

# game/script.rpy:6399
translate english character_11_58613dc4:

    # "Si, esto no estaba funcionando del todo para ti."
    "Yeah, this wasn't working out perfectly for you."

# game/script.rpy:6400
translate english character_11_38305b84:

    # "No sólo Jeff no era digno de confianza, era violento, volátil e impredecible."
    "Not only was Jeff untrustworthy, he was violent, volatile, and unpredictable."

# game/script.rpy:6401
translate english character_11_0b8b4140:

    # "Si en sólo 7 días se enamoró de ti, ¿Cómo sabes si en otros 7 días te va a odiar?"
    "If in just 7 days he fell in love with you, how did you know if in another 7 days he would hate you?"

# game/script.rpy:6402
translate english character_11_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6403
translate english character_11_1f3c2c08:

    # pov "Jeff, tengo algo que preguntarte."
    pov "Jeff, I have something to ask you."

# game/script.rpy:6404
translate english character_11_02dcf7c8:

    # J "¿Qué es?"
    J "What is it?"

# game/script.rpy:6405
translate english character_11_fb6684ed:

    # pov "… ¿Te sigue importando si te temo o no?"
    pov "... Does it still matter to you if I fear you or not?"

# game/script.rpy:6406
translate english character_11_9a021dd9:

    # "Antes parecía muy fijado en que le temas, pero ahora… No sabes lo que realmente quiere."
    "Before, he seemed very fixated on you fearing him, but now... You didn't know what he really wanted."

# game/script.rpy:6408
translate english character_11_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6409
translate english character_11_38787ceb:

    # J "¿Me temes?"
    J "Do you fear me?"

# game/script.rpy:6419
translate english miedo_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6421
translate english miedo_51815759:

    # J "Heh…"
    J "Heh…"

# game/script.rpy:6423
translate english miedo_597fec25:

    # J "¡Hahaha!"
    J "Hahaha!"

# game/script.rpy:6424
translate english miedo_d5a915c3:

    # "Él ríe estruendosamente, sorprendiéndote."
    "He laughed thunderously, startling you."

# game/script.rpy:6425
translate english miedo_c0c6bc5b:

    # "No sabes si preocuparte por esa reacción o no."
    "You didn't know whether to worry about that reaction or not."

# game/script.rpy:6427
translate english miedo_a3bcc0b5:

    # J "… Hah."
    J "… Hah."

# game/script.rpy:6428
translate english miedo_4834489d:

    # J "No importaba cuál fuera tu respuesta, no cambia lo que siento por ti."
    J "No matter what your answer was, it doesn't change what I feel for you."

# game/script.rpy:6429
translate english miedo_da397893:

    # J "Tampoco cambiaría nuestra situación."
    J "It wouldn't change our situation either."

# game/script.rpy:6431
translate english miedo_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6432
translate english miedo_36de94a2:

    # J "Lo que sí me preocuparía, sería que te aburrieras de mí."
    J "What would worry me, would be if you got bored of me."

# game/script.rpy:6434
translate english miedo_66082656:

    # J "Tú… ¿Me dirías si empiezas a aburrirte de mí?"
    J "You... Would you tell me if you start getting bored of me?"

# game/script.rpy:6438
translate english miedo_81156c95:

    # pov "Pfft, eso no va a pasar."
    pov "Pfft, that's not going to happen."

# game/script.rpy:6440
translate english miedo_6c2811b8:

    # "Jeff suspira, resignado."
    "Jeff sighed, resigned."

# game/script.rpy:6445
translate english miedo_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:6446
translate english miedo_0d72e8f7:

    # "Sabías por experiencia que él prefería la honestidad."
    "You knew from experience that he preferred honesty."

# game/script.rpy:6448
translate english miedo_171e15fd:

    # "Jeff sonríe satisfecho."
    "Jeff smiled, satisfied."

# game/script.rpy:6453
translate english ruta_normal_50_559914fb:

    # "Ustedes dejan el tema, y terminan su desayuno."
    "You both dropped the subject, and finished your breakfast."

# game/script.rpy:6455
translate english ruta_normal_50_164fd116:

    # "El resto del día es tranquilo, incluso puedes presenciar a Jeff durmiendo. Cosa que nunca habías visto antes."
    "The rest of the day was quiet; you even saw Jeff sleeping. Something you had never seen before."

# game/script.rpy:6456
translate english ruta_normal_50_c2c2c867:

    # "La realidad parecía estar estableciéndose, y llegó el atardecer."
    "Reality seemed to be settling in, and evening arrived."

# game/script.rpy:6457
translate english ruta_normal_50_1b0eeffe:

    # "Jeff había mencionado que tenía algunos billetes y que podría comprar una cena para llevar de un restaurante a unas calles."
    "Jeff had mentioned he had some cash and could buy dinner to go from a takeout a few blocks away."

# game/script.rpy:6461
translate english ruta_normal_50_0cdcae2d:

    # "Pero de repente, se escuchan sirenas de policía."
    "But suddenly, police sirens were heard."

# game/script.rpy:6462
translate english ruta_normal_50_8f0addf7:

    # "Cada vez se escuchan más fuerte, y parecen ser de varios autos."
    "They grew louder, and seemed to be from several cars."

# game/script.rpy:6463
translate english ruta_normal_50_808896c7:

    # pov "… ¿Jeff?"
    pov "… ¿Jeff?"

# game/script.rpy:6467
translate english ruta_normal_50_3820d195:

    # "Él se pone de pie y va a la sala, asomándose ligeramente por la ventana."
    "He stood up and went to the living room, peering slightly out the window."

# game/script.rpy:6468
translate english ruta_normal_50_1ee3904d:

    # "Las luces se asoman por las ventanas, y aunque esperas que pasen de largo, se quedan ahí."
    "The lights peeked through the windows, and although you expected them to pass by, they stayed."

# game/script.rpy:6469
translate english ruta_normal_50_6812260e:

    # "Las sirenas se apagan, y puedes ver por la cantidad de luces que al menos hay tres patrullas."
    "The sirens went silent, and you could see by the number of lights that there were at least three patrol cars."

# game/script.rpy:6470
translate english ruta_normal_50_9e655069:

    # "Se escucha el chasquido de un megáfono y la voz de alguien resuena."
    "You heard the click of a megaphone and someone's voice echoed."

# game/script.rpy:6471
translate english ruta_normal_50_d2403323:

    # Stranger "¡Te tenemos rodeado!"
    Stranger "We have you surrounded!"

# game/script.rpy:6472
translate english ruta_normal_50_a2ba409b:

    # Stranger "¡Entrega al rehén!"
    Stranger "Surrender the hostage!"

# game/script.rpy:6474
translate english ruta_normal_50_b385212e:

    # J "¡Mierda!"
    J "Shit!"

# game/script.rpy:6478
translate english ruta_normal_50_9d23b791:

    # "Jeff se apresura a un rincón de la sala y se coloca su sudadera blanca."
    "Jeff hurried to a corner of the room and put on his white hoodie."

# game/script.rpy:6479
translate english ruta_normal_50_6823016f:

    # pov "¿Qué vas hacer?"
    pov "What are you going to do?"

# game/script.rpy:6480
translate english ruta_normal_50_e3c12478:

    # J "¿Entregarme?, ni loco."
    J "Turn myself in? No way."

# game/script.rpy:6481
translate english ruta_normal_50_9de67b00:

    # J "Ven."
    J "Come."

# game/script.rpy:6483
translate english ruta_normal_50_fd2136c4:

    # "Él toma tu mano fuertemente y tira de ti."
    "He took your hand firmly and pulled you."

# game/script.rpy:6485
translate english ruta_normal_50_f6a636ae:

    # pov "Pero estamos rodeados, no podemos salir."
    pov "But we're surrounded, we can't get out."

# game/script.rpy:6486
translate english ruta_normal_50_fe7ff9c1:

    # J "Por adelante y atrás no, pero por debajo…"
    J "Not from the front or back, but from underneath..."

# game/script.rpy:6487
translate english ruta_normal_50_9cdc0d68:

    # "Entiendes lo que él está diciendo cuando se dirige al sótano."
    "You understood what he was saying when he headed for the basement."

# game/script.rpy:6489
translate english ruta_normal_50_151de98f:

    # "Escuchas que la puerta de la entrada es azotada."
    "You heard the entrance door being slammed."

# game/script.rpy:6490
translate english ruta_normal_50_c429e2f1:

    # DS "¡[povname]!"
    DS "[povname]!"

# game/script.rpy:6494
translate english ruta_normal_50_b80169af:

    # "Reconoces esa voz, pero cuando llegas al sótano, Jeff te suelta y va a un extremo del lugar."
    "You recognized that voice, but when you reached the basement, Jeff let go of you and went to one end of the room."

# game/script.rpy:6495
translate english ruta_normal_50_edb10030:

    # pov "¿A dónde vamos ahora?"
    pov "Where are we going now?"

# game/script.rpy:6496
translate english ruta_normal_50_74c1dae5:

    # "Jeff forcejea con algo en el suelo, y ves que levanta un pedazo de cemento que lleva a un lugar abajo."
    "Jeff struggled with something on the floor, and you saw him lift a piece of concrete that led to a place below."

# game/script.rpy:6497
translate english ruta_normal_50_4987d436:

    # "Vaya, que conveniente."
    "Well, that's convenient."

# game/script.rpy:6498
translate english ruta_normal_50_8dea5eef:

    # J "Por las alcantarillas."
    J "Through the sewers."

# game/script.rpy:6499
translate english ruta_normal_50_dda4fef6:

    # pov "Ew…"
    pov "Ew..."

# game/script.rpy:6501
translate english ruta_normal_50_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:6502
translate english ruta_normal_50_19da9268:

    # pov "¡Ok, ok!"
    pov "Okay, okay!"

# game/script.rpy:6503
translate english ruta_normal_50_57565f6f:

    # "Obedeces y bajas por la abertura."
    "You obeyed and climbed down the opening."

# game/script.rpy:6505
translate english ruta_normal_50_1e1c6c77:

    # "Caes en el interior de una alcantarilla, el agua bajo tus pies chapotea por tus movimientos."
    "You fell into the sewer, the water splashing under your feet from your movements."

# game/script.rpy:6509
translate english ruta_normal_50_d13e9e0b:

    # "Jeff salta después de ti y tira de tu brazo."
    "Jeff jumped down after you and pulled your arm."

# game/script.rpy:6510
translate english ruta_normal_50_f0654ea0:

    # J "¡Vamos!, ¡Nos siguen de cerca!"
    J "Come on! They're close behind us!"

# game/script.rpy:6512
translate english ruta_normal_50_5a6d23ef:

    # "Ustedes corren, escuchando como varias personas los siguen por detrás."
    "You both ran, hearing several people following you."

# game/script.rpy:6513
translate english ruta_normal_50_00bf2340:

    # "Entre la prisa, logras avistar el final del túnel."
    "In the rush, you managed to glimpse the end of the tunnel."

# game/script.rpy:6514
translate english ruta_normal_50_fde27518:

    # pov "¿A donde vamos después?"
    pov "Where do we go next?"

# game/script.rpy:6515
translate english ruta_normal_50_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6516
translate english ruta_normal_50_f9ed2707:

    # pov "¿Jeff?"
    pov "Jeff?"

# game/script.rpy:6517
translate english ruta_normal_50_f0a6db74:

    # J "¡Cállate!, ¡Estoy pensando!"
    J "Shut up! I'm thinking!"

# game/script.rpy:6522
translate english ruta_normal_50_866dabc8:

    # "El agarre en tu brazo se vuelve más fuerte, lo que te lastima."
    "His grip on your arm tightened, hurting you."

# game/script.rpy:6523
translate english ruta_normal_50_c39df7cb:

    # "Ustedes salen a un arroyo en medio del bosque, y Jeff apresura el paso."
    "You both emerged into a stream in the middle of the forest, and Jeff quickened his pace."

# game/script.rpy:6524
translate english ruta_normal_50_c42fe6a0:

    # pov "¿No nos vamos a perder?"
    pov "Aren't we going to get lost?"

# game/script.rpy:6525
translate english ruta_normal_50_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6526
translate english ruta_normal_50_3c926b3d:

    # "Jeff permanecía en silencio, respirando agitadamente."
    "Jeff remained silent, breathing heavily."

# game/script.rpy:6527
translate english ruta_normal_50_a91defcc:

    # "Parecía… Realmente un criminal buscado."
    "He seemed... truly a wanted criminal."

# game/script.rpy:6528
translate english ruta_normal_50_9b2921a5:

    # "Te has metido en un problema muy grande."
    "You had gotten into a lot of trouble."

# game/script.rpy:6533
translate english ruta_normal_50_711f6bd1:

    # "Ustedes se adentran en el bosque, pero tras encontrarse luces provenientes de linternas, toman un desvío."
    "You both ventured into the forest, but after encountering lights from flashlights, you took a detour."

# game/script.rpy:6534
translate english ruta_normal_50_a3956cb6:

    # "Sucede lo mismo por el otro camino, ustedes están arrinconados."
    "The same happened on the other path; you were cornered."

# game/script.rpy:6535
translate english ruta_normal_50_d9afd364:

    # "No tienen de otra que seguir recto, pero adelante sólo hay…"
    "You had no choice but to go straight, but ahead there was only..."

# game/script.rpy:6539
translate english ruta_normal_50_b4405fe3:

    # "Ustedes llegan al borde del barranco, y Jeff finalmente te suelta."
    "You both reached the edge of the cliff, and Jeff finally let you go."

# game/script.rpy:6540
translate english ruta_normal_50_75e22c72:

    # "A lo lejos, a la entrada del bosque, se reúnen las luces y avanzan hacia ustedes a gran velocidad."
    "In the distance, at the forest entrance, the lights gathered and advanced towards you at high speed."

# game/script.rpy:6541
translate english ruta_normal_50_f76c8657:

    # pov "Jeff…"
    pov "Jeff…"

# game/script.rpy:6543
translate english ruta_normal_50_26b4ccdd:

    # J "Mierda, mierda, ¡Mierda!"
    J "Shit, shit, shit!"

# game/script.rpy:6544
translate english ruta_normal_50_cd5fa684:

    # "Las personas se acercan más."
    "More people approached."

# game/script.rpy:6545
translate english ruta_normal_50_520c5b41:

    # "La multitud es una sombra, pero puedes decir que son muchos."
    "The crowd was a shadow, but you could tell there were many."

# game/script.rpy:6546
translate english ruta_normal_50_80388382:

    # "Ustedes no tienen salida."
    "You had no way out."

# game/script.rpy:6582
translate english final_muerte_f76c8657:

    # pov "Jeff…"
    pov "Jeff…"

# game/script.rpy:6584
translate english final_muerte_c5d8df9b:

    # "Suavemente, alcanzas la mano de él, y entrelazas sus dedos."
    "Gently, you reached for his hand, and intertwined your fingers with his."

# game/script.rpy:6586
translate english final_muerte_2cc11ef3:

    # "Jeff te mira desesperado, pero al encontrarse con tus ojos, se tranquiliza."
    "Jeff looked at you desperately, but upon meeting your eyes, he calmed down."

# game/script.rpy:6587
translate english final_muerte_66f9e556:

    # J "[povname]... Te amo."
    J "[povname]... I love you."

# game/script.rpy:6588
translate english final_muerte_d6401e97:

    # "Tu le sonríes afectuosamente."
    "You smiled affectionately at him."

# game/script.rpy:6589
translate english final_muerte_d82da54b:

    # "El sonido de los pasos de las personas se acercan, acompañados por voces desesperadas, gritando que se detengan."
    "The sound of people's footsteps approached, accompanied by desperate voices, shouting for them to stop."

# game/script.rpy:6590
translate english final_muerte_f27876a2:

    # "Ustedes se enfrentan al acantilado, sintiendo la brisa del mar golpearlos, como si les estuviera advirtiendo de lo que los esperaba."
    "You faced the cliff, feeling the sea breeze hit you, as if warning you of what awaited."

# game/script.rpy:6591
translate english final_muerte_50f2067d:

    # "Apretaste la mano de él, con decisión."
    "You squeezed his hand, decisively."

# game/script.rpy:6592
translate english final_muerte_d619f187:

    # "Ustedes dan un paso al frente, y el suelo desaparece de sus pies."
    "You both took a step forward, and the ground disappeared beneath your feet."

# game/script.rpy:6594
translate english final_muerte_283b6c32:

    # "Lo último que sientes, es el viento chocando con tu rostro, y el agarre en tu mano que nunca se soltó."
    "The last thing you felt was the wind hitting your face, and his hand's grip that never let go."

# game/script.rpy:6597
translate english final_muerte_89ce31a0:

    # "{b}Final VII: Juntos Para Siempre{/b}"
    "{b}Ending VII: Together Forever{/b}"

# game/script.rpy:6603
translate english final_neutral_9bacc2b9:

    # pov "Jeff… Tengo miedo."
    pov "Jeff... I'm scared."

# game/script.rpy:6606
translate english final_neutral_de633d1c:

    # "Jeff sujeta tus mejillas entre sus manos, y te mira sin saber qué hacer."
    "Jeff held your cheeks between his hands, and looked at you not knowing what to do."

# game/script.rpy:6608
translate english final_neutral_7058a783:

    # "Sintiendo que los demás se acercan, los hombros de él caen con resignación, y él te sonríe con tristeza."
    "Feeling the others approaching, his shoulders slumped in resignation, and he smiled sadly at you."

# game/script.rpy:6609
translate english final_neutral_4a1d5273:

    # J "Hah, logré que temieras por tu vida."
    J "Hah, I made you fear for your life."

# game/script.rpy:6611
#translate english final_neutral_f6a1ae21:

    # "Tienes las palabras en la boca, escuchas el sonido de un disparo demasiado cerca como para alarmarte.."
    #"The words were in your mouth, you heard the sound of a gunshot too close to alarm you."

# game/script.rpy:6613
translate english final_neutral_c1795435:

    # "El pecho de Jeff se tiñe de rojo, y una fuerza lo empuja hacia el acantilado."
    "Jeff's chest turned red, and a force pushed him towards the cliff."

# game/script.rpy:6615
translate english final_neutral_2560efd9:

    # pov "¡NO!"
    pov "NO!"

# game/script.rpy:6617
translate english final_neutral_c1dc0d46:

    # "Tratas de alcanzar la mano de él, y seguramente hubieras caído también si la alcanzabas, pero un agarre en tu cintura te lo impide."
    "You tried to reach for his hand, and surely you would have fallen too if you had reached it, but a grip on your waist prevented you."

# game/script.rpy:6618
translate english final_neutral_2a723026:

    # DS "¡[povname]!, ¡Ya acabó!"
    DS "[povname]! It's over!"

# game/script.rpy:6619
translate english final_neutral_da8efc1d:

    # "Tratas de liberarte, sintiendo que las lágrimas corren por tus mejillas."
    "You tried to break free, feeling tears run down your cheeks."

# game/script.rpy:6620
translate english final_neutral_a1206f2f:

    # pov "¡Jeff, Jeff!"
    pov "Jeff, Jeff!"

# game/script.rpy:6621
translate english final_neutral_2f132b69:

    # "Llamas su nombre, pues aún recuerdas a unos instantes atrás, estaba a tu lado."
    "You called his name, because just moments ago, he was by your side."

# game/script.rpy:6623
translate english final_neutral_3bc79863:

    # "Sean te obliga a caer sobre tus rodillas, y te rompes por completo."
    "Sean forced you to your knees, and you completely broke down."

# game/script.rpy:6625
translate english final_neutral_eb16df10:

    # "Ella te envuelve en tus brazos, pero no se siente del todo bien."
    "She wrapped you in her arms, but it didn't feel quite right."

# game/script.rpy:6626
translate english final_neutral_5512b450:

    # DS "Ssh, ya acabó…"
    DS "Ssh, it's over..."

# game/script.rpy:6627
translate english final_neutral_df0b26a5:

    # "Su voz es tranquilizante, pero no te consuela por completo."
    "Her voice was soothing, but it didn't completely comfort you."

# game/script.rpy:6631
translate english final_neutral_ce617998:

    # "…"
    "..."

# game/script.rpy:6634
translate english final_neutral_93803e97:

    # pov "Así que eso pasó."
    pov "So that's what happened."

# game/script.rpy:6635
translate english final_neutral_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6636
translate english final_neutral_7f1fee85:

    # T "Por como lo veo yo, [povname], lograste lo que muchos no han podido."
    T "From my perspective, [povname], you achieved what many could not."

# game/script.rpy:6637
translate english final_neutral_02f2d8bd:

    # T "Pudiste sobrevivir."
    T "You survived."

# game/script.rpy:6638
translate english final_neutral_7b41b66e:

    # pov "… ¿Entonces porque siento que algo está mal?"
    pov "... So why do I feel like something's wrong?"

# game/script.rpy:6639
translate english final_neutral_0caf702c:

    # T "Construiste una relación socio-afectiva con Jeff. Él se volvió el monstruo y tu salvador a la vez, es difícil desligarse de alguien que significó tanto para ti."
    T "You built a socio-affective relationship with Jeff. He became both the monster and your savior at the same time, it's hard to detach from someone who meant so much to you."

# game/script.rpy:6640
translate english final_neutral_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6641
translate english final_neutral_8310e204:

    # T "Con el tiempo, podrás llenar el vacío que él dejó. Es parte del proceso de sanar."
    T "With time, you'll be able to fill the void he left. It's part of the healing process."

# game/script.rpy:6642
translate english final_neutral_a654e86b:

    # "Te mantienes en silencio, tratando de encontrar un lugar en tu mente que acepte lo que el terapeuta está diciendo."
    "You remained silent, trying to find a place in your mind that accepted what the therapist was saying."

# game/script.rpy:6643
translate english final_neutral_779533f1:

    # T "Nuestro tiempo se acabó, ¿Alguien viene por ti?"
    T "Our time is up, is someone coming for you?"

# game/script.rpy:6645
translate english final_neutral_783cbeca:

    # pov "Sí, Paul me está esperando afuera."
    pov "Yeah, Paul is waiting for me outside."

# game/script.rpy:6646
translate english final_neutral_b48f564f:

    # "Resulta que él pudo ser llevado al hospital a tiempo."
    "It turns out he was taken to the hospital in time."

# game/script.rpy:6647
translate english final_neutral_926f09dc:

    # "Fue la primera persona a la que viste cuando te recuperaron."
    "He was the first person you saw when you recovered."

# game/script.rpy:6649
translate english final_neutral_3118e67a:

    # pov "Cindy no tarda nada en llegar."
    pov "Cindy won’t take long."

# game/script.rpy:6650
translate english final_neutral_38a6eb07:

    # "Resulta que ella pudo ser llevada al hospital a tiempo."
    "It turns out she was taken to the hospital in time."

# game/script.rpy:6651
translate english final_neutral_926f09dc_1:

    # "Fue la primera persona a la que viste cuando te recuperaron."
    "She was the first person you saw when you recovered."

# game/script.rpy:6652
translate english final_neutral_066856a9:

    # T "Ah, veo que ustedes siguen en contacto."
    T "Oh, I see you two are still in contact."

# game/script.rpy:6656
translate english final_neutral_47a414b1:

    # "No te costó mucho entender que era mucho mejor salir con alguien que estaba bien de la cabeza."
    "It didn't take you long to understand that it was much better to go out with someone who was sane."

# game/script.rpy:6660
translate english final_neutral_230850f3:

    # "Él fue el que te convenció de ir a terapia, por más que te negaras."
    "He was the one who convinced you to go to therapy, no matter how much you refused."

# game/script.rpy:6662
translate english final_neutral_d3b0968c:

    # "Gracias a su compañía, lograste muchas cosas, incluso volver al trabajo."
    "Thanks to her company, you achieved many things, including going back to work."

# game/script.rpy:6667
translate english final_n_5b9b6f94:

    # T "Me alegro por ti."
    T "I'm glad for you."

# game/script.rpy:6668
translate english final_n_6ab328c7:

    # "Asientes por la simple cortesía."
    "You nodded out of simple courtesy."

# game/script.rpy:6670
translate english final_n_0b1edc78:

    # "Sales de la consulta, y respiras profundamente, sintiendo que un gran peso se liberaba de tus hombros."
    "You left the session, and breathed deeply, feeling a great weight lift from your shoulders."

# game/script.rpy:6674
translate english final_n_1e79f087:

    # DR "¿Cómo te fue?"
    DR "How was it?"

# game/script.rpy:6675
translate english final_n_6bc4f3ca:

    # pov "Bien, hablé mucho."
    pov "Good, I talked a lot."

# game/script.rpy:6676
translate english final_n_7e6ae12d:

    # "Salazar sonríe cálidamente."
    "Salazar smiled warmly."

# game/script.rpy:6677
translate english final_n_bbbcb1fd:

    # "Su brazo ya había sanado."
    "His arm had healed."

# game/script.rpy:6681
translate english final_n_d10ac37b:

    # C "¿Todo bien?"
    C "All good?"

# game/script.rpy:6682
translate english final_n_05e081b1:

    # "Sientes el toque en tu hombro, y asientes con una pequeña sonrisa."
    "You felt her touch on your shoulder, and nodded with a small smile."

# game/script.rpy:6683
translate english final_n_caf0ea3f:

    # "Lejos de ocultar la cicatriz que le ocasionó el incidente, lo portaba con orgullo."
    "Far from hiding the scar the incident caused her, she wore it with pride."

# game/script.rpy:6686
translate english final_n_60310fbe:

    # "Ustedes caminan por la calle, bajo la luz del sol y con un silencio cómodo."
    "You walked down the street, under the sunlight and in comfortable silence."

# game/script.rpy:6687
translate english final_n_8f0403e6:

    # "No sabes lo que te depara de ahora en adelante."
    "You didn't know what lay ahead for you."

# game/script.rpy:6688
translate english final_n_97ace942:

    # "Nunca olvidarás lo que sucedió esa semana."
    "You would never forget what happened that week."

# game/script.rpy:6689
translate english final_n_6684d3d9:

    # "Nunca olvidarás a Jeff, lo que te hizo sentir y cuestionar."
    "You would never forget Jeff, what he made you feel and question."

# game/script.rpy:6690
translate english final_n_de30a3d3:

    # "Pero sabes con seguridad, que todo acabó. Tu vida volvió a la normalidad."
    "But you knew for sure that it was all over. Your life had returned to normal."

# game/script.rpy:6691
translate english final_n_430500b4:

    # "{b}Final Normal: Vivirá En Tu Memoria{/b}"
    "{b}Normal Ending: He Will Live In Your Memory{/b}"

# game/script.rpy:6696
translate english final_verdadero_4e6cf994:

    # pov "Jeff… Ven aquí."
    pov "Jeff... Come here."

# game/script.rpy:6700
translate english final_verdadero_f9ab2645:

    # "Jeff te mira con duda, pero obedece."
    "Jeff looked at you with doubt, but obeyed."

# game/script.rpy:6701
translate english final_verdadero_576f3b86:

    # "Sujetas su cabeza entre tus manos, y lo atraes hacia ti."
    "You held his head between your hands, and pulled him towards you."

# game/script.rpy:6702
translate english final_verdadero_0b88d550:

    # "Rozas tus labios contra la oreja de él, y susurras algo en voz baja."
    "You grazed your lips against his ear, and whispered something softly."

# game/script.rpy:6704
translate english final_verdadero_2131ede1:

    # "Él se sobresalta, y cuando se endereza, te mira con desconcierto."
    "He startled, and when he straightened up, he looked at you bewildered."

# game/script.rpy:6705
translate english final_verdadero_7b726b3b:

    # "Tú le sonríes."
    "You smiled at him."

# game/script.rpy:6706
translate english final_verdadero_98779d41:

    # DS "¡Quieto!"
    DS "Stay still!"

# game/script.rpy:6707
translate english final_verdadero_03bde726:

    # "Escuchas cómo los policías llegaron a ustedes, por lo que actúas con rapidez."
    "You heard the police arrive for you, so you acted quickly."

# game/script.rpy:6709
translate english final_verdadero_a242d65e:

    # "Pones tus manos sobre el pecho de Jeff, y empujas con todas tus fuerzas."
    "You put your hands on Jeff's chest, and pushed him with all your might."

# game/script.rpy:6712
translate english final_verdadero_4989045a:

    # "Jeff no puso resistencia, y mientras caía hacia el vacío, pudiste ver sus ojos desorbitados, observándote."
    "Jeff offered no resistance, and as he fell into the void, you could see his wide eyes, staring at you."

# game/script.rpy:6714
translate english final_verdadero_8f96635d:

    # "Miras abajo desde el borde del acantilado, y sientes que alguien se pone a tu lado."
    "You looked down from the edge of the cliff, and felt someone stand beside you."

# game/script.rpy:6715
translate english final_verdadero_da05cf6f:

    # "Por el rabillo del ojo, sabes que se trata de Sean."
    "Out of the corner of your eye, you knew it was Sean."

# game/script.rpy:6716
translate english final_verdadero_4e4ea233:

    # pov "Ya todo acabó."
    pov "It was all over."

# game/script.rpy:6720
translate english final_verdadero_ce617998:

    # "…"
    "..."

# game/script.rpy:6723
translate english final_verdadero_8ece5da7:

    # pov "Y eso pasó."
    pov "So, that happened."

# game/script.rpy:6724
translate english final_verdadero_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6725
translate english final_verdadero_40b141f9:

    # "El terapeuta mira el suelo pensativamente."
    "The therapist looked at the floor thoughtfully."

# game/script.rpy:6726
translate english final_verdadero_817e32f8:

    # T "Bueno, definitivamente… El mérito es tuyo."
    T "Well, definitely... The credit is yours."

# game/script.rpy:6727
translate english final_verdadero_216c93e8:

    # T "Lograste vencer el mal que te acechaba, no tienes que sentirte culpable."
    T "You managed to overcome the evil that was stalking you, you don't have to feel guilty."

# game/script.rpy:6728
translate english final_verdadero_5a298b23:

    # T "Fue en defensa propia, eras tú o él."
    T "It was self-defense, it was you or him."

# game/script.rpy:6729
translate english final_verdadero_c0662a5c:

    # pov "Claro."
    pov "Sure."

# game/script.rpy:6730
translate english final_verdadero_3de04149_1:

    # T "…"
    T "..."

# game/script.rpy:6731
translate english final_verdadero_bd335c55:

    # T "¿Cómo te sientes al respecto?"
    T "How do you feel about it?"

# game/script.rpy:6732
translate english final_verdadero_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6736
translate english final_verdadero_6c095e67:

    # pov "Bueno, definitivamente me siento diferente."
    pov "Well, I definitely feel different."

# game/script.rpy:6737
translate english final_verdadero_011b8e56:

    # pov "Maté a alguien."
    pov "I killed someone."

# game/script.rpy:6740
translate english final_verdadero_bfacd690:

    # pov "Como siempre."
    pov "As usual."

# game/script.rpy:6741
translate english final_verdadero_6a526be2:

    # "… Como si siempre hubiera algo dentro de ti que estaba mal."
    "… As if there was always something wrong inside you."

# game/script.rpy:6746
translate english final_v_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6747
translate english final_v_01c0ba06:

    # T "¿Sigues viviendo por tu cuenta?"
    T "Are you still living on your own?"

# game/script.rpy:6748
translate english final_v_9310589d:

    # pov "Sip, pero me cambié a otro departamento."
    pov "Yes, but I moved to another apartment."

# game/script.rpy:6749
translate english final_v_cda864d1:

    # T "Entonces, ¿No vives con nadie?"
    T "So, you don't live with anyone?"

# game/script.rpy:6750
translate english final_v_0348e8ee:

    # pov "No, es un departamento pequeño."
    pov "No, it's a small apartment."

# game/script.rpy:6751
translate english final_v_40ecee7e:

    # T "… De acuerdo, por lo que veo, no sientes tanto apego hacia él."
    T "…Okay, from what I see, you don't feel that attached to him."

# game/script.rpy:6752
translate english final_v_0c9d5d4d:

    # T "Eso… Supongo que es porque tienes una mente fuerte."
    T "That… I guess it's because you have a strong mind."

# game/script.rpy:6753
translate english final_v_d1e890a4:

    # pov "Gracias."
    pov "Thanks."

# game/script.rpy:6754
translate english final_v_c623af9c:

    # T "Pero… Me gustaría que siguieras viniendo, para ver cómo te sientes en tu vida normal."
    T "But… I'd like you to keep coming back, to see how you feel in your normal life."

# game/script.rpy:6756
translate english final_v_c0c76561:

    # "Te encoges de hombros, poniéndote de pie al ver que tu hora ya terminó."
    "You shrug, standing up when you see that your hour is over."

# game/script.rpy:6757
translate english final_v_8084c690:

    # pov "De acuerdo, ¿El próximo mes?"
    pov "Okay, next month?"

# game/script.rpy:6758
translate english final_v_4305ce89:

    # T "… Que sea la próxima semana."
    T "…Let it be next week."

# game/script.rpy:6759
translate english final_v_727ce6e3:

    # pov "Ok."
    pov "Ok."

# game/script.rpy:6761
translate english final_v_a2eca826:

    # "Sales de la consulta, y viéndote en la calle concurrida de día, sientes que tus hombros se relajan."
    "You leave the office, and seeing yourself on the busy street during the day, you feel your shoulders relax."

# game/script.rpy:6762
translate english final_v_f2e3fbc0:

    # "Tu vida había vuelto casi a la normalidad, con la excepción de que te mudaste y cambiaste de trabajo."
    "Your life had returned almost to normal, except that you moved and changed jobs."

# game/script.rpy:6763
translate english final_v_343864e7:

    # "Muchos dirían que lo que pasaste fue un infierno, pero para ti, fue algo especial."
    "Many would say that what you went through was hell, but for you, it was something special."

# game/script.rpy:6764
translate english final_v_7df5a380:

    # "Tu… Extrañabas a Jeff. Y no eras tan idiota como para admitirlo con el terapeuta."
    "You… You missed Jeff. And you weren't stupid enough to admit it to the therapist."

# game/script.rpy:6766
translate english final_v_25650239:

    # "Lo amabas, después de todo."
    "You loved him, after all."

# game/script.rpy:6768
translate english final_v_b83e740f:

    # "Fue tu amigo, después de todo."
    "He was your friend, after all."

# game/script.rpy:6769
translate english final_v_4917d808:

    # "Su risa estruendosa, su cabello largo revuelto, sus manos blancas sujetando tu rostro."
    "His booming laugh, his long, disheveled hair, his white hands holding your face."

# game/script.rpy:6770
translate english final_v_9f85ba35:

    # "Extrañabas todo."
    "You missed everything."

# game/script.rpy:6771
translate english final_v_55f381cf:

    # "Así que te aferrabas a la promesa que hiciste ese día."
    "So you held on to the promise you made that day."

# game/script.rpy:6776
translate english final_v_7c39b2e7:

    # pov "… Te estaré esperando."
    pov "…I’ll be waiting for you."

# game/script.rpy:6778
translate english final_v_6bdbcd0c:

    # "No explicaste mucho, y aún así, Jeff pareció comprenderlo."
    "You didn't explain much, and yet Jeff seemed to understand."

# game/script.rpy:6779
translate english final_v_ddb77d6a:

    # "Porque él siempre logra escapar."
    "Because he always manages to escape."

# game/script.rpy:6780
translate english final_v_acdd06d8:

    # "Así que aprovechaste la conveniencia de la que él goza, sabiendo que él sobreviviría."
    "So you took advantage of the convenience he enjoyed, knowing that he would survive."

# game/script.rpy:6781
translate english final_v_a20cefa7:

    # "..."
    "..."

# game/script.rpy:6783
translate english final_v_ac195da2:

    # "Ya habían pasado semanas de lo ocurrido, pero él aún no aparecía…"
    "Weeks had passed since what happened, but he still hadn't appeared..."

# game/script.rpy:6784
translate english final_v_52f75f3a:

    # "Se estaba tomando su tiempo, eso es seguro."
    "He was taking his time, that's for sure."

# game/script.rpy:6785
translate english final_v_1a1f378b:

    # "Pero volvería, lo sabías."
    "But he would come back, you knew it."

# game/script.rpy:6786
translate english final_v_178becc7:

    # "{b}Final Verdadero: Viene Por Ti{/b}"
    "{b}True Ending: He's Coming For You{/b}"

translate english strings:

    # game/script.rpy:9
    old "*+{0}"
    new "*+{0}"

    # game/script.rpy:14
    old "¡Vives!"
    new "You Live!"

    # game/script.rpy:129
    old "Te encantan las películas"
    new "You love movies"

    # game/script.rpy:129
    old "Las películas están bien"
    new "Movies are ok"

    # game/script.rpy:235
    old "Tu nombre es..."
    new "Your name is..."

    # game/script.rpy:240
    old "Agradecer"
    new "Thank him"

    # game/script.rpy:240
    old "Burlarte"
    new "Mock him"

    # game/script.rpy:303
    #old "Si"
    #new "Yes"

    # game/script.rpy:303
    #old "No"
    #new "No"

    # game/script.rpy:340
    old "Desviar la mirada"
    new "Look away"

    # game/script.rpy:340
    old "Corresponder la mirada"
    new "Meet his gaze"

    # game/script.rpy:361
    old "Fantasía"
    new "Fantasy"

    # game/script.rpy:361
    old "Romance"
    new "Romance"

    # game/script.rpy:361
    old "Terror"
    new "Horror"

    # game/script.rpy:361
    old "Comedia"
    new "Comedy"

    # game/script.rpy:361
    old "Musical"
    new "Musical"

    # game/script.rpy:361
    old "Ciencia Ficción"
    new "Sci-Fi"

    # game/script.rpy:404
    old "Black Swan (2010)"
    new "Black Swan (2010)"

    # game/script.rpy:404
    old "The Exorcist (1973)"
    new "The Exorcist (1973)"

    # game/script.rpy:404
    old "Scream (1996)"
    new "Scream (1996)"

    # game/script.rpy:404
    old "Tremors (1990)"
    new "Tremors (1990)"

    # game/script.rpy:404
    old "Paranormal Activity (2007)"
    new "Paranormal Activity (2007)"

    # game/script.rpy:404
    old "Pulse (2001)"
    new "Pulse (2001)"

    # game/script.rpy:404
    old "The Thing (1982)"
    new "The Thing (1982)"

    # game/script.rpy:484
    old "Seguirle la corriente"
    new "Go with it"

    # game/script.rpy:484
    old "Ignorarlo"
    new "Ignore him"

    # game/script.rpy:508
    old "Ser sutil"
    new "Be subtle"

    # game/script.rpy:508
    old "Ir al grano"
    new "Be direct"

    # game/script.rpy:535
    old "Chocar su mano"
    new "High five him"

    # game/script.rpy:535
    old "Tomar su mano"
    new "Take his hand"

    # game/script.rpy:564
    old "¿Qué hay con la bandana?"
    new "What's up with the bandana?"

    # game/script.rpy:564
    old "¿En qué trabajas?"
    new "What do you do for work?"

    # game/script.rpy:564
    old "¿Tienes pareja?"
    new "Are you single?"

    # game/script.rpy:568
    old "Curiosidad"
    new "Curiosity"

    # game/script.rpy:568
    old "¿Duele?"
    new "Does it hurt?"

    # game/script.rpy:599
    old "Coquetear"
    new "Flirt"

    # game/script.rpy:599
    old "Encogerte de hombros"
    new "Shrug"

    # game/script.rpy:620
    old "Responder con amabilidad"
    new "Answer nicely"

    # game/script.rpy:620
    old "Responder con sarcasmo"
    new "Answer sarcastically"

    # game/script.rpy:826
    old "Disculparte"
    new "Apologize"

    # game/script.rpy:826
    old "Provocarlo"
    new "Tease him"

    # game/script.rpy:919
    old "Cara"
    new "Face"

    # game/script.rpy:919
    old "Voz"
    new "Voice"

    # game/script.rpy:919
    old "Está loco"
    new "He's insane"

    # game/script.rpy:919
    old "Te va a matar"
    new "He's going to kill you"

    # game/script.rpy:981
    old "Está bien"
    new "Alright"

    # game/script.rpy:981
    old "Yo te persigo a ti"
    new "I chase you"

    # game/script.rpy:1003
    old "Ir a la derecha"
    new "Go right"

    # game/script.rpy:1003
    old "Ir a la izquierda"
    new "Go left"

    # game/script.rpy:1152
    old "Rendirte"
    new "Give up"

    # game/script.rpy:1152
    old "Desafiarlo"
    new "Defy him"

    # game/script.rpy:1198
    old "Suplicarle"
    new "Plead"

    # game/script.rpy:1327
    old "Hospital"
    new "Hospital"

    # game/script.rpy:1327
    old "Cielo"
    new "Heaven"

    # game/script.rpy:1355
    old "Como él quiera llamarte"
    new "Whatever he wants to call you"

    # game/script.rpy:1355
    old "Di tu nombre"
    new "Say your name"

    # game/script.rpy:1427
    old "No estás bien"
    new "You're not okay"

    # game/script.rpy:1427
    old "Estarás bien"
    new "You will be okay"

    # game/script.rpy:1469
    old "No tienes familia"
    new "You don't have a family"

    # game/script.rpy:1469
    old "No hablas con tu familia"
    new "You don't talk to your family"

    # game/script.rpy:1469
    old "Tu familia vive en otra ciudad"
    new "Your family lives in another city"

    # game/script.rpy:1577
    old "Agradecerle"
    new "Thank her"

    # game/script.rpy:1577
    old "Cuestionarla"
    new "Question her"

    # game/script.rpy:1662
    old "Di la verdad"
    new "Say the truth"

    # game/script.rpy:1662
    old "Exagera"
    new "Exaggerate"

    # game/script.rpy:1730
    old "Algo dulce"
    new "Something sweet"

    # game/script.rpy:1730
    old "Algo salado"
    new "Something salty"

    # game/script.rpy:1754
    old "Ser amigable"
    new "Be nice"

    # game/script.rpy:1754
    old "Ser cortante"
    new "Be cold"

    # game/script.rpy:1819
    old "Desconfiar"
    new "Distrust"

    # game/script.rpy:1837
    old "Negociar"
    new "Negotiate"

    # game/script.rpy:1837
    old "Quejarte"
    new "Complain"

    # game/script.rpy:1858
    old "Decirle lo que te pasó"
    new "Tell him what happened to you"

    # game/script.rpy:1858
    old "Mostrar interés"
    new "Show interest"

    # game/script.rpy:1990
    old "Confiar en el Dr. Salazar"
    new "Trust Dr. Salazar"

    # game/script.rpy:1990
    old "Guardatelo para ti"
    new "Keep it to yourself"

    # game/script.rpy:2223
    old "Coquetear con Wes"
    new "Flirt with Wes"

    # game/script.rpy:2223
    old "Coquetear con Sean"
    new "Flirt with Sean"

    # game/script.rpy:2223
    old "Preguntar sobre el caso"
    new "Ask about the case"

    # game/script.rpy:2317
    old "Posters"
    new "Posters"

    # game/script.rpy:2317
    old "Luces"
    new "Lights"

    # game/script.rpy:2317
    old "Muebles"
    new "Furniture"

    # game/script.rpy:2681
    old "Opción vegana"
    new "Vegan option"

    # game/script.rpy:2681
    old "Opción normal"
    new "Normal option"

    # game/script.rpy:2770
    old "Aceptar"
    new "Accept"

    # game/script.rpy:2770
    old "Rechazar"
    new "Reject"

    # game/script.rpy:3034
    old "Vino"
    new "Wine"

    # game/script.rpy:3034
    old "Cerveza"
    new "Beer"

    # game/script.rpy:3069
    old "Provocar"
    new "Tease"

    # game/script.rpy:3069
    old "Desafiar"
    new "Defy"

    # game/script.rpy:3109
    old "Tener empatía"
    new "Show empathy"

    # game/script.rpy:3141
    old "Comentar de tu día"
    new "Comment on your day"

    # game/script.rpy:3141
    old "Preguntar sobre el día de él"
    new "Ask about his day"

    # game/script.rpy:3187
    old "Sospechar"
    new "Suspect"

    # game/script.rpy:3219
    old "Indagar"
    new "Inquire"

    # game/script.rpy:3219
    old "Comprender"
    new "Understand"

    # game/script.rpy:3244
    old "Liberarte"
    new "Free yourself"

    # game/script.rpy:3244
    old "Gemir"
    new "Moan"

    # game/script.rpy:3272
    old "Brindar"
    new "Toast"

    # game/script.rpy:3272
    old "Regañar"
    new "Scold"

    # game/script.rpy:3315
    old "¿Eres celoso?"
    new "Are you jealous?"

    # game/script.rpy:3315
    old "¿De donde sacas el dinero?"
    new "Where do you get your money?"

    # game/script.rpy:3315
    old "¿Qué te pasó en la boca?"
    new "What happened to your mouth?"

    # game/script.rpy:3378
    old "Juzgarlo"
    new "Judge him"

    # game/script.rpy:3378
    old "Calmarlo"
    new "Calm him"

    # game/script.rpy:3411
    #old "Sí"
    #new "Yes"

    # game/script.rpy:3435
    old "Besar su mejilla"
    new "Kiss his cheek"

    # game/script.rpy:3512
    old "Abrir"
    new "Open"

    # game/script.rpy:3512
    old "No abrir"
    new "Don't Open"

    # game/script.rpy:3733
    old "Cindy"
    new "Cindy"

    # game/script.rpy:3733
    old "Salazar"
    new "Salazar"

    # game/script.rpy:3777
    old "Charlar"
    new "Chat"

    # game/script.rpy:3819
    old "Mencionarlo"
    new "Mention it"

    # game/script.rpy:3819
    old "No mencionarlo"
    new "Don't mention it"

    # game/script.rpy:3889
    old "Restar importancia"
    new "Downplay"

    # game/script.rpy:4071
    old "Le gustas"
    new "He likes you"

    # game/script.rpy:4071
    old "Quiere dejarte en paz"
    new "He wants to leave you alone"

    # game/script.rpy:4204
    old "Preguntar"
    new "Ask"

    # game/script.rpy:4204
    old "No preguntar"
    new "Don't ask"

    # game/script.rpy:4262
    old "Ser cool"
    new "Be cool"

    # game/script.rpy:4262
    old "Ser indiferente"
    new "Be indifferent"

    # game/script.rpy:4532
    old "Ser optimista"
    new "Be positive"

    # game/script.rpy:4657
    old "Tiene sentido"
    new "Makes sense"

    # game/script.rpy:4695
    old "Proponer cenar juntos"
    new "Suggest having dinner together"

    # game/script.rpy:4771
    old "Hombres"
    new "Men"

    # game/script.rpy:4771
    old "Mujeres"
    new "Women"

    # game/script.rpy:4771
    old "Ambos"
    new "Both"

    # game/script.rpy:4771
    old "No te importa"
    new "It doesn't matter to you"

    # game/script.rpy:4771
    old "No lo has considerado"
    new "You haven't considered it"

    # game/script.rpy:4808
    old "¿Tienes familia?"
    new "Do you have a family?"

    # game/script.rpy:4808
    old "¿Tienes amigos?"
    new "Do you have any friends?"

    # game/script.rpy:4808
    old "¿Qué edad tienes?"
    new "How old are you?"

    # game/script.rpy:4808
    old "Eso es todo"
    new "That's all"

    # game/script.rpy:4817
    old "¿Los mataste?"
    new "Did you kill them?"

    # game/script.rpy:4817
    old "¿Cómo?"
    new "How?"

    # game/script.rpy:4837
    old "Suenan cool"
    new "They sound cool"

    # game/script.rpy:4837
    old "Suenan raros"
    new "They sound weird"

    # game/script.rpy:4863
    old "Menos de 20"
    new "Less than 20"

    # game/script.rpy:4863
    old "En tus 20's"
    new "In your 20s"

    # game/script.rpy:4863
    old "En tus 30's"
    new "In your 30s"

    # game/script.rpy:4885
    old "Halagarlo"
    new "Flatter him"

    # game/script.rpy:5347
    old "Es raro"
    new "It's weird"

    # game/script.rpy:5347
    old "Es jodido"
    new "It's fucked up"

    # game/script.rpy:5418
    old "Decir la verdad"
    new "Tell the truth"

    # game/script.rpy:5418
    old "Mentir"
    new "Lie"

    # game/script.rpy:5497
    old "Ser complaciente"
    new "Be agreeable"

    # game/script.rpy:5528
    old "Alejarte"
    new "Move away"

    # game/script.rpy:5528
    old "Dejarlo"
    new "Let him"

    # game/script.rpy:5568
    old "Incluir lengua (sugestivo)"
    new "Use tongue (suggestive)"

    # game/script.rpy:5568
    old "Con eso basta"
    new "That's enough"

    # game/script.rpy:5646
    old "No es tu tipo"
    new "He's not your type"

    # game/script.rpy:5748
    old "Contarle a Jeff"
    new "Tell Jeff"

    # game/script.rpy:5748
    old "Guardarlo para ti"
    new "Keep it to yourself"

    # game/script.rpy:5804
    old "Bromear"
    new "Joke"

    # game/script.rpy:5881
    old "Unirte a él"
    new "Join him"

    # game/script.rpy:6010
    old "Lo amas"
    new "You love him"

    # game/script.rpy:6010
    old "Sólo te agrada"
    new "You just like him"

    # game/script.rpy:6042
    old "Nunca"
    new "Never"

    # game/script.rpy:6042
    old "Exactamente"
    new "Exactly"

    # game/script.rpy:6132
    old "Ojos"
    new "Eyes"

    # game/script.rpy:6132
    old "Sonrisa"
    new "Smile"

    # game/script.rpy:6132
    old "Cuerpo"
    new "Body"

    # game/script.rpy:6132
    old "Calva"
    new "Bald spot"

    # game/script.rpy:6175
    old "Preguntar por el antiguo dueño"
    new "Ask about the former owner"

    # game/script.rpy:6175
    old "Preguntar por el cadáver del sótano"
    new "Ask for the body in the basement"

    # game/script.rpy:6321
    old "Acariciarlo (Sugestivo)"
    new "Caress him (Suggestive)"

    # game/script.rpy:6364
    old "Tienes experiencia"
    new "You have experience"

    # game/script.rpy:6364
    old "No tienes experiencia"
    new "You don't have experience"

    # game/script.rpy:6436
    old "Desviar el tema"
    new "Avoid the subject"

    # game/script.rpy:6558
    old "Quedarse con él"
    new "Stay with him"

    # game/script.rpy:6564
    #old "Qudarse con él"
    #new ""

    # game/script.rpy:6564
    #old "Tiendes miedo..."
    #new ""

    # game/script.rpy:6572
    old "..."
    new "..."

    # game/script.rpy:6654
    old "Estamos saliendo"
    new "We're dating"

    # game/script.rpy:6654
    old "Nuestra amistad creció"
    new "Our friendship grew"

    # game/script.rpy:6734
    old "Diferente"
    new "Different"

    # game/script.rpy:6734
    old "Normal"
    new "Normal"

    # game/script.rpy:6794
    old "{size=70}{color=#27BBF5}Guión, Arte y Programación{/color} by Neesa Complex"
    new "{size=70}{color=#27BBF5}Script, Art, and Programming{/color} by Neesa Complex"

    # game/script.rpy:6810
    old "{size=70}{color=#D90000}Jeff The Killer{/color} by Jeff 'Sesseur' Case and 'GameFuelTV'{/size}"
    new "{size=70}{color=#D90000}Jeff The Killer{/color} by Jeff 'Sesseur' Case and 'GameFuelTV'{/size}"

    # game/script.rpy:6817
    old "{size=70}Muchas gracias por jugar{/size}"
    new "{size=70}Thanks so much for playing{/size}"

    # game/script.rpy:6824
    old "{size=70}Si quieres seguir viendo mis proyectos, no dudes en apoyarme *{/size}"
    new "{size=70}If you'd like to continue seeing my projects, feel free to support me *{/size}"

# TODO: Translation updated at 2025-10-25 17:22

# game/script.rpy:4547
translate english ruta_normal_31_d424802a:

    # "Él te evitó, ¿Cierto?"
    "He avoided you, didn't he?"

# game/script.rpy:5460
translate english ruta_normal_37_246c251f:

    # "{b}Final VI: Lo Traicionaste{/b}"
    "{b}Ending VI: You Betrayed Him{/b}"

# TODO: Translation updated at 2025-10-25 17:25

translate english strings:

    # game/script.rpy:6564
    old "Tienes miedo..."
    new "You're scared..."

# TODO: Translation updated at 2025-10-25 19:54

# game/script.rpy:1388
#translate english ruta_normal_12_4e29cce3:

    # "Él notó tu silencio y retiró la mano enseguida."
    #"He noticed your silence. Your lack of reaction made him uncomfortable."

# TODO: Translation updated at 2025-10-26 19:12

# game/script.rpy:1423
#translate english ruta_normal_12_0ef77194:

    # "Él notó tu silencio. Tu falta de reacción lo incomodaba."
    #"He noticed your silence. Your lack of reaction made him uncomfortable."

translate english strings:

    # game/script.rpy:45
    old "{size=70}Este juego contiene {size=80}{color=#F02800}violencia, gore, asesinato, acoso, abuso, manipulación y muerte de personaje principal{/color}{/size}"
    new "{size=70}This game contains {size=80}{color=#F02800}violence, gore, murder, stalking, abuse, manipulation, and major character death{/color}{/size}"

    # game/script.rpy:53
    old "{size=70}Está dirigido a una audiencia {color=#FFED0A}MADURA(+18){/color}{/size}"
    new "{size=70}This game is intended for a {color=#FFED0A}MATURE AUDIENCE (18+){/color}{/size}"

    # game/script.rpy:61
    old "{size=70}{color=#ffffff}Por favor juega con discreción{/color}{/size}"
    new "{size=70}{color=#ffffff}Viewer discretion is advised{/color}{/size}"

# TODO: Translation updated at 2025-10-26 19:32

# game/script.rpy:1393
translate english ruta_normal_12_4e29cce3:

    # "Él notó tu silencio y retiró la mano enseguida."
    "He noticed your silence and quickly pulled his hand back."

# TODO: Translation updated at 2025-10-26 19:34

# game/script.rpy:1428
translate english ruta_normal_12_0ef77194:

    # "Él notó tu silencio. Tu falta de reacción lo incomodaba."
    "He noticed your silence. Your lack of reaction made him uncomfortable."

# TODO: Translation updated at 2025-10-27 20:25

# game/script.rpy:6480
translate english ruta_normal_50_c72ac230:

    # J "¡Ese hijo de puta alcohólico no sabe quedarse callado!"
    J "That alcoholic son of a bitch doesn’t know when to shut up!"

# game/script.rpy:6481
translate english ruta_normal_50_022ea01f:

    # "Claro, era bastante obvio que un tipo que colecciona basura y da lo que sea por brandy no era confiable."
    "Of course, it was pretty obvious that a guy who collects trash and would do anything for brandy wasn’t exactly trustworthy."

# TODO: Translation updated at 2025-10-30 15:40

# game/script.rpy:4225
translate english cindy3_d3393c43:

    # "Cindy era realmente perspicaz, ¿No?"
    "Cindy was really perceptive, wasn't she?"

# TODO: Translation updated at 2025-10-30 16:58

# game/script.rpy:6200
translate english ruta_normal_47_b2363fb5:

    # pov "No me extraña… Es sólo que…"
    pov "It's not... It's just that..."

# TODO: Translation updated at 2025-11-01 17:57

# game/script.rpy:2490
translate english muerte_closet_ed2f83fb:

    # "Caes en el suelo, por el dolor intenso y la pérdida de sangre."
    "You fell to the floor, because of the intense pain and loss of blood."

# TODO: Translation updated at 2025-11-12 14:40

# game/script.rpy:2292
translate english supervivencia_7_08e3a901:

    # "Bueno, eso fue un gran volcado de información, presuntamente valiosa."
    "Well, that was a big information dump, presumably valuable."

# game/script.rpy:2947
translate english historia_continua_3_35d7c0d4:

    # C "¿Viste si sentía placer al atacarte?"
    C "Did you see if he felt pleasure attacking you?"

# TODO: Translation updated at 2025-11-20 21:21

# game/script.rpy:2194
translate english supervivencia_7_133dab0c:

    # pov "Es sólo una compañera de trabajo, ni siquiera es mi amiga."
    pov "She's just a coworker, we're not even that close."

# TODO: Translation updated at 2026-01-07 21:02

translate english strings:

    # game/script.rpy:82
    old "Easy Mode ON"
    new "Easy Mode ON"

# TODO: Translation updated at 2026-01-12 14:57

translate english strings:

    # game/script.rpy:6813
    old "{size=70}{color=#EC96FF}Traducción al Ruso{/color} by regisvinex"
    new "{size=70}{color=#EC96FF}Russian translation{/color} by regisvinex"

# TODO: Translation updated at 2026-01-19 10:53

# game/script.rpy:5525
#translate english ruta_normal_39_7e8b5b2d:

    # "Su tono burlesco te fastidiaba, sólo quería molestarte"
    #"His mocking tone was getting on your nerves, he just wanted to tease you."

# game/script.rpy:5625
translate english beso_1_8809c5b7:

    # "Esa broma era más molesta que graciosa."
    "That joke was more annoying than funny."

# game/script.rpy:6621
translate english final_neutral_aa238c36:

    # "Tienes las palabras en la boca, escuchas el sonido de un disparo demasiado cerca como para alarmarte."
    "The words were in your mouth, you heard the sound of a gunshot too close to alarm you."

# TODO: Translation updated at 2026-01-19 10:56

# game/script.rpy:5525
translate english ruta_normal_39_056a4c75:

    # "Su tono burlesco te fastidiaba, sólo quería molestarte."
    "His mocking tone was getting on your nerves, he just wanted to tease you."

