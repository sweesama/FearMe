﻿# TODO: Translation updated at 2025-05-20 15:12

translate english strings:

    # game/options.rpy:16
    old "Fear Me DEMO"
    new "Fear Me DEMO"

# TODO: Translation updated at 2025-05-29 17:13

translate english strings:

    # game/options.rpy:16
    old "Fear Me DEMO update"
    new "Fear Me DEMO update"

# TODO: Translation updated at 2025-10-12 17:55

translate english strings:

    # game/options.rpy:16
    old "Fear Me"
    new "Fear Me"

