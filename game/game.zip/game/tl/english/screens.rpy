﻿# TODO: Translation updated at 2025-05-20 15:12

translate english strings:

    # game/screens.rpy:251
    old "Atrás"
    new "Back"

    # game/screens.rpy:252
    old "Historial"
    new "History"

    # game/screens.rpy:253
    old "Saltar"
    new "Skip"

    # game/screens.rpy:254
    old "Auto"
    new "Auto"

    # game/screens.rpy:255
    old "Guardar"
    new "Save"

    # game/screens.rpy:256
    old "Guardar R."
    new "Q. Save"

    # game/screens.rpy:257
    old "Cargar R."
    new "Q. Load"

    # game/screens.rpy:258
    old "Prefs."
    new "Prefs."

    # game/screens.rpy:299
    old "Comenzar"
    new "Start"

    # game/screens.rpy:307
    old "Cargar"
    new "Load"

    # game/screens.rpy:309
    old "Opciones"
    new "Options"

    # game/screens.rpy:313
    old "Finaliza repetición"
    new "Ends Replay"

    # game/screens.rpy:317
    old "Menú principal"
    new "Main Menu"

    # game/screens.rpy:319
    old "Acerca de"
    new "About"

    # game/screens.rpy:324
    old "Ayuda"
    new "Help"

    # game/screens.rpy:330
    old "Salir"
    new "Quit"

    # game/screens.rpy:475
    old "Volver"
    new "Return"

    # game/screens.rpy:560
    old "Versión [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:566
    old "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:602
    old "Página {}"
    new "Page {}"

    # game/screens.rpy:602
    old "Grabación automática"
    new "Automatic Recording"

    # game/screens.rpy:602
    old "Grabación rápida"
    new "Quick recording"

    # game/screens.rpy:645
    old "{#file_time}%A, %d de %B %Y, %H:%M"
    new "{#file_time}%A, %d de %B %Y, %H:%M"

    # game/screens.rpy:645
    old "vacío"
    new "empty"

    # game/screens.rpy:665
    old "<"
    new "<"

    # game/screens.rpy:669
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:672
    old "{#quick_page}R"
    new "{#quick_page}R"

    # game/screens.rpy:678
    old ">"
    new ">"

    # game/screens.rpy:683
    old "Subir Sync"
    new "Upload Sync"

    # game/screens.rpy:687
    old "Descargar Sync"
    new "Download Sync"

    # game/screens.rpy:746
    old "Pantalla"
    new "Screen"

    # game/screens.rpy:747
    old "Ventana"
    new "Window"

    # game/screens.rpy:748
    old "Pantalla completa"
    new "Full Screen"

    # game/screens.rpy:753
    old "Texto no visto"
    new "Unseen Text"

    # game/screens.rpy:754
    old "Tras elecciones"
    new "After Choices"

    # game/screens.rpy:755
    old "Transiciones"
    new "Transitions"

    # game/screens.rpy:768
    old "Text speed"
    new "Text speed"

    # game/screens.rpy:772
    old "Veloc. autoavance"
    new "Auto-Forward Time"

    # game/screens.rpy:779
    old "Volumen música"
    new "Music Volume"

    # game/screens.rpy:786
    old "Volumen sonido"
    new "Sound Volume"

    # game/screens.rpy:792
    old "Prueba"
    new "Test"

    # game/screens.rpy:796
    old "Volumen voz"
    new "Voice Volume"

    # game/screens.rpy:807
    old "Silenciar todo"
    new "Mute All"

    # game/screens.rpy:926
    old "El historial está vacío."
    new "The history is empty."

    # game/screens.rpy:994
    old "Teclado"
    new "Keyboard"

    # game/screens.rpy:995
    old "Ratón"
    new "Mouse"

    # game/screens.rpy:998
    old "Mando"
    new "Gamepad"

    # game/screens.rpy:1011
    old "Intro"
    new "Intro"

    # game/screens.rpy:1012
    old "Avanza el diálogo y activa la interfaz."
    new "Advance the dialogue and activate the interface."

    # game/screens.rpy:1015
    old "Espacio"
    new "Space"

    # game/screens.rpy:1016
    old "Avanza el diálogo sin seleccionar opciones."
    new "Advance the dialog without selecting options."

    # game/screens.rpy:1019
    old "Teclas de flecha"
    new "Arrow Keys"

    # game/screens.rpy:1020
    old "Navega la interfaz."
    new "Navigate the interface."

    # game/screens.rpy:1023
    old "Escape"
    new "Escape"

    # game/screens.rpy:1024
    old "Accede al menú del juego."
    new "Access the game menu."

    # game/screens.rpy:1027
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1028
    old "Salta el diálogo mientras se presiona."
    new "Skips dialogue while pressed."

    # game/screens.rpy:1031
    old "Tabulador"
    new "Tab"

    # game/screens.rpy:1032
    old "Activa/desactiva el salto de diálogo."
    new "Toggles dialog skipping."

    # game/screens.rpy:1035
    old "Av. pág."
    new "Page up."

    # game/screens.rpy:1036
    old "Retrocede al diálogo anterior."
    new "Go back to the previous dialogue."

    # game/screens.rpy:1039
    old "Re. pág."
    new "Pague down."

    # game/screens.rpy:1040
    old "Avanza hacia el diálogo siguiente."
    new "Proceed to the next dialogue."

    # game/screens.rpy:1044
    old "Oculta la interfaz."
    new "Hide the interface."

    # game/screens.rpy:1048
    old "Captura la pantalla."
    new "Screenshot."

    # game/screens.rpy:1052
    old "Activa/desactiva la asistencia por {a=https://www.renpy.org/l/voicing}voz-automática{/a}."
    new "Enables/disables automatic voice assistance."

    # game/screens.rpy:1056
    old "Abre el menú de accesibilidad."
    new "Open the accessibility menu."

    # game/screens.rpy:1062
    old "Clic izquierdo"
    new "Left Click"

    # game/screens.rpy:1066
    old "Clic medio"
    new "Middle Click"

    # game/screens.rpy:1070
    old "Clic derecho"
    new "Right Click"

    # game/screens.rpy:1074
    old "Rueda del ratón arriba"
    new "Mouse Wheel Up"

    # game/screens.rpy:1078
    old "Rueda del ratón abajo"
    new "Mouse Wheel Down"

    # game/screens.rpy:1085
    old "Gatillo derecho\nA/Botón inferior"
    new "Right Trigger\nA/Bottom Button"

    # game/screens.rpy:1089
    old "Gatillo izquierdo\nBotón sup. frontal izq."
    new "Left Trigger\nLeft Front Upper Button"

    # game/screens.rpy:1093
    old "Botón sup. frontal der."
    new "Right front top button"

    # game/screens.rpy:1097
    old "D-Pad, Sticks"
    new "D-Pad, Sticks"

    # game/screens.rpy:1101
    old "Inicio, Guía, B/Botón Derecho"
    new "Home, Guide, B/Right Click"

    # game/screens.rpy:1105
    old "Y/Botón superior"
    new "Y/Top Button"

    # game/screens.rpy:1108
    old "Calibrar"
    new "Calibrate"

    # game/screens.rpy:1174
    old "Sí"
    new "Yes"

    # game/screens.rpy:1221
    old "Saltando"
    new "Skipping"

    # game/screens.rpy:1533
    old "Menú"
    new "Menu"

# TODO: Translation updated at 2025-05-20 17:20

translate english strings:

    # game/screens.rpy:300
    old "Inglés"
    new "English"

    # game/screens.rpy:301
    old "Español"
    new "Español"

    # game/screens.rpy:770
    old "Veloc. texto"
    new "Text speed"

# TODO: Translation updated at 2025-05-20 17:41

translate english strings:

    # game/screens.rpy:762
    old "Idioma"
    new "Language"

# TODO: Translation updated at 2025-10-12 17:55

# TODO: Translation updated at 2025-10-12 20:25

translate english strings:

    # game/screens.rpy:359
    old "Día 1"
    new "Day 1"

    # game/screens.rpy:360
    old "Día 2"
    new "Day 2"

    # game/screens.rpy:361
    old "Día 3"
    new "Day 3"

    # game/screens.rpy:362
    old "Día 4"
    new "Day 4"

    # game/screens.rpy:363
    old "Día 5"
    new "Day 5"

    # game/screens.rpy:364
    old "Día 6"
    new "Day 6"

    # game/screens.rpy:365
    old "Día 7"
    new "Day 7"

# TODO: Translation updated at 2025-10-12 20:27

translate english strings:

    # game/screens.rpy:327
    old "Álbum"
    new "Album"

# TODO: Translation updated at 2025-10-26 19:32

translate english strings:

    # game/screens.rpy:918
    #old "Interfaz"
    #new "Interface"

    # game/screens.rpy:920
    old "Interfaz de afecto"
    new "Affection HUD"

# TODO: Translation updated at 2025-10-30 14:36

translate english strings:

    # game/screens.rpy:918
    old "Haz trampa"
    new "Cheat"

# TODO: Translation updated at 2026-01-07 21:02

translate english strings:

    # game/screens.rpy:281
    old "['Easy Mode: ON') if easy_mode else 'Easy Mode: OFF' ]"
    new "['Easy Mode: ON') if easy_mode else 'Easy Mode: OFF' ]"

    # game/screens.rpy:344
    old "Easy Mode:"
    new "Easy Mode:"

    # game/screens.rpy:344
    old "ON"
    new "ON"

    # game/screens.rpy:344
    old "OFF"
    new "OFF"

# TODO: Translation updated at 2026-01-12 14:57

translate english strings:

    # game/screens.rpy:281
    old "Easy Mode: ON"
    new "Easy Mode: ON"

    # game/screens.rpy:281
    old "Easy Mode: OFF"
    new "Easy Mode: OFF"

    # game/screens.rpy:344
    old "Easy Mode:{vspace=15}ON"
    new "Easy Mode:{vspace=15}ON"

    # game/screens.rpy:344
    old "Easy Mode:{vspace=15}OFF"
    new "Easy Mode:{vspace=15}OFF"

