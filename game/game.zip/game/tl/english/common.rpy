﻿
translate english strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Voz automática desactivada."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "'Portapapeles a voz' activado. "

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Voz automática activada. "

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "barra"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "seleccionado"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "viewport"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "deslizamiento horizontal"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "deslizamiento vertical"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "activar"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "desactivar"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentar"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "disminuir"

    # renpy/common/00accessibility.rpy:122
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."

    # renpy/common/00accessibility.rpy:141
    old "Font Override"
    new "Sobreescribir fuente"

    # renpy/common/00accessibility.rpy:145
    old "Default"
    new "Por defecto"

    # renpy/common/00accessibility.rpy:149
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:153
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:159
    old "Text Size Scaling"
    new "Escalado del tamaño del texto"

    # renpy/common/00accessibility.rpy:165
    old "Reset"
    new "Reiniciar"

    # renpy/common/00accessibility.rpy:171
    old "Line Spacing Scaling"
    new "Escalado del espacio de línea"

    # renpy/common/00accessibility.rpy:183
    old "High Contrast Text"
    new "Texto de alto contraste"

    # renpy/common/00accessibility.rpy:185
    old "Enable"
    new "Activar"

    # renpy/common/00accessibility.rpy:189
    old "Disable"
    new "Desactivar"

    # renpy/common/00accessibility.rpy:196
    old "Self-Voicing"
    new "Voz automática"

    # renpy/common/00accessibility.rpy:199
    old "Self-voicing support is limited when using a touch screen."
    new "Self-voicing support is limited when using a touch screen."

    # renpy/common/00accessibility.rpy:203
    old "Off"
    new "Apagado"

    # renpy/common/00accessibility.rpy:207
    old "Text-to-speech"
    new "Texto a voz"

    # renpy/common/00accessibility.rpy:211
    old "Clipboard"
    new "Portapapeles"

    # renpy/common/00accessibility.rpy:215
    old "Debug"
    new "Depurar"

    # renpy/common/00accessibility.rpy:221
    old "Voice Volume"
    new "Volumen voz"

    # renpy/common/00accessibility.rpy:229
    old "Self-Voicing Volume Drop"
    new "Caída de volumen de voz automática"

    # renpy/common/00accessibility.rpy:238
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Las opciones en este menú están destinadas a mejorar la accesibilidad. Es posible que no funcionen con todos los juegos, y algunas combinaciones de opciones pueden hacer que el juego no se pueda jugar. Esto no es un problema con el juego o el motor. Para obtener los mejores resultados al cambiar las fuentes, intenta mantener el tamaño del texto igual al original."

    # renpy/common/00accessibility.rpy:243
    old "Return"
    new "Volver"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "Lunes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "Martes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "Miércoles"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "Jueves"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "Viernes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "Sábado"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "Domingo"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "Lun."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "Mar."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "Mié."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "Jue."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "Vie."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "Sab."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "Dom."

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "Enero"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "Febrero"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "Marzo"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "Abril"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "Mayo"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "Junio"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "Julio"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "Agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "Septiembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "Octubre"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "Noviembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "Diciembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "Ene."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "Feb."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "Mar."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "Abr."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "May."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "Jun."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "Jul."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "Ago."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "Sep."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "Oct."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "Nov."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "Dic."

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%d de %b, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Guardar partida %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Cargar ranura %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Borrar partida [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Página de guardado automático"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Página de guardado rápido"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Página de archivos [text]"

    # renpy/common/00action_file.rpy:675
    old "Page {}"
    new "Página {}"

    # renpy/common/00action_file.rpy:675
    old "Automatic saves"
    new "Grabación automática"

    # renpy/common/00action_file.rpy:675
    old "Quick saves"
    new "Grabación rápida"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Página siguiente."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Página anterior."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Guardado rápido completado."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Guardado rápido."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Carga rápida."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Idioma [text]"

    # renpy/common/00action_other.rpy:781
    old "Open [text] directory."
    new "Abrir directorio [text]."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "El director interactivo no está habilitado aquí."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "Hecho"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(sentencia)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(etiqueta)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(transformación)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transición)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(archivo)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Cambiar"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Añadir"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Cancelar"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Eliminar"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Sentencia:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Etiqueta:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Atributos:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Clic para cambiar el atributo, Clic derecho para cambiar el atributo a negativo."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "Transformaciones:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Clic para establecer la transformación, clic derecho para añadir a la lista de transformaciones."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Modifica director.transforms para añadir más transformaciones."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Detrás:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Clic para fijar, clic derecho para añadir a detrás de la lista."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Transición:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Haz clic para ajustar."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Modifica director.transitions para añadir más transiciones."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Canal:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Modifica director.audio_channels para añadir más canales."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Archivo de audio:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "¿Seguro?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "¿Seguro que quieres borrar esta partida?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "¿Seguro que quieres sobreescribir esta partida?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Al cargar se perderá el progreso no guardado.\n¿Seguro que quieres hacer esto?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "¿Seguro que quieres salir?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Seguro que quieres volver al menú principal?\nSe perderá el progreso no guardado."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "Are you sure you want to continue where you left off?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "¿Seguro que quieres finalizar la repetición?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "¿Seguro que quieres empezar el modo salto de escenas?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "¿Seguro que quieres saltar hasta la próxima elección?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Seguro que quieres saltar el texto no visto hasta la próxima elección?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Este archivo se creó en otro dispositivo. Los archivos de guardado maliciosamente creados pueden dañar tu computadora. Confías en el creador de este archivo y en todos los que podrían haberlo modificado?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "¿Confías en el dispositivo en el que se creó el archivo de  guardado? Sólo debes elegir sí si eres el único usuario del dispositivo."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Modo salto"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contiene {i}software{/i} libre sujeto a diversas licencias, incluidas la licencia MIT y la {i}GNU Lesser General Public License{/i} (Licencia Pública General Reducida de GNU). Puedes encontrar la lista completa de {i}software{/i}, con enlaces al código fuente completo, {a=https://www.renpy.org/l/license}aquí (en inglés){/a}."

    # renpy/common/00preferences.rpy:290
    old "display"
    new "pantalla"

    # renpy/common/00preferences.rpy:310
    old "transitions"
    new "transiciones"

    # renpy/common/00preferences.rpy:319
    old "skip transitions"
    new "saltar transiciones"

    # renpy/common/00preferences.rpy:321
    old "video sprites"
    new "sprites de vídeo"

    # renpy/common/00preferences.rpy:330
    old "show empty window"
    new "mostrar ventana vacía"

    # renpy/common/00preferences.rpy:339
    old "text speed"
    new "velocidad de texto"

    # renpy/common/00preferences.rpy:347
    old "joystick"
    new "mando"

    # renpy/common/00preferences.rpy:347
    old "joystick..."
    new "mando..."

    # renpy/common/00preferences.rpy:354
    old "skip"
    new "saltar"

    # renpy/common/00preferences.rpy:357
    old "skip unseen [text]"
    new "saltar no visto [text]"

    # renpy/common/00preferences.rpy:362
    old "skip unseen text"
    new "saltar texto no visto"

    # renpy/common/00preferences.rpy:364
    old "begin skipping"
    new "comenzar salto"

    # renpy/common/00preferences.rpy:368
    old "after choices"
    new "tras elecciones"

    # renpy/common/00preferences.rpy:375
    old "skip after choices"
    new "saltar tras elecciones"

    # renpy/common/00preferences.rpy:377
    old "auto-forward time"
    new "tiempo de autoavance"

    # renpy/common/00preferences.rpy:391
    old "auto-forward"
    new "autoavance"

    # renpy/common/00preferences.rpy:398
    old "Auto forward"
    new "Autoavance"

    # renpy/common/00preferences.rpy:401
    old "auto-forward after click"
    new "autoavanzar después del clic"

    # renpy/common/00preferences.rpy:410
    old "automatic move"
    new "movimiento automático"

    # renpy/common/00preferences.rpy:419
    old "wait for voice"
    new "esperar la voz"

    # renpy/common/00preferences.rpy:428
    old "voice sustain"
    new "mantener voz"

    # renpy/common/00preferences.rpy:437
    old "self voicing"
    new "autovoz"

    # renpy/common/00preferences.rpy:440
    old "self voicing enable"
    new "self voicing enable"

    # renpy/common/00preferences.rpy:442
    old "self voicing disable"
    new "self voicing disable"

    # renpy/common/00preferences.rpy:446
    old "self voicing volume drop"
    new "Caída de volumen de voz automática"

    # renpy/common/00preferences.rpy:454
    old "clipboard voicing"
    new "voz en portapapeles"

    # renpy/common/00preferences.rpy:457
    old "clipboard voicing enable"
    new "clipboard voicing enable"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing disable"
    new "clipboard voicing disable"

    # renpy/common/00preferences.rpy:463
    old "debug voicing"
    new "depurar voz"

    # renpy/common/00preferences.rpy:466
    old "debug voicing enable"
    new "debug voicing enable"

    # renpy/common/00preferences.rpy:468
    old "debug voicing disable"
    new "debug voicing disable"

    # renpy/common/00preferences.rpy:472
    old "emphasize audio"
    new "enfatizar audio"

    # renpy/common/00preferences.rpy:481
    old "rollback side"
    new "lado de retroceso"

    # renpy/common/00preferences.rpy:491
    old "gl powersave"
    new "gl ahorro de energía"

    # renpy/common/00preferences.rpy:497
    old "gl framerate"
    new "gl cuadros por segundo"

    # renpy/common/00preferences.rpy:500
    old "gl tearing"
    new "gl tearing"

    # renpy/common/00preferences.rpy:503
    old "font transform"
    new "transformación de fuente"

    # renpy/common/00preferences.rpy:506
    old "font size"
    new "tamaño de fuente"

    # renpy/common/00preferences.rpy:514
    old "font line spacing"
    new "fuente de espacio de líneas"

    # renpy/common/00preferences.rpy:522
    old "system cursor"
    new "cursor del sistema"

    # renpy/common/00preferences.rpy:531
    old "renderer menu"
    new "menú de renderizado"

    # renpy/common/00preferences.rpy:534
    old "accessibility menu"
    new "menú de accesibilidad"

    # renpy/common/00preferences.rpy:537
    old "high contrast text"
    new "texto de alto contraste"

    # renpy/common/00preferences.rpy:546
    old "audio when minimized"
    new "audio cuando está minimizado"

    # renpy/common/00preferences.rpy:555
    old "audio when unfocused"
    new "audio cuando no está enfocado"

    # renpy/common/00preferences.rpy:564
    old "web cache preload"
    new "precarga de la caché web"

    # renpy/common/00preferences.rpy:579
    old "voice after game menu"
    new "voz después de un menú del juego"

    # renpy/common/00preferences.rpy:588
    old "restore window position"
    new "restaurar la posición de la ventana"

    # renpy/common/00preferences.rpy:597
    old "reset"
    new "restablecer"

    # renpy/common/00preferences.rpy:610
    old "main volume"
    new "volumen principal"

    # renpy/common/00preferences.rpy:611
    old "music volume"
    new "volumen de música"

    # renpy/common/00preferences.rpy:612
    old "sound volume"
    new "volumen de sonido"

    # renpy/common/00preferences.rpy:613
    old "voice volume"
    new "volumen de voz"

    # renpy/common/00preferences.rpy:614
    old "mute main"
    new "silenciar volumen principal"

    # renpy/common/00preferences.rpy:615
    old "mute music"
    new "silenciar música"

    # renpy/common/00preferences.rpy:616
    old "mute sound"
    new "silenciar sonido"

    # renpy/common/00preferences.rpy:617
    old "mute voice"
    new "silenciar voz"

    # renpy/common/00preferences.rpy:618
    old "mute all"
    new "silenciar todo"

    # renpy/common/00preferences.rpy:701
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "'Portapapeles a voz' activado. Pulsa 'Mayús.+C' para desactivarlo."

    # renpy/common/00preferences.rpy:703
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Voz automática dirá \"[renpy.display.tts.last]\". Pulsa 'alt+shift+V' para desactivarla."

    # renpy/common/00preferences.rpy:705
    old "Self-voicing enabled. Press 'v' to disable."
    new "Voz automática activada. Presiona 'v' para desactivarla."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Editor de globos de diálogo"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(ocultar)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(borrar burbujas retenidas)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Sincronización descargada"

    # renpy/common/00sync.rpy:193
    old "Could not connect to the Ren'Py Sync server."
    new "No se pudo conectar al servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:195
    old "The Ren'Py Sync server timed out."
    new "Se agotó el tiempo de espera del servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:197
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Se produjo un error desconocido al conectarse al servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:213
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "El servidor Ren'Py Sync no tiene una copia de esta sincronización. Es posible que el ID de sincronización no sea válido o que se haya agotado el tiempo de espera."

    # renpy/common/00sync.rpy:316
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Ingresa la ID de sincronización SI que generaste.\nNunca ingreses una ID de sincronización que no creaste."

    # renpy/common/00sync.rpy:335
    old "The sync ID is not in the correct format."
    new "El ID de sincronización no tiene el formato correcto."

    # renpy/common/00sync.rpy:355
    old "The sync could not be decrypted."
    new "No se pudo descifrar la ID de sincronización."

    # renpy/common/00sync.rpy:378
    old "The sync belongs to a different game."
    new "La sincronización pertenece a un juego diferente."

    # renpy/common/00sync.rpy:383
    old "The sync contains a file with an invalid name."
    new "La sincronización contiene un archivo con un nombre no válido."

    # renpy/common/00sync.rpy:440
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Esto cargará tus archivos guardados en el {a=https://sync.renpy.org}Servidor Ren'Py Sync{/a}..\n¿Quieres continuar?"

    # renpy/common/00sync.rpy:448
    old "Si"
    new "Yes"

    # renpy/common/00sync.rpy:449
    old "No"
    new "No"

    # renpy/common/00sync.rpy:472
    old "Enter Sync ID"
    new "Ingrese ID de Sync"

    # renpy/common/00sync.rpy:483
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Esto contactará con el {a=https://sync.renpy.org}Servidor Ren'Py Sync{/a}."

    # renpy/common/00sync.rpy:513
    old "Sync Success"
    new "Sincronización exitosa"

    # renpy/common/00sync.rpy:516
    old "The Sync ID is:"
    new "El ID de Sync es:"

    # renpy/common/00sync.rpy:522
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puede usar esta ID para descargar su guardado en otro dispositivo.\nEsta sincronización caducará en una hora.\nRenPy Sync está para {a=https://www.renpy.org/sponsors.html}los patrocinadores de Ren'Py{/a}."

    # renpy/common/00sync.rpy:526
    old "Continue"
    new "Continuar"

    # renpy/common/00sync.rpy:551
    old "Sync Error"
    new "Error de sincronización"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Translation identifier: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " translates [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copiado en el portapapeles.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Contactando con App Store\nPor favor, espera..."

    # renpy/common/00updater.rpy:505
    old "No update methods found."
    new "Métodos de actualización no encontrados."

    # renpy/common/00updater.rpy:552
    old "Could not download file list: "
    new "No se pudo descargar la lista de archivos: "

    # renpy/common/00updater.rpy:555
    old "File list digest does not match."
    new "El compendio de la lista de archivos no coincide."

    # renpy/common/00updater.rpy:765
    old "An error is being simulated."
    new "Se simula un error."

    # renpy/common/00updater.rpy:953
    old "Either this project does not support updating, or the update status file was deleted."
    new "O bien este proyecto no es compatible con la actualización o el archivo de estado de la actualización se ha eliminado."

    # renpy/common/00updater.rpy:967
    old "This account does not have permission to perform an update."
    new "Esta cuenta no tiene permiso para realizar una actualización."

    # renpy/common/00updater.rpy:970
    old "This account does not have permission to write the update log."
    new "Esta cuenta no tiene permiso para escribir en el registro de actualización."

    # renpy/common/00updater.rpy:1050
    old "Could not verify update signature."
    new "No se pudo verificar la actualización de firmas."

    # renpy/common/00updater.rpy:1373
    old "The update file was not downloaded."
    new "El archivo de actualización no se ha descargado."

    # renpy/common/00updater.rpy:1391
    old "The update file does not have the correct digest - it may have been corrupted."
    new "El archivo de actualización no tiene el 'digest' correcto - es posible que esté dañado."

    # renpy/common/00updater.rpy:1541
    old "While unpacking {}, unknown type {}."
    new "Tipo desconocido {1} al desempaquetar {0}."

    # renpy/common/00updater.rpy:2022
    old "Updater"
    new "Actualizador"

    # renpy/common/00updater.rpy:2029
    old "An error has occured:"
    new "Ha sucedido un error:"

    # renpy/common/00updater.rpy:2031
    old "Checking for updates."
    new "Buscando actualizaciones."

    # renpy/common/00updater.rpy:2033
    old "This program is up to date."
    new "Este programa está actualizado."

    # renpy/common/00updater.rpy:2035
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] está disponible. ¿Quieres instalarla?"

    # renpy/common/00updater.rpy:2037
    old "Preparing to download the updates."
    new "Preparando para descargar la actualización."

    # renpy/common/00updater.rpy:2039
    old "Downloading the updates."
    new "Descargando la actualización."

    # renpy/common/00updater.rpy:2041
    old "Unpacking the updates."
    new "Desempaquetando la actualización."

    # renpy/common/00updater.rpy:2043
    old "Finishing up."
    new "Finalizando."

    # renpy/common/00updater.rpy:2045
    old "The updates have been installed. The program will restart."
    new "La actualización ha sido instalada. El programa se reiniciará."

    # renpy/common/00updater.rpy:2047
    old "The updates have been installed."
    new "La actualización ha sido instalada."

    # renpy/common/00updater.rpy:2049
    old "The updates were cancelled."
    new "La actualización ha sido cancelada."

    # renpy/common/00updater.rpy:2064
    old "Proceed"
    new "Continuar"

    # renpy/common/00updater.rpy:2080
    old "Preparing to download the game data."
    new "Preparando la descarga de los datos del juego."

    # renpy/common/00updater.rpy:2082
    old "Downloading the game data."
    new "Downloading the game data."

    # renpy/common/00updater.rpy:2084
    old "The game data has been downloaded."
    new "Descarga de los datos del juego."

    # renpy/common/00updater.rpy:2086
    old "An error occured when trying to download game data:"
    new "Se ha producido un error al intentar descargar los datos del juego:"

    # renpy/common/00updater.rpy:2091
    old "This game cannot be run until the game data has been downloaded."
    new "Este juego no puede ejecutarse hasta que se hayan descargado los datos del juego."

    # renpy/common/00updater.rpy:2098
    old "Retry"
    new "Reintentar"

    # renpy/common/00compat.rpy:442
    old "Fullscreen"
    new "Pantalla completa"

    # renpy/common/00gallery.rpy:643
    old "Image [index] of [count] locked."
    new "Imagen [index] de [count] bloqueada."

    # renpy/common/00gallery.rpy:663
    old "prev"
    new "ant."

    # renpy/common/00gallery.rpy:664
    old "next"
    new "sig."

    # renpy/common/00gallery.rpy:665
    old "slideshow"
    new "presentación"

    # renpy/common/00gallery.rpy:666
    old "return"
    new "volver"

    # renpy/common/00gltest.rpy:90
    old "Renderer"
    new "Renderizador"

    # renpy/common/00gltest.rpy:94
    old "Automatically Choose"
    new "Escoger automáticamente"

    # renpy/common/00gltest.rpy:101
    old "Force GL Renderer"
    new "Forzar renderizador GL"

    # renpy/common/00gltest.rpy:106
    old "Force ANGLE Renderer"
    new "Forzar renderizador ANGLE"

    # renpy/common/00gltest.rpy:111
    old "Force GLES Renderer"
    new "Forzar renderizador GLES"

    # renpy/common/00gltest.rpy:117
    old "Force GL2 Renderer"
    new "Forzar renderizador GL2"

    # renpy/common/00gltest.rpy:122
    old "Force ANGLE2 Renderer"
    new "Forzar renderizador ANGLE2"

    # renpy/common/00gltest.rpy:127
    old "Force GLES2 Renderer"
    new "Forzar renderizador GLES2"

    # renpy/common/00gltest.rpy:133
    old "Gamepad"
    new "Mando"

    # renpy/common/00gltest.rpy:137
    old "Enable (No Blocklist)"
    new "Habilitar (sin Blocklist)"

    # renpy/common/00gltest.rpy:151
    old "Calibrate"
    new "Calibrar"

    # renpy/common/00gltest.rpy:160
    old "Powersave"
    new "Ahorro de energía"

    # renpy/common/00gltest.rpy:174
    old "Framerate"
    new "Cuadros por segundo"

    # renpy/common/00gltest.rpy:178
    old "Screen"
    new "Pantalla"

    # renpy/common/00gltest.rpy:182
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:186
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:192
    old "Tearing"
    new "Tearing"

    # renpy/common/00gltest.rpy:208
    old "Changes will take effect the next time this program is run."
    new "Los cambios se aplicarán la próxima vez que el programa se ejecute."

    # renpy/common/00gltest.rpy:215
    old "Quit"
    new "Salir"

    # renpy/common/00gltest.rpy:244
    old "Performance Warning"
    new "Aviso de funcionamiento"

    # renpy/common/00gltest.rpy:249
    old "This computer is using software rendering."
    new "Este ordenador usa 'software' de renderizado."

    # renpy/common/00gltest.rpy:251
    old "This game requires use of GL2 that can't be initialised."
    new "Este juego requiere el uso de GL2, el cual no se puede iniciar."

    # renpy/common/00gltest.rpy:253
    old "This computer has a problem displaying graphics: [problem]."
    new "Este ordenador tiene un problema al mostrar los gráficos: [problem]."

    # renpy/common/00gltest.rpy:257
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Los controladores gráficos pueden estar obsoletos o no funcionar adecuadamente. Esto puede conllevar que los gráficos se muestren lenta o incorrectamente."

    # renpy/common/00gltest.rpy:261
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "El archivo {a=edit:1:log.txt}log.txt{/a} puede contener información para ayudarte a encontrar el problema en tu ordenador."

    # renpy/common/00gltest.rpy:266
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Puedes encontrar más detalles sobre cómo solucionar este problema en la {a=[url]} documentación {/a}."

    # renpy/common/00gltest.rpy:271
    old "Continue, Show this warning again"
    new "Continuar. Mostrar este aviso de nuevo"

    # renpy/common/00gltest.rpy:275
    old "Continue, Don't show warning again"
    new "Continuar. No mostrar este aviso de nuevo"

    # renpy/common/00gltest.rpy:283
    old "Change render options"
    new "Cambiar las opciones de renderizado"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Selecciona mando para calibrar"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "No hay mandos disponibles"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Presiona o mueve el '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Saltar (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Atrás (B)"

    # renpy/common/_errorhandling.rpym:674
    old "Open"
    new "Abrir"

    # renpy/common/_errorhandling.rpym:676
    old "Opens the traceback.txt file in a text editor."
    new "Abre el archivo de rastreo 'traceback.txt' en un editor de texto."

    # renpy/common/_errorhandling.rpym:678
    old "Copy BBCode"
    new "Copiar BBCode"

    # renpy/common/_errorhandling.rpym:680
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia el archivo traceback.txt en el portapapeles como BBcode para foros como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:682
    old "Copy Markdown"
    new "Copiar Markdown"

    # renpy/common/_errorhandling.rpym:684
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia el archivo traceback.txt al portapapeles como Markdown paara Discord."

    # renpy/common/_errorhandling.rpym:716
    old "An exception has occurred."
    new "Ha sucedido una excepción."

    # renpy/common/_errorhandling.rpym:739
    old "Rollback"
    new "Volver atrás"

    # renpy/common/_errorhandling.rpym:741
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Intenta volver a un momento anterior y permite guardar o escoger una opción diferente."

    # renpy/common/_errorhandling.rpym:744
    old "Ignore"
    new "Ignorar"

    # renpy/common/_errorhandling.rpym:748
    old "Ignores the exception, allowing you to continue."
    new "Ignora la excepción y permite continuar."

    # renpy/common/_errorhandling.rpym:750
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora la excepción y permite continuar. Suele conllevar más errores."

    # renpy/common/_errorhandling.rpym:754
    old "Reload"
    new "Recargar"

    # renpy/common/_errorhandling.rpym:756
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarga el juego desde el disco, guardando y restaurando la partida si es posible."

    # renpy/common/_errorhandling.rpym:759
    old "Console"
    new "Consola"

    # renpy/common/_errorhandling.rpym:761
    old "Opens a console to allow debugging the problem."
    new "Abre una consola y permite depurar el problema."

    # renpy/common/_errorhandling.rpym:774
    old "Quits the game."
    new "Sale del juego."

    # renpy/common/_errorhandling.rpym:796
    old "Parsing the script failed."
    new "Error en el análisis del código."

    # renpy/common/_developer/developer.rpym:39
    old "Developer Menu"
    new "Menú de desarrollo"

    # renpy/common/_developer/developer.rpym:44
    old "Interactive Director (D)"
    new "Director interactivo (D)"

    # renpy/common/_developer/developer.rpym:46
    old "Reload Game (Shift+R)"
    new "Reiniciar juego (Mayús+R)"

    # renpy/common/_developer/developer.rpym:48
    old "Console (Shift+O)"
    new "Consola (Mayús.+O)"

    # renpy/common/_developer/developer.rpym:50
    old "Variable Viewer"
    new "Visor de variables"

    # renpy/common/_developer/developer.rpym:52
    old "Persistent Viewer"
    new "Visor de datos persistentes"

    # renpy/common/_developer/developer.rpym:54
    old "Image Location Picker"
    new "Selector de posición en imágenes"

    # renpy/common/_developer/developer.rpym:56
    old "Filename List"
    new "Lista de archivos"

    # renpy/common/_developer/developer.rpym:60
    old "Show Image Load Log (F4)"
    new "Mostrar registro de carga de imagen (F4)"

    # renpy/common/_developer/developer.rpym:63
    old "Hide Image Load Log (F4)"
    new "Ocultar registro de carga de imagen (F4)"

    # renpy/common/_developer/developer.rpym:66
    old "Image Attributes"
    new "Atributos de imagen"

    # renpy/common/_developer/developer.rpym:70
    old "Show Translation Info"
    new "Show Translation Info"

    # renpy/common/_developer/developer.rpym:73
    old "Hide Translation Info"
    new "Hide Translation Info"

    # renpy/common/_developer/developer.rpym:78
    old "Speech Bubble Editor (Shift+B)"
    new "Editor de burbujas de diálogo (Mayús+B)"

    # renpy/common/_developer/developer.rpym:82
    old "Show Filename and Line"
    new "Mostrar nombre de archivo y línea"

    # renpy/common/_developer/developer.rpym:85
    old "Hide Filename and Line"
    new "Ocultar nombre de archivo y línea"

    # renpy/common/_developer/developer.rpym:129
    old "Layer [l]:"
    new "Capa [l]:"

    # renpy/common/_developer/developer.rpym:133
    old "    [name!q] [attributes!q] (hidden)"
    new "    [name!q] [attributes!q] (hidden)"

    # renpy/common/_developer/developer.rpym:137
    old "    [name!q] [attributes!q]"
    new "    [name!q] [attributes!q]"

    # renpy/common/_developer/developer.rpym:190
    old "Nothing to inspect."
    new "Nada para inspeccionar."

    # renpy/common/_developer/developer.rpym:201
    old "Hide deleted"
    new "Ocultar borrados"

    # renpy/common/_developer/developer.rpym:201
    old "Show deleted"
    new "Mostrar borrados"

    # renpy/common/_developer/developer.rpym:352
    old "Rectangle copied to clipboard."
    new "Rectángulo copiado al portapapeles."

    # renpy/common/_developer/developer.rpym:355
    old "Position copied to clipboard."
    new "Posición copiada al portapapeles."

    # renpy/common/_developer/developer.rpym:367
    old "Rectangle: %r"
    new "Rectángulo: %r"

    # renpy/common/_developer/developer.rpym:370
    old "Mouse position: %r"
    new "Posición del ratón: %r"

    # renpy/common/_developer/developer.rpym:375
    old "Right-click or escape to quit."
    new "Clic-derecho o escape para salir."

    # renpy/common/_developer/developer.rpym:425
    old "Type to filter: "
    new "Tipo a filtrar: "

    # renpy/common/_developer/developer.rpym:544
    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new "Texturas: [tex_count] ([tex_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:548
    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new "Caché de imagen: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:558
    old "✔ "
    new "✔ "

    # renpy/common/_developer/developer.rpym:561
    old "✘ "
    new "✘ "

    # renpy/common/_developer/developer.rpym:566
    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ imagen prevista (correcto){/color}\n{color=#fcc}✘ imagen no prevista (fallido){/color}\n{color=#fff}Arrastra para mover.{/color}"

    # renpy/common/_developer/developer.rpym:616
    old "Click to open in editor."
    new "Haz clic para abrir en el editor."

    # renpy/common/_developer/inspector.rpym:39
    old "Displayable Inspector"
    new "Inspector de visualizables"

    # renpy/common/_developer/inspector.rpym:62
    old "Size"
    new "Tamaño"

    # renpy/common/_developer/inspector.rpym:66
    old "Style"
    new "Estilo"

    # renpy/common/_developer/inspector.rpym:72
    old "Location"
    new "Ubicación"

    # renpy/common/_developer/inspector.rpym:124
    old "Inspecting Styles of [displayable_name!q]"
    new "Inspeccionando estilos de [displayable_name!q]"

    # renpy/common/_developer/inspector.rpym:141
    old "displayable:"
    new "visualizable:"

    # renpy/common/_developer/inspector.rpym:147
    old "        (no properties affect the displayable)"
    new "        (no hay propiedades que afecten la visualización)"

    # renpy/common/_developer/inspector.rpym:149
    old "        (default properties omitted)"
    new "        (propiedades por defecto omitidas)"

    # renpy/common/_developer/inspector.rpym:187
    old "<repr() failed>"
    new "<repr() fallido>"

    # renpy/common/00console.rpy:538
    old "Press <esc> to exit console. Type help for help.\n"
    new "Presiona <esc> para salir de la consola. Escribe 'help' para obtener ayuda.\n"

    # renpy/common/00console.rpy:542
    old "Ren'Py script enabled."
    new "Script Ren'Py habilitado."

    # renpy/common/00console.rpy:544
    old "Ren'Py script disabled."
    new "Script Ren'Py deshabilitado."

    # renpy/common/00console.rpy:725
    old "The console is using short representations. To disable this, type 'long', and to re-enable, type 'short'"
    new "The console is using short representations. To disable this, type 'long', and to re-enable, type 'short'"

    # renpy/common/00console.rpy:797
    old "help: show this help\n help <expr>: show signature and documentation of <expr>"
    new "help: muestra esta ayuda\n help <expr>: muestra la firma y la documentación de <expr>"

    # renpy/common/00console.rpy:821
    old "Help may display undocumented functions. Please check that the function or\nclass you want to use is documented.\n\n"
    new "La ayuda puede mostrar funciones no documentadas. Por favor, compruebe que la función o\nclase que desea utilizar está documentada.\n\n"

    # renpy/common/00console.rpy:830
    old "commands:\n"
    new "comandos:\n"

    # renpy/common/00console.rpy:840
    old " <renpy script statement>: run the statement\n"
    new " <sentencia renpy script>: ejecuta la sentencia\n"

    # renpy/common/00console.rpy:842
    old " <python expression or statement>: run the expression or statement"
    new " <expresión o sentencia python>: ejecuta la expresión o sentencia"

    # renpy/common/00console.rpy:850
    old "clear: clear the console history"
    new "clear: limpia el historial de la consola"

    # renpy/common/00console.rpy:854
    old "exit: exit the console"
    new "exit: sale de la consola"

    # renpy/common/00console.rpy:862
    old "stack: print the return stack"
    new "stack: imprime la pila de retorno"

    # renpy/common/00console.rpy:884
    old "load <slot>: loads the game from slot"
    new "load <slot>: carga el juego desde la ranura"

    # renpy/common/00console.rpy:897
    old "save <slot>: saves the game in slot"
    new "save <slot>: guarda el juego en la ranura"

    # renpy/common/00console.rpy:908
    old "reload: reloads the game, refreshing the scripts"
    new "reload: recarga el juego, actualizando los 'scripts'"

    # renpy/common/00console.rpy:916
    old "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"
    new "watch <expression>: observa una expresión de Python\n watch short: hace que la representación de las expresiones rastreadas sea corta (predeterminado)\n watch long: hace que la representación de las expresiones rastreadas sea corta"

    # renpy/common/00console.rpy:953
    old "unwatch <expression>: stop watching an expression"
    new "unwatch <expresión>: deja de observar una expresión"

    # renpy/common/00console.rpy:999
    old "unwatchall: stop watching all expressions"
    new "unwatchall: deja de observar todas las expresiones"

    # renpy/common/00console.rpy:1020
    old "jump <label>: jumps to label"
    new "jump <label>: salta a la etiqueta"

    # renpy/common/00console.rpy:1036
    old "short: Shorten the representation of objects on the console (default)."
    new "short: Acorta la representación de los objetos en la consola (predeterminado)."

    # renpy/common/00console.rpy:1040
    old "long: Print the full representation of objects on the console."
    new "long: imprime la representación completa de los objetos en la consola."

    # renpy/common/00console.rpy:1044
    old "escape: Enables escaping of unicode symbols in unicode strings."
    new "escape: habilita el escape de símbolos Unicode en cadenas Unicode."

    # renpy/common/00console.rpy:1048
    old "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."
    new "unescape: Desactiva el escape de símbolos Unicode en cadenas Unicode y lo imprime como está (predeterminado)."

# TODO: Translation updated at 2025-10-25 17:22

translate english strings:

    # renpy/common/00sync.rpy:448
    old "Yes"
    new "Sí"

