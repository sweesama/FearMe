﻿# TODO: Translation updated at 2025-10-24 16:08

translate english strings:

    # game/resources.rpy:9
    old "Periodista"
    new "Journalist"

    # game/resources.rpy:10
    old "Terapeuta"
    new "Therapist"

    # game/resources.rpy:11
    old "Policia"
    new "Police Officer"

# TODO: Translation updated at 2025-11-01 17:57

translate english strings:

    # game/resources.rpy:7
    old "T. Wes"
    new "L. Wes"

# TODO: Translation updated at 2026-01-07 21:02

translate english strings:

    # game/resources.rpy:4
    old "Jeff"
    new "Jeff"

    # game/resources.rpy:6
    old "Dr. Salazar"
    new "Dr. Salazar"

    # game/resources.rpy:8
    old "D. Sean"
    new "D. Sean"

