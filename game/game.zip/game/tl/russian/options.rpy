﻿# TODO: Translation updated at 2025-12-29 21:05

translate russian strings:

    # game/options.rpy:16
    old "Fear Me"
    new "Бойся меня"

