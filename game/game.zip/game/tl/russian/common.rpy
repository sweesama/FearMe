﻿# TODO: Translation updated at 2025-12-29 21:05

translate russian strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Самоозвучка отключена."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Включена озвучка буфера обмена."

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Самоозвучка включена."

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "панель"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "выбрано"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "окно просмотра"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "горизонтальная прокрутка"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "вертикальная прокрутка"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "активировать"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "деактивировать"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "увеличить"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "уменьшить"

    # renpy/common/00accessibility.rpy:122
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Меню специальных возможностей. Используйте стрелки вверх и вниз для навигации, и Enter для активации кнопок и панелей."

    # renpy/common/00accessibility.rpy:141
    old "Font Override"
    new "Переопределение шрифта"

    # renpy/common/00accessibility.rpy:145
    old "Default"
    new "По умолчанию"

    # renpy/common/00accessibility.rpy:149
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:153
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:159
    old "Text Size Scaling"
    new "Масштабирование текста"

    # renpy/common/00accessibility.rpy:165
    old "Reset"
    new "Сброс"

    # renpy/common/00accessibility.rpy:171
    old "Line Spacing Scaling"
    new "Масштабирование межстрочного интервала"

    # renpy/common/00accessibility.rpy:183
    old "High Contrast Text"
    new "Высококонтрастный текст"

    # renpy/common/00accessibility.rpy:185
    old "Enable"
    new "Включить"

    # renpy/common/00accessibility.rpy:189
    old "Disable"
    new "Выключить"

    # renpy/common/00accessibility.rpy:196
    old "Self-Voicing"
    new "Самоозвучка"

    # renpy/common/00accessibility.rpy:199
    old "Self-voicing support is limited when using a touch screen."
    new "При использовании сенсорного экрана поддержка самоозвучки ограничена."

    # renpy/common/00accessibility.rpy:203
    old "Off"
    new "Выкл"

    # renpy/common/00accessibility.rpy:207
    old "Text-to-speech"
    new "Преобразование текста в речь"

    # renpy/common/00accessibility.rpy:211
    old "Clipboard"
    new "Буфер обмена"

    # renpy/common/00accessibility.rpy:215
    old "Debug"
    new "Отладка"

    # renpy/common/00accessibility.rpy:221
    old "Voice Volume"
    new "Громкость озвучки"

    # renpy/common/00accessibility.rpy:229
    old "Self-Voicing Volume Drop"
    new "Снижение громкости самоозвучки"

    # renpy/common/00accessibility.rpy:238
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Параметры в этом меню предназначены для улучшения возможностей. Они могут работать не со всеми играми, а некоторые комбинации параметров могут сделать игру неиграбельной. Это не является проблемой игры или движка. Для достижения наилучших результатов при изменении шрифтов старайтесь сохранять размер текста таким же, как и изначально."

    # renpy/common/00accessibility.rpy:243
    old "Return"
    new "Вернуться"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Понедельник"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Вторник"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Среда"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Четверг"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Пятница"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Суббота"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Воскресенье"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Пн"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Вт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Ср"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Чт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Пт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Сб"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Вс"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Январь"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Февраль"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Март"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Апрель"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Май"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Июнь"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Июль"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Август"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Сентябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Октябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Ноябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Декабрь"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Янв"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Февр"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Март"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Апр"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}Май"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Июнь"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Июль"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Авг"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Сент"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Окт"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Нояб"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Дек"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%d de %b, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Сохранить слот %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Загрузить слот %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Удалить слот [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Автоматическая страница файла"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Быстрая страница файла"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Страница файла [text]"

    # renpy/common/00action_file.rpy:675
    old "Page {}"
    new "Страница {}"

    # renpy/common/00action_file.rpy:675
    old "Automatic saves"
    new "Автоматические сохранения"

    # renpy/common/00action_file.rpy:675
    old "Quick saves"
    new "Быстрые сохранения"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Следующая страница файла."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Предыдущая страница файла."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Быстрое сохранение завершено."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Быстрое сохранение."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Быстрая загрузка."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Язык [text]"

    # renpy/common/00action_other.rpy:781
    old "Open [text] directory."
    new "Открыть каталог [text]."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "Интерактивный директор здесь не включен."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "Готово"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(sentencia)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(etiqueta)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(transformación)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transición)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(archivo)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Изменить"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Добавить"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Отменить"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Удалить"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Оператор:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Тег:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Атрибуты:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Щёлкните, чтобы переключить атрибут, щёлкните ПКМ, чтобы переключить отрицательный атрибут."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "Преобразования:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Щёлкните, чтобы установить преобразование, щёлкните ПКМ, чтобы добавить в список преобразований."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Настройте director.transforms, чтобы добавить дополнительные преобразования."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Задник:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Щёлкните, чтобы установить, щёлкните ПКМ, чтобы добавить в список задников."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Переход:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Щёлкните, чтобы установить."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Настройте director.transitions, чтобы добавить больше переходов."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Канал:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Настройте director.audio_channels, чтобы добавить больше каналов."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Название аудиофайла:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "Вы уверены?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "Вы уверены, что хотите удалить это сохранение?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "Вы уверены, что хотите перезаписать ваше сохранение?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "При загрузке будут потеряны несохраненные данные. Вы уверены, что хотите это сделать?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "Вы уверены, что хотите выйти?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Вы уверены, что хотите вернуться в главное меню?\nПри этом будет потерян несохраненный прогресс."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "Вы уверены, что хотите продолжить с того места, где остановились?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "Вы уверены, что хотите завершить воспроизведение?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "Вы уверены, что хотите начать пропуск?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "Вы уверены, что хотите перейти к следующему выбору?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Вы уверены, что хотите пропустить непрочитанный диалог и перейти к следующему выбору?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Этот файл сохранения был создан на другом устройстве. Злонамеренно созданные файлы сохранения могут нанести вред вашему компьютеру. Доверяете ли вы создателю этого файла сохранения и всем, кто мог изменить этот файл?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Доверяете ли вы устройству, на котором было создано сохранение? Вы должны выбрать Да только в том случае, если вы являетесь единственным пользователем этого устройства."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "Не удалось сохранить скриншот как %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Скриншот сохранён как %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Режим пропуска"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Эта программа содержит бесплатное программное обеспечение, распространяемое по ряду лицензий, включая лицензию MIT и GNU Lesser General Public License. Полный список программного обеспечения, включая ссылки на полный исходный код, можно найти {a=https://www.renpy.org/l/license}здесь{/a}."

    # renpy/common/00preferences.rpy:290
    old "display"
    new "дисплей"

    # renpy/common/00preferences.rpy:310
    old "transitions"
    new "переходы"

    # renpy/common/00preferences.rpy:319
    old "skip transitions"
    new "пропуск переходов"

    # renpy/common/00preferences.rpy:321
    old "video sprites"
    new "видео спрайты"

    # renpy/common/00preferences.rpy:330
    old "show empty window"
    new "показать пустое окно"

    # renpy/common/00preferences.rpy:339
    old "text speed"
    new "скорость текста"

    # renpy/common/00preferences.rpy:347
    old "joystick"
    new "джойстик"

    # renpy/common/00preferences.rpy:347
    old "joystick..."
    new "джойстик..."

    # renpy/common/00preferences.rpy:354
    old "skip"
    new "пропуск"

    # renpy/common/00preferences.rpy:357
    old "skip unseen [text]"
    new "пропустить непрочитанный [text]"

    # renpy/common/00preferences.rpy:362
    old "skip unseen text"
    new "пропустить непрочитанный текст"

    # renpy/common/00preferences.rpy:364
    old "begin skipping"
    new "начать пропуск"

    # renpy/common/00preferences.rpy:368
    old "after choices"
    new "после выборов"

    # renpy/common/00preferences.rpy:375
    old "skip after choices"
    new "пропуск после выборов"

    # renpy/common/00preferences.rpy:377
    old "auto-forward time"
    new "время автопрокрутки"

    # renpy/common/00preferences.rpy:391
    old "auto-forward"
    new "автопрокрутка"

    # renpy/common/00preferences.rpy:398
    old "Auto forward"
    new "Автопрокрутка"

    # renpy/common/00preferences.rpy:401
    old "auto-forward after click"
    new "автопрокрутка после клика"

    # renpy/common/00preferences.rpy:410
    old "automatic move"
    new "автоматическое движение"

    # renpy/common/00preferences.rpy:419
    old "wait for voice"
    new "ждать озвучки"

    # renpy/common/00preferences.rpy:428
    old "voice sustain"
    new "поддержание озвучки"

    # renpy/common/00preferences.rpy:437
    old "self voicing"
    new "самоозвучка"

    # renpy/common/00preferences.rpy:440
    old "self voicing enable"
    new "включить самоозвучку"

    # renpy/common/00preferences.rpy:442
    old "self voicing disable"
    new "выключить самоозвучку"

    # renpy/common/00preferences.rpy:446
    old "self voicing volume drop"
    new "снижение громкости самоозвучки"

    # renpy/common/00preferences.rpy:454
    old "clipboard voicing"
    new "озвучка буфера обмена"

    # renpy/common/00preferences.rpy:457
    old "clipboard voicing enable"
    new "включить озвучку буфера обмена"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing disable"
    new "выключить озвучку буфера обмена"

    # renpy/common/00preferences.rpy:463
    old "debug voicing"
    new "отладка озвучки"

    # renpy/common/00preferences.rpy:466
    old "debug voicing enable"
    new "включить отладку озвучки"

    # renpy/common/00preferences.rpy:468
    old "debug voicing disable"
    new "выключить отладку озвучки"

    # renpy/common/00preferences.rpy:472
    old "emphasize audio"
    new "подчеркнуть аудио"

    # renpy/common/00preferences.rpy:481
    old "rollback side"
    new "сторона отката"

    # renpy/common/00preferences.rpy:491
    old "gl powersave"
    new "gl энергосбережение"

    # renpy/common/00preferences.rpy:497
    old "gl framerate"
    new "gl частота кадров"

    # renpy/common/00preferences.rpy:500
    old "gl tearing"
    new "gl разрывы"

    # renpy/common/00preferences.rpy:503
    old "font transform"
    new "трансформация шрифта"

    # renpy/common/00preferences.rpy:506
    old "font size"
    new "размер шрифта"

    # renpy/common/00preferences.rpy:514
    old "font line spacing"
    new "межстрочный интервал шрифта"

    # renpy/common/00preferences.rpy:522
    old "system cursor"
    new "системный курсор"

    # renpy/common/00preferences.rpy:531
    old "renderer menu"
    new "меню рендерера"

    # renpy/common/00preferences.rpy:534
    old "accessibility menu"
    new "меню специальных возможностей"

    # renpy/common/00preferences.rpy:537
    old "high contrast text"
    new "высококонтрастный текст"

    # renpy/common/00preferences.rpy:546
    old "audio when minimized"
    new "аудио при минимизации"

    # renpy/common/00preferences.rpy:555
    old "audio when unfocused"
    new "аудио при расфокусировке"

    # renpy/common/00preferences.rpy:564
    old "web cache preload"
    new "предварительная загрузка веб-кеша"

    # renpy/common/00preferences.rpy:579
    old "voice after game menu"
    new "озвучка после игрового меню"

    # renpy/common/00preferences.rpy:588
    old "restore window position"
    new "восстановить положение окна"

    # renpy/common/00preferences.rpy:597
    old "reset"
    new "сброс"

    # renpy/common/00preferences.rpy:610
    old "main volume"
    new "основная громкость"

    # renpy/common/00preferences.rpy:611
    old "music volume"
    new "громкость музыки"

    # renpy/common/00preferences.rpy:612
    old "sound volume"
    new "громкость звуков"

    # renpy/common/00preferences.rpy:613
    old "voice volume"
    new "громкость озвучки"

    # renpy/common/00preferences.rpy:614
    old "mute main"
    new "заглушить основной"

    # renpy/common/00preferences.rpy:615
    old "mute music"
    new "заглушить музыку"

    # renpy/common/00preferences.rpy:616
    old "mute sound"
    new "заглушить звуки"

    # renpy/common/00preferences.rpy:617
    old "mute voice"
    new "заглушить озвучку"

    # renpy/common/00preferences.rpy:618
    old "mute all"
    new "заглушить всё"

    # renpy/common/00preferences.rpy:701
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Включена озвучка буфера обмена. Нажмите shift+C, чтобы выключить."

    # renpy/common/00preferences.rpy:703
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Самоозвучка будет произносить \"[renpy.display.tts.last]\". Нажмите alt+shift+V, чтобы выключить."

    # renpy/common/00preferences.rpy:705
    old "Self-voicing enabled. Press 'v' to disable."
    new "Самоозвучка включена. Нажмите v, чтобы выключить."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Редактор диалоговых пузырей"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(ocultar)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(borrar burbujas retenidas)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Синхронизация загружена."

    # renpy/common/00sync.rpy:193
    old "Could not connect to the Ren'Py Sync server."
    new "Не удалось установить соединение с сервером синхронизации Ren'Py."

    # renpy/common/00sync.rpy:195
    old "The Ren'Py Sync server timed out."
    new "Сервер синхронизации Ren'Py превысил время ожидания."

    # renpy/common/00sync.rpy:197
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Произошла неизвестная ошибка при подключении к серверу синхронизации Ren'Py."

    # renpy/common/00sync.rpy:213
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Сервер синхронизации Ren'Py не имеет копии этой синхронизации. Идентификатор синхронизации может быть недействительным или истёк срок его действия."

    # renpy/common/00sync.rpy:316
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Пожалуйста, введите сгенерированный вами идентификатор синхронизации. Ни в коем случае не вводите идентификатор синхронизации, который вы не создавали самостоятельно."

    # renpy/common/00sync.rpy:335
    old "The sync ID is not in the correct format."
    new "Идентификатор синхронизации не соответствует требуемому формату."

    # renpy/common/00sync.rpy:355
    old "The sync could not be decrypted."
    new "Не удалось расшифровать синхронизацию."

    # renpy/common/00sync.rpy:378
    old "The sync belongs to a different game."
    new "Синхронизация принадлежит другой игре."

    # renpy/common/00sync.rpy:383
    old "The sync contains a file with an invalid name."
    new "Синхронизация содержит файл с недопустимым именем."

    # renpy/common/00sync.rpy:440
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Это загрузит ваши сохранения на {a=https://sync.renpy.org}Сервер синхронизации Ren'Py{/a}.\nПродолжить?"

    # renpy/common/00sync.rpy:448
    old "Yes"
    new "Да"

    # renpy/common/00sync.rpy:472
    old "Enter Sync ID"
    new "Введите идентификатор синхронизации"

    # renpy/common/00sync.rpy:483
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Это приведет к подключению к {a=https://sync.renpy.org}Серверу синхронизации Ren'Py{/a}."

    # renpy/common/00sync.rpy:513
    old "Sync Success"
    new "Синхронизация успешно завершена"

    # renpy/common/00sync.rpy:516
    old "The Sync ID is:"
    new "Идентификатор синхронизации:"

    # renpy/common/00sync.rpy:522
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Вы можете использовать этот идентификатор для загрузки вашего сохранения на другое устройство.\nЭта синхронизация истечёт через час.\nСинхронизация Ren'Py поддерживается {a=https://www.renpy.org/sponsors.html}спонсорами Ren'Py{/a}."

    # renpy/common/00sync.rpy:526
    old "Continue"
    new "Продолжить"

    # renpy/common/00sync.rpy:551
    old "Sync Error"
    new "Ошибка синхронизации"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Идентификатор перехода: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " переводит [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Скопировано в буфер обмена.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Установление связи с App Store\nПожалуйста, подождите..."

    # renpy/common/00updater.rpy:505
    old "No update methods found."
    new "Методы обновления не найдены."

    # renpy/common/00updater.rpy:552
    old "Could not download file list: "
    new "Не удалось загрузить список файлов: "

    # renpy/common/00updater.rpy:555
    old "File list digest does not match."
    new "Дайджест списка файлов не совпадает."

    # renpy/common/00updater.rpy:765
    old "An error is being simulated."
    new "Симулируется ошибка."

    # renpy/common/00updater.rpy:953
    old "Either this project does not support updating, or the update status file was deleted."
    new "Этот проект не поддерживает обновление или файл статуса обновления был удалён."

    # renpy/common/00updater.rpy:967
    old "This account does not have permission to perform an update."
    new "Эта учётная запись не имеет прав на выполнение обновления."

    # renpy/common/00updater.rpy:970
    old "This account does not have permission to write the update log."
    new "Эта учётная запись не имеет прав на запись в журнал обновлений."

    # renpy/common/00updater.rpy:1050
    old "Could not verify update signature."
    new "Не удалось проверить подпись обновления."

    # renpy/common/00updater.rpy:1373
    old "The update file was not downloaded."
    new "Файл обновления не был загружен."

    # renpy/common/00updater.rpy:1391
    old "The update file does not have the correct digest - it may have been corrupted."
    new "Файл обновления не имеет правильного дайджеста — возможно, он повреждён."

    # renpy/common/00updater.rpy:1541
    old "While unpacking {}, unknown type {}."
    new "При распаковке {}, неизвестный тип {}."

    # renpy/common/00updater.rpy:2022
    old "Updater"
    new "Средство обновления"

    # renpy/common/00updater.rpy:2029
    old "An error has occured:"
    new "Произошла ошибка:"

    # renpy/common/00updater.rpy:2031
    old "Checking for updates."
    new "Проверка обновлений."

    # renpy/common/00updater.rpy:2033
    old "This program is up to date."
    new "Эта программа обновлена."

    # renpy/common/00updater.rpy:2035
    old "[u.version] is available. Do you want to install it?"
    new "Версия [u.version] доступна. Хотите установить?"

    # renpy/common/00updater.rpy:2037
    old "Preparing to download the updates."
    new "Подготовка к загрузке обновлений."

    # renpy/common/00updater.rpy:2039
    old "Downloading the updates."
    new "Загрузка обновлений."

    # renpy/common/00updater.rpy:2041
    old "Unpacking the updates."
    new "Распаковка обновлений."

    # renpy/common/00updater.rpy:2043
    old "Finishing up."
    new "Завершение."

    # renpy/common/00updater.rpy:2045
    old "The updates have been installed. The program will restart."
    new "Обновления установлены. Программа перезапустится."

    # renpy/common/00updater.rpy:2047
    old "The updates have been installed."
    new "Обновления установлены."

    # renpy/common/00updater.rpy:2049
    old "The updates were cancelled."
    new "Обновления были отменены."

    # renpy/common/00updater.rpy:2064
    old "Proceed"
    new "Продолжить"

    # renpy/common/00updater.rpy:2080
    old "Preparing to download the game data."
    new "Подготовка к загрузке данных игры."

    # renpy/common/00updater.rpy:2082
    old "Downloading the game data."
    new "Загрузка данных игры."

    # renpy/common/00updater.rpy:2084
    old "The game data has been downloaded."
    new "Данные игры были загружены."

    # renpy/common/00updater.rpy:2086
    old "An error occured when trying to download game data:"
    new "При попытке загрузить данные игры произошла ошибка:"

    # renpy/common/00updater.rpy:2091
    old "This game cannot be run until the game data has been downloaded."
    new "Эта игра не может быть запущена до тех пор, пока не будут загружены данные игры."

    # renpy/common/00updater.rpy:2098
    old "Retry"
    new "Повторить"

    # renpy/common/00compat.rpy:442
    old "Fullscreen"
    new "Полноэкранный режим"

    # renpy/common/00gallery.rpy:643
    old "Image [index] of [count] locked."
    new "Изображение [index] из [count] заблокировано."

    # renpy/common/00gallery.rpy:663
    old "prev"
    new "предыдущий"

    # renpy/common/00gallery.rpy:664
    old "next"
    new "следующий"

    # renpy/common/00gallery.rpy:665
    old "slideshow"
    new "слайдшоу"

    # renpy/common/00gallery.rpy:666
    old "return"
    new "вернуться"

    # renpy/common/00gltest.rpy:90
    old "Renderer"
    new "Рендерер"

    # renpy/common/00gltest.rpy:94
    old "Automatically Choose"
    new "Выбрать автоматически"

    # renpy/common/00gltest.rpy:101
    old "Force GL Renderer"
    new "Принудительно использовать рендерер GL"

    # renpy/common/00gltest.rpy:106
    old "Force ANGLE Renderer"
    new "Принудительно использовать рендерер ANGLE"

    # renpy/common/00gltest.rpy:111
    old "Force GLES Renderer"
    new "Принудительно использовать рендерер GLES"

    # renpy/common/00gltest.rpy:117
    old "Force GL2 Renderer"
    new "Принудительно использовать рендерер GL2"

    # renpy/common/00gltest.rpy:122
    old "Force ANGLE2 Renderer"
    new "Принудительно использовать рендерер ANGLE2"

    # renpy/common/00gltest.rpy:127
    old "Force GLES2 Renderer"
    new "Принудительно использовать рендерер GLES2"

    # renpy/common/00gltest.rpy:133
    old "Gamepad"
    new "Геймпад"

    # renpy/common/00gltest.rpy:137
    old "Enable (No Blocklist)"
    new "Включить (No Blocklist)"

    # renpy/common/00gltest.rpy:151
    old "Calibrate"
    new "Калибровка"

    # renpy/common/00gltest.rpy:160
    old "Powersave"
    new "Энергосбережение"

    # renpy/common/00gltest.rpy:174
    old "Framerate"
    new "Частота кадров"

    # renpy/common/00gltest.rpy:178
    old "Screen"
    new "Экран"

    # renpy/common/00gltest.rpy:182
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:186
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:192
    old "Tearing"
    new "Разрыв"

    # renpy/common/00gltest.rpy:208
    old "Changes will take effect the next time this program is run."
    new "Изменения вступят в силу при следующем запуске программы."

    # renpy/common/00gltest.rpy:215
    old "Quit"
    new "Выйти"

    # renpy/common/00gltest.rpy:244
    old "Performance Warning"
    new "Предупреждение о производительности"

    # renpy/common/00gltest.rpy:249
    old "This computer is using software rendering."
    new "Этот компьютер использует программный рендеринг."

    # renpy/common/00gltest.rpy:251
    old "This game requires use of GL2 that can't be initialised."
    new "Эта игра требует использования GL2, которое не может быть инициализировано."

    # renpy/common/00gltest.rpy:253
    old "This computer has a problem displaying graphics: [problem]."
    new "На этом компьютере возникла проблема с отображением графики: [problem]."

    # renpy/common/00gltest.rpy:257
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Графические драйверы могут быть устаревшими или работать некорректно. Это может привести к замедлению или некорректному отображению графики."

    # renpy/common/00gltest.rpy:261
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "Файл {a=edit:1:log.txt}log.txt{/a} может содержать информацию, которая поможет вам определить, что не так с вашим компьютером."

    # renpy/common/00gltest.rpy:266
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Более подробную информацию о том, как исправить эту проблему, можно найти в {a=[url]}документации{/a}."

    # renpy/common/00gltest.rpy:271
    old "Continue, Show this warning again"
    new "Продолжить, показать это предупреждение снова"

    # renpy/common/00gltest.rpy:275
    old "Continue, Don't show warning again"
    new "Продолжить, не показывать предупреждение снова"

    # renpy/common/00gltest.rpy:283
    old "Change render options"
    new "Изменить параметры рендеринга"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Выбрать геймпад для калибровки"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "Нет доступных геймпадов"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Калибровка [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Нажмите или переместите '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Пропуск (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Назад (B)"

    # renpy/common/_errorhandling.rpym:674
    old "Open"
    new "Открыть"

    # renpy/common/_errorhandling.rpym:676
    old "Opens the traceback.txt file in a text editor."
    new "Открывает файл traceback.txt в текстовом редакторе."

    # renpy/common/_errorhandling.rpym:678
    old "Copy BBCode"
    new "Копировать BBCode"

    # renpy/common/_errorhandling.rpym:680
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Копирует файл traceback.txt в буфер обмена как BBcode для таких форумов, как https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:682
    old "Copy Markdown"
    new "Копировать Markdown"

    # renpy/common/_errorhandling.rpym:684
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Копирует файл traceback.txt в буфер обмена как Markdown для Discord."

    # renpy/common/_errorhandling.rpym:716
    old "An exception has occurred."
    new "Произошло исключение."

    # renpy/common/_errorhandling.rpym:739
    old "Rollback"
    new "Откат"

    # renpy/common/_errorhandling.rpym:741
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Попытка отката к предыдущему моменту времени, позволяющая сохранить или выбрать другой вариант."

    # renpy/common/_errorhandling.rpym:744
    old "Ignore"
    new "Игнорировать"

    # renpy/common/_errorhandling.rpym:748
    old "Ignores the exception, allowing you to continue."
    new "Игнорирует исключение, позволяя вам продолжить."

    # renpy/common/_errorhandling.rpym:750
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Игнорирует исключение, позволяя вам продолжить. Это часто приводит к дополнительным ошибкам."

    # renpy/common/_errorhandling.rpym:754
    old "Reload"
    new "Перезагрузить"

    # renpy/common/_errorhandling.rpym:756
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Перезагружает игру с диска, сохраняя и восстанавливая состояние игры, если это возможно."

    # renpy/common/_errorhandling.rpym:759
    old "Console"
    new "Консоль"

    # renpy/common/_errorhandling.rpym:761
    old "Opens a console to allow debugging the problem."
    new "Открывает консоль для отладки проблемы."

    # renpy/common/_errorhandling.rpym:774
    old "Quits the game."
    new "Закрывает игру."

    # renpy/common/_errorhandling.rpym:796
    old "Parsing the script failed."
    new "Сбой при разборе скрипта."

