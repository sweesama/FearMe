﻿# TODO: Translation updated at 2025-12-29 21:05

#translate russian strings:

    # game/resources.rpy:7
    # old "T. Wes"
    # new "Л. Уес"

    # game/resources.rpy:9
    # old "Periodista"
    # new "Репортёр"

    # game/resources.rpy:10
    # old "Terapeuta"
    # new "Психолог"

    # game/resources.rpy:11
    # old "Policia"
    # new "Полицейский"

    # game/resources.rpy:4
    # old "Jeff"
    # new "Джефф"

    # game/resources.rpy:5
    # old "Cindy"
    # new "Синди"

    # game/resources.rpy:6
    # old "Dr. Salazar"
    # new "Д-р Салазар"

    # game/resources.rpy:8
    # old "D. Sean"
    # new "Д. Шон"
    
# TODO: Translation updated at 2026-01-07 12:56

translate russian strings:

    # game/resources.rpy:4
    old "Jeff"
    new "Джефф"

    # game/resources.rpy:6
    old "Dr. Salazar"
    new "Д-р Салазар"

    # game/resources.rpy:7
    old "T. Wes"
    new "Л. Уэс"

    # game/resources.rpy:9
    old "Periodista"
    new "Репортёр"

    # game/resources.rpy:10
    old "Terapeuta"
    new "Психолог"

    # game/resources.rpy:11
    old "Policia"
    new "Полицейский"

# TODO: Translation updated at 2026-01-07 13:01

translate russian strings:

    # game/resources.rpy:8
    old "D. Sean"
    new "Д. Шон"

