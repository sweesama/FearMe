﻿# TODO: Translation updated at 2025-12-29 21:05

# game/script.rpy:89
translate russian start_253e915d:

    # "La habitación está en silencio, iluminada por la cálida luz del mediodía que se filtra por la ventana."
    "В комнате тихо, она залита тёплым полуденным светом, пробивающимся сквозь окно."

# game/script.rpy:90
translate russian start_5bd4202f:

    # "Miras a cualquier parte que no sea tu terapeuta. Aún no tenías la confianza de hablar con familiaridad."
    "Вы смотрите куда угодно, только не на своего психолога. Вы всё ещё не чувствовали себя достаточно комфортно, чтобы говорить откровенно."

# game/script.rpy:91
translate russian start_6c536a08:

    # "Asistir a esas sesiones se sentía como tarea. Más que por tu bien, parecía ser una manera de vigilarte."
    "Посещение этих сеансов казалось обязанностью. Это было похоже не столько на заботу, сколько на способ контролировать вас."

# game/script.rpy:92
translate russian start_d3cf8ed6:

    # T "Sabes que no tienes obligación de hablar de él."
    T "Ты ведь знаешь, что не обязаны говорить о нём."

# game/script.rpy:93
translate russian start_9a1d3ee0:

    # "El terapeuta te miraba con paciencia, apoyando su espalda en el respaldo de su sillón con calma."
    "Психолог терпеливо наблюдает за вами, спокойно откинувшись на спинку кресла."

# game/script.rpy:94
translate russian start_317bbe28:

    # T "Puedes hablar de lo que quieras."
    T "Можешь говорить о чём угодно."

# game/script.rpy:95
translate russian start_e427c5c8:

    # "Tú resoplas con ironía, sin dar respuesta."
    "Вы иронично усмехаетесь, ничего не отвечая."

# game/script.rpy:96
translate russian start_03a479b0:

    # T "Fueron 7 días. Suficiente para que alguien cambie, ¿No crees?"
    T "Прошло 7 дней. Достаточно, чтобы кто-то изменился, не думаешь?"

# game/script.rpy:97
translate russian start_ce4635fc:

    # "Instintivamente, alzas la mano al lado izquierdo de tu rostro, donde tienes un parche cubriendo el lugar de tu ojo izquierdo."
    "Вы инстинктивно поднимаете руку к левой стороне лица, где повязка скрывает ваш левый глаз."

# game/script.rpy:98
translate russian start_a6f596a2:

    # T "Te hizo daño, no hay duda de eso. La policía, el hospital... todos tienen su versión. Pero yo quiero la tuya."
    T "Он причинил тебе боль — в этом нет сомнений. Полиция, больница... у всех есть своя версия. Но я хочу услышать твою."

# game/script.rpy:99
translate russian start_c191c049:

    # "Te encoges de hombros."
    "Вы пожимаете плечами."

# game/script.rpy:100
translate russian start_01299a9d:

    # T "Está bien. El silencio es una respuesta."
    T "Хорошо. Молчание — тоже ответ."

# game/script.rpy:101
translate russian start_05c4662d:

    # "Miras hacia la ventana, en el vidrio se distinguía la silueta de tu reflejo."
    "Вы смотрите в сторону окна; в стекле виднеется смутный силуэт вашего отражения."

# game/script.rpy:102
translate russian start_4e6749f3:

    # "A pesar de que no te veías con tanta claridad, tu postura y expresión eran notablemente diferentes a una semana atrás."
    "Пусть вы и не могли себя рассмотреть, осанка и выражение лица заметно отличались от тех, что были неделей раньше."

# game/script.rpy:120
translate russian start_81875c7e:

    # "El inicio de tu turno es como el botón “Comenzar” de tu vida."
    "Начало вашей смены — как кнопка «Старт» в вашей жизни."

# game/script.rpy:121
translate russian start_7956f306:

    # "Tienes una rutina clara, despertar, trabajar y dormir."
    "У вас есть простая рутина: проснуться, поработать, лечь спать."

# game/script.rpy:122
translate russian start_f9519c9e:

    # "No tienes un legado, no tienes ambiciones, no tienes asuntos pendientes."
    "У вас нет наследия, нет амбиций, нет незавершённых дел."

# game/script.rpy:123
translate russian start_27975d0e:

    # "Cumpliste con tus deberes como estudiante y terminaste la escuela."
    "Свой долг ученика вы выполнили, школу окончили."

# game/script.rpy:124
translate russian start_06baf93d:

    # "Pero no tienes motivaciones para perseguir un sueño o una meta más allá de donde estás ahora."
    "Но у вас нет ни сил, ни желания гнаться за мечтой или целью, которая лежит дальше того, что вы имеете."

# game/script.rpy:125
translate russian start_eb9e088b:

    # "Sientes como si no tuvieras el un rol protagónico en el mundo, porque nada en especial te ha sucedido (todavía)."
    "Порой вам кажется, что вы не главный герой своей истории — ведь с вами (пока) не случилось ничего по-настоящему особенного."

# game/script.rpy:126
translate russian start_d36386ed:

    # "De hecho, se podría decir que te dejas llevar por la apatía."
    "Можно даже сказать, что вами управляет апатия."

# game/script.rpy:127
translate russian start_b6d0f08b:

    # "Una apatía que te hace sentir las emociones fuertes entumecidas."
    "Апатия, притупляющая сильные эмоции."

# game/script.rpy:128
translate russian start_08a745d8:

    # "¿Una vuelta en una montaña rusa?, Agradable, ¿Te tropiezas y caes de bruces en el suelo en público?, No es el fin del mundo."
    "Американские горки? Забавно. Поскользнулись и упали лицом в грязь на глазах у всех? Не смертельно."

# game/script.rpy:129
translate russian start_da9d8111:

    # "Positivo o negativo, tu rango de emociones era muy bajo."
    "Радость или уныние — ваш эмоциональный диапазон едва заметен."

# game/script.rpy:130
translate russian start_a208fb7d:

    # "Como un perfecto papel en blanco."
    "Словно чистый лист бумаги."

# game/script.rpy:131
translate russian start_b6582220:

    # "De todas maneras, intentas hacer tu vida lo más cómoda posible."
    "И всё же вы стараетесь сделать свою жизнь максимально комфортной."

# game/script.rpy:132
translate russian start_ff063798:

    # "Por más raro que suene, trabajas en una tienda de películas que sólo atrae a nostálgicos y a cinéfilos."
    "Как бы странно это ни звучало, вы работаете в видеопрокате — месте, куда заходят разве что любители ностальгии и киноманы."

# game/script.rpy:137
translate russian start_93385125:

    # "La principal razón por la que tomaste el empleo es porque es algo que te gusta."
    "Главная причина, по которой вы взялись за эту работу, проста: вам это нравится."

# game/script.rpy:138
translate russian start_7603bb79:

    # "Puedes pasar horas viendo películas y nunca aburrirte."
    "Вы можете часами смотреть фильмы, и вам это никогда не наскучит."

# game/script.rpy:144
translate russian start_b19502e2:

    # "No te entusiasman mucho."
    "Они не очень вас вдохновляют."

# game/script.rpy:145
translate russian start_3fae0c89:

    # "El hecho de que para hacer bien tu trabajo debes saber al menos una película decente de cada género, lo hace más conveniente."
    "Впрочем, на работе это даже удобно: чтобы хорошо её выполнять, достаточно знать хотя бы по одному приличному фильму каждого жанра."

# game/script.rpy:146
translate russian start_4916808c:

    # "Ni siquiera tienes que verlas, con sólo tomar la opinión de personas a las que si les gustan las películas puedes arreglártelas."
    "И смотреть их вовсе не обязательно — достаточно просто пользоваться мнениями других любителей кино."

# game/script.rpy:152
translate russian character_1_a887f9b8:

    # "El lugar es lo suficientemente colorido como para no deprimirte con sólo estar ahí, y si tienes suerte, puedes encontrarte uno que otro personaje."
    "Место, где вы работаете, достаточно яркое, чтобы не навевать тоску одним своим видом. А если повезёт — можно встретить парочку колоритных персонажей."

# game/script.rpy:153
translate russian character_1_d8769169:

    # "Claro, aparte de los personajes que ya existen."
    "Конечно, помимо тех, что уже существуют."

# game/script.rpy:156
translate russian character_1_a8a411d2:

    # C "¿Recuperando el tiempo perdido?"
    C "Навёрстываешь упущенное время?"

# game/script.rpy:157
translate russian character_1_a129665b:

    # C "Por un momento pensé que no vendrías."
    C "Я уже подумала, что ты не придёшь."

# game/script.rpy:158
translate russian character_1_8c90e6ad:

    # "Cindy, tu compañera de trabajo."
    "Синди, ваша коллега по работе."

# game/script.rpy:159
translate russian character_1_2b3eedb2:

    # "No es muy buena en lo que hace, lo cual es decir mucho ya que ser dependiente de una tienda perdida en el tiempo no requiere mucho esfuerzo, pero es la hija del dueño."
    "В своей должности она не очень компетентна, что само по себе многое говорит, ведь работа в полузабытом видеопрокате и не требует особых талантов. Но она — дочь владельца."

# game/script.rpy:160
translate russian character_1_3c709925:

    # "Tú eres la otra persona que trabaja full-time, y te desempeñas bien."
    "Вы — второй постоянный сотрудник, и со своими обязанностями справляетесь куда лучше."

# game/script.rpy:161
translate russian character_1_cfa5e664:

    # "Ustedes no se llevan ni muy bien ni muy mal, se soportan."
    "Ваши отношения сложно назвать близкими, но и врагами вы не были; просто терпите друг друга."

# game/script.rpy:162
translate russian character_1_fe42fed0:

    # C "¿Dónde está tu credencial?"
    C "А где твой бейджик?"

# game/script.rpy:163
translate russian character_1_06dd4662:

    # "Instintivamente te llevaste la mano al cuello, y efectivamente, tu credencial de empleado no estaba."
    "Вы машинально касаетесь шеи — и действительно, рабочего бейджа на месте не оказалось."

# game/script.rpy:164
translate russian character_1_5eb31b77:

    # C "Es raro, pero siento que no puedo decir tu nombre sin tu credencial."
    C "Странно... У меня ощущение, что я не могу назвать твоё имя без бейджика."

# game/script.rpy:165
translate russian character_1_b4b58704:

    # "Cindy se encogió de hombros y se retiró a la trastienda con una caja llena de películas."
    "Синди пожимает плечами и уходит в подсобку с коробкой, полной фильмов."

# game/script.rpy:167
translate russian character_1_a909a2a2:

    # "De alguna manera, lo que te dijo ella tenía algo de sentido."
    "И каким-то образом её слова имели смысл."

# game/script.rpy:168
translate russian character_1_d77d6979:

    # "Es como si tampoco pudieras recordar tu nombre si no estaba escrito frente a ti."
    "Как будто вы и сами не могли вспомнить своё имя, если оно не написано перед глазами."

# game/script.rpy:169
translate russian character_1_0e463432:

    # "Como si los nombres solo existieran si alguien más los decía en voz alta."
    "Будто имена существуют лишь тогда, когда их произносят вслух."

# game/script.rpy:170
translate russian character_1_4c099ea6:

    # "Bueno, recordabas haberlo sacado entre tus cosas cuando llegaste, lo más seguro es que estaba en la tienda."
    "Ну, вы помните, что доставали бейдж, когда пришли — значит, он должен быть где-то в магазине."

# game/script.rpy:182
translate russian mostrador_8305cafb:

    # "Revisas detrás del mostrador, en el suelo no hay nada."
    "Вы заглядываете за прилавок, но на полу ничего нет."

# game/script.rpy:191
translate russian trastienda_b77e0aa2:

    # "Tal vez lo hayas dejado caer en la trastienda, pero sólo te encontraste a Cindy viendo su teléfono junto a las cajas que se había llevado."
    "Возможно, вы уронили его в подсобке. Но там вас встретила только Синди, уткнувшаяся в телефон среди коробок, которые принесла ранее."

# game/script.rpy:192
translate russian trastienda_847d2c02:

    # "Cindy te dio una mirada rápida, para luego volver a ignorarte."
    "Она бросила на вас короткий взгляд и вновь сделала вид, что не замечает вас."

# game/script.rpy:193
translate russian trastienda_e4c1a3b9:

    # "Tú seguiste su ejemplo y te enfocas en buscar tu credencial."
    "Вы последовали её примеру и сосредоточились на поисках бейджа."

# game/script.rpy:195
translate russian trastienda_da6cbd4e:

    # "Sip, no estaba ahí."
    "Нет, его здесь нет."

# game/script.rpy:202
translate russian pasillo1_3e0a8a07:

    # "Entre los estantes llenos de películas de acción, tu credencial no está ahí."
    "Среди полок, забитых боевиками, тоже пусто."

# game/script.rpy:208
translate russian pasillo2_37ce519a:

    # "Te inclinas para intentar ver mejor el suelo, con esperanza de que tu credencial esté por ahí."
    "Вы наклоняетесь в попытке рассмотреть пол получше, в надежде, что бейджик всё-таки где-то рядом."

# game/script.rpy:209
translate russian pasillo2_cf1b11af:

    # "Avanzas por el pequeño pasillo, determinado por estanterías llenas de películas de terror y thriller."
    "Пройдя дальше по узкому проходу между стеллажами с хоррорами и триллерами, вы продолжаете искать."

# game/script.rpy:223
translate russian movimiento_1_cec488aa:

    # "Hasta que visualizas el inconfundible pedazo de plástico, casi llegando al final del pasillo."
    "Наконец вы замечаете знакомый кусочек пластика, почти в конце прохода."

# game/script.rpy:225
translate russian movimiento_1_610313c8:

    # "Estás por alcanzar tu credencial, pero una mano blanca se te adelanta, recogiendo con lentitud el pedazo de plástico."
    "Вы уже тянетесь за бейджем, как белая рука опережает вас и медленно подбирает его с пола."

# game/script.rpy:229
translate russian movimiento_1_7eabdc81:

    # "Miras hacia arriba y te encuentras con un hombre alto, encapuchado y con la cara cubierta."
    "Подняв взгляд, вы видите перед собой высокого парня в капюшоне, лицо которого скрыто."

# game/script.rpy:230
translate russian movimiento_1_6eb89af0:

    # "Parece un criminal en potencia, o alguien resfriado."
    "Он выглядит то ли как преступник, то ли как человек с простудой."

# game/script.rpy:231
translate russian movimiento_1_483996b9:

    # "Pero no tienes energías de preocuparte."
    "Впрочем, сил тревожиться у вас нет."

# game/script.rpy:232
translate russian movimiento_1_1227d9d5:

    # "Te enderezas en tu lugar, quedando frente a frente."
    "Вы выпрямляетесь, оказываясь с ним лицом к лицу."

# game/script.rpy:233
translate russian movimiento_1_7e21fbc4:

    # "El hombre parece ignorarte, más interesado en tu credencial en su mano."
    "Парень, похоже, не обращает на вас внимания — его больше интересует ваш бейдж в его руке."

# game/script.rpy:234
translate russian movimiento_1_2e8071c4:

    # Stranger "¿Es tuya?"
    Stranger "Это твоё?"

# game/script.rpy:235
translate russian movimiento_1_10d2bb24:

    # "Su voz, suavizada por la tela, es grave y ligeramente rasposa."
    "Его голос, приглушённый тканью, звучит низко и немного хрипло."

# game/script.rpy:236
translate russian movimiento_1_67183082:

    # "Asientes en silencio, mirando con sospecha al hombre."
    "Вы молча киваете, с подозрением глядя на парня."

# game/script.rpy:237
translate russian movimiento_1_d0b58d2b:

    # "Por el cómo ladeó la cabeza."
    "Он чуть склоняет голову набок."

# game/script.rpy:238
translate russian movimiento_1_c542e169:

    # Stranger "Pruébalo."
    Stranger "Докажи."

# game/script.rpy:239
translate russian movimiento_1_e3c35191:

    # "Ahora, por fin puedes visualizar tu nombre."
    "Теперь вы наконец можете разглядеть своё имя."

# game/script.rpy:241
translate russian movimiento_1_860c11db:

    # Stranger "…."
    Stranger "..."

# game/script.rpy:242
translate russian movimiento_1_fe36de0d:

    # "El hombre mira en silencio la credencial, y por un momento de verdad pensaste que quizás te equivocaste después de todo, pero entonces él te ofreció el pedazo de plástico."
    "Парень молча посмотрел на бейдж, и на миг вам даже показалось, что, быть может, вы ошиблись. Но затем он протягивает вам кусочек пластика."

# game/script.rpy:243
translate russian movimiento_1_d372c5a4:

    # Stranger "De acuerdo, [povname]."
    Stranger "Хорошо, [povname]."

# game/script.rpy:244
translate russian movimiento_1_39cf6bbb:

    # "Recibes la credencial en tus manos, dedicándole una mirada al tipo."
    "Вы берёте бейджик в руки и пристально смотрите на парня."

# game/script.rpy:247
translate russian movimiento_1_79558830:

    # pov "Gracias, señor."
    pov "Спасибо, сэр."

# game/script.rpy:248
translate russian movimiento_1_f1124ab9:

    # Stranger "… No me digas así, no soy tan viejo."
    Stranger "...Не называй меня так, я не настолько стар."

# game/script.rpy:249
translate russian movimiento_1_2c3a1f62:

    # pov "Lo siento, pero no tengo manera de saberlo cuando no veo tu cara."
    pov "Прости, но мне неоткуда знать, лица-то не вижу."

# game/script.rpy:250
translate russian movimiento_1_a60ecf05:

    # Stranger "Mmh, supongo que tienes un punto."
    Stranger "М-м, имеет смысл."

# game/script.rpy:251
translate russian movimiento_1_101a4993:

    # pov "Además, por la piel de tus manos, puedo decir que no eres exactamente un jovencito-"
    pov "К тому же, по коже рук видно, что ты уже не совсем юн—"

# game/script.rpy:252
translate russian movimiento_1_8fe33072:

    # Stranger "Sí, ya entendí."
    Stranger "Да понял я."

# game/script.rpy:253
translate russian movimiento_1_8125bf81:

    # "La voz del sujeto se escuchaba irritada."
    "Его голос стал раздражённым."

# game/script.rpy:254
translate russian movimiento_1_a6b9f3b4:

    # "Una parte de ti te decía que debías ser más “dulce” con los clientes, pero si con tu palabrería lograste molestarlo, podrías considerarlo un logro."
    "Что-то внутри вас подсказывало, что с клиентами стоит быть повежливее. Но если своей болтовнёй вам удалось вывести его из себя — в каком-то смысле это уже успех."

# game/script.rpy:255
translate russian movimiento_1_7ca2858d:

    # "Este tipo te daba mala espina."
    "Этот парень вызывает у вас неприятные ощущения."

# game/script.rpy:261
translate russian movimiento_1_5b5434cf:

    # pov "¿Quién eres?, ¿La seguridad de credenciales?"
    pov "А ты что, охранник бейджей?"

# game/script.rpy:262
translate russian movimiento_1_744cff50:

    # "El hombre se encoge de hombros, despreocupado."
    "Парень беспечно пожимает плечами."

# game/script.rpy:263
translate russian movimiento_1_7c26673f:

    # Stranger "Sólo quería asegurarme de dárselo a la persona correcta."
    Stranger "Просто хотел убедиться, что возвращаю его тому, кому нужно."

# game/script.rpy:264
translate russian movimiento_1_c25af955:

    # pov "Evidentemente trabajo aquí."
    pov "Очевидно же, что я тут работаю."

# game/script.rpy:265
translate russian movimiento_1_ad5c7e03:

    # "Él se ríe entre dientes."
    "Он усмехается."

# game/script.rpy:266
translate russian movimiento_1_9c70edbe:

    # Stranger "Sí~ pero podría haberle pertenecido a algún otro trabajador."
    Stranger "Ага~ Но он мог принадлежать и кому-то другому."

# game/script.rpy:267
translate russian movimiento_1_b459f57e:

    # pov "Literalmente tiene mi foto impresa."
    pov "Там буквально напечатано моё фото."

# game/script.rpy:268
translate russian movimiento_1_58d49fe9:

    # "El sujeto restó importancia con un gesto de mano."
    "Парень пренебрежительно отмахнулся."

# game/script.rpy:269
translate russian movimiento_1_9a7ea173:

    # Stranger "¿Hubieras preferido que le diera tu credencial a cualquiera con uniforme que la reclame como suya?"
    Stranger "А ты бы предпочли, чтобы я отдал твой бейдж первому встречному в форме, который сказал бы, что это его?"

# game/script.rpy:270
translate russian movimiento_1_e95c90d2:

    # "Su lógica era extrañamente convincente."
    "Его логика странно убедительна."

# game/script.rpy:271
translate russian movimiento_1_8c85875e:

    # pov "… Supongo que no."
    pov "...Пожалуй, нет."

# game/script.rpy:272
translate russian movimiento_1_5d017620:

    # "El hombre ladeó la cabeza con burla."
    "Он с усмешкой наклоняет голову набок."

# game/script.rpy:273
translate russian movimiento_1_948bcf69:

    # "No podías verlo por la bandana, pero sabías que estaba sonriendo."
    "Лица за повязкой не видно, но вы знаете — он улыбается."

# game/script.rpy:274
translate russian movimiento_1_902577b0:

    # Stranger "¿Ves?, no soy tan malo."
    Stranger "Видишь? Я не такой уж плохой."

# game/script.rpy:275
translate russian movimiento_1_6af11f3e:

    # "Que él dijera eso te hizo pensar lo contrario."
    "После его слов вы только сильнее убедились в обратном."

# game/script.rpy:281
translate russian ruta_normal_1_14868465:

    # "Te colocas en silencio la credencial en tu cuello, mientras él seguía inmóvil en su lugar."
    "Молча повесив бейдж на шею, вы замечаете, что парень всё так же стоит на месте, не двигаясь."

# game/script.rpy:282
translate russian ruta_normal_1_bd2ca35a:

    # "Te moviste lentamente en dirección al mostrador."
    "Вы медленно направляетесь к прилавку."

# game/script.rpy:283
translate russian ruta_normal_1_4e5bde80:

    # "El tipo te miró fijamente mientras te movías, lo que hizo empeorar tu incomodidad."
    "Он не сводит с вас глаз, и это лишь усиливает ваше беспокойство."

# game/script.rpy:285
translate russian ruta_normal_1_8af99058:

    # "Decidiste ignorarlo, desviando tu atención a uno de los monitores junto a ti."
    "Вы решаете не обращать внимания, переводя взгляд на один из мониторов рядом."

# game/script.rpy:286
translate russian ruta_normal_1_e5cd9c3c:

    # "Podrías, si el sujeto encapuchado de antes dejara de darse tantas vueltas por la tienda de manera sospechosa."
    "Возможно, получилось бы успокоиться, если бы этот тип в капюшоне перестал так подозрительно бродить по магазину."

# game/script.rpy:287
translate russian ruta_normal_1_560c188e:

    # "Lo ignorabas con todas las ganas, pero era imposible no notarlo."
    "Вы всеми силами пытаетесь его игнорировать, но не замечать невозможно."

# game/script.rpy:288
translate russian ruta_normal_1_f4fac144:

    # "Quizás lo estaba haciendo a propósito."
    "Может, он делает это нарочно."

# game/script.rpy:291
translate russian ruta_normal_1_e90550e8:

    # C "Hey, [povname]."
    C "Эй, [povname]."

# game/script.rpy:292
translate russian ruta_normal_1_4955c0ab:

    # "Ante el llamado de tu nombre, alzaste la mirada hacia Cindy, la cual había rodeado el mostrador para estar a tu lado."
    "Услышав своё имя, вы поднимаете взгляд на Синди — она обходит прилавок и становится рядом."

# game/script.rpy:293
translate russian ruta_normal_1_071b72fb:

    # C "¿Viste que ese tipo ha estado aquí mucho tiempo?"
    C "Ты заметили, что этот тип уже довольно долго тут торчит?"

# game/script.rpy:294
translate russian ruta_normal_1_d4b2a28d:

    # "Miraste hacia donde ella estaba apuntando disimuladamente, y por supuesto, estaba hablando del mismo tipo."
    "Вы проследили за её едва заметным жестом, и, разумеется, речь идёт об одном и том же человеке."

# game/script.rpy:295
translate russian ruta_normal_1_908ff5a8:

    # pov "Seh, lo vi."
    pov "Ага, видели его."

# game/script.rpy:296
translate russian ruta_normal_1_66fd586d:

    # "Te encoges de hombros. Una reacción muy lógica, ¿No?"
    "Вы пожимаете плечами. Вполне логичная реакция, не так ли?"

# game/script.rpy:297
translate russian ruta_normal_1_f87eaf8d:

    # pov "Tal vez está decidiendo qué comprar."
    pov "Может, просто выбирает, что купить."

# game/script.rpy:298
translate russian ruta_normal_1_62771837:

    # "Seguramente era un tipo raro que vas a ver una vez, no era para tanto."
    "Скорее всего, это просто какой-то фрик. Один из тех, что мелькают раз в жизни и исчезают, ничего необычного."

# game/script.rpy:299
translate russian ruta_normal_1_03ec8c08:

    # "De todas formas, Cindy, por más que fuera insufrible, no se alteraba fácil."
    "Впрочем, Синди, даже при всей своей несносности, не из тех, кого легко вывести из равновесия."

# game/script.rpy:300
translate russian ruta_normal_1_34e679ad:

    # pov "Es sólo un rarito, vemos de esos a diario."
    pov "Обычный странноватый тип, каждый день таких видим."

# game/script.rpy:301
translate russian ruta_normal_1_ae284ab8:

    # C "Pero este se siente diferente…"
    C "Но от него... ощущение другое."

# game/script.rpy:302
translate russian ruta_normal_1_733a3677:

    # "Estabas empezando a creer que Cindy había visto muchas películas, pero luego recordaste que ella no le gustaba el séptimo arte y sólo trabaja en la tienda de su padre."
    "Вы уже хотели было подумать, что Синди пересмотрела фильмов, но потом вспомнили: она не любит кино, просто работает в лавке отца."

# game/script.rpy:303
translate russian ruta_normal_1_d780a543:

    # pov "Cuando hablé con él, no parecía ser peligroso."
    pov "Я с ним разговаривали, вроде не показался опасным."

# game/script.rpy:305
translate russian ruta_normal_1_ed362492:

    # "Cindy se giró a ti con sorpresa."
    "Синди удивлённо поворачивается к вам."

# game/script.rpy:306
translate russian ruta_normal_1_7c0a489a:

    # C "¿Hablaste con él?, ¿Te dijo algo extraño?"
    C "Ты с ним разговаривали? Он сказал что-нибудь странное?"

# game/script.rpy:312
translate russian ruta_normal_1_87d69241:

    # pov "Me pidió que dijera mi nombre."
    pov "Он спросил моё имя."

# game/script.rpy:313
translate russian ruta_normal_1_79cfc7e8:

    # C "¿Eh?, ¿Por qué?"
    C "А? Зачем?"

# game/script.rpy:314
translate russian ruta_normal_1_ffb9cba5:

    # pov "Él recogió mi credencial, supongo que para corroborar que era mía."
    pov "Он нашёл мой бейдж... Наверное, хотел убедиться, что он действительно мой."

# game/script.rpy:315
translate russian ruta_normal_1_68f5b046:

    # "Cindy se sujetó la barbilla, pensativa."
    "Синди задумчиво подпёрла подбородок рукой."

# game/script.rpy:316
translate russian ruta_normal_1_d729dd55:

    # pov "Fue… un poco raro, supongo."
    pov "Это было... немного странно, пожалуй."

# game/script.rpy:320
translate russian ruta_normal_1_ae362f25:

    # pov "Solo devolvió mi credencial."
    pov "Он просто вернул мне бейдж."

# game/script.rpy:321
translate russian ruta_normal_1_5bae812b:

    # C "¿Por qué la tenía él?"
    C "А почему он вообще был у него?"

# game/script.rpy:322
translate russian ruta_normal_1_7c90a249:

    # pov "O sea, él la agarró primero- mira, no fue la gran cosa."
    pov "Ну, он нашёл его раньше меня — честно, ничего особенного."

# game/script.rpy:327
translate russian ruta_normal_2_acb62680:

    # "Cindy te miró en silencio por unos segundos, para después suspirar."
    "Синди несколько секунд молча смотрит на вас, потом тяжело вздыхает."

# game/script.rpy:328
translate russian ruta_normal_2_31e940bc:

    # pov "Si te incomoda, puedo pedirle que se vaya."
    pov "Если он тебя нервирует, я могу попросить его уйти."

# game/script.rpy:329
translate russian ruta_normal_2_ae29e262:

    # "Cindy negó con la cabeza, mirando de reojo al sujeto."
    "Синди качает головой, бросая короткий взгляд на того парня."

# game/script.rpy:330
translate russian ruta_normal_2_23bc24e0:

    # C "Probablemente tengas razón…"
    C "Наверное, ты правы..."

# game/script.rpy:331
translate russian ruta_normal_2_3ad3c68b:

    # C "Bueno, te dejo, seguiré viendo el inventario."
    C "Ладно, не буду мешать, пойду проверю инвентарь."

# game/script.rpy:332
translate russian ruta_normal_2_c0662a5c:

    # pov "Claro."
    pov "Хорошо."

# game/script.rpy:333
translate russian ruta_normal_2_4e517ebe:

    # "Te acomodaste en tu silla designada, y antes de fingir ver los recibos, Cindy volvió a hablar."
    "Вы устраиваетесь в своём кресле, и прежде чем вы успеваете сделать вид, что просматриваете чеки, Синди снова говорит."

# game/script.rpy:334
translate russian ruta_normal_2_92d91f0d:

    # C "Pero si hace algo sospechoso, me avisas, ¿Sí?"
    C "Но если он сделает что-то подозрительное — дай мне знать, ладно?"

# game/script.rpy:336
translate russian ruta_normal_2_419d7f0d:

    # "Asentiste con un leve gesto. Cindy no esperó respuesta verbal; sólo volvió a su tarea."
    "Вы кивнули. Синди не стала ждать ответа, а просто вернулась к своим делам."

# game/script.rpy:337
translate russian ruta_normal_2_eb55ff67:

    # "Te quedaste un momento con los ojos fijos en la pantalla del monitor. Por el rabillo del ojo miraste los pasillos."
    "Несколько секунд вы сидите, не отрывая взгляда от экрана монитора. Затем краем глаза смотрите в сторону рядов."

# game/script.rpy:338
translate russian ruta_normal_2_776f35c1:

    # "El tipo seguía ahí."
    "Парень всё ещё там."

# game/script.rpy:339
translate russian ruta_normal_2_354be233:

    # "Sólo parado."
    "Просто стоит."

# game/script.rpy:340
translate russian ruta_normal_2_2edd89ef:

    # "Miraba una estantería que no tenía nada particularmente interesante."
    "Смотрит на стеллаж, где нет ничего примечательного."

# game/script.rpy:341
translate russian ruta_normal_2_172f0ed3:

    # "Y entonces, te miró."
    "А потом смотрит на вас."

# game/script.rpy:342
translate russian ruta_normal_2_749a1b42:

    # "No fue una mirada rápida o distraída."
    "Это не случайный, рассеянный взгляд."

# game/script.rpy:343
translate russian ruta_normal_2_f97e4ce2:

    # "Fue directa."
    "Он смотрит прямо на вас."

# game/script.rpy:347
translate russian ruta_normal_2_5af008ef:

    # "Ese tipo te estaba empezando a espantar."
    "Этот тип начинает вас по-настоящему пугать."

# game/script.rpy:348
translate russian ruta_normal_2_fe67954b:

    # "No pudiste enfrentarlo, estaba siendo demasiado."
    "Вы не смогли посмотреть на него — это уже слишком."

# game/script.rpy:353
translate russian ruta_normal_2_5fd684a7:

    # "Le devolviste la mirada con la misma intensidad."
    "Вы отвечаете ему таким же пристальным взглядом."

# game/script.rpy:354
translate russian ruta_normal_2_44843b97:

    # "No sabías si lo hacías por valentía, terquedad… o simple curiosidad."
    "Вы и сами не знаете, сделали это из смелости, упрямства... или просто из любопытства."

# game/script.rpy:355
translate russian ruta_normal_2_74854c52:

    # "Pero él no pestañeó."
    "Но он даже не моргнул."

# game/script.rpy:356
translate russian ruta_normal_2_1bc05b4d:

    # "Y entonces, hizo un leve gesto."
    "А затем сделал лёгкий жест."

# game/script.rpy:357
translate russian ruta_normal_2_343ef582:

    # "Un movimiento casi imperceptible con la cabeza."
    "Едва заметно кивнул головой."

# game/script.rpy:358
translate russian ruta_normal_2_a019b42d:

    # "Como si estuviera saludando."
    "Будто в знак приветствия."

# game/script.rpy:363
translate russian ruta_normal_3_baa32eed:

    # "Decidiste ignorarlo, volviendo tu atención al monitor para quitar el cd del reproductor."
    "Вы решаете не обращать внимания и снова смотрите на монитор, чтобы вынуть диск из проигрывателя."

# game/script.rpy:364
translate russian ruta_normal_3_f74cc9e0:

    # "Mientras guardas el cd en su respectiva caja, observas tus opciones."
    "Убирая диск в коробку, вы рассматриваете несколько вариантов."

# game/script.rpy:368
translate russian ruta_normal_3_e2b3880d:

    # "Te apetecía salir de la realidad, con mundos mágicos y criaturas extraordinarias."
    "Хочется уйти от реальности, в миры магии и необычных существ."

# game/script.rpy:369
translate russian ruta_normal_3_accd8364:

    # "Así que escoges una película y la ves el resto de tu turno."
    "Вы выбираете фильм и проводите за просмотром остаток смены."

# game/script.rpy:372
translate russian ruta_normal_3_bf33e6a9:

    # "Te apetece ver cómo se desenvuelven las relaciones ajenas, tal vez una parte de ti desearía vivir una historia de amor."
    "Сегодня тянет понаблюдать за чужими чувствами — может быть, где-то глубоко внутри вам тоже хотелось бы пережить свою историю любви."

# game/script.rpy:373
translate russian ruta_normal_3_accd8364_1:

    # "Así que escoges una película y la ves el resto de tu turno."
    "Вы выбираете фильм и проводите за просмотром остаток смены."

# game/script.rpy:378
translate russian ruta_normal_3_9ff14b94:

    # "Disfrutas los sustos y la atmósfera que generan las películas de terror."
    "Вам нравится ощущение тревожного ожидания и атмосфера, которую создают фильмы ужасов."

# game/script.rpy:381
translate russian ruta_normal_3_76db4b4b:

    # "Te apetece reír y disfrutar de buenos chistes y situaciones."
    "Вам просто хочется посмеяться над хорошими шутками и нелепыми ситуациями."

# game/script.rpy:382
translate russian ruta_normal_3_accd8364_2:

    # "Así que escoges una película y la ves el resto de tu turno."
    "Вы выбираете фильм и проводите за просмотром остаток смены."

# game/script.rpy:385
translate russian ruta_normal_3_2ad13818:

    # "Disfrutas de un buen musical, grandes canciones y coreografías."
    "Вам нравятся мюзиклы — с их великолепными песнями и эффектными танцевальными номерами."

# game/script.rpy:386
translate russian ruta_normal_3_accd8364_3:

    # "Así que escoges una película y la ves el resto de tu turno."
    "Вы выбираете фильм и проводите за просмотром остаток смены."

# game/script.rpy:389
translate russian ruta_normal_3_ffa8e314:

    # "Te interesa la tecnología y cómo es que la gente se imagina cómo sería el futuro."
    "Вам интересны технологии и то, как люди представляют себе будущее."

# game/script.rpy:390
translate russian ruta_normal_3_accd8364_4:

    # "Así que escoges una película y la ves el resto de tu turno."
    "Вы выбираете фильм и проводите за просмотром остаток смены."

# game/script.rpy:395
translate russian ruta_normal_4_0d22d6b3:

    # "Estás por escoger una película, hasta que el repentino sonido de alguien apoyándose en el mostrador frente a ti te desconcentra."
    "Вы уже собираетесь выбрать фильм, как вдруг резкий звук — кто-то облокотился на прилавок перед вами — вырывает вас из мыслей."

# game/script.rpy:401
translate russian ruta_normal_4_bc5ac81e:

    # "Nuevamente, el sujeto desconocido se hace presente, esta vez frente a ti, mirando con atención el cd en tus manos."
    "Незнакомец снова появился, теперь прямо напротив, внимательно глядя на диск в ваших руках."

# game/script.rpy:402
translate russian ruta_normal_4_a3e745a4:

    # Stranger "¿Qué película vas a poner?"
    Stranger "Какой фильм включаешь?"

# game/script.rpy:403
translate russian ruta_normal_4_74267743:

    # pov "¿Disculpa?"
    pov "Прошу прощения?"

# game/script.rpy:404
translate russian ruta_normal_4_f8f7158b:

    # Stranger "Quiero saber qué película vas a poner, ¿Eso es un crimen?"
    Stranger "Просто интересно, что ты поставишь. Это что, преступление?"

# game/script.rpy:405
translate russian ruta_normal_4_58563c79:

    # pov "No, claro que no, pero-"
    pov "Нет, конечно нет, но—"

# game/script.rpy:406
translate russian ruta_normal_4_7a0cebca:

    # Stranger "Vamos, estoy indeciso, tal vez puedas inspirarme."
    Stranger "Да ладно тебе, я просто не могу выбрать. Может, ты меня вдохновишь."

# game/script.rpy:407
translate russian ruta_normal_4_5e7421d8:

    # "Lo miraste en silencio por un momento, para después suspirar con cansancio."
    "Вы молча смотрите на него, а потом устало вздыхаете."

# game/script.rpy:411
translate russian ruta_normal_4_8674d526:

    # Stranger "Ah, psicológico."
    Stranger "А, психологическое кино."

# game/script.rpy:412
translate russian ruta_normal_4_ee76db2c:

    # Stranger "¿Te gusta analizar a las personas?"
    Stranger "Тебе нравится анализировать людей?"

# game/script.rpy:413
translate russian ruta_normal_4_b4be9333:

    # Stranger "¿Qué conclusiones sacas de mí?"
    Stranger "И какие выводы можешь сделать обо мне?"

# game/script.rpy:414
translate russian ruta_normal_4_749da67d:

    # pov "Que te parece que mis gustos son patéticos."
    pov "Ты считаешь мои вкусы убогими."

# game/script.rpy:415
translate russian ruta_normal_4_710f203b:

    # Stranger "….."
    Stranger "..."

# game/script.rpy:416
translate russian ruta_normal_4_3d81733a:

    # Stranger "Vaya, diste en el clavo."
    Stranger "Вау, в точку."

# game/script.rpy:417
translate russian ruta_normal_4_f302080a:

    # pov "¿Ahora quien tiene gustos patéticos?"
    pov "Так у кого из нас теперь странные вкусы?"

# game/script.rpy:418
translate russian ruta_normal_4_85f633f9:

    # "El tipo se cruza de brazos con irritación."
    "Парень раздражённо скрестил руки."

# game/script.rpy:419
translate russian ruta_normal_4_3eafab4e:

    # Stranger "Tch…"
    Stranger "Тц..."

# game/script.rpy:423
translate russian ruta_normal_4_d03d8729:

    # Stranger "¡Hahaha!"
    Stranger "Ха-ха-ха!"

# game/script.rpy:424
translate russian ruta_normal_4_311dd15f:

    # Stranger "¿En serio te gusta eso?"
    Stranger "Серьёзно, тебе это нравится?"

# game/script.rpy:425
translate russian ruta_normal_4_7ca24f77:

    # pov "Hey, es un clásico."
    pov "Эй, это же классика."

# game/script.rpy:426
translate russian ruta_normal_4_46476a6d:

    # Stranger "Admito que tuvo su impacto, pero es sólo propaganda religiosa."
    Stranger "Признаю, своё влияние фильм оказал, но по сути — сплошная религиозная пропаганда."

# game/script.rpy:427
translate russian ruta_normal_4_fedc5190:

    # pov "Ok, tal vez tengas un punto, pero no quita que sea buena."
    pov "Ладно, может, ты прав, но это не делает его хуже."

# game/script.rpy:428
translate russian ruta_normal_4_d3a93014:

    # Stranger "Lo que digas."
    Stranger "Как скажешь."

# game/script.rpy:434
translate russian ruta_normal_4_da3c9522:

    # Stranger "Oh~"
    Stranger "О-о~"

# game/script.rpy:435
translate russian ruta_normal_4_2288b594:

    # Stranger "Un clásico slasher~"
    Stranger "Классический слэшер~"

# game/script.rpy:436
translate russian ruta_normal_4_644cb77a:

    # Stranger "Interesante."
    Stranger "Интересно."

# game/script.rpy:440
translate russian ruta_normal_4_7acf4be8:

    # Stranger "……."
    Stranger "..."

# game/script.rpy:441
translate russian ruta_normal_4_30f85677:

    # Stranger "¿En serio?"
    Stranger "Серьёзно?"

# game/script.rpy:442
translate russian ruta_normal_4_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:446
translate russian ruta_normal_4_b5b797cc:

    # Stranger "Oh, si, a mi también me gusta esa."
    Stranger "О, да, мне тоже он нравится."

# game/script.rpy:447
translate russian ruta_normal_4_493e448f:

    # Stranger "Me ayuda a dormir."
    Stranger "Помогает заснуть."

# game/script.rpy:453
translate russian ruta_normal_4_da3c9522_1:

    # Stranger "Oh~"
    Stranger "О-о~"

# game/script.rpy:454
translate russian ruta_normal_4_9a7fb7f4:

    # Stranger "Es de esas películas sin sustos fáciles y que se mete en la piel."
    Stranger "Один из тех фильмов, которые не пугают резкими скримерами, но всё равно пробирают."

# game/script.rpy:455
translate russian ruta_normal_4_578fbdc9:

    # Stranger "Me gusta~"
    Stranger "Мне нравится~"

# game/script.rpy:459
translate russian ruta_normal_4_ff1f770f:

    # Stranger "Mmh, los efectos especiales son geniales, supongo…"
    Stranger "М-м, там классные спецэффекты, пожалуй..."

# game/script.rpy:465
translate russian ruta_normal_5_b3a8649c:

    # pov "Bueno, ¿Eso te ayudó a decidir?"
    pov "Ну что, помогло определиться?"

# game/script.rpy:468
translate russian ruta_normal_5_891ab733:

    # "El sujeto ladeó la cabeza, ahora sabías con seguridad que esa era su manera de mostrar burla."
    "Парень слегка склоняет голову набок — теперь вы точно знаете, что так он выражает насмешку."

# game/script.rpy:469
translate russian ruta_normal_5_725c5e0d:

    # Stranger "Un poco."
    Stranger "Отчасти."

# game/script.rpy:470
translate russian ruta_normal_5_3c3da743:

    # Stranger "Aunque lo que más me llamó la atención fue el género que elegiste."
    Stranger "Хотя больше всего моё внимание привлёк жанр, который ты выбрали."

# game/script.rpy:471
translate russian ruta_normal_5_45b264e1:

    # "Alzaste una ceja."
    "Вы вопросительно приподнимаете бровь."

# game/script.rpy:472
translate russian ruta_normal_5_107e6b99:

    # pov "¿Sí? ¿Y qué tiene?"
    pov "Да? И что с ним?"

# game/script.rpy:473
translate russian ruta_normal_5_9ae72082:

    # Stranger "Terror."
    Stranger "Хоррор."

# game/script.rpy:474
translate russian ruta_normal_5_888068ad:

    # "El tono de él baja."
    "Его тон понизился."

# game/script.rpy:475
translate russian ruta_normal_5_086864c3:

    # Stranger "Interesante elección. Siempre dice algo de quien lo prefiere."
    Stranger "Интересный выбор. Он всегда многое говорит о тех, кто его предпочитает."

# game/script.rpy:476
translate russian ruta_normal_5_6c41161b:

    # pov "¿Como qué?"
    pov "Например?"

# game/script.rpy:477
translate russian ruta_normal_5_4a41220d:

    # Stranger "Que buscas sentir algo real."
    Stranger "Ты хочешь почувствовать что-то по-настящему."

# game/script.rpy:478
translate russian ruta_normal_5_edd25cab:

    # Stranger "O quieres que el miedo tenga un rostro."
    Stranger "Или хочешь, чтобы страх обрёл лицо."

# game/script.rpy:479
translate russian ruta_normal_5_fc1d6905:

    # Stranger "Algo que puedas entender, incluso si significa peligro."
    Stranger "Что-то, что ты можешь понять, даже если это означает опасность."

# game/script.rpy:480
translate russian ruta_normal_5_dff41859:

    # "Sus palabras eran suaves, pero se clavaban como agujas bajo la piel."
    "Его слова звучат мягко, но впиваются как иглы под кожу."

# game/script.rpy:481
translate russian ruta_normal_5_be1a1dc2:

    # pov "O tal vez me gustan las emociones fuertes sin ponerme en riesgo. Como todos los demás."
    pov "А может, мне просто нравятся сильные эмоции, без риска для жизни. Как и всем остальным."

# game/script.rpy:482
translate russian ruta_normal_5_ad98273a:

    # Stranger "Pero tú no eres como todos los demás."
    Stranger "Но ты не такие, как все."

# game/script.rpy:483
translate russian ruta_normal_5_14c2af34:

    # "Vaya, hay que quitar esa frase del bingo de la novela visual."
    "Ну да, классика. Эту фразу можно вычёркивать из бинго визуальной новеллы."

# game/script.rpy:484
translate russian ruta_normal_5_f872c175:

    # "Él se acercó un poco más al mostrador. No invadía tu espacio… pero era como si lo acariciara."
    "Он придвинулся чуть ближе к прилавку. Он не вторгается в ваше личное пространство... но есть ощущение, что само его присутствие будто касается вас."

# game/script.rpy:485
translate russian ruta_normal_5_00157c57:

    # Stranger "No pareces tener miedo."
    Stranger "Ты не выглядишь напуганно."

# game/script.rpy:486
translate russian ruta_normal_5_a8bbecbb:

    # pov "¿Debería tenerlo?"
    pov "А должны?"

# game/script.rpy:487
translate russian ruta_normal_5_05b2a07f:

    # Stranger "Depende. ¿Prefieres ver el horror desde afuera… o que te mire de vuelta?"
    Stranger "Зависит от того, что тебе ближе — смотреть на ужас со стороны... или позволить ему смотреть на тебя."

# game/script.rpy:493
translate russian ruta_normal_5_d0cab671:

    # pov "Supongo que eso depende de qué tan bonita sea la cara del horror."
    pov "Пожалуй, всё зависит от того, насколько красиво лицо у ужаса."

# game/script.rpy:494
translate russian ruta_normal_5_dff2b092:

    # "Él ladea un poco la cabeza, como si le hubieras dicho algo que no esperaba del todo, pero tampoco parece sorprendido."
    "Он слегка наклоняет голову, будто не ожидая такого ответа, хотя и не выглядит особенно удивлённым."

# game/script.rpy:495
translate russian ruta_normal_5_05576f06:

    # Stranger "…Vaya."
    Stranger "...Вот как."

# game/script.rpy:496
translate russian ruta_normal_5_6da8515b:

    # Stranger "Ten en cuenta que a veces lo bonito también muerde."
    Stranger "Только имей в виду — даже что-то красивое иногда кусается."

# game/script.rpy:497
translate russian ruta_normal_5_255e690a:

    # "Mira un segundo hacia los estantes como si buscara algo, pero es obvio que no lo hace."
    "Он бросает короткий взгляд на полки, словно что-то ищет, но сразу становится ясно, что это не так."

# game/script.rpy:498
translate russian ruta_normal_5_41c5b8b1:

    # Stranger "O quizás te gusta que te muerdan. Quién sabe."
    Stranger "А может, тебе даже нравится, когда тебя кусают. Кто знает."

# game/script.rpy:499
translate russian ruta_normal_5_22c8cb22:

    # "Se encoge de hombros, como restándole importancia a sus propias palabras."
    "Он пожимает плечами, будто сам считает сказанное не стоящим внимания."

# game/script.rpy:502
translate russian ruta_normal_5_e1da323f:

    # pov "Voy a revisar el sistema un momento. Si decides algo, me avisas."
    pov "Мне нужно проверить систему. Если выберешь что-то — скажи."

# game/script.rpy:503
translate russian ruta_normal_5_86e5cb94:

    # "No se mueve. Apoya el codo en el mostrador, observándote."
    "Он даже не шелохнулся. Облокотился на прилавок, наблюдая за вами."

# game/script.rpy:504
translate russian ruta_normal_5_f818d1ac:

    # "El silencio es pesado."
    "Тишина повисла тяжёлым грузом."

# game/script.rpy:509
translate russian ruta_normal_6_31e46d31:

    # "Él extendió un dedo e hizo círculos sobre la superficie del mostrador."
    "Он протягивает палец и начинает медленно выводить круги на поверхности прилавка."

# game/script.rpy:510
translate russian ruta_normal_6_dd900e51:

    # "Estaba fingiendo pensar, ignorándote, pero consciente de tu presencia."
    "Делает вид, что задумался, и вроде бы не замечает вас, но прекрасно осознаёт ваше присутствие."

# game/script.rpy:511
translate russian ruta_normal_6_da57c29c:

    # "Por el bien de tu sanidad mental, debías apresurarlo."
    "Ради собственного душевного спокойствия стоит поторопить его."

# game/script.rpy:515
translate russian ruta_normal_6_b84a99ac:

    # "Carraspeas contra tu mano hecha un puño."
    "Вы кашлянули, прикрыв рот кулаком."

# game/script.rpy:516
translate russian ruta_normal_6_03ad10c2:

    # pov "Ehm, ¿Vas a escoger algo?"
    pov "Эм, ты собираешься что-нибуль выбирать?"

# game/script.rpy:517
translate russian ruta_normal_6_f340bcaf:

    # Stranger "Eres algo impaciente, ¿Eh?"
    Stranger "Ты немного нетерпеливы, а?"

# game/script.rpy:518
translate russian ruta_normal_6_b041e5a8:

    # pov "Oh, disculpa, no quise-"
    pov "О, прости, я не хоте—"

# game/script.rpy:519
translate russian ruta_normal_6_55df15bf:

    # Stranger "Relájate, sólo estoy jugando."
    Stranger "Расслабься, просто шучу."

# game/script.rpy:524
translate russian ruta_normal_6_6b036851:

    # pov "Hey, amigo, ¿Podrías apresurarte?"
    pov "Эй, приятель, можешь поторопиться?"

# game/script.rpy:525
translate russian ruta_normal_6_d45f46e4:

    # Stranger "¿Cuál es la prisa?, no hay muchos clientes además de mí."
    Stranger "А куда спешить? Кроме меня тут всё равно почти никого нет."

# game/script.rpy:526
translate russian ruta_normal_6_862483a0:

    # pov "¿Siquiera quieres comprar algo?"
    pov "Ты вообще собираешься что-нибудь покупать?"

# game/script.rpy:527
translate russian ruta_normal_6_d7bc3471:

    # "El tipo se rió entre dientes."
    "Парень усмехнулся."

# game/script.rpy:528
translate russian ruta_normal_6_9894db0c:

    # Stranger "Sólo soy indeciso, no le hago daño a nadie."
    Stranger "Я просто не могу выбрать, никому ведь не мешаю."

# game/script.rpy:533
translate russian ruta_normal_7_f4cd09be:

    # "Desviaste la mirada hacia atrás, en búsqueda de Cindy, sólo para sentir algo de seguridad de que no estabas por tu cuenta."
    "Вы отводите взгляд назад, ища Синди — просто чтобы убедиться, что вы здесь не одни."

# game/script.rpy:534
translate russian ruta_normal_7_3e402da3:

    # "Pero lamentablemente, no la veías por ningún lado."
    "Но, к сожалению, вы её нигде не видите."

# game/script.rpy:536
translate russian ruta_normal_7_03c6350e:

    # "Entonces, sin que se lo pidieras, él estiró una mano por encima del mostrador."
    "И тогда, без приглашения, он протягивает руку через прилавок."

# game/script.rpy:537
translate russian ruta_normal_7_dcabc9da:

    # J "Soy Jeff, creo que es momento de presentarnos formalmente, ¿No crees, [povname]?"
    J "Я Джефф. Думаю, самое время нормально познакомиться, не так ли, [povname]?"

# game/script.rpy:538
translate russian ruta_normal_7_465c3e77:

    # "Tu mirada bajó a su mano."
    "Ваш взгляд опускается на его руку."

# game/script.rpy:545
translate russian ruta_normal_7_9c908b85:

    # J "……"
    J "......"

# game/script.rpy:546
translate russian ruta_normal_7_1cb9306f:

    # pov "……"
    pov "......"

# game/script.rpy:547
translate russian ruta_normal_7_7b7d640d:

    # J "¡Hahahaha!"
    J "Ха-ха-ха!"

# game/script.rpy:548
translate russian ruta_normal_7_1527fe50:

    # "Jeff se rió fuertemente, llamando la atención de los pocos clientes que seguían en la tienda."
    "Джефф громко рассмеялся, привлекая внимание немногих покупателей, что ещё оставались в магазине."

# game/script.rpy:549
translate russian ruta_normal_7_e5ec76c2:

    # "No pudiste evitarlo, pero tu también te reíste por tu acción."
    "Вы не смогли удержаться и тоже рассмеялись над собственным поступком."

# game/script.rpy:550
translate russian ruta_normal_7_6a03cbae:

    # pov "Hey, no exageres… nos están viendo."
    pov "Эй, не переигрывай... на нас смотрят."

# game/script.rpy:551
translate russian ruta_normal_7_f2d3f19e:

    # J "¿Por qué? ¿Te avergüenza de que te vean?"
    J "И что? Стесняешься, что тебя видят?"

# game/script.rpy:552
translate russian ruta_normal_7_5d03a9f5:

    # pov "No es eso, estás molestando a los clientes."
    pov "Дело не в этом. Ты просто мешаешь клиентам."

# game/script.rpy:553
translate russian ruta_normal_7_a005b756:

    # J "Heh, cierto, no te tomaba como alguien que se avergüence fácilmente."
    J "Хех, верно. Не думал, что ты из тех, кого легко смутить."

# game/script.rpy:556
translate russian ruta_normal_7_a180aa46:

    # "Jeff sujetó tu mano con suavidad, como si quisiera hacer ver su contacto como algo inofensivo."
    "Джефф мягко берёт вашу руку, будто стараясь, чтобы прикосновение выглядело безобидно."

# game/script.rpy:557
translate russian ruta_normal_7_ed4cfdae:

    # J "Mmh, lindo…"
    J "М-м, мило..."

# game/script.rpy:558
translate russian ruta_normal_7_af17a36a:

    # "Sus dedos no apretaron, pero tampoco se retiraron enseguida."
    "Его пальцы не сжимают ладонь, но и не спешат отпускать."

# game/script.rpy:559
translate russian ruta_normal_7_0856e44d:

    # "La frialdad del gesto no parecía molestarle, al contrario, le hacía gracia."
    "Холодность вашей реакции, похоже, его не смущает — напротив, забавляет."

# game/script.rpy:560
translate russian ruta_normal_7_f227e563:

    # "Finalmente soltó tu mano, como quien deja caer algo que ya inspeccionó suficiente."
    "Наконец он отпускает вашу руку, как отпускают вещь, которую уже достаточно осмотрели."

# game/script.rpy:565
translate russian ruta_normal_8_3cf9f753:

    # "Como alguien que trabaja en una tienda, deberías convencer al cliente de llevar lo más que pueda, pero algo te decía que Jeff se tomaría su buen tiempo."
    "Как человек, работающий в магазине, вы должны уговаривать клиента брать побольше, но что-то подсказывает — Джефф не из тех, кто торопится."

# game/script.rpy:566
translate russian ruta_normal_8_ebe71245:

    # "Lo miraste unos segundos en silencio, observando su postura pensativa."
    "Несколько секунд вы молча на него смотрите, наблюдая за его задумчивой позой."

# game/script.rpy:567
translate russian ruta_normal_8_ea413312:

    # "Si él estaba insistiendo en alargar la interacción, tenías permitido incomodar también, ¿No?"
    "Если он намеренно затягивает разговор, то, наверное, и вам позволено немного вывести его из равновесия, верно?"

# game/script.rpy:571
translate russian ruta_normal_8_f2a658e9:

    # J "…."
    J "..."

# game/script.rpy:572
translate russian ruta_normal_8_dd4773e1:

    # J "¿Por qué quieres saber?"
    J "Зачем тебе это знать?"

# game/script.rpy:575
translate russian ruta_normal_8_f2a658e9_1:

    # J "…."
    J "..."

# game/script.rpy:576
translate russian ruta_normal_8_4a80f2ea:

    # J "Tengo cicatrices, no son agradables de ver."
    J "У меня есть шрамы. Вид у них не самый приятный."

# game/script.rpy:577
translate russian ruta_normal_8_9937ed6d:

    # "Parece que tocaste una fibra sensible."
    "Похоже, вы задели больную тему."

# game/script.rpy:582
translate russian ruta_normal_8_14360a18:

    # J "…"
    J "..."

# game/script.rpy:583
translate russian ruta_normal_8_8d2ed3a9:

    # J "Ya no lo hace, eso es lo que importa."
    J "Уже нет, и это главное."

# game/script.rpy:584
translate russian ruta_normal_8_e2e8b803:

    # "No eras de meterte en asuntos ajenos, pero ya estableciste una conversación con él."
    "Обычно вы не лезете в чужие дела, но разговор уже начат."

# game/script.rpy:585
translate russian ruta_normal_8_f3611b6e:

    # "No podía simplemente no importarte."
    "Просто отмахнуться и не проявить интерес нельзя."

# game/script.rpy:588
translate russian ruta_normal_8_0eb96dcd:

    # J "¿Huh?"
    J "А?"

# game/script.rpy:589
translate russian ruta_normal_8_564c8fc4:

    # J "¿Qué tiene que ver eso?"
    J "А это тут при чём?"

# game/script.rpy:590
translate russian ruta_normal_8_88d2d51f:

    # pov "Oh, ¿Eres freelancer?"
    pov "О, ты фрилансер?"

# game/script.rpy:591
translate russian ruta_normal_8_7ba8913d:

    # J "¿Qué mierd…? ¡No!"
    J "Что за х..? Нет!"

# game/script.rpy:592
translate russian ruta_normal_8_4cdb1132:

    # pov "¿Entonces estás desempleado?"
    pov "Тогда безработный?"

# game/script.rpy:593
translate russian ruta_normal_8_a4883f2f:

    # J "¡Yo-!"
    J "Я—!"

# game/script.rpy:594
translate russian ruta_normal_8_b5e56971:

    # J "…. Bueno, técnicamente sí."
    J "...Ну, технически да."

# game/script.rpy:595
translate russian ruta_normal_8_55227dee:

    # pov "Hey, no hay de qué avergonzarse, ya te llegará la oportunidad."
    pov "Эй, в этом нет ничего постыдного, шанс ещё будет."

# game/script.rpy:596
translate russian ruta_normal_8_c64ac46b:

    # J "No quiero escuchar eso de ti."
    J "Не хочу от тебя это слышать."

# game/script.rpy:597
translate russian ruta_normal_8_bbe0c635:

    # pov "¿Qué quieres decir con eso?"
    pov "В смысле?"

# game/script.rpy:598
translate russian ruta_normal_8_a6a781f5:

    # J "Descúbrelo tú."
    J "Догадайся."

# game/script.rpy:601
translate russian ruta_normal_8_a5784726:

    # "Jeff se trastabilló en su lugar, dirigiendo su mirada hacia ti."
    "Джефф пошатнулся на месте, поднимая на вас взгляд."

# game/script.rpy:602
translate russian ruta_normal_8_ed91d6c2:

    # "Se quedó en silencio unos segundos, recuperándose de la sorpresa inicial, para después ladear la cabeza, con un toque burlón."
    "Несколько секунд он стоит молча, приходя в себя после неожиданности, затем слегка склоняет голову с насмешливым выражением лица."

# game/script.rpy:603
translate russian ruta_normal_8_1d975fe1:

    # J "¿Y si lo hago?"
    J "А если есть?"

# game/script.rpy:608
translate russian ruta_normal_8_1ba220be:

    # pov "No me molestaría compartir."
    pov "Я не против делиться."

# game/script.rpy:609
translate russian ruta_normal_8_4d129c8f:

    # "Apoyas tu barbilla sobre tu mano, alzando las cejas juguetonamente."
    "Вы опёрлись подбородком на руку, игриво приподнимая брови."

# game/script.rpy:610
translate russian ruta_normal_8_fd0fa39f:

    # "Jeff carraspea contra su bandana, ocultando lo que tu sospechas que es una carcajada."
    "Джефф кашлянул в повязку, прикрывая — как вам показалось — сдержанный смешок."

# game/script.rpy:611
translate russian ruta_normal_8_44ccc4e5:

    # "Al menos lo hiciste reír."
    "По крайней мере, вам удалось его рассмешить."

# game/script.rpy:614
translate russian ruta_normal_8_55d7389c:

    # pov "Bien por ti si es el caso."
    pov "Ну, тогда рады за тебя."

# game/script.rpy:615
translate russian ruta_normal_8_b7084154:

    # "Preguntaste por preguntar, no porque realmente tuvieras interés en él."
    "Вы спросили просто ради вопроса, без особого интереса."

# game/script.rpy:616
translate russian ruta_normal_8_e8682974:

    # "Los hombros de él cayeron y te pareció escuchar un suspiro de su parte."
    "Его плечи слегка опускаются, и вам кажется, что он вздыхает."

# game/script.rpy:621
translate russian ruta_normal_9_5a9a98ab:

    # pov "Bueno, ¿Decidiste que llevar?"
    pov "Ну что, решил, что взять?"

# game/script.rpy:622
translate russian ruta_normal_9_b68673fd:

    # "Jeff depositó su atención nuevamente en ti."
    "Джефф снова переводит взгляд на вас."

# game/script.rpy:623
translate russian ruta_normal_9_b47ab4ca:

    # J "Vaya, pareciera que de verdad quisieras deshacerte de mí."
    J "Ого, похоже, ты и правда хочешь поскорее от меня избавиться."

# game/script.rpy:627
translate russian ruta_normal_9_b4f2b9bc:

    # pov "No es eso… si necesitas ayuda, estoy para atender."
    pov "Не в этом дело... Если тебе нужна помощь, я помогу."

# game/script.rpy:628
translate russian ruta_normal_9_de096237:

    # "Él ladeó la cabeza ligeramente, pero esta vez no con burla, sino más bien con aburrimiento."
    "Он слегка наклоняет голову — на этот раз не насмешливо, а скорее от скуки."

# game/script.rpy:629
translate russian ruta_normal_9_6e8e4c83:

    # "Sus dedos dejaron de tamborilear, ahora quietos sobre la superficie del mostrador."
    "Его пальцы перестают стучать по прилавку, замирая на гладкой поверхности."

# game/script.rpy:630
translate russian ruta_normal_9_3cdaa8f0:

    # J "Ah… claro. El protocolo de servicio."
    J "А... Ну да. Протокол обслуживания."

# game/script.rpy:631
translate russian ruta_normal_9_8e5b001a:

    # "La burla seguía ahí, pero sus ojos ya no brillaban con la misma chispa de antes."
    "Насмешка ещё звучит в его голосе, но в глазах уже нет прежней искры."

# game/script.rpy:632
translate russian ruta_normal_9_c6cec9a8:

    # "Por un segundo, casi parecía que iba a decir algo más, pero se limitó a un suspiro discreto."
    "На миг вам кажется, что он хочет сказать что-то ещё, но вместо этого лишь тихо выдыхает."

# game/script.rpy:636
translate russian ruta_normal_9_d205df72:

    # J "En fin, creo que no llevaré nada."
    J "В общем, думаю, ничего брать не буду."

# game/script.rpy:637
translate russian ruta_normal_9_35671ebc:

    # "Genial, todo fue para nada."
    "Отлично. Всё впустую."

# game/script.rpy:638
translate russian ruta_normal_9_9a59fcb3:

    # J "Ojalá hubiera sido un gusto conocerte, [povname], pero… no estoy tan seguro."
    J "Хотел бы сказать, что рад был познакомиться, [povname], но... не уверен."

# game/script.rpy:639
translate russian ruta_normal_9_ea99ece5:

    # "Jeff se enderezó del mostrador, dándole palmadas al mostrador."
    "Джефф выпрямляется, стукнув ладонью по прилавку."

# game/script.rpy:640
translate russian ruta_normal_9_d9ead54c:

    # pov "Seh, opino igual, Jeff."
    pov "Ага, я того же мнения, Джефф."

# game/script.rpy:641
translate russian ruta_normal_9_5a34650e:

    # "No te quedas atrás y correspondes a la poca energía."
    "Вы решаете не сдерживаться и отвечаете тем же холодным тоном."

# game/script.rpy:643
translate russian ruta_normal_9_2c711a9d:

    # "Jeff resta importancia con un gesto de mano y se retira."
    "Джефф равнодушно отмахивается и направляется к выходу."

# game/script.rpy:644
translate russian ruta_normal_9_2f5a7aff:

    # "Por fin."
    "Наконец-то."

# game/script.rpy:645
translate russian ruta_normal_9_56da2df2:

    # "Este tipo te estaba poniendo de los nervios, con todas sus preguntas y comentarios."
    "Этот тип уже начинал действовать вам на нервы своими вопросами и замечаниями."

# game/script.rpy:646
translate russian ruta_normal_9_6791b26a:

    # "Todo parecía una invitación a un juego, pero no tenías por qué aceptarlo."
    "Всё это походило на игру, но вы вовсе не обязаны в ней участвовать."

# game/script.rpy:651
translate russian ruta_normal_9_937773fa:

    # pov "No, para nada. Amo perder el tiempo con raritos que caminan en círculos como si estuvieran perdidos en el supermercado."
    pov "Нет, вовсе нет. Обожаю тратить время на странных личностей, которые носятся по кругу, будто заблудились в супермаркете."

# game/script.rpy:652
translate russian ruta_normal_9_e9c644c1:

    # "Jeff abrió mucho los ojos, fingiendo ofensa."
    "Глаза Джеффа широко раскрылись, он притворился оскорблённым."

# game/script.rpy:653
translate russian ruta_normal_9_62e317c1:

    # J "¡Oye! Eso fue cruel. Me vas a hacer llorar."
    J "Эй! Это грубо. Ещё чуть-чуть и я заплачу."

# game/script.rpy:654
translate russian ruta_normal_9_90c16e08:

    # "Se llevó una mano al pecho, exagerando, y luego volvió a reírse entre dientes. Esta vez su risa fue más baja, más real."
    "Он драматично прижимает руку к груди, потом снова усмехается — на этот раз тише и более искренне."

# game/script.rpy:655
translate russian ruta_normal_9_2d4c2ce6:

    # J "No sé si esto fue divertido porque hablé contigo o porque te arruiné el día."
    J "Даже не знаю, было ли весело потому, что я поговорил с тобой, или потому, что испортил тебе день."

# game/script.rpy:656
translate russian ruta_normal_9_d735a1aa:

    # "La declaración salió con una franqueza inquietante."
    "Слова прозвучали с неприятной прямотой."

# game/script.rpy:657
translate russian ruta_normal_9_e3a146df:

    # "No sabías como reaccionar, pero sí sabías que al final Jeff había hecho las cosas adrede"
    "Вы не знаете, как на это ответить, но уже понимаете: Джефф намеренно всё это затеял."

# game/script.rpy:658
translate russian ruta_normal_9_28cc16f3:

    # pov "Bueno… al menos reconoces que no fuiste exactamente un deleite."
    pov "Ну... хотя бы признаёшь, что сам не подарок."

# game/script.rpy:659
translate russian ruta_normal_9_14db9991:

    # J "Claro, no soy idiota, me doy cuenta de lo que provoco en la gente."
    J "Разумеется, я же не идиот. Понимаю, какое впечатление произвожу."

# game/script.rpy:660
translate russian ruta_normal_9_90119485:

    # "Jeff se encogió de hombros, para después ladear la cabeza, interrogante y burlesco."
    "Он пожимает плечами и наклоняет голову с насмешливым любопытством."

# game/script.rpy:661
translate russian ruta_normal_9_3731e46e:

    # J "¿Tratas a todos los clientes así o soy especial?"
    J "Ты всех клиентов так обслуживаешь или я особенный?"

# game/script.rpy:662
translate russian ruta_normal_9_4d226e02:

    # "No pudiste evitar soltar una pequeña carcajada ante sus palabras."
    "Вы не смогли сдержать смешок, услышав его слова."

# game/script.rpy:663
translate russian ruta_normal_9_76f846b2:

    # pov "¿Sabes qué?, no suelo gastar tanta energía en desconocidos. Pero tú te lo ganaste."
    pov "Знаешь, я обычно не трачу столько сил на случайных людей. Но ты это заслужил."

# game/script.rpy:667
translate russian ruta_normal_9_01ac062d:

    # "Jeff se enderezó repentinamente, contento, como si le hubieran dicho que consiguió un gran logro."
    "Джефф резко выпрямляется, довольный, словно только что совершил великий подвиг."

# game/script.rpy:668
translate russian ruta_normal_9_e59bf4a8:

    # J "¡Lo tomo!"
    J "Возьму это!"

# game/script.rpy:669
translate russian ruta_normal_9_23e642f7:

    # "Por un momento pensaste que Jeff se refería a que tomaba tus palabras con gusto, hasta que te fijaste que los ojos de él estaban dirigidos a la película que habías escogido para colocar en el reproductor."
    "На секунду вам кажется, что он имеет в виду ваши слова, но потом замечаете: его взгляд прикован к фильму, который вы собирались поставить в плеер."

# game/script.rpy:671
translate russian ruta_normal_9_e38d0662:

    # pov "Oh, genial."
    pov "О, прекрасно."

# game/script.rpy:672
translate russian ruta_normal_9_bb4b41d0:

    # "Hablaste con alivio. Por fin Jeff se llevaría algo."
    "Сказали вы с облегчением. Наконец-то Джефф решил что-то взять."

# game/script.rpy:673
translate russian ruta_normal_9_92344c5d:

    # "Además de que era algo que sabías que le gustaba."
    "К тому же, это именно то, что, как вы поняли, ему нравится."

# game/script.rpy:674
translate russian ruta_normal_9_723cede3:

    # "Sentiste que hacer bien tu trabajo no se sintió tan mal."
    "И вдруг оказалось, что выполнять свою работу не так уж и плохо."

# game/script.rpy:676
translate russian ruta_normal_9_65eb677e:

    # pov "Oh, de acuerdo."
    pov "О, ладно."

# game/script.rpy:677
translate russian ruta_normal_9_b02e9d0f:

    # "No creías que le vaya a gustar, pero aprecias que al final se haya llevado algo."
    "Вы сомневаетесь, что ему это действительно понравится, но всё же цените, что он хоть что-то взял."

# game/script.rpy:678
translate russian ruta_normal_9_2d424167:

    # "A pesar de haber hecho bien tu trabajo, no sientes mucha satisfacción"
    "Несмотря на то, что вы справились со своей работой, удовлетворения вы почти не почувствовали."

# game/script.rpy:679
translate russian ruta_normal_9_06f4dacf:

    # pov "Gracias por comprar con nosotros."
    pov "Спасибо за покупку."

# game/script.rpy:680
translate russian ruta_normal_9_bd9528a1:

    # "Jeff asintió, recibiendo la película en su respectiva bolsa y se dirigió a la salida."
    "Джефф кивает, берёт пакет с диском и направляется к выходу."

# game/script.rpy:681
translate russian ruta_normal_9_3005fd63:

    # J "Fue un placer, [povname]."
    J "Было приятно, [povname]."

# game/script.rpy:683
translate russian ruta_normal_9_b853bc69:

    # "Él sacudió su mano a modo de despedida, y tú correspondiste con tu propia mano, aunque no tan entusiasta como la de él."
    "Он машет вам на прощание, и вы отвечаете тем же; хоть и не с таким энтузиазмом, как он."

# game/script.rpy:684
translate russian ruta_normal_9_d5ce5829:

    # "Bueno, lograste venderle al rarito del día."
    "Ну вот, удалось продать что-то придурку дня."

# game/script.rpy:685
translate russian ruta_normal_9_278c84ce:

    # "Fue un logro, después de todo."
    "В конце концов, уже это можно считать достижением."

# game/script.rpy:691
translate russian ruta_normal_10_f8fe4a1f:

    # "Tu día laboral ha terminado."
    "Рабочий день подошёл к концу."

# game/script.rpy:692
translate russian ruta_normal_10_69ecb368:

    # "Dentro de todo, fue tranquilo."
    "В целом он прошёл спокойно."

# game/script.rpy:693
translate russian ruta_normal_10_011b6360:

    # "La noche ha caído, pero no es razón para preocuparte porque vives a unas calles."
    "Ночь уже опустилась, но беспокоиться не о чем — ваш дом находится всего в паре кварталов отсюда."

# game/script.rpy:694
translate russian ruta_normal_10_7d1b8af5:

    # "Algunas cosas son así de convenientes."
    "Пожалуй, в чём-то жизнь всё же бывает удобной."

# game/script.rpy:695
translate russian ruta_normal_10_73825a29:

    # "Esta semana le tocaba a Cindy quedarse para cerrar la tienda."
    "На этой неделе закрывать магазин выпадает Синди."

# game/script.rpy:696
translate russian ruta_normal_10_7d132380:

    # "Como ustedes dos tienen casi el mismo cargo, decidieron que la tarea de cerrar sería por turnos."
    "Поскольку у вас двоих почти одинаковые должности, вы решили чередоваться с закрытием магазина."

# game/script.rpy:697
translate russian ruta_normal_10_d3cebf8b:

    # "Así que tu estabas con tus cosas listas para irte a tu hogar."
    "Сегодня очередь не ваша, так что вы уже собрали вещи и готовитесь идти домой."

# game/script.rpy:700
translate russian ruta_normal_10_f690edb1:

    # C "¿Vas a estar bien?"
    C "Ты точно будешь в порядке?"

# game/script.rpy:701
translate russian ruta_normal_10_a92e43d0:

    # pov "Claro, ¿Por qué no lo estaría?"
    pov "Конечно, а с чего бы нет?"

# game/script.rpy:702
translate russian ruta_normal_10_8df76e26:

    # C "Ese tipo, parecía estar algo fijado en ti."
    C "Тот тип был как будто зациклен на тебе."

# game/script.rpy:703
translate russian ruta_normal_10_5b6cbcc6:

    # "Resoplas con ironía."
    "Вы иронично фыркаете."

# game/script.rpy:704
translate russian ruta_normal_10_e926f3e7:

    # pov "Vamos, ¿En mi?"
    pov "Да ладно, на мне?"

# game/script.rpy:706
translate russian ruta_normal_10_1b2ad7d4:

    # C "Si, tampoco lo entiendo."
    C "Да, я сама не понимаю."

# game/script.rpy:707
translate russian ruta_normal_10_9f9aa0ea:

    # "Ok, ouch."
    "Ладно, это было больно."

# game/script.rpy:709
translate russian ruta_normal_10_36c496c7:

    # C "Pero, ¿Y si te sigue?"
    C "А если он за тобой пойдёт?"

# game/script.rpy:710
translate russian ruta_normal_10_3df52fa3:

    # pov "Eso no va a pasar. Se fue hace horas, es imposible que se haya quedado rondando por aquí."
    pov "Это исключено. Он ушёл ещё пару часов назад — сомневаюсь, что кто-то будет всё это время слоняться вокруг магазина."

# game/script.rpy:711
translate russian ruta_normal_10_ac1aea29:

    # C "No lo sé… tu sensor de peligro no es muy acertado que digamos."
    C "Ну не знаю... Твой внутренний датчик опасности, скажем так, не слишком надёжен."

# game/script.rpy:712
translate russian ruta_normal_10_7906ca35:

    # pov "El peligro es subjetivo."
    pov "Опасность — понятие относительное."

# game/script.rpy:714
translate russian ruta_normal_10_4e645e54:

    # C "Eso no es así."
    C "Вообще нет."

# game/script.rpy:715
translate russian ruta_normal_10_21a3cd41:

    # pov "¿Por qué te importa tanto?, creí que me odiabas."
    pov "С чего тебе вообще так переживать? Я думали, ты меня ненавидишь."

# game/script.rpy:717
translate russian ruta_normal_10_4d72f6db:

    # "Cindy se sorprende ante tus palabras. Desvía la mirada hacia un lado, jugando con la vara de la mopa que tenía en manos, para limpiar antes de cerrar."
    "Синди удивлённо поднимает взгляд, потом отводит глаза в сторону, повертев в руках швабру, которой собиралась прибраться перед закрытием."

# game/script.rpy:718
translate russian ruta_normal_10_4da6f8f6:

    # C "No te odio… Sólo pienso que estar contigo es aburrido."
    C "Я не ненавижу тебя... Просто с тобой скучновато."

# game/script.rpy:719
translate russian ruta_normal_10_63b5d32e:

    # pov "Sí, bueno, tú no eres exactamente el alma de la fiesta."
    pov "Да? Ну, ты тоже не сказать чтоб душа компании."

# game/script.rpy:721
translate russian ruta_normal_10_0ee3a25f:

    # C "No lo digo como algo malo, en realidad… siento paz contigo."
    C "Я не со зла, правда... просто с тобой спокойно."

# game/script.rpy:722
translate russian ruta_normal_10_b746947b:

    # pov "Oh."
    pov "Оу."

# game/script.rpy:723
translate russian ruta_normal_10_18b6c29b:

    # C "Tu despreocupación por todo puede llegar a ser tedioso, pero también es reconfortante… de alguna manera."
    C "Твоя беззаботность порой раздражает, но одновременно и успокаивает... в каком-то смысле."

# game/script.rpy:724
translate russian ruta_normal_10_a068fddf:

    # "Rascas tu cabeza, sin saber cómo reaccionar ante las palabras de Cindy. En realidad nunca te había dicho algo lindo hasta ahora."
    "Вы почесали затылок, не зная, как ответить на слова Синди. Раньше она никогда не говорила вам ничего приятного."

# game/script.rpy:726
translate russian ruta_normal_10_b5a34223:

    # "Cindy se aclara la garganta, desviando la mirada con una mueca avergonzada."
    "Синди прокашлялась, отворачиваясь с немного смущённой гримасой."

# game/script.rpy:727
translate russian ruta_normal_10_16e04610:

    # C "Lo que quiero decir… es que no quiero que te pase nada."
    C "Я хотела сказать... я просто не хочу, чтобы с тобой что-нибудь случилось."

# game/script.rpy:728
translate russian ruta_normal_10_32448f1f:

    # "Das un paso a ella y posas tu mano en su hombro, sonriéndole con calma."
    "Вы делаете шаг к ней и кладёте руку ей на плечо, спокойно улыбаясь."

# game/script.rpy:729
translate russian ruta_normal_10_60dad86e:

    # pov "Estaré bien. Que algo raro pase no significa que el universo haya decidido girar en mi contra."
    pov "Со мной всё будет хорошо. То, что случилось что-то странное, ещё не значит, что весь мир ополчился против меня."

# game/script.rpy:730
translate russian ruta_normal_10_c3e697c9:

    # "Ustedes compartieron un último gesto de despedida antes de que tú cerraras la puerta detrás de ti."
    "Вы обмениваетесь последним прощальным жестом, прежде чем закрыть за собой дверь."

# game/script.rpy:732
translate russian ruta_normal_10_405fbc5b:

    # "El letrero de la tienda indicaba que estaba cerrado, y tú suspiraste, sintiendo que el peso de vivir una vida adulta en un mundo capitalista se levantaba un poco de tus hombros."
    "Табличка на двери гласит, что магазин закрыт, — и вы выдыхаете, чувствуя, как груз взрослой жизни в капиталистическом мире ненадолго сбрасывается с плеч."

# game/script.rpy:733
translate russian ruta_normal_10_479fead5:

    # "Sólo un poco."
    "Совсем немного."

# game/script.rpy:735
translate russian ruta_normal_10_29fc634a:

    # "Es parte de la rutina, despedirte de Cindy e irte finalmente a tu hogar."
    "Это часть привычного распорядка — попрощаться с Синди и наконец отправиться домой."

# game/script.rpy:736
translate russian ruta_normal_10_789485ef:

    # "Vives por tu cuenta desde que empezaste a trabajar, por lo que no tienes responsabilidades extra por las que preocuparte, eso te daba espacio para concentrarte en tus propias necesidades."
    "Вы живёте одни с тех самых пор, как начали работать, поэтому нет никаких лишних обязанностей, которые могли бы вас тяготить. Это даёт возможность сосредоточиться на себе и своих нуждах."

# game/script.rpy:737
translate russian ruta_normal_10_fdc40514:

    # "No es una vida extraordinaria, pero es funcional."
    "Жизнь у вас не из примечательных, но вполне сносная."

# game/script.rpy:738
translate russian ruta_normal_10_e865c2f2:

    # "Trabajas durante la semana, ganas dinero suficiente para el alquiler y las cuentas, y descansas los fines de semana."
    "По будням — работа, дохода хватало на оплату аренды и счетов, а в выходные — отдых."

# game/script.rpy:739
translate russian ruta_normal_10_52d12e2c:

    # "A pesar de que la calle está bien iluminada, el ambiente no deja de ser lúgubre mientras caminas en dirección a tu departamento."
    "Несмотря на то, что улица хорошо освещена, атмосфера всё равно остаётся мрачной, пока вы идёте в направлении своей квартиры."

# game/script.rpy:740
translate russian ruta_normal_10_05a725ca:

    # "Siempre ha sido así. Nada por lo que temer. ¿Cierto?"
    "Так всегда. Ничего странного. Бояться нечего, правда?"

# game/script.rpy:752
translate russian ruta_mala_1_dcf6eb48:

    # "Repentinamente, sientes el sonido de pasos acelerados desde atrás."
    "Вдруг за спиной раздаётся звук торопливых шагов."

# game/script.rpy:754
translate russian ruta_mala_1_6ec1599f:

    # "Te giras para poder reaccionar, pero sientes que unos brazos te rodean fuertemente por el cuello, lo que te inmoviliza."
    "Вы резко оборачиваетесь, но не успеваете среагировать — чьи-то руки смыкаются у вас на шее, крепко, не давая пошевелиться."

# game/script.rpy:756
translate russian ruta_mala_1_a839a0ff:

    # "Forcejeas para liberarte, pero es entonces que sientes la presión en tu estómago."
    "Вы дёргаетесь, пытаясь освободиться, — и в этот момент ощущаете давление в районе живота."

# game/script.rpy:759
translate russian ruta_mala_1_a32b7649:

    # "El frío se ramifica desde tu estómago hasta el resto de tu cuerpo, y puedes jurar que sientes tus entrañas al aire libre."
    "Холод растекается по телу, начиная изнутри, откуда-то из живота, и вам кажется, будто внутренности вываливаются наружу."

# game/script.rpy:760
translate russian ruta_mala_1_369e00db:

    # "Tu cuerpo se estremece tras ser perforado, y es entonces que el dolor llega."
    "Тело содрогается, пронзённое, и вот тогда приходит боль."

# game/script.rpy:761
translate russian ruta_mala_1_624f73a6:

    # "Duele, duele mucho."
    "Больно, чертовски больно."

# game/script.rpy:762
translate russian ruta_mala_1_dfbe77d5:

    # "Es tan intenso que no puedes sentir tus extremidades."
    "Настолько, что вы перестаёте чувствовать свои конечности."

# game/script.rpy:763
translate russian ruta_mala_1_d79a79c2:

    # "¿Así es cómo ibas a morir?"
    "Неужели вот так вы и умрёте?"

# game/script.rpy:764
translate russian ruta_mala_1_ec2dcadc:

    # "Sabías que iba a pasar eventualmente, pero no sabías que iba a doler tanto."
    "В глубине души вы знали — когда-нибудь это случится. Просто не думали, что будет так больно."

# game/script.rpy:765
translate russian ruta_mala_1_58673d96:

    # "¿Quién pudo hacerte esto?"
    "Кто мог это сделать?"

# game/script.rpy:766
translate russian ruta_mala_1_a738b8a0:

    # "Algo tan cruel…"
    "Что-то столь жестокое..."

# game/script.rpy:767
translate russian ruta_mala_1_12ae082c:

    # "¿Si quiera te lo merecías?"
    "Заслужили ли вы это хоть чем-то?"

# game/script.rpy:768
translate russian ruta_mala_1_958897ff:

    # "No eras una santidad, pero no te considerabas una mala persona."
    "Да, святым вы не были, но и плохим человеком себя не считали."

# game/script.rpy:770
translate russian ruta_mala_1_b8289e29:

    # "El último pensamiento que cruzó por tu mente, es que Cindy tendrá que cubrir tu turno mientras buscan un reemplazo."
    "И последняя мысль, мелькнувшая в голове, — о том, что теперь Синди придётся работать за вас, пока не найдут замену."

# game/script.rpy:774
translate russian ruta_mala_1_1fea95e6:

    # "{b}Final I: No Llamaste Su Atención{/b}"
    "{b}Концовка I: Вы не смогли привлечь его внимание{/b}"

# game/script.rpy:782
translate russian historia_continua_1_7780c235:

    # "Es entonces que sientes que tiran de tu brazo hacia un lado, con una gran fuerza."
    "В этот момент вы чувствуете, как кто-то резко дёргает вас за руку в сторону."

# game/script.rpy:783
translate russian historia_continua_1_37b85890:

    # "Tal vez sí debiste estar más alerta."
    "Может, стоило быть внимательнее."

# game/script.rpy:786
translate russian historia_continua_1_d076a17a:

    # "Tiran de ti hasta un callejón al lado de la calle, es ligeramente más oscuro, pero por un farol al costado puedes distinguir lo que está frente a ti."
    "Вас затаскивают в переулок сбоку от улицы. Там чуть темнее, но свет ближайшего фонаря позволяет различить то, что находится перед вами."

# game/script.rpy:787
translate russian historia_continua_1_b136983e:

    # "Como la repentina acción te desorientó, te demoras en reaccionar."
    "Всё произошло слишком быстро — из-за внезапности вы не сразу приходите в себя."

# game/script.rpy:788
translate russian historia_continua_1_c815043a:

    # pov "¿Que mierd-?"
    pov "Что за—?"

# game/script.rpy:790
translate russian historia_continua_1_7298b65e:

    # "El sonido de un golpe leve a un lado de tu cabeza te interrumpe, y te das cuenta que la persona te acorraló contra la pared de ladrillos detrás de ti."
    "Тихий удар сбоку по голове обрывает ваши слова. Вы осознаёте, что вас прижали к прохладной кирпичной стене."

# game/script.rpy:791
translate russian historia_continua_1_4cf5d3d7:

    # "Miras de reojo el brazo de la persona, una familiar manga blanca cubre un brazo que se alarga desde tu punto ciego hacia delante."
    "Краем глаза вы замечаете руку нападавшего — знакомый белый рукав тянется из вашей слепой зоны вперёд."

# game/script.rpy:792
translate russian historia_continua_1_a3f5837b:

    # "Te cansas de la intriga y finalmente alzas la mirada hacia la persona que te acorraló, tienes un idea de quien podría ser."
    "Устав от интриги, вы наконец поднимаете взгляд на того, кто загнал вас в угол. Вы догадывались, кто это мог быть."

# game/script.rpy:797
translate russian historia_continua_1_d3542d80:

    # J "[povname], nos encontramos de nuevo."
    J "[povname], вот мы и встретились."

# game/script.rpy:798
translate russian historia_continua_1_66f6a037:

    # "La incertidumbre te invade ante la vista de un rostro blanco, lleno de cicatrices."
    "Неуверенность охватывает вас при виде бледного лица, покрытого шрамами."

# game/script.rpy:799
translate russian historia_continua_1_20aa010b:

    # "Jeff se había quitado la capucha y la bandana, revelando su rostro."
    "Джефф снимает капюшон и повязку, обнажая своё лицо."

# game/script.rpy:800
translate russian historia_continua_1_c546e882:

    # "La piel variaba de colores y texturas, su nariz estaba hundida, sus ojos azules lechosos estaban sumidos en párpados negros, y tenías la seguridad de que no lo has visto parpadear ni una sóla vez."
    "Его кожа неравномерна по цвету и текстуре; нос впалый, мутные голубые глаза утопают в чёрных впадинах век, и вы уверены в том, что он ни разу не моргнул."

# game/script.rpy:801
translate russian historia_continua_1_ffe6c6c8:

    # "Pero lo que llamó más tu atención, fue la cicatriz que atravesaba su boca."
    "Но больше всего ваше внимание привлекает шрам, пересекающий его рот."

# game/script.rpy:802
translate russian historia_continua_1_9eb6c8c7:

    # "No parecía ser un corte limpio, y el cómo deformaba la expresión de él te causó un escalofrío desagradable."
    "Это не аккуратный разрез — неровная рана искажает выражение лица так, что по спине пробегает неприятный озноб."

# game/script.rpy:803
translate russian historia_continua_1_7bc7ae10:

    # "Suponías que su rostro tendría imperfecciones que él querría esconder para no recibir miradas de desconocidos, pero considerando la bizarra situación, no fue sorprendente."
    "Вы предполагали, что на его лице могут быть изъяны, которые он предпочитает скрывать, чтобы не привлекать внимание прохожих. Но при таком странном развитии событий это уже не удивляет."

# game/script.rpy:804
translate russian historia_continua_1_f9ed2707:

    # pov "¿Jeff?"
    pov "Джефф?"

# game/script.rpy:805
translate russian historia_continua_1_d1ab8411:

    # "Ciertamente, estabas en desventaja aquí, por lo que intentas pensar maneras para dar vuelta la mesa."
    "Без сомнений, вы находитесь в невыгодном положении, поэтому лихорадочно пытаетесь придумать, как обернуть ситуацию в свою пользу."

# game/script.rpy:806
translate russian historia_continua_1_5cd86084:

    # pov "Wow, quién lo hubiera imaginado, de noche, alguien solo, callejón lúgubre, un clásico."
    pov "Вау, кто бы мог подумать. Ночь, одинокий человек, тёмный переулок. Классика."

# game/script.rpy:807
translate russian historia_continua_1_b641250c:

    # "Jeff se rió entre dientes ante tu sarcasmo."
    "Джефф усмехается вашему сарказму."

# game/script.rpy:808
translate russian historia_continua_1_27e95444:

    # J "No dejas la actitud, ¿Eh?"
    J "Всё та же манера, а?"

# game/script.rpy:812
translate russian historia_continua_1_7ce8cd1f:

    # "Para luego sacar del bolsillo de su capucha un… cuchillo."
    "И после этих слов он медленно достаёт из кармана толстовки... нож."

# game/script.rpy:813
translate russian historia_continua_1_65abf3f0:

    # J "Ahora… aseguráte de darme un buen espectáculo."
    J "А теперь... постарайся устроить мне достойное зрелище."

# game/script.rpy:814
translate russian historia_continua_1_87ac3896:

    # "La voz de él era rasposa, acelerada en un tono ansioso. Daba la impresión de que él estaba impaciente."
    "Его голос хриплый, сбивчивый, с нетерпеливой интонацией. Кажется, он едва сдерживается."

# game/script.rpy:815
translate russian historia_continua_1_711eff21:

    # pov "¿... Espectáculo?"
    pov "...Зрелище?"

# game/script.rpy:816
translate russian historia_continua_1_59f910aa:

    # J "El miedo es exquisito…"
    J "Страх восхитителен..."

# game/script.rpy:817
translate russian historia_continua_1_8f73355e:

    # "Él susurró, casi (e innecesariamente) poético, inclinándose hacia ti, su respiración rozando tu rostro."
    "Он шепчет это почти с (ненужной) поэтической вычурностью, наклоняясь ближе, настолько, что его дыхание касается вашего лица."

# game/script.rpy:818
translate russian historia_continua_1_90c55b6f:

    # pov "Hey, no es por nada… pero todo tu acercamiento se siente muy cliché."
    pov "Слушай, без обид... но твой подход чересчур банальный."

# game/script.rpy:819
translate russian historia_continua_1_a2a56b45:

    # "Jeff ladeó la cabeza hacia un lado, hubieras jurado que eso era el equivalente de él alzando una ceja."
    "Джефф склоняет голову набок — вы можете поклясться, что это равносильно поднятой брови."

# game/script.rpy:820
translate russian historia_continua_1_f188a2b1:

    # "Si él tuviera cejas."
    "Если бы у него вообще были брови."

# game/script.rpy:821
translate russian historia_continua_1_29af6601:

    # J "No es un momento adecuado para bromear, ¿No crees?"
    J "Сейчас не время для шуток, не находишь?"

# game/script.rpy:822
translate russian historia_continua_1_cf7fac73:

    # pov "Si, bueno, realmente no sé qué te motivó a atacarme, pensé que nos estábamos llevando bien."
    pov "Ну, не знаю, я так и не поняли, с чего ты вдруг решил на меня напасть. Мне казалось, мы неплохо ладили."

# game/script.rpy:823
translate russian historia_continua_1_b4b21736:

    # "Jeff presionó el ancho de la hoja contra tu mejilla, el metal frío contra tu piel tibia."
    "Джефф прижимает лезвие к вашей щеке — холодный металл резко контрастирует с теплом вашей кожи."

# game/script.rpy:824
translate russian historia_continua_1_aeb4f907:

    # J "¿Estás preguntando qué te hace especial?"
    J "Спрашиваешь, что делает тебя особенными?"

# game/script.rpy:825
translate russian historia_continua_1_b6fd1da7:

    # pov "¿Ser especial es que me lleves a un callejón oscuro?, Vaya, no debes ser muy popular."
    pov "Быть особенным — значит быть затащенным в тёмный переулок? Вау, видимо, популярностью ты не пользуешься."

# game/script.rpy:826
translate russian historia_continua_1_6eb80083:

    # "Jeff resopló con molestia."
    "Джефф раздражённо фыркает."

# game/script.rpy:828
translate russian historia_continua_1_e4740630:

    # "Te sujetó el hombro con la mano con la que te acorraló, y te estrelló contra el muro detrás de ti."
    "Он хватает вас за плечо той же рукой, что удерживала вас, и со всей силы впечатывает в стену позади."

# game/script.rpy:829
translate russian historia_continua_1_4c5dd3b4:

    # "Sentiste tu cabeza golpear contra la textura áspera de la superficie dura, lo que te hizo sisear."
    "Вы чувствуете, как ваша голова ударяется о шероховатую поверхность, и содрогаетесь от боли."

# game/script.rpy:835
translate russian historia_continua_1_a1e16c99:

    # pov "Lo siento, ¿Si?"
    pov "Прости, ладно?"

# game/script.rpy:836
translate russian historia_continua_1_71679a68:

    # pov "No quise hacerte enojar."
    pov "Я не хотели тебя злить."

# game/script.rpy:837
translate russian historia_continua_1_10d23d8c:

    # "Jeff estiró su ya de por sí gran sonrisa, y bajó el cuchillo."
    "Улыбка Джеффа, и без того широкая, ещё сильнее расползается по лицу, и он опускает нож."

# game/script.rpy:838
translate russian historia_continua_1_c287a789:

    # "Pero en el momento en que sentiste alivio por no ver el arma blanca, una punzada en el estómago te invadió."
    "Но в тот самый миг, когда вы успели почувствовать облегчение — будто опасность миновала, — живот пронзает резкая боль."

# game/script.rpy:841
translate russian historia_continua_1_9dbefc29:

    # "Instintivamente, tu voz salió en un grito, pero tu boca fue cubierta por una mano que ahogó tu voz en tu garganta."
    "Вы инстинктивно вскрикиваете, но его ладонь накрывает ваш рот, заглушая голос."

# game/script.rpy:842
translate russian historia_continua_1_b66154e4:

    # J "Así que sí sientes miedo, después de todo…"
    J "Значит, ты всё-таки умеешь бояться..."

# game/script.rpy:845
translate russian historia_continua_1_af4ddf79:

    # "¿De eso se trataba?"
    "Так дело в этом?"

# game/script.rpy:846
translate russian historia_continua_1_985b0de6:

    # "De verdad había mucha gente rara en el mundo."
    "В мире и правда хватает странных людей."

# game/script.rpy:847
translate russian historia_continua_1_393c0e5e:

    # "Bueno, estabas por dejar de dejar de existir de todas maneras, ya no tendrías que lidiar con eso."
    "Впрочем, вы всё равно собирались перестать быть частью этого мира, так что теперь вам не нужно об этом беспокоиться."

# game/script.rpy:850
translate russian historia_continua_1_96dc7a76:

    # "Fuiste alguien más del montón para Jeff."
    "Для Джеффа вы были просто очередной жертвой."

# game/script.rpy:854
translate russian historia_continua_1_a3b6b84e:

    # pov "Más fuerte~"
    pov "Сильнее~"

# game/script.rpy:855
translate russian historia_continua_1_3e73e32c:

    # "Jeff te soltó y retrocedió un par de pasos, como si quemaras."
    "Джефф резко отпускает вас и отступает на пару шагов, как ошпаренный."

# game/script.rpy:860
translate russian historia_continua_1_b96635c7:

    # "Su expresión reflejaba sorpresa, y fue una reacción más grande de lo que esperabas."
    "На лице у него отражается искреннее удивление — более сильная реакция, чем вы ожидали."

# game/script.rpy:861
translate russian historia_continua_1_83625366:

    # pov "Relájate, sólo bromeo."
    pov "Расслабься, просто шучу."

# game/script.rpy:862
translate russian historia_continua_1_0b347551:

    # J "…No fue gracioso."
    J "...Не смешно."

# game/script.rpy:863
translate russian historia_continua_1_cfeeb0e6:

    # pov "Para mi lo fue."
    pov "А по-моему, вполне."

# game/script.rpy:864
translate russian historia_continua_1_f655c4e9:

    # J "¡Cállate, esto no debería ser divertido!"
    J "Заткнись! Тебе не должно быть весело!"

# game/script.rpy:865
translate russian historia_continua_1_4f9bc483:

    # J "¡Deberías tener miedo!"
    J "Тебе должно быть страшно!"

# game/script.rpy:870
translate russian supervivencia_1_87229444:

    # "Jeff se acercó nuevamente, alzando el cuchillo hasta tu cuello."
    "Джефф вновь приближается, поднимая нож к вашему горлу."

# game/script.rpy:871
translate russian supervivencia_1_f1361762:

    # "Por reflejo, te alejaste de la hoja, sintiendo la punta perforar tu barbilla."
    "Вы рефлекторно отшатываетесь от лезвия, чувствуя, как остриё пронзает ваш подбородок."

# game/script.rpy:872
translate russian supervivencia_1_12e06310:

    # J "Estás en un callejón, de noche, con un cuchillo en tu cuello…"
    J "Ты в тёмном переулке, посреди ночи, с ножом у горла..."

# game/script.rpy:873
translate russian supervivencia_1_d7b64098:

    # J "Así que te preguntaré de nuevo."
    J "Ещё раз спрашиваю."

# game/script.rpy:874
translate russian supervivencia_1_56b48378:

    # J "¿Tienes miedo?"
    J "Тебе страшно?"

# game/script.rpy:879
translate russian supervivencia_1_55323a12:

    # "Jeff no ha provocado mucha impresión en ti."
    "Джефф не произвёл на вас особого впечатления."

# game/script.rpy:880
translate russian supervivencia_1_f2f1c3b2:

    # "Eres consciente que tu situación es peligrosa, pero… realmente no te podría importar menos."
    "Конечно, вы понимаете, что ситуация опасная, но... по правде говоря, вас это совершенно не волнует."

# game/script.rpy:881
translate russian supervivencia_1_ed2da1f7:

    # "Pero de todas formas, parecía ser divertido ver lo que sucede si te metes con él."
    "Более того — внутри зародилось любопытство: а что будет, если поддразнить его ещё немного?"

# game/script.rpy:882
translate russian supervivencia_1_0f4e1967:

    # "Por el momento, decidiste seguirle la corriente."
    "Пока вы решаете подыграть."

# game/script.rpy:883
translate russian supervivencia_1_08fbf2f1:

    # pov "¿Sabes qué?, si, tengo miedo."
    pov "А знаешь что? Да, страшно."

# game/script.rpy:888
translate russian supervivencia_1_fa5d173a:

    # "Que Jeff se joda."
    "К чёрту Джеффа."

# game/script.rpy:889
translate russian supervivencia_1_0a058309:

    # "No tienes ganas de lidiar con un loco sádico."
    "У вас нет ни малейшего желания возиться с каким-то садистом-психом."

# game/script.rpy:890
translate russian supervivencia_1_a076b74f:

    # pov "Siga participando."
    pov "Удачи в следующий раз."

# game/script.rpy:891
translate russian supervivencia_1_fdc76934:

    # "La sonrisa de Jeff cae, sutilmente."
    "Улыбка Джеффа подрагивает и медленно сползает с его лица."

# game/script.rpy:892
translate russian supervivencia_1_5dfb0431:

    # J "¿Oh? ¿Así que así son las cosas?"
    J "О? Вот как?"

# game/script.rpy:895
translate russian supervivencia_1_f48b149f:

    # "Un dolor intenso, agudo, que se ramifica desde tu estómago hasta las puntas de tus dedos te invade, quitándote el aliento."
    "Внезапно всё тело пронзает острая, всепоглощающая боль — от живота до кончиков пальцев, выбивая воздух из лёгких."

# game/script.rpy:896
translate russian supervivencia_1_c2cdfe7d:

    # "Tu voz se atora en la base de tu garganta."
    "Голос застревает где-то в горле."

# game/script.rpy:897
translate russian supervivencia_1_64ffeb12:

    # J "¡¡Hahahahaha!!"
    J "Хахахахаха!!"

# game/script.rpy:898
translate russian supervivencia_1_bef58e60:

    # "La risa descontrolada de Jeff es lo único que escuchas."
    "Безудержный смех Джеффа — единственное, что вы слышите."

# game/script.rpy:899
translate russian supervivencia_1_9ca6fe1a:

    # "Realmente suena como si se estuviera divirtiendo."
    "И звучит он так, будто ему действительно весело."

# game/script.rpy:901
translate russian supervivencia_1_ea5b8ad9:

    # "Él te mantiene de pie con su mano en tu hombro, pero sientes que te suelta."
    "Его ладонь всё ещё держит вас за плечо, не давая упасть. Но вдруг вы чувствуете, как хватка ослабевает."

# game/script.rpy:903
translate russian supervivencia_1_747987a4:

    # "Inevitablemente caes al suelo, sintiendo frío, mucho frío. Las extremidades te pesan y no puedes abrir los ojos por más que lo intentes."
    "Вы неизбежно падаете на землю, ощущая холод. Сильный холод. Конечности тяжелеют, и вы не можете открыть глаза, как бы ни старались."

# game/script.rpy:906
translate russian supervivencia_1_561cdaaf:

    # "No contuviste a Jeff."
    "Вам не удалось остановить Джеффа."

# game/script.rpy:912
translate russian supervivencia_2_721185f9:

    # "Jeff recuperó su ánimo, extendiendo su gran sonrisa."
    "Джефф снова приободрился, его широкая улыбка вернулась."

# game/script.rpy:913
translate russian supervivencia_2_e93df6d2:

    # "Él bajó el cuchillo, pero lo mantuvo en su mano."
    "Он опускает нож, но не убирает его из руки."

# game/script.rpy:914
translate russian supervivencia_2_5fa9007d:

    # "No te estaba amenazando, quizás quería seguir divirtiéndose contigo."
    "Не похоже, что он собирается угрожать; скорее, хочет продолжить игру."

# game/script.rpy:915
translate russian supervivencia_2_ed5207bf:

    # J "Bien, bien, eso quería oír."
    J "Хорошо, хорошо, это я и хотел услышать."

# game/script.rpy:916
translate russian supervivencia_2_db4fce28:

    # "Típico."
    "Банально."

# game/script.rpy:917
translate russian supervivencia_2_6b526010:

    # J "Ahora, ¿Qué te da miedo de mi?"
    J "А теперь скажи, чего именно ты во мне боишься?"

# game/script.rpy:918
translate russian supervivencia_2_24733583:

    # "Evidentemente, Jeff disfrutaba de ver el miedo en sus víctimas."
    "Очевидно, Джефф наслаждается страхом своих жертв."

# game/script.rpy:919
translate russian supervivencia_2_c7eb33ac:

    # "Por el momento lograste mantenerlo lo suficientemente contento como para mantener una conversación contigo, pero quizás él buscaba escarbar más."
    "Пока вам удаётся держать его в хорошем настроении — ровно настолько, чтобы он продолжал разговор. Но, возможно, ему хочется копнуть глубже."

# game/script.rpy:920
translate russian supervivencia_2_bff97120:

    # "Tal vez le gustaba saber lo que él provocaba en sus víctimas con detalle."
    "Может, ему доставляет удовольствие слушать, что именно он вызывает в своих жертвах."

# game/script.rpy:921
translate russian supervivencia_2_8b30829a:

    # "Eso es gracioso."
    "Забавно."

# game/script.rpy:922
translate russian supervivencia_2_d7c27310:

    # "¿Puedes aceptar el desafío de mimarlo?"
    "Сумеете ли вы потакать его желаниям?"

# game/script.rpy:926
translate russian supervivencia_2_1815d7fe:

    # J "¿Mi cara? No eres la única persona en decir eso."
    J "Моё лицо? Ты не первые, кто это говорит."

# game/script.rpy:927
translate russian supervivencia_2_478efdd5:

    # pov "Sí bueno, es un look... Único."
    pov "Ну, ты выглядишь... необычно."

# game/script.rpy:929
translate russian supervivencia_2_7f01bc01:

    # "La sonrisa de Jeff se extendió."
    "Улыбка Джеффа расползается шире."

# game/script.rpy:930
translate russian supervivencia_2_0630d6af:

    # J "¿Dices que soy hermoso?"
    J "Хочешь сказать, я красивый?"

# game/script.rpy:931
translate russian supervivencia_2_240153ac:

    # "Bueno, parece ser vanidoso respecto a su apariencia."
    "Кажется, он не лишён тщеславия в отношении своей внешности."

# game/script.rpy:932
translate russian supervivencia_2_efd67d59:

    # pov "Claro, tus cicatrices son encantadoras."
    pov "Разумеется, твои шрамы очаровательны."

# game/script.rpy:935
translate russian supervivencia_2_c12880b6:

    # J "Huh, nadie había dicho antes eso, haha."
    J "Хм, никто раньше такого не говорил, ха-ха."

# game/script.rpy:936
translate russian supervivencia_2_6eb2857f:

    # pov "Suenas joven, ¿Cuántos años tienes?"
    pov "Ты звучишь молодо. Сколько тебе лет?"

# game/script.rpy:937
translate russian supervivencia_2_6664fd83:

    # "Jeff se sobresaltó de la emoción."
    "Джефф вздрагивает от волнения."

# game/script.rpy:939
translate russian supervivencia_2_5a3a4017:

    # J "¿Te parece?"
    J "Правда?"

# game/script.rpy:940
translate russian supervivencia_2_9e93dc8c:

    # "Y él ignoró por completo tu pregunta."
    "И он пропустил ваш вопрос мимо ушей."

# game/script.rpy:941
translate russian supervivencia_2_0ab402a0:

    # "Tal vez era de esos que no le gustaba decir su edad."
    "Похоже, он из тех, кто не любит говорить о возрасте."

# game/script.rpy:945
translate russian supervivencia_2_4c56e5dc:

    # J "¡Qué grosero!"
    J "Как грубо!"

# game/script.rpy:946
translate russian supervivencia_2_c404ba9b:

    # "Su voz sonó más divertida que ofendida."
    "Голос звучит скорее весело, чем оскорблённо."

# game/script.rpy:947
translate russian supervivencia_2_5c10dc63:

    # J "Me gustan los desafíos…"
    J "Мне нравятся вызовы..."

# game/script.rpy:948
translate russian supervivencia_2_fd0c67a2:

    # "La forma en que dijo eso fue aún más aterradora."
    "То, как он это произносит, ещё более жутко."

# game/script.rpy:951
translate russian supervivencia_2_bc765010:

    # J "¡Ding! ¡Ding! ¡Tenemos un ganador!"
    J "Динь-динь! У нас победитель!"

# game/script.rpy:952
translate russian supervivencia_2_9fba5ea9:

    # pov "¿Cuál es el premio?"
    pov "И какой приз?"

# game/script.rpy:954
translate russian supervivencia_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:955
translate russian supervivencia_2_feb1cf35:

    # "Jeff no parece apreciar tu sarcasmo, pero se lo toma a bien."
    "Джефф, похоже, не оценил ваш сарказм, но отнёсся к этому нормально."

# game/script.rpy:956
translate russian supervivencia_2_b505f7e0:

    # J "Podría pensar en algunos…"
    J "Пара вариантов точно найдётся..."

# game/script.rpy:962
translate russian supervivencia_3_8f1749ea:

    # J "Esto es más divertido de lo que creía."
    J "Это веселее, чем я думал."

# game/script.rpy:963
translate russian supervivencia_3_c48b34f5:

    # pov "De todas maneras… ¿Por qué me atacas?"
    pov "Но всё-таки... Зачем ты на меня напал?"

# game/script.rpy:964
translate russian supervivencia_3_bcf3e859:

    # "Jeff te queda mirando unos segundos en silencio, su sonrisa estática."
    "Джефф несколько секунд просто смотрит на вас, его улыбка остаётся неподвижной."

# game/script.rpy:965
translate russian supervivencia_3_14a02595:

    # "Te daban ganas de exigirle que parpadee."
    "Вам прямо захотелось попросить его моргнуть."

# game/script.rpy:966
translate russian supervivencia_3_3d2eb5de:

    # J "Siento que matarte va a ser divertido."
    J "Есть ощущение, что убить тебя будет забавно."

# game/script.rpy:967
translate russian supervivencia_3_b8806b9f:

    # "Genial."
    "Прекрасно."

# game/script.rpy:968
translate russian supervivencia_3_26495026:

    # "Tenías la esperanza de que era un simple ladrón que seguía en su fase de adolescente angsty y sólo quería asustarte, pero resulta que es un loco que genuinamente piensa en asesinarte."
    "Вы ещё надеялись, что он обычный грабитель в затянувшемся подростковом кризисе, который просто хочет вас напугать, но оказалось, что перед вами псих, всерьёз намеренный убить вас."

# game/script.rpy:969
translate russian supervivencia_3_6574df0b:

    # "Sacaste la lotería."
    "Вы сорвали джекпот."

# game/script.rpy:970
translate russian supervivencia_3_7e06a86c:

    # pov "Y yo creí que me había ganado tu corazón."
    pov "А я-то думали, что завоевали твоё сердце."

# game/script.rpy:971
translate russian supervivencia_3_902f2a64:

    # J "Oh~ hace falta mucho más que sólo un día para eso."
    J "Оу~ Одного дня для этого маловато."

# game/script.rpy:972
translate russian supervivencia_3_85cdb876:

    # "Eso parecía ser información útil."
    "Полезная деталь на будущее."

# game/script.rpy:973
translate russian supervivencia_3_32299f29:

    # "Pero para el futuro, ahora deberías concentrarte en sobrevivir."
    "Но сейчас стоит сосредоточиться на том, чтобы выжить."

# game/script.rpy:974
translate russian supervivencia_3_5845e4f9:

    # J "Ya sé. Juguemos a algo."
    J "Придумал. Давай сыграем."

# game/script.rpy:975
translate russian supervivencia_3_d0bf93b8:

    # pov "¿Jugar a qué?"
    pov "Во что?"

# game/script.rpy:976
translate russian supervivencia_3_a8450a72:

    # J "Un simple las traes."
    J "Обычные догонялки."

# game/script.rpy:977
translate russian supervivencia_3_9b1fb005:

    # pov "¿Qué pasa si gano?"
    pov "И что будет, если я выиграю?"

# game/script.rpy:978
translate russian supervivencia_3_3855746b:

    # J "..."
    J "..."

# game/script.rpy:979
translate russian supervivencia_3_fbd8506e:

    # J "Te dejaré ir."
    J "Я тебя отпущу."

# game/script.rpy:980
translate russian supervivencia_3_a5a95d8a:

    # "……………….."
    "..........."

# game/script.rpy:982
translate russian supervivencia_3_afcc87f7:

    # J "¡Es lo que te gustaría que dijera! ¡Hahahaha!"
    J "Это то, что ты хотели бы услышать! Ха-ха-ха!"

# game/script.rpy:983
translate russian supervivencia_3_751b5c2a:

    # "Era un idiota. Un idiota muy peligroso."
    "Он идиот. Очень опасный идиот."

# game/script.rpy:984
translate russian supervivencia_3_8c4bab6b:

    # "Tenías que escoger con cuidado."
    "Придётся выбирать осторожно."

# game/script.rpy:990
translate russian supervivencia_3_9981559c:

    # J "¡Estupendo!"
    J "Отлично!"

# game/script.rpy:992
translate russian supervivencia_3_2535fd97:

    # "Jeff te suelta y retrocede un par de pasos."
    "Джефф отпускает вас и отступает на пару шагов."

# game/script.rpy:994
translate russian supervivencia_3_2207b7a2:

    # J "Te daré una ventaja de 10 segundos."
    J "Даю тебе фору в 10 секунд."

# game/script.rpy:995
translate russian supervivencia_3_a7ce8336:

    # J "1….."
    J "1..."

# game/script.rpy:998
translate russian supervivencia_3_d6cd672c:

    # "No dudas y sales corriendo hacia la salida del callejón. Las piernas te temblaban, pero las obligaste a seguir."
    "Вы не раздумывая срываетесь с места и бросаетесь к выходу. Ноги дрожат, но вы заставляете их двигаться."

# game/script.rpy:999
translate russian supervivencia_3_f867755c:

    # "No querías ser precisamente víctima de asesinato después de todo."
    "В конце концов, совсем не хотелось стать жертвой."

# game/script.rpy:1000
translate russian supervivencia_3_c7b62b46:

    # "Si de morir se trata, preferirías morir de manera indolora."
    "Если уж умирать, то хотя бы безболезненно."

# game/script.rpy:1001
translate russian supervivencia_3_dcb3dbd1:

    # J "¡{size=30}...2,4, 6….{/size}!"
    J "{size=30}...2, 4, 6..{/size}!"

# game/script.rpy:1002
translate russian supervivencia_3_5d809fa7:

    # "¡¡!!"
    "!!"

# game/script.rpy:1003
translate russian supervivencia_3_5fc35918:

    # "¡El desgraciado está contando mal!"
    "Этот придурок неправильно считает!"

# game/script.rpy:1004
translate russian supervivencia_3_25bd8309:

    # "Pero era tu culpa por confiar en lo que él dice."
    "Впрочем, вы сами виноваты, что поверили ему на слово."

# game/script.rpy:1005
translate russian supervivencia_3_20e133db:

    # "¿Qué podías esperar de un demente?"
    "Чего ещё можно было ожидать от психа?"

# game/script.rpy:1007
translate russian supervivencia_3_040d801d:

    # "Sales del callejón, , casi te caes, pero la adrenalina te hace continuar."
    "Вы выскакиваете из переулка, едва не споткнувшись, но адреналин заставляет вас бежать дальше."

# game/script.rpy:1011
translate russian supervivencia_3_2074bdca:

    # "Estarás yendo de vuelta hacia la tienda."
    "Вы направляетесь обратно к магазину."

# game/script.rpy:1012
translate russian supervivencia_3_ca7b06dc:

    # "Cindy debería seguir ahí, podías pedir su ayuda y refugiarte."
    "Синди ещё должна быть там, можно попросить у неё помощи и спрятаться."

# game/script.rpy:1014
translate russian supervivencia_3_8be8cba1:

    # "Llegas a la puerta, intentas abrir, pero está cerrada."
    "Добежав до двери, вы дёргаете ручку, но она оказывается заперта."

# game/script.rpy:1016
translate russian supervivencia_3_bf665b22:

    # "Golpeas la puerta con fuerza, sin importarte si rompes el vidrio."
    "Вы яростно барабаните по двери, не заботясь о том, что можете разбить стекло."

# game/script.rpy:1017
translate russian supervivencia_3_b50eda55:

    # pov "¡Cindy!, ¡Abre!, ¡Rápido!"
    pov "Синди! Открой! Быстрее!"

# game/script.rpy:1019
translate russian supervivencia_3_f5ac74a1:

    # "Tu corazón acelerado rebota con esperanza al ver a Cindy entre las repisas de películas."
    "Сердце бешено колотится, когда среди полок с фильмами вы замечаете Синди."

# game/script.rpy:1020
translate russian supervivencia_3_d8d60e12:

    # "Pero tu esperanza cae cuando la ves audífonos mientras trapea el piso."
    "Но надежда мигом угасает — на ней наушники, и она спокойно моет пол."

# game/script.rpy:1021
translate russian supervivencia_3_78bfcf62:

    # pov "¡Cindy!, ¡Tu… perra, abre la puerta!"
    pov "Синди! Ты... сука, открой дверь!"

# game/script.rpy:1022
translate russian supervivencia_3_fbb69540:

    # "Tus gritos no parecen ser escuchados, por la manera en la que la ves contonearse con el trapero en manos."
    "Судя по тому, как она в такт покачивается со шваброй в руках, ваши крики она не слышит."

# game/script.rpy:1023
translate russian supervivencia_3_db17128d:

    # "No es la primera vez que Cindy te decepciona, pero esta vez se siente más doloroso."
    "Не впервые Синди вас разочаровывает — но на этот раз больно как никогда."

# game/script.rpy:1024
translate russian supervivencia_3_e54a1954:

    # "Y eso que pensaste que las cosas podían mejorar entre ustedes dos."
    "А ведь вы верили, что ваши отношения ещё могут наладиться."

# game/script.rpy:1026
translate russian supervivencia_3_9f55fa5c:

    # J "{size=30}Las traes….{/size}"
    J "{size=30}Твоя очередь...{/size}"

# game/script.rpy:1029
translate russian supervivencia_3_17eb7f0a:

    # "Escuchas ese susurro burlón en tu oído, pero no tienes momento para girarte cuando te empujan contra el vidrio de la puerta y sientes una presión dolorosa en tu costado derecho."
    "Вы слышите этот насмешливый шёпот прямо у уха, и не успеваете даже обернуться, как вас швыряют в сторону стеклянной двери. Правый бок пронзает резкая боль."

# game/script.rpy:1031
translate russian supervivencia_3_5d88d5a7:

    # pov "¡Cough!"
    pov "Кха!"

# game/script.rpy:1032
translate russian supervivencia_3_286d2a42:

    # "Te ahogas con tu propia sangre, el líquido salpica el vidrio."
    "Вы давитесь собственной кровью, жидкость разбрызгивается по стеклу."

# game/script.rpy:1033
translate russian supervivencia_3_51ef2b57:

    # J "Pensé que sería más divertido… Bueno, qué más da."
    J "А я думал, будет веселее... Ну да ладно."

# game/script.rpy:1034
translate russian supervivencia_3_6ea04490:

    # "No puedes formular ningún pensamiento en el momento que la presión de tu costado es liberada."
    "Вы не успеваете даже осознать, что происходит, как давление в боку внезапно исчезает."

# game/script.rpy:1035
translate russian supervivencia_3_d437c2ea:

    # "Sientes algo se derrama de tu costado, mojando tu pierna."
    "Что-то тёплое вытекает из вашего бока, стекая по ноге."

# game/script.rpy:1036
translate russian supervivencia_3_cf9b0316:

    # "Instintivamente diriges una mano a la herida, con el impulso de detener la hemorragia."
    "Вы инстинктивно прижимаете руку к ране в попытке остановить кровотечение."

# game/script.rpy:1037
translate russian supervivencia_3_4ece4b0d:

    # "Pero es imposible."
    "Но бесполезно."

# game/script.rpy:1038
translate russian supervivencia_3_eed4c30c:

    # "Sientes que te sueltan, pero tus piernas pierden la fuerza."
    "Вас отпускают, но ноги подкашиваются."

# game/script.rpy:1040
translate russian supervivencia_3_af23b231:

    # "Te deslizas contra la puerta hasta llegar al suelo, sintiendo que debajo de ti se forma un charco de sangre drenada del lugar donde te apuñalaron."
    "Вы медленно сползаете по двери, пока не оказываетесь на земле, чувствуя, как под вами растекается лужа крови."

# game/script.rpy:1042
translate russian supervivencia_3_c057e001:

    # "Tu consciencia se va, tus ojos pesan."
    "Сознание покидает вас, а веки тяжелеют."

# game/script.rpy:1043
translate russian supervivencia_3_d80eec30:

    # C "¿Qué está-? ¡¡[povname]!!"
    C "Что случи—? [povname]!!"

# game/script.rpy:1044
translate russian supervivencia_3_18f1b098:

    # "Al menos Cindy se dio cuenta al final."
    "По крайней мере, Синди всё-таки заметила."

# game/script.rpy:1045
translate russian supervivencia_3_538c6bd8:

    # "Ella era todo un caso, pero esperabas que ella lo hiciera mejor a futuro."
    "Она всегда была трудной, но вы надеялись, что со временем она станет лучше."

# game/script.rpy:1048
translate russian supervivencia_3_5f5b3cef:

    # "Perdiste el juego de Jeff."
    "Вы проиграли Джеффу."

# game/script.rpy:1052
translate russian supervivencia_3_cf52abc5:

    # "¡Si puedes llegar a tu hogar estarás a salvo!"
    "Если вы сможете добраться до дома, то будете в безопасности!"

# game/script.rpy:1054
translate russian supervivencia_3_b6b99fa1:

    # "Corres hacia adelante sin mirar atrás, el aire frío perforando tus pulmones mientras escuchas los latidos de tu corazón en los oídos."
    "Вы несётесь вперёд, не оглядываясь. Холодный воздух пронизывает лёгкие, а в ушах слышен стук вашего сердца."

# game/script.rpy:1055
translate russian supervivencia_3_c5e00754:

    # "¡Falta poco….! ¡Sólo un poco más…!"
    "Ещё немного..! Совсем чуть-чуть..!"

# game/script.rpy:1060
translate russian supervivencia_3_743cb459:

    # "Un peso demasiado pesado cae encima tuyo te inmoviliza contra el suelo."
    "И вдруг на вас сзади обрушивается что-то чересчур тяжёлое, прижимая к земле."

# game/script.rpy:1061
translate russian supervivencia_3_da4c2f51:

    # J "¡Haaaa…. Eso fue divertido!"
    J "Ха-а-а... Вот это было весело!"

# game/script.rpy:1062
translate russian supervivencia_3_d1f27681:

    # "Te congelas al escuchar la voz de Jeff, para después sacudirte con la esperanza de quitártelo de encima."
    "Вы замираете, услышав голос Джеффа, а затем начинаете сопротивляться, пытаясь стряхнуть его с себя."

# game/script.rpy:1063
translate russian supervivencia_3_6e308af4:

    # J "Tsk, tsk… Aprende a perder, [povname]."
    J "Тц, тц... Научись проигрывать, [povname]."

# game/script.rpy:1064
translate russian supervivencia_3_eb65b64d:

    # pov "E-espera, hiciste trampa, no contaste bien…"
    pov "П-подожди, ты жульничал, ты неправильно считал..."

# game/script.rpy:1065
translate russian supervivencia_3_14360a18:

    # J "…"
    J "..."

# game/script.rpy:1066
translate russian supervivencia_3_5d4a1466:

    # J "Seh, eso no importa realmente."
    J "Да это, по сути, неважно."

# game/script.rpy:1067
translate russian supervivencia_3_a8455697:

    # "Él sujeta tu cabeza con fuerza, lo que te saca un quejido de dolor."
    "Он сжимает вашу голову, и вы непроизвольно вскрикиваете от боли."

# game/script.rpy:1069
translate russian supervivencia_3_133603e5:

    # "El frío y duro filo de la hoja del cuchillo presiona tu cuello expuesto."
    "К горлу прижимается холодное, твёрдое лезвие ножа."

# game/script.rpy:1070
translate russian supervivencia_3_13ee4ae2:

    # pov "P-pero jugamos como querías."
    pov "Н-но мы же играли по твоим правилам."

# game/script.rpy:1071
translate russian supervivencia_3_3855746b_1:

    # J "..."
    J "..."

# game/script.rpy:1072
translate russian supervivencia_3_ba610d29:

    # J "Heh….heh…"
    J "Хе... хех..."

# game/script.rpy:1073
translate russian supervivencia_3_19cfa11b:

    # J "¡¡HAHAHAHAHA!!"
    J "ХАХАХАХАХА!!"

# game/script.rpy:1074
translate russian supervivencia_3_9aacd991:

    # J "Hah…. haha….."
    J "Хах... ха-ха..."

# game/script.rpy:1075
translate russian supervivencia_3_44dfb139:

    # J "Esto fue refrescante."
    J "Это было освежающе."

# game/script.rpy:1076
translate russian supervivencia_3_59167366:

    # J "Pero ya me aburrí."
    J "Но теперь мне скучно."

# game/script.rpy:1078
translate russian supervivencia_3_1a645669:

    # "La hoja se deslizó de un extremo a otro de tu cuello."
    "Лезвие скользнуло от одного конца вашей шеи до другого."

# game/script.rpy:1081
translate russian supervivencia_3_020867c5:

    # "La sangre brotó de tu garganta en un gran chorro."
    "Кровь льётся из вашего горла мощным потоком."

# game/script.rpy:1082
translate russian supervivencia_3_6ebf04ba:

    # "Tus ojos se nublaron y los músculos de tu cuello perdieron la fuerza."
    "Глаза затуманиваются, а мышцы шеи лишаются сил."

# game/script.rpy:1083
translate russian supervivencia_3_08d817c2:

    # "El agarre en tu cabello fue soltado y tu cabeza cayó sobre el charco de sangre que seguía creciendo lentamente."
    "Его хватка на ваших волосах ослабевает, и ваша голова падает в медленно расползающуюся лужу крови."

# game/script.rpy:1084
translate russian supervivencia_3_46cad9c1:

    # "No podías ver nada, pero percibiste el sonido de los pasos de él alejarse."
    "Вы уже ничего не видите, лишь слышите, как его шаги постепенно удаляются."

# game/script.rpy:1086
translate russian supervivencia_3_82c37a85:

    # "¿Ibas a terminar así?"
    "Неужели всё закончится вот так?"

# game/script.rpy:1087
translate russian supervivencia_3_e57b1fdb:

    # "Era injusto."
    "Несправедливо."

# game/script.rpy:1088
translate russian supervivencia_3_a2d26da0:

    # "Ser desechado."
    "Быть выброшенным."

# game/script.rpy:1089
translate russian supervivencia_3_3fff576a:

    # "Hubieras preferido morir de otra manera."
    "Вы бы предпочли другую смерть."

# game/script.rpy:1092
translate russian supervivencia_3_45579616:

    # "Aburriste a Jeff."
    "Вы наскучили Джеффу."

# game/script.rpy:1098
translate russian supervivencia_3_6fac7ef3:

    # J "...."
    J "...."

# game/script.rpy:1099
translate russian supervivencia_3_688f8e78:

    # "Los ojos de él se inyectan en sangre, sus dientes chocan y generan un chirrido que te provoca un escalofrío."
    "Его глаза наливаются кровью, зубы лязгают друг о друга, издавая неприятный скрежет, от которого по коже пробегают мурашки."

# game/script.rpy:1100
translate russian supervivencia_3_4533ff0e:

    # J "¿Desprecias mi amabilidad?"
    J "Ты смеешь презирать мою доброту?"

# game/script.rpy:1101
translate russian supervivencia_3_81e334ce:

    # "La voz de él se vuelve grave y temblorosa por la rabia."
    "Голос его становится низким и дрожащим от ярости."

# game/script.rpy:1102
translate russian supervivencia_3_4973e052:

    # "Estás a punto de retractarte y tranquilizarlo."
    "Вы уже готовы отступить и попытаться его успокоить."

# game/script.rpy:1105
translate russian supervivencia_3_52bc9c43:

    # "Pero es tarde cuando sientes una repentina presión en tu barbilla, atravesando tu piel y músculos hasta atravesar tu lengua."
    "Но уже слишком поздно — вы ощущаете резкое давление под подбородком, лезвие пронзает кожу и мышцы, проходя насквозь, до самого языка."

# game/script.rpy:1107
translate russian supervivencia_3_5bcbbd14:

    # "Te ahogas con la sangre que brota de tu boca, el dolor agudo nublando tu mente y visión."
    "Вы захлёбываетесь кровью, хлынувшей изо рта; острая боль застилает разум и зрение."

# game/script.rpy:1108
translate russian supervivencia_3_21147a3e:

    # J "¡Te doy la elección y tú la desperdicias!"
    J "Я даю тебе выбор, а ты его упускаешь!"

# game/script.rpy:1109
translate russian supervivencia_3_3f4e8d73:

    # "Él grita estridente, empujando más la hoja de su cuchillo en ti, hasta sentir que el metal llega a tu paladar."
    "Он пронзительно закричал и всадил лезвие ножа глубже, пока металл не коснулся нёба."

# game/script.rpy:1111
translate russian supervivencia_3_54324133:

    # "Tus sentidos se apagan lentamente, hasta que ya no sientes nada…"
    "Чувства постепенно угасают, пока не остаётся только пустота..."

# game/script.rpy:1112
translate russian supervivencia_3_57811a7c:

    # "Que manera tan horrible de morir…"
    "Какая же ужасная смерть..."

# game/script.rpy:1115
translate russian supervivencia_3_dea93038:

    # "Despreciaste a Jeff."
    "Вы презираете Джеффа."

# game/script.rpy:1126
translate russian supervivencia_4_3571cf5f:

    # "Jeff se trastabilla con sus palabras, sin haberse esperado esa respuesta."
    "Джефф запинается, не ожидая такого ответа."

# game/script.rpy:1127
translate russian supervivencia_4_53e32e89:

    # J "............."
    J "............."

# game/script.rpy:1128
translate russian supervivencia_4_34dc9b3a:

    # "Jeff se enderezó sobre ti, analizándote en silencio."
    "Джефф выпрямляется над вами, молча изучая вас взглядом."

# game/script.rpy:1131
translate russian supervivencia_4_b96596f3:

    # "El rostro de él era extrañamente inexpresivo, supones porque con la boca rota como la tiene él, es una condena a tener la misma expresión permanentemente."
    "Его лицо выглядит необычайно бесстрастным — наверное, потому что с такой изуродованной улыбкой он обречён всегда носить одно и то же выражение."

# game/script.rpy:1135
translate russian supervivencia_4_76829a15:

    # "Repentinamente, sientes que tu cuello es apretado con fuerza, siendo difícil para ti respirar."
    "Внезапно он сжимает вам шею так сильно, что становится трудно дышать."

# game/script.rpy:1136
translate russian supervivencia_4_a25243ff:

    # "Instintivamente, alzas las manos y tiras del brazo de Jeff, un impulso de tu cuerpo para tratar de luchar."
    "Вы инстинктивно хватаете Джеффа за руку — тело само пытается вырваться."

# game/script.rpy:1137
translate russian supervivencia_4_dc2bee19:

    # J "Témeme…"
    J "Бойся меня..."

# game/script.rpy:1138
translate russian supervivencia_4_fdf0276d:

    # "El reclamo sonó casi infantil, a pesar de provenir de un hombre amenazante."
    "Эта фраза звучит почти по-детски, несмотря на исходящую от него угрозу."

# game/script.rpy:1139
translate russian supervivencia_4_07d11d74:

    # "Intentas responder algo, cualquier cosa, pero tus cuerdas vocales están siendo apretadas demasiado fuerte."
    "Вы пытаетесь ответить что-нибудь, что угодно, но связки сдавлены слишком сильно."

# game/script.rpy:1140
translate russian supervivencia_4_cb6ea212:

    # "Alcanzaste a escuchar el murmullo de él antes de sentir que la presión en tu cuello era liberada."
    "Вы лишь успеваете уловить его тихий шёпот, прежде чем стальная хватка ослабевает."

# game/script.rpy:1141
translate russian supervivencia_4_ddbff59f:

    # "La mano de él seguía sobre tu cuello, pero sólo presionaba lo suficiente como para inmovilizarte."
    "Его ладонь всё ещё лежит у вас на шее, но давит ровно настолько, чтобы вас обездвижить."

# game/script.rpy:1142
translate russian supervivencia_4_abf0ba29:

    # "Tosiste y respiraste aceleradamente, tratando de recuperar el aire que te faltaba."
    "Вы кашляете и судорожно втягиваете воздух, стараясь восстановить дыхание."

# game/script.rpy:1146
translate russian supervivencia_4_ec90ca76:

    # "Pero entonces te diste cuenta que Jeff nuevamente estaba casi sobre ti, con cuchillo en mano."
    "Но затем вы понимаете, что Джефф снова навис над вами с ножом в руке."

# game/script.rpy:1147
translate russian supervivencia_4_c86edcb4:

    # "Sentiste una punzada de dolor en tu mejilla, pero fue por un instante."
    "Щёку обжигает короткая вспышка боли, но длится она всего мгновение."

# game/script.rpy:1148
translate russian supervivencia_4_e6c4a7cd:

    # "Jeff le hizo un corte limpio a la piel de tu mejilla izquierda, sentiste el cosquilleo de una delgada línea de sangre caer hasta tu mandíbula."
    "Джефф делает ровный надрез на коже вашей левой щеки; по лицу ощутимо скользит тонкая струйка крови, стекающая к подбородку."

# game/script.rpy:1149
translate russian supervivencia_4_c5c3f19e:

    # J "¿Por qué no tienes miedo?"
    J "Почему ты не боишься?"

# game/script.rpy:1150
translate russian supervivencia_4_ab682701:

    # "Jeff te examinaba en silencio, como si al mirar tu reacción podría sacar una respuesta que lo satisfaga."
    "Джефф молча вас разглядывает, будто пытается вычитать в вашем лице ответ, который мог бы его удовлетворить."

# game/script.rpy:1152
translate russian supervivencia_4_a2ff6030:

    # "No era como si realmente no sintieras nada."
    "Не то чтобы вы действительно ничего не чувствуете."

# game/script.rpy:1153
translate russian supervivencia_4_f640861b:

    # "Reconocías que la situación era peligrosa, tu cuerpo lo sabía por el fuerte latir de tu corazón."
    "Вы прекрасно понимаете, что ситуация опасна — тело само напоминает об этом бешеным биением сердца."

# game/script.rpy:1154
translate russian supervivencia_4_72918e70:

    # "Pero como ha sido desde el inicio, no te importaba."
    "Но, как и с самого начала, вам всё равно."

# game/script.rpy:1155
translate russian supervivencia_4_c03c3c74:

    # "Él pedía que te le temas, pero como él amenaza tu vida, y no te importa realmente morir, en consecuencia, no le temes."
    "Он требует страха, но как можно бояться того, кто угрожает жизни, если вам уже всё равно, умрёте вы или нет?"

# game/script.rpy:1160
translate russian supervivencia_4_d0958fb4:

    # "Bajas la mirada, pero no por miedo."
    "Вы опускаете взгляд, но не от страха."

# game/script.rpy:1161
translate russian supervivencia_4_0fe9f491:

    # "Sino que por cansancio."
    "Скорее от усталости."

# game/script.rpy:1162
translate russian supervivencia_4_ec930570:

    # "¿Qué dejarías atrás si morías?"
    "Что вы вообще оставите после себя, если умрёте?"

# game/script.rpy:1163
translate russian supervivencia_4_2a829ef6:

    # "No mucho, así que ya no te importaba."
    "Почти ничего, именно поэтому вам уже всё равно."

# game/script.rpy:1164
translate russian supervivencia_4_a107038b:

    # pov "Lo siento Jeff, pero no tengo miedo para darte."
    pov "Прости, Джефф, но мне нечего бояться."

# game/script.rpy:1169
translate russian supervivencia_4_c49c65c4:

    # "Lo miras directamente a los ojos."
    "Вы смотрите ему прямо в глаза."

# game/script.rpy:1170
translate russian supervivencia_4_a420ef97:

    # pov "Tanto drama… ¿Para esto?"
    pov "Столько драмы... ради этого?"

# game/script.rpy:1171
translate russian supervivencia_4_edf0091d:

    # "La boca de Jeff se tuerce."
    "Улыбка Джеффа перекосилась."

# game/script.rpy:1172
translate russian supervivencia_4_0bf262c8:

    # pov "Sólo eres un asesino genérico, acosando a la víctima y llevándola a un callejón."
    pov "Ты всего лишь обычный убийца — подкараулил жертву и затащил в переулок."

# game/script.rpy:1173
translate russian supervivencia_4_20ef8dd6:

    # pov "Si querías causar una mejor impresión, podrías ser más original."
    pov "Если и хотел произвести впечатление, то мог бы проявить хоть каплю оригинальности."

# game/script.rpy:1174
translate russian supervivencia_4_3331a0da:

    # "De repente, la comisura extendida de Jeff se alza, extrañándote."
    "Вдруг вырезанная улыбка Джеффа приподнимается — странное зрелище."

# game/script.rpy:1175
translate russian supervivencia_4_ded07d51:

    # J "Fue algo difícil de ver, pero…"
    J "Трудно было заметить, но..."

# game/script.rpy:1178
translate russian supervivencia_4_31d5d579:

    # "Jeff clavó el cuchillo debajo de tus costillas, quitándote el aire."
    "Джефф вонзает нож вам под рёбра, лишая дыхания."

# game/script.rpy:1179
translate russian supervivencia_4_2708e788:

    # "Él se inclinó sobre tu oído"
    "Он наклоняется к вашему уху."

# game/script.rpy:1180
translate russian supervivencia_4_2fa024fe:

    # J "Eres de luchar, ¿No?"
    J "Ты борец, да?"

# game/script.rpy:1181
translate russian supervivencia_4_4ebd09b2:

    # "La sangre sube por tu garganta, ahogándote."
    "Кровь поднимается к горлу, и вы начинаете захлёбываться."

# game/script.rpy:1183
translate russian supervivencia_4_023a8e77:

    # "Vaya, parece que desafiarlo lo interpretó como una manera de luchar por tu vida."
    "Похоже, он принял ваше неповиновение за попытку бороться за жизнь."

# game/script.rpy:1184
translate russian supervivencia_4_d76bf665:

    # "Realmente ese no era el caso, pero te resignaste."
    "И хотя дело было не в этом, вы просто смирились."

# game/script.rpy:1187
translate russian supervivencia_4_ec31decd:

    # "Alargaste lo inevitable."
    "Вы лишь отсрочили неизбежное."

# game/script.rpy:1194
translate russian supervivencia_5_3855746b:

    # J "..."
    J "..."

# game/script.rpy:1196
translate russian supervivencia_5_e557b377:

    # "Jeff se mantuvo en silencio por un segundo, hasta que lograste notar cómo su sonrisa se extendía sutilmente."
    "Джефф молчит несколько секунд, и только потом вы замечаете, как его улыбка едва заметно расширяется."

# game/script.rpy:1197
translate russian supervivencia_5_2d55de67:

    # "Él lentamente se inclinó hacia a ti {w=0.5}y lamió tu mejilla herida, limpiando la línea de sangre."
    "Он медленно наклоняется к вам {w=0.5}и проводит языком по ране на вашей щеке, слизывая тонкую полоску крови."

# game/script.rpy:1198
translate russian supervivencia_5_afe026a6:

    # "Su respiración chocaba contra tu piel, tibia y húmeda."
    "Его дыхание касается вашей кожи, тёплое и влажное."

# game/script.rpy:1199
translate russian supervivencia_5_b1981d4e:

    # "El toque de su lengua te ardió en la herida, haciéndote sisear."
    "Прикосновение его языка обжигает рану, и вы шипите."

# game/script.rpy:1200
translate russian supervivencia_5_8728fb3b:

    # "Podías aceptar que él te lamiera, sólo era él siendo raro."
    "Вы можете смириться с тем, что он вас лижет — странность для него не нова."

# game/script.rpy:1201
translate russian supervivencia_5_4af39a27:

    # "Pero no podías quitarte de encima lo que él quería decirte con esa acción."
    "Но вы не можете не думать о том, что этот жест вообще значит."

# game/script.rpy:1206
translate russian supervivencia_5_c4263066:

    # pov "¿Lamerme? Qué romántico. Me derrito."
    pov "Лижешь меня? Как романтично. Я просто таю."

# game/script.rpy:1207
translate russian supervivencia_5_63e56f22:

    # "¿Quizás si le tomas el pelo lo suficiente te deje en paz?"
    "Может, если достаточно его подразнить, он оставит вас в покое?"

# game/script.rpy:1208
translate russian supervivencia_5_519c5c0c:

    # "Tenías que intentar."
    "Стоит попытаться."

# game/script.rpy:1213
translate russian supervivencia_5_a8639721:

    # "Una cosa es que no te importe que te atacan en la noche por un maníaco, pero otra cosa distinta es que te… ataquen de otra forma."
    "Одно дело — не бояться, когда на вас ночью нападает псих, и совсем другое — когда он может... напасть в другом смысле."

# game/script.rpy:1214
translate russian supervivencia_5_6255dceb:

    # "No quieres ni pensarlo."
    "Вы даже не хотите об этом думать."

# game/script.rpy:1215
translate russian supervivencia_5_89d11338:

    # pov "Por favor… no me hagas daño…."
    pov "Пожалуйста... не трогай меня..."

# game/script.rpy:1216
translate russian supervivencia_5_64be5f66:

    # "Quizás si pedías clemencia te deje ir."
    "Может, если попросить пощады, он отпустит?"

# game/script.rpy:1218
translate russian supervivencia_5_32df0955:

    # J ".......Heh."
    J ".......Хех."

# game/script.rpy:1219
translate russian supervivencia_5_9f30f070:

    # "Jeff rió entre dientes, bajando el cuchillo hasta tu abdomen."
    "Джефф усмехается, опуская нож к вашему животу."

# game/script.rpy:1220
translate russian supervivencia_5_0572e0bb:

    # J "Sabía que me temerías…."
    J "Я знал, что ты всё-таки испугаешься..."

# game/script.rpy:1221
translate russian supervivencia_5_f02a8d27:

    # "Buenop, parece que Jeff lo tomó como tu queriendo complacerlo para que no te haga daño."
    "Похоже, Джефф решил, что вы просто пытаетесь его задобрить, чтобы он не причинил вам вреда."

# game/script.rpy:1222
translate russian supervivencia_5_93a2f669:

    # "No estaba del todo equivocado, pero ciertamente tu intención era algo distinta…"
    "Впрочем, ошибался он лишь наполовину — ваши намерения были немного иными..."

# game/script.rpy:1225
translate russian supervivencia_5_032bc689:

    # "Jeff hundió la hoja en tus entrañas, la punzada quitándote el aire."
    "Джефф вонзает лезвие вам в живот, и от боли у вас перехватывает дыхание."

# game/script.rpy:1227
translate russian supervivencia_5_4f4f06d4:

    # "Pero eso no lo detuvo."
    "Но ему мало."

# game/script.rpy:1229
translate russian supervivencia_5_f4987dc7:

    # "Te apuñaló una y otra vez, hasta que se sintiera satisfecho."
    "Он наносит удар за ударом, пока не чувствует удовлетворение."

# game/script.rpy:1231
translate russian supervivencia_5_7bed8e66:

    # "El cansancio y el dolor era tan intensos que no podías mantener los ojos abiertos, pero aún podías escuchar."
    "Усталость и боль настолько сильные, что глаза закрываются сами по себе; однако вы ещё можете слышать."

# game/script.rpy:1232
translate russian supervivencia_5_e2eb7f2c:

    # J "Eso fue un dolor…."
    J "Ну и заноза..."

# game/script.rpy:1235
translate russian supervivencia_5_ec31decd:

    # "Alargaste lo inevitable."
    "Вы лишь отсрочили неизбежное."

# game/script.rpy:1244
translate russian supervivencia_6_b3e1dfe3:

    # "Jeff gruñó entre dientes, volviendo a estrellarte contra la pared de ladrillos."
    "Джефф рычит сквозь зубы, снова впечатывая вас в кирпичную стену."

# game/script.rpy:1245
translate russian supervivencia_6_7c8c8fc8:

    # "Soltaste un quejido de dolor ante el impacto."
    "От удара вы невольно болезненно стонете."

# game/script.rpy:1246
translate russian supervivencia_6_1673fd60:

    # J "¿Por qué… no me temes?"
    J "Почему... ты меня не боишься?"

# game/script.rpy:1247
translate russian supervivencia_6_5ddb771f:

    # pov "No sé qué quieres que te diga, Jeff."
    pov "Не знаю, что ты хочешь от меня услышать, Джефф."

# game/script.rpy:1249
translate russian supervivencia_6_27c953cc:

    # "Jeff bajó la cabeza, aparentemente decepcionado."
    "Джефф опускает голову, явно разочарованный."

# game/script.rpy:1250
translate russian supervivencia_6_d9ccfc41:

    # "Desviaste la mirada hacia los lados con duda, sin saber qué hacer."
    "Вы нерешительно оглядываетесь по сторонам, не зная, что делать."

# game/script.rpy:1252
translate russian supervivencia_6_f85d2aab:

    # "Pero entonces él se enderezó nuevamente, con su sonrisa tan extendida que sus labios estaban tensos."
    "Но затем он снова выпрямляется, его улыбка такая широкая, что кожа на губах натягивается."

# game/script.rpy:1253
translate russian supervivencia_6_b6c4889b:

    # J "No hay nada que pueda hacer si no temes a la muerte."
    J "Если ты не боишься смерти — тут я бессилен."

# game/script.rpy:1254
translate russian supervivencia_6_9d642099:

    # J "Pero puedo hacer que me temas."
    J "Но я заставлю тебя бояться меня."

# game/script.rpy:1257
translate russian supervivencia_6_f3c8232a:

    # "Alzó el cuchillo nuevamente, pero no a la altura para apuñalarte en un punto vital, sino que acercó la punta lentamente a tu rostro, a la altura de tu ojo izquierdo."
    "Он снова поднимает нож, но не для удара в жизненно важное место. Лезвие медленно тянется к вашему лицу, останавливаясь на уровне левого глаза."

# game/script.rpy:1258
translate russian supervivencia_6_2b90a2ec:

    # J "Así que haremos esto, [povname]."
    J "Поступим так, [povname]."

# game/script.rpy:1259
translate russian supervivencia_6_6330ffcc:

    # "Tragaste duro ante la visión distorsionada de la punta del cuchillo a milímetros de tu pupila."
    "Вы с трудом сглатываете, наблюдая, как искажённое отражение лезвия приближается к самому зрачку."

# game/script.rpy:1260
translate russian supervivencia_6_ed1d67a2:

    # J "Voy a perseguirte. Cada vez que te atrape, te haré daño, y cada vez que me evites, me alejaré un poco."
    J "Я буду охотиться за тобой. Каждый раз, когда поймаю — буду причинять боль; и каждый раз, когда ты сумеешь скрыться — буду немного отступать."

# game/script.rpy:1261
translate russian supervivencia_6_93993593:

    # "Los ojos de Jeff temblaban, casi blancos, como dos focos en medio de la oscuridad."
    "Его глаза дрожат, почти побелев, как два слепящих огня в самой тьме."

# game/script.rpy:1262
translate russian supervivencia_6_0ca5f186:

    # pov "E-espera…"
    pov "П-подожди..."

# game/script.rpy:1263
translate russian supervivencia_6_2b07c755:

    # J "Perdiste el primer turno."
    J "Ты проиграли первый раунд."

# game/script.rpy:1264
translate russian supervivencia_6_4a942a8b:

    # "Dictó Jeff, empujando su mano."
    "Говорит Джефф, надавливая рукой."

# game/script.rpy:1268
translate russian supervivencia_6_9b8d4e12:

    # "La hoja se enterró en la esquina de tu ojo, casi rozando el borde del párpado."
    "Лезвие вонзается в угол глаза, едва не задевая веко."

# game/script.rpy:1269
translate russian supervivencia_6_583ee911:

    # "Gritaste con todas tus fuerzas, hasta que sentiste que tu garganta se desgarraba."
    "Вы изо всех сил кричите, пока не чувствуете, как раздирается горло."

# game/script.rpy:1271
translate russian supervivencia_6_442966d9:

    # "La sangre brotó como una pequeña cascada, y con la repentina sacudida de tu cuerpo, la sangre salpicó."
    "Кровь течёт тонким потоком, и при судорожном вздрагивании брызги разлетаются вокруг."

# game/script.rpy:1272
translate russian supervivencia_6_8f04e5ee:

    # "Jeff rió satisfecho con la reacción y enterró más la hoja, hundiéndola en la blanda carne de tu globo ocular."
    "Джефф довольно смеётся при виде вашей реакции и вдавливает нож ещё глубже, в мягкую ткань глаза."

# game/script.rpy:1273
translate russian supervivencia_6_df9fc0fc:

    # pov "¡A-ACK!"
    pov "А-АХ!"

# game/script.rpy:1274
translate russian supervivencia_6_6e9ed3d0:

    # "Te atragantántaste con tu saliva, a punto de vomitar por el insoportable dolor."
    "Вы давитесь слюной, едва сдерживая рвотный позыв от невыносимой боли."

# game/script.rpy:1275
translate russian supervivencia_6_d7d41f4e:

    # "Tus manos dieron manotazos hacia el pecho de Jeff, pero no lo movieron ni un centímetro."
    "Руки в панике колотят по груди Джеффа, но он не движется с места."

# game/script.rpy:1278
translate russian supervivencia_6_63958df9:

    # "Jeff sacudió el mango del cuchillo violentamente, moviéndolo aún enterrado en el ojo."
    "Джефф резко дёргает рукоять ножа, вгоняя его ещё глубже в ваш глаз."

# game/script.rpy:1280
translate russian supervivencia_6_2eb8dfdd:

    # "Él sacudió un poco más el cuchillo y tiró, logrando sacar el globo ocular aún conectado a las venas."
    "Он ещё немного проворачивает нож и снова дёргает, сумев вырвать ваше глазное яблоко, всё ещё соединённое с венами."

# game/script.rpy:1281
translate russian supervivencia_6_f9821093:

    # Stranger "¿Qué está pasando?"
    Stranger "Что происходит?"

# game/script.rpy:1282
translate russian supervivencia_6_7d950801:

    # Stranger "¿Hay alguien ahí?"
    Stranger "Тут есть кто-нибудь?"

# game/script.rpy:1283
translate russian supervivencia_6_af979cd1:

    # "Como campanas celestiales, lograste escuchar las voces de otras personas proviniendo de un costado, pero ya no tenías fuerzas para mantenerte de pie."
    "Словно небесные колокола, до вас доносятся голоса — где-то рядом, совсем близко. Но сил стоять уже не остаётся."

# game/script.rpy:1286
translate russian supervivencia_6_361d26d2:

    # "Te desplomas en el suelo, con la cuenca izquierda sangrando por el arranque."
    "Вы рухнули на землю, из опустевшей глазницы течёт кровь."

# game/script.rpy:1287
translate russian supervivencia_6_3a27b0b2:

    # "Tu visión estaba borrosa y dañada, no había manera de confiar en lo que veías."
    "Зрение расплывается, и вы больше не можете доверять тому, что видите."

# game/script.rpy:1288
translate russian supervivencia_6_459373fe:

    # "Sólo podías centrarte en lo que escuchabas."
    "Остаётся лишь слушать."

# game/script.rpy:1289
translate russian supervivencia_6_14a84329:

    # J "Recuerda nuestro juego, [povname]."
    J "Помни о нашей игре, [povname]."

# game/script.rpy:1290
translate russian supervivencia_6_d053d53b:

    # "Jeff murmuró suavemente, su voz escuchándose desde atrás."
    "Джефф тихо шепчет, его голос доносится из-за вашей спины."

# game/script.rpy:1293
translate russian supervivencia_6_5f93ba9b:

    # "Lograste sentir los pasos de varias personas dirigiéndose a tu dirección, por lo que te rendiste ante el cansancio y el dolor."
    "Вы улавливаете приближающиеся шаги нескольких человек, и тогда просто сдаётесь от усталости и боли."

# game/script.rpy:1308
translate russian supervivencia_6_0427078d:

    # "Nunca habías sentido tanto dolor antes."
    "Вы никогда раньше не испытывали такой боли."

# game/script.rpy:1309
translate russian supervivencia_6_6d1436d7:

    # "Claro, alguna vez te habías tropezado, raspado las rodillas, o quemado los dedos con agua hirviendo, cosas normales."
    "Конечно, бывало, что вы спотыкались, сдирали колени, ошпаривали пальцы кипятком — обычные мелочи."

# game/script.rpy:1310
translate russian supervivencia_6_bdceb634:

    # "Pero esto…"
    "Но это..."

# game/script.rpy:1311
translate russian supervivencia_6_224029e3:

    # "Esto era otro nivel."
    "Это совсем иной уровень."

# game/script.rpy:1312
translate russian supervivencia_6_f339c3a8:

    # "No era el dolor físico lo que más molestaba, sino el tipo de dolor que te hace consciente de que todo lo que está pasando importa más de lo que quisieras."
    "Больше всего терзает не физическая боль, а та, что заставляет понять — всё происходящее куда важнее, чем вам бы хотелось."

# game/script.rpy:1313
translate russian supervivencia_6_999b1722:

    # "El tipo de dolor que te despierta, te obliga a existir, te arranca de la comodidad de no sentir nada."
    "Та боль, что вырывает из оцепенения, заставляя существовать, лишая утешительного безразличия."

# game/script.rpy:1314
translate russian supervivencia_6_7b0da4d9:

    # "Para colmo, querías dormir. Dormir siempre ha sido tu mejor plan en cualquier situación."
    "В довершение ко всему, вам просто хочется спать. Сон всегда был вашим лучшим решением в любой ситуации."

# game/script.rpy:1315
translate russian supervivencia_6_b4494801:

    # "Pero, por supuesto, a la vida le encanta arruinarte los planes."
    "Но, разумеется, жизнь обожает рушить ваши планы."

# game/script.rpy:1316
translate russian supervivencia_6_d168d066:

    # Stranger "¿Despertaste?"
    Stranger "Вы проснулись?"

# game/script.rpy:1317
translate russian supervivencia_6_20d16868:

    # "La voz era masculina, suave, con ese tono educado que inspiraba confianza."
    "Голос мужской — мягкий, с вежливой интонацией, внушающей доверие."

# game/script.rpy:1318
translate russian supervivencia_6_ec37c51e:

    # "No despertaste de inmediato. Sentías tu cuerpo pesado por el cansancio."
    "Вы не очнулись сразу же. Тело кажется тяжёлым от усталости."

# game/script.rpy:1319
translate russian supervivencia_6_b3241158:

    # "Pero después de un par de respiraciones incómodas, lograste forzarte a ver."
    "Но после пары трудных вдохов вам удаётся заставить себя открыть глаза."

# game/script.rpy:1322
translate russian supervivencia_6_a7606896:

    # "El blanco te rodeaba. Te tomó unos segundos entender que estabas en una camilla de hospital."
    "Вокруг бело. Лишь спустя несколько секунд вы понимаете, что лежите на больничной койке."

# game/script.rpy:1323
translate russian supervivencia_6_a0495911:

    # "Sábanas ásperas, olor a desinfectante y esa luz fluorescente de las ampolletas led."
    "Шероховатые простыни, запах дезинфицирующего средства и холодный свет светодиодных лампочек."

# game/script.rpy:1324
translate russian supervivencia_6_c4d0302a:

    # "Lo bueno, si es que había algo bueno, es que estabas con cuidados médicos."
    "Если и искать что-то хорошее — вы хотя бы получаете медицинскую помощь."

# game/script.rpy:1325
translate russian supervivencia_6_aa224475:

    # "Con suerte no te iban a dejar morir de forma estúpida después de todo lo que pasaste anoche."
    "Хочется верить, что вам не дадут так глупо умереть после всего, что случилось прошлой ночью."

# game/script.rpy:1326
translate russian supervivencia_6_7de2feb3:

    # "Finalmente te enfocas en el responsable de la voz."
    "Наконец, вы сосредотачиваетесь на человеке, чей голос до этого слышали."

# game/script.rpy:1329
translate russian supervivencia_6_2b2064bf:

    # "Frente a ti había un hombre de bata blanca. Joven, bien peinado, de rostro amable."
    "Перед вами стоит мужчина в белом халате. Молодой, ухоженный, с добродушным лицом."

# game/script.rpy:1330
translate russian supervivencia_6_23321409:

    # Stranger "¿Sabes dónde estás?"
    Stranger "Знаете, где находитесь?"

# game/script.rpy:1336
translate russian supervivencia_6_1f7e3e82:

    # "El doctor asintió y anotó algo en unos papeles que llevaba consigo."
    "Доктор кивает и записывает что-то в бумагах, которые держит в руках."

# game/script.rpy:1337
translate russian supervivencia_6_7f2e900c:

    # Stranger "Bien. Eso es un buen signo."
    Stranger "Хорошо. Это уже положительный знак."

# game/script.rpy:1338
translate russian supervivencia_6_15ba08c5:

    # pov "¿Anotas por profesionalismo o porque necesitas llenar espacio?"
    pov "Вы записываете это из профессионализма или просто чтобы заполнить место в отчёте?"

# game/script.rpy:1339
translate russian supervivencia_6_021dc0db:

    # "El doctor alzó una ceja a tu dirección, como si no se hubiera esperado un comentario tan seco, pero lejos de verse ofendido, se veía intrigado."
    "Доктор приподнимает бровь, явно не ожидая такого резкого комментария, но вместо раздражения в его взгляде читается лёгкое любопытство."

# game/script.rpy:1340
translate russian supervivencia_6_4585ceaa:

    # Stranger "Ambas."
    Stranger "И то, и другое."

# game/script.rpy:1343
translate russian supervivencia_6_4a9467f5:

    # pov "Creo que tengo un ángel ante mí."
    pov "Кажется, передо мной ангел."

# game/script.rpy:1345
translate russian supervivencia_6_8c00cbab:

    # "El doctor resopló divertido."
    "Доктор тихо усмехается."

# game/script.rpy:1346
translate russian supervivencia_6_c586da9a:

    # Stranger "Veo que tienes sentido del humor, eso es buena señal."
    Stranger "Вижу, чувство юмора у тебя есть, это хороший знак."

# game/script.rpy:1347
translate russian supervivencia_6_e409c40a:

    # pov "Hubiera dicho algo más original, pero no tengo tantas energías…"
    pov "Я бы сказали что-то пооригинальнее, но сил немного..."

# game/script.rpy:1348
translate russian supervivencia_6_208641f3:

    # Stranger "Me conformo. No todos los días me dicen ángel mientras trabajo."
    Stranger "Этого достаточно. Не каждый день на работе меня называют ангелом."

# game/script.rpy:1350
translate russian supervivencia_6_24fa83cc:

    # "Anotó un par de cosas en los papeles que llevaba. Parecía estar más entretenido que preocupado."
    "Он делает несколько пометок в своих бумагах. Он выглядит скорее развеселённым, чем обеспокоенным."

# game/script.rpy:1355
translate russian ruta_normal_11_0d22ae43:

    # "Tu voz estaba ronca y te dolía la garganta."
    "Ваш голос хриплый, а горло саднит."

# game/script.rpy:1356
translate russian ruta_normal_11_6c641bab:

    # "Tragaste con fuerza, tratando de aplacar el dolor."
    "Вы сглатываете, пытаясь приглушить боль."

# game/script.rpy:1357
translate russian ruta_normal_11_a06ad2c1:

    # "El doctor te dedicó una mirada seria, como si te dijera que te lo tomaras con calma."
    "Доктор бросает на вас серьёзный взгляд, будто без слов советуя не перенапрягаться."

# game/script.rpy:1358
translate russian ruta_normal_11_77649624:

    # Stranger "¿Recuerdas tu nombre?"
    Stranger "Помнишь своё имя?"

# game/script.rpy:1363
translate russian ruta_normal_11_931ad9fd:

    # "El doctor soltó una leve carcajada, negando con la cabeza."
    "Доктор слегка усмехается и качает головой."

# game/script.rpy:1364
translate russian ruta_normal_11_5cacde45:

    # Stranger "Responde seriamente."
    Stranger "Отвечай серьёзно."

# game/script.rpy:1374
translate russian ruta_normal_12_b47ff447:

    # pov "Es… [povname]."
    pov "...[povname]."

# game/script.rpy:1375
translate russian ruta_normal_12_83cfeb5e:

    # "Tu voz salió ronca y entrecortada, pero lo suficientemente clara para que él te entienda."
    "Ваш голос звучит хрипло и прерывисто, но достаточно разборчиво, чтобы он понял."

# game/script.rpy:1376
translate russian ruta_normal_12_3bfee5af:

    # "El doctor asintió, concentrado."
    "Доктор кивает, сосредоточившись."

# game/script.rpy:1377
translate russian ruta_normal_12_ff988f40:

    # "Evidentemente te estaba haciendo esas preguntas para saber que tan desorientada estaba tu cabeza."
    "Очевидно, он задаёт эти вопросы, чтобы проверить, насколько вы дезориентированы."

# game/script.rpy:1378
translate russian ruta_normal_12_9a121480:

    # Stranger "De acuerdo. ¿Sabes por qué estás aquí?"
    Stranger "Хорошо. Знаешь, почему ты здесь?"

# game/script.rpy:1379
translate russian ruta_normal_12_fcc1eb7a:

    # "No respondiste de inmediato."
    "Вы отвечаете не сразу."

# game/script.rpy:1380
translate russian ruta_normal_12_34507ba4:

    # "La imagen apareció sola. Una cara con cicatrices. Ojos hundidos. Una sonrisa deformada."
    "Образ всплывает перед глазами сам по себе. Лицо, изуродованное шрамами. Впалые глаза. Искажённая улыбка."

# game/script.rpy:1381
translate russian ruta_normal_12_c4879149:

    # "Y la risa. Esa maldita risa."
    "И смех. Тот ужасный смех."

# game/script.rpy:1382
translate russian ruta_normal_12_409e3172:

    # "Por supuesto que sabías por qué estabas ahí."
    "Конечно, вы знаете, почему оказались здесь."

# game/script.rpy:1383
translate russian ruta_normal_12_50f63a7d:

    # pov "Me atacó… alguien."
    pov "На меня... напали."

# game/script.rpy:1385
translate russian ruta_normal_12_f2395561:

    # "El doctor se acercó y tomó tu mano con firmeza."
    "Доктор подходит ближе и крепко берёт вас за руку."

# game/script.rpy:1386
translate russian ruta_normal_12_e7375928:

    # "No te preguntó si querías ese gesto. Solo lo hizo."
    "Он не спросил, нужно ли. Просто сделал это."

# game/script.rpy:1387
translate russian ruta_normal_12_d1798ed2:

    # Stranger "Este lugar es seguro."
    Stranger "Здесь безопасно."

# game/script.rpy:1388
translate russian ruta_normal_12_b2076610:

    # Stranger "Él no puede hacerte daño ahora."
    Stranger "Он больше не сможет навредить."

# game/script.rpy:1389
translate russian ruta_normal_12_c6e9ad4d:

    # "Te quedaste mirando su mano sobre la tuya."
    "Вы уставились на его ладонь, лежащую поверх вашей."

# game/script.rpy:1390
translate russian ruta_normal_12_de523062:

    # "No sabías qué era peor: el dolor, o lo raro que se sentía que alguien te consolara de forma tan… correcta."
    "Вы не знаете, что хуже — боль или то странное чувство, когда кто-то утешает вас так... по-человечески."

# game/script.rpy:1391
translate russian ruta_normal_12_ebd5b091:

    # "{i}Buen servicio{/i}, pensaste."
    "{i}Отличное обслуживание{/i}, — подумали вы."

# game/script.rpy:1392
translate russian ruta_normal_12_52345a77:

    # "Tal vez te traigan café gratis después."
    "Может, потом ещё кофе предложат."

# game/script.rpy:1393
translate russian ruta_normal_12_4e29cce3:

    # "Él notó tu silencio y retiró la mano enseguida."
    "Он замечает ваше молчание и быстро убирает руку."

# game/script.rpy:1395
translate russian ruta_normal_12_1e30bc5f:

    # "Se aclaró la garganta, avergonzado."
    "Он откашлялся, явно смущённый."

# game/script.rpy:1396
translate russian ruta_normal_12_06423d78:

    # Stranger "Perdón… No me he presentado."
    Stranger "Прошу прощения... Я так и не представился."

# game/script.rpy:1398
translate russian ruta_normal_12_ed759624:

    # DR "Soy tu doctor, Paul Salazar."
    DR "Я твой лечащий врач, Пол Салазар."

# game/script.rpy:1399
translate russian ruta_normal_12_6bdcbf35:

    # "Te tomó un segundo procesarlo."
    "Вы несколько секунд перевариваете эту информацию."

# game/script.rpy:1400
translate russian ruta_normal_12_a4ca3f82:

    # pov "Un gusto… Dr. Salazar."
    pov "Приятно познакомиться... доктор Салазар."

# game/script.rpy:1401
translate russian ruta_normal_12_487d741c:

    # pov "Diría que me habría gustado conocerte… en otra situación… pero ya sabes."
    pov "Я бы сказали, что хотелось бы познакомится... при других обстоятельствах... ну, понимаешь."

# game/script.rpy:1402
translate russian ruta_normal_12_f2e04105:

    # "Él esbozó una sonrisa breve, sin saber si reír o disculparse otra vez."
    "Он коротко улыбается, будто не зная, стоит ли смеяться или снова извиниться."

# game/script.rpy:1404
translate russian ruta_normal_12_78511d7e:

    # DR "Te explicaré un poco tu situación."
    DR "Немного объясню твоё состояние."

# game/script.rpy:1405
translate russian ruta_normal_12_c0913212:

    # "Se puso más recto y serio."
    "Он выпрямляется, становясь серьёзнее."

# game/script.rpy:1406
translate russian ruta_normal_12_75a36b4f:

    # DR "Tienes golpes en la cabeza. Hay que vigilarte por si presentas vómito, mareos o pérdida de conciencia."
    DR "У тебя ушибы головы. Нужно наблюдать — возможны тошнота, головокружение или потеря сознания."

# game/script.rpy:1407
translate russian ruta_normal_12_c99a4bf2:

    # DR "También tienes algunos cortes menores. No necesitas puntos, pero… nada de rascarse ni tocarlos. ¿De acuerdo?"
    DR "Есть и несколько неглубоких порезов. Швы не понадобятся, но... не чесать и не трогать. Договорились?"

# game/script.rpy:1408
translate russian ruta_normal_12_61765e0f:

    # "En el instante exacto que lo dijo, la picazón te atacó. Maldita sugestión."
    "Стоило ему это сказать, как сразу же появился противный зуд. Проклятое внушение."

# game/script.rpy:1409
translate russian ruta_normal_12_6422b0d1:

    # DR "Lo más importante ahora: Sufriste asfixia. No hagas esfuerzos, no hables mucho. Si te mareas o te cuesta respirar, avisa."
    DR "Самое важное: было удушье. Не переутомляйся, говори поменьше. Если начнёт кружиться голова или станет тяжело дышать — сразу говори."

# game/script.rpy:1411
translate russian ruta_normal_12_88b747e6:

    # "Asentiste en silencio, acomodándote lentamente en la camilla."
    "Вы молча киваете, осторожно устраиваясь на койке."

# game/script.rpy:1412
translate russian ruta_normal_12_91fb0d22:

    # "La tela de la bata raspaba un poco contra tu piel. El colchón olía a desinfectante. Todo olía a desinfectante."
    "Ткань больничной рубашки слегка царапает кожу. Матрас пахнет дезинфицирующим средством. Всё вокруг им пахнет."

# game/script.rpy:1414
translate russian ruta_normal_12_a5b20686:

    # DR "Y… respecto a tu ojo…"
    DR "И... насчёт твоего глаза..."

# game/script.rpy:1415
translate russian ruta_normal_12_baef4747:

    # "Su tono cambió. Como si estuviera por dar muy malas noticias."
    "Его голос изменился. В нём звучит то напряжение, которое бывает перед плохими новостями."

# game/script.rpy:1416
translate russian ruta_normal_12_41161dc8:

    # DR "Lo siento. No pudimos salvarlo."
    DR "Мне очень жаль. Спасти его не удалось."

# game/script.rpy:1417
translate russian ruta_normal_12_22d61838:

    # "Frío. Como si alguien hubiera abierto una ventana en mitad del invierno."
    "Холодно. Будто кто-то распахнул окно посреди зимы."

# game/script.rpy:1418
translate russian ruta_normal_12_8399e5bc:

    # "Por reflejo, llevaste una mano temblorosa al costado izquierdo de tu rostro."
    "Вы машинально поднимаете дрожащую руку к левой стороне лица."

# game/script.rpy:1419
translate russian ruta_normal_12_230ff9bc:

    # "Sólo vendajes. Sólo vacío."
    "Только повязки. Только пустота."

# game/script.rpy:1420
translate russian ruta_normal_12_0b2e0907:

    # "Habías imaginado perder cosas. Objetos, relaciones, tiempo."
    "Вы представляли, что можете терять что-то. Вещи, людей, время."

# game/script.rpy:1421
translate russian ruta_normal_12_1c655e24:

    # "Pero esto era distinto. Perder pedazos."
    "Но это уже другое. Терять части."

# game/script.rpy:1423
translate russian ruta_normal_12_4d0bc2c5:

    # DR "Podrás tener una vida normal."
    DR "Ты сможешь жить нормальной жизнью."

# game/script.rpy:1424
translate russian ruta_normal_12_3c227684:

    # "Él dijo rápidamente, como si quisiera remediar tu situación."
    "Сказал он поспешно, будто хотел хоть немного смягчить обстановку."

# game/script.rpy:1425
translate russian ruta_normal_12_fb3c4e76:

    # DR "Perderás algo de percepción de profundidad, pero no te impedirá hacer tu vida. Más adelante puedes optar por una prótesis, si lo deseas."
    DR "Ты потеряешь некоторое восприятие глубины, но это не будет мешать жить. Позже можно подумать о протезе, если захочешь."

# game/script.rpy:1426
translate russian ruta_normal_12_bc4cf9f3:

    # DR "Ahora… Lo importante es que cicatrice bien."
    DR "А пока... Главное, что рана хорошо заживает."

# game/script.rpy:1428
translate russian ruta_normal_12_0ef77194:

    # "Él notó tu silencio. Tu falta de reacción lo incomodaba."
    "Он замечает ваше молчание. Отсутствие реакции его немного настораживает."

# game/script.rpy:1429
translate russian ruta_normal_12_8afab75c:

    # "Se inclinó levemente hacia ti."
    "Он слегка наклоняется к вам."

# game/script.rpy:1430
translate russian ruta_normal_12_3e1dadd5:

    # DR "¿Estás bien, [povname]?"
    DR "Ты в порядке, [povname]?"

# game/script.rpy:1434
translate russian ruta_normal_12_c3f83adb:

    # "Tu voz bajó, al igual que tu mirada."
    "Ваш голос понижается, как и взгляд."

# game/script.rpy:1435
translate russian ruta_normal_12_68315d3f:

    # pov "No… no estoy bien."
    pov "Нет... я не порядке."

# game/script.rpy:1436
translate russian ruta_normal_12_8dcc7612:

    # "No lo dijiste con drama, ni con lágrimas."
    "Вы говорите это без драматизма или слёз."

# game/script.rpy:1437
translate russian ruta_normal_12_fff8f982:

    # "Solo lo dijiste porque era cierto."
    "Просто потому, что это правда."

# game/script.rpy:1438
translate russian ruta_normal_12_a0a91b1b:

    # "Por una vez, no tenías energía para fingir."
    "Впервые за долгое время у вас нет сил притворяться."

# game/script.rpy:1439
translate russian ruta_normal_12_2dc3da98:

    # "El Dr. Salazar asintió despacio."
    "Доктор Салазар медленно кивает."

# game/script.rpy:1440
translate russian ruta_normal_12_7555b820:

    # DR "No tienes por qué estarlo."
    DR "И не обязаны быть."

# game/script.rpy:1441
translate russian ruta_normal_12_3c904b4e:

    # "El silencio se sintió pesado, pero no incómodo."
    "Тишина кажется тяжёлой, но не неуютной."

# game/script.rpy:1442
translate russian ruta_normal_12_8a69c36f:

    # "Era raro que alguien no tratara de llenar el espacio con frases vacías."
    "Редко кто-то не пытается заполнить её дежурными фразами."

# game/script.rpy:1443
translate russian ruta_normal_12_6fd286eb:

    # pov "Creía que los doctores eran más… metódicos."
    pov "Я думали, врачи более... методичны."

# game/script.rpy:1445
translate russian ruta_normal_12_78a830b2:

    # "El Dr. Salazar sonrió apenas, como si entendiera más de lo que decía."
    "Доктор Салазар едва заметно улыбается, будто понимает больше, чем говорит."

# game/script.rpy:1446
translate russian ruta_normal_12_bfcb874c:

    # DR "No todos los doctores somos un cliché."
    DR "Не все врачи такие, как принято в клише."

# game/script.rpy:1447
translate russian ruta_normal_12_5b8d8cdc:

    # "Por primera vez en mucho tiempo… sentiste menos soledad."
    "Впервые за долгое время... вы чувствуете себя не так одиноко."

# game/script.rpy:1448
translate russian ruta_normal_12_299c7f85:

    # "Solo un poco. Pero algo era algo."
    "Совсем немного. Но и этого уже достаточно."

# game/script.rpy:1453
translate russian ruta_normal_12_e405c244:

    # pov "Estaré bien. Es sólo un ojo, tengo otro."
    pov "Со мной всё будет хорошо. Это всего лишь глаз, второй-то остался."

# game/script.rpy:1454
translate russian ruta_normal_12_82a9f63e:

    # "No sabías si era cierto, pero tampoco importaba."
    "Вы и сами не уверены в том, правда ли это, но не придаёте значения."

# game/script.rpy:1455
translate russian ruta_normal_12_427b61a4:

    # "No lo dijiste para él. Lo dijiste para cortar la conversación."
    "Вы сказали это не ради него, а просто чтобы закончить разговор."

# game/script.rpy:1456
translate russian ruta_normal_12_af17194d:

    # "Hablar dolía. Escuchar también."
    "Говорить больно. Слушать — тоже."

# game/script.rpy:1458
translate russian ruta_normal_12_50d7d692:

    # "Salazar te miró, como queriendo leer algo más en tu cara, pero solo encontró lo de siempre: apatía."
    "Салазар внимательно смотрит, будто надеется найти в вашем лице что-то ещё, но видит только привычную апатию."

# game/script.rpy:1459
translate russian ruta_normal_12_dbf02063:

    # DR "No tienes que fingir ser fuerte."
    DR "Не нужно притворяться сильными."

# game/script.rpy:1460
translate russian ruta_normal_12_87a1efb2:

    # DR "Tenemos profesionales con los que puedes hablar-"
    DR "У нас есть специалисты, с которыми можно поговорить—"

# game/script.rpy:1461
translate russian ruta_normal_12_2b24fec5:

    # pov "No estoy fingiendo. Solo… no me importa."
    pov "Я не притворяюсь. Просто... мне всё равно."

# game/script.rpy:1462
translate russian ruta_normal_12_54b285ba:

    # "Ahí estaba: la barrera. Sutil, pero sólida."
    "Вот он — тот самый барьер. Невидимый, но прочный."

# game/script.rpy:1463
translate russian ruta_normal_12_de9c8beb:

    # "No querías consuelo. No querías compañía. Solo querías que te dejaran en paz."
    "Вы не хотите утешения. Не хотите общения. Лишь чтобы оставили в покое."

# game/script.rpy:1464
translate russian ruta_normal_12_11b58f43:

    # "Por un segundo, el silencio en la sala pesó más que el dolor en el cuerpo."
    "На секунду тишина в палате показалась тяжелее, чем боль в теле."

# game/script.rpy:1469
translate russian ruta_normal_13_9a7546c2:

    # DR "¿Hay alguien a quien llamar?"
    DR "Есть кто-нибудь, кому можно позвонить?"

# game/script.rpy:1470
translate russian ruta_normal_13_75fd4299:

    # DR "¿Algún familiar, un amigo, pareja?"
    DR "Родные, друзья, кто-то близкий?"

# game/script.rpy:1471
translate russian ruta_normal_13_f8b872b0:

    # pov "…."
    pov "..."

# game/script.rpy:1472
translate russian ruta_normal_13_c7415228:

    # "No querías admitir que tu vida era solitaria, pero no podías simplemente mentirle a tu doctor."
    "Не хочется признавать, что жизнь у вас одинокая. Но и солгать врачу вы не можете."

# game/script.rpy:1477
translate russian ruta_normal_13_42d056b9:

    # DR "Oh, lo lamento mucho…"
    DR "Ох, мне очень жаль..."

# game/script.rpy:1481
translate russian ruta_normal_13_0ff0e7b9:

    # DR "Entiendo…"
    DR "Понимаю..."

# game/script.rpy:1485
translate russian ruta_normal_13_e782a7f3:

    # DR "Eso va hacer las cosas algo complicadas…."
    DR "Это немного усложнит дело..."

# game/script.rpy:1490
translate russian character_2_3bfb7f2a:

    # "El Dr. Salazar se rascó la cabeza con incomodidad."
    "Доктор Салазар неловко почесал затылок."

# game/script.rpy:1491
translate russian character_2_9d7c39db:

    # "Precisamente por eso no querías decir nada en primer lugar."
    "Именно поэтому вы и не хотели ничего говорить с самого начала."

# game/script.rpy:1492
translate russian character_2_c46eadc2:

    # DR "Debe haber alguien en esta ciudad con la que tengas contacto, ¿Algún compañero de trabajo?"
    DR "Наверняка в этом городе есть кто-то, с кем ты на связи? Коллега, например?"

# game/script.rpy:1493
translate russian character_2_0a36c9f9:

    # "Hablar de trabajo te hizo recordar a cierta persona."
    "Упоминание работы невольно напоминает вам об одном человеке."

# game/script.rpy:1495
translate russian character_2_b7876698:

    # pov "¿Qué hora es, doctor?"
    pov "Который час, доктор?"

# game/script.rpy:1496
translate russian character_2_f7897793:

    # "El Dr. Salazar se sacude la muñeca y ojea su reloj de muñeca."
    "Доктор Салазар смотрит на наручные часы, слегка встряхнув кистью."

# game/script.rpy:1497
translate russian character_2_75c17823:

    # DR "Son las 4 am."
    DR "4 утра."

# game/script.rpy:1498
translate russian character_2_b8167d93:

    # DR "¿Por qué?"
    DR "А что?"

# game/script.rpy:1499
translate russian character_2_7de095ba:

    # pov "… Hay alguien a quien puedo llamar, pero es muy temprano…"
    pov "...Есть человек, которому я могли бы позвонить, но сейчас слишком рано..."

# game/script.rpy:1500
translate russian character_2_e08e3f59:

    # DR "Alguien te atacó, lo entenderá."
    DR "На тебя напали, он поймёт."

# game/script.rpy:1501
translate russian character_2_981f1251:

    # "Apretaste los labios en una línea, con duda."
    "Вы с сомнением поджимаете губы."

# game/script.rpy:1502
translate russian character_2_f3a6ee2c:

    # "No tenías tanta cercanía con ella… pero no podías pensar en nadie más."
    "Вы не настолько близки с ней... но никого другого вы вспомнить не можете."

# game/script.rpy:1503
translate russian character_2_8bccb757:

    # pov "Está bien… le daré su número."
    pov "Ладно... я дам её номер."

# game/script.rpy:1504
translate russian character_2_4f296540:

    # "Anotas en un papel un número de teléfono y se lo entregas."
    "Вы записываете номер телефона на бумаге и передаёте его врачу."

# game/script.rpy:1505
translate russian character_2_a403dee2:

    # DR "Van a estar viniendo miembros del personal, para monitorear."
    DR "Скоро будут заходить сотрудники, чтобы понаблюдать за тобой."

# game/script.rpy:1506
translate russian character_2_d5f56107:

    # DR "Puedes pedirles lo que necesites."
    DR "Можешь просить у них всё, что понадобится."

# game/script.rpy:1507
translate russian character_2_1cb031e6:

    # pov "De acuerdo."
    pov "Хорошо."

# game/script.rpy:1508
translate russian character_2_173d27ad:

    # "El Dr. Salazar asiente levemente ante tu afirmativa, y se dirige a la puerta de la habitación."
    "Доктор Салазар слегка кивает в ответ и направляется к двери палаты."

# game/script.rpy:1509
translate russian character_2_91622aa0:

    # "Pero antes de retirarse, se gira hacia ti."
    "Но перед тем, как уйти, он оборачивается к вам."

# game/script.rpy:1510
translate russian character_2_40d10fae:

    # DR "Cuando te sientas mejor, podrás hablar con la policía."
    DR "Когда почувствуешь себя лучше, можешь поговорить с полицией."

# game/script.rpy:1511
translate russian character_2_51a04127:

    # DR "Por ahora, descansa."
    DR "А пока — отдыхай."

# game/script.rpy:1513
translate russian character_2_e3bc4291:

    # "Y con eso, el doctor abandonó la habitación, dejándote con tus pensamientos."
    "С этими словами доктор выходит из палаты, оставляя вас наедине с мыслями."

# game/script.rpy:1514
translate russian character_2_16d5b70d:

    # "Recuerdas vagamente que escuchaste personas acercarse a ti cuando te desmayaste en el callejón, seguramente ahuyentaron a Jeff."
    "Вы смутно помните, как в переулке перед потерей сознания слышали приближающиеся голоса — наверное, люди спугнули Джеффа."

# game/script.rpy:1515
translate russian character_2_7c061bdf:

    # "Lo importante es que estás bien y con vigilancia, no hay manera de que Jeff te alcance, ¿Cierto?"
    "Главное — теперь вы в безопасности и под наблюдением. Джефф не сможет вас достать, верно?"

# game/script.rpy:1516
translate russian character_2_b6a9d0ff:

    # "No era extraño que te preocupara eso, ya que lo último que te dijo fue que te perseguiría hasta encontrarte."
    "И всё же тревога не отпускает — ведь последним, что он сказал, было обещание: он будет охотиться, пока не найдёт вас."

# game/script.rpy:1517
translate russian character_2_c972ab96:

    # "Pero nuevamente, estás en un hospital, se supone que es seguro."
    "Но вы же в больнице — здесь должно быть безопасно."

# game/script.rpy:1518
translate russian character_2_91f3abeb:

    # "Tanto pensar te agotó nuevamente, por lo que te acomodaste en la camilla para poder descansar."
    "От всех этих мыслей снова наваливается усталость, так что вы устраиваетесь поудобнее на койке."

# game/script.rpy:1519
translate russian character_2_329aeee0:

    # "Unos minutos… querías dormir aunque sea unos minutos."
    "Всего несколько минут... Вы хотите поспать хотя бы немного."

# game/script.rpy:1523
translate russian character_2_7f348ac7:

    # "………."
    "........."

# game/script.rpy:1524
translate russian character_2_daddafea:

    # "Mientras dormías, habrías jurado haber sentido una caricia en tu mejilla."
    "Во сне вам кажется, что по щеке скользит лёгкое прикосновение."

# game/script.rpy:1525
translate russian character_2_546026d9:

    # "Era suave y delicada, unos dedos recorrieron la piel de tu pómulo derecho, bajando por tu mandíbula hasta rozar tus labios."
    "Нежное, едва уловимое — чьи-то пальцы проходятся по правой скуле, спускаются по линии челюсти и замирают у губ."

# game/script.rpy:1528
translate russian character_2_a24f52bf:

    # "Abriendo tu único ojo, miraste la habitación, buscando quien quiera que sea que te haya tocado mientras dormías."
    "Вы открываете единственный глаз и оглядываете палату в поисках того, кто мог вас коснуться."

# game/script.rpy:1531
translate russian character_2_7cecf6f5:

    # "Pero sólo viste a Cindy."
    "Но в комнате только Синди."

# game/script.rpy:1532
translate russian character_2_c36c0133:

    # C "¡[povname]!"
    C "[povname]!"

# game/script.rpy:1534
translate russian character_2_901479c4:

    # "Repentinamente, y para gran sorpresa tuya, Cindy rodeó tus hombros entre sus brazos, inclinándose sobre ti para estrecharse en un ligero abrazo."
    "Неожиданно, и к вашему большому удивлению, Синди обхватывает вас за плечи, наклоняясь, чтобы прижаться в лёгких, коротких объятиях."

# game/script.rpy:1535
translate russian character_2_00a7bc9c:

    # "Te quedaste de piedra."
    "Вы замираете."

# game/script.rpy:1536
translate russian character_2_bc9db973:

    # C "¡Pensé que no despertarías!, oh, que susto…"
    C "Я думала, ты уже не очнёшься! Боже, я так испугалась..."

# game/script.rpy:1538
translate russian character_2_c6c108fb:

    # "Cindy se separó de ti, tratándote con una delicadeza a la que no terminas de acostumbrarte."
    "Синди отстраняется, обращаясь с вами с такой бережностью, к которой вы никак не могли привыкнуть."

# game/script.rpy:1539
translate russian character_2_4514a241:

    # "¿Es tu idea, o es como si Cindy… tuviera el papel de tu mejor amiga?"
    "Вам просто кажется, или Синди сейчас... пытается играть роль вашей лучшей подруги?"

# game/script.rpy:1540
translate russian character_2_b521bee9:

    # "Ella era por lejos tu mejor amiga, sólo la conoces por un tiempo."
    "Пожалуй, она самая близкая ваша подруга, хоть вы и знакомы совсем недолго."

# game/script.rpy:1541
translate russian character_2_92f57cfa:

    # "Está bien, tú fuiste quien le dio su contacto a Salazar, pero sólo porque es la persona más cercana que tienes a mano."
    "Да, это вы дали Салазару её контакты, но только потому, что ближе у вас никого нет."

# game/script.rpy:1542
translate russian character_2_fb7c3408:

    # pov "Ehm… ¿A qué viene tanto cariño?"
    pov "Эм... а с чего вдруг столько нежностей?"

# game/script.rpy:1544
translate russian character_2_01482190:

    # "Un rayo pareció partir a Cindy, haciéndola retroceder con una expresión consternada."
    "Словно громом поражённая, Синди отпрянула с растерянным выражением лица."

# game/script.rpy:1545
translate russian character_2_d4f2e9e4:

    # C "No… lo sé, pero es como… si tu de repente fueras muy importante."
    C "Я... не знаю, просто... ты как будто вдруг стали для меня чем-то очень важным."

# game/script.rpy:1546
translate russian character_2_b526851f:

    # "¿O sea que antes no lo eras?"
    "То есть до этого — нет?"

# game/script.rpy:1547
translate russian character_2_237535bd:

    # "Ok, una cosa es que tu pienses eso de ti personalmente, pero que otra persona lo diga te dolía un poco."
    "Одно дело, когда вы сами так о себе думаете, но слышать это от другого человека — неприятно."

# game/script.rpy:1549
translate russian character_2_553edb11:

    # C "Cuando supe lo que te pasó, vine de inmediato."
    C "Когда я узнала, что с тобой случилось, сразу приехала."

# game/script.rpy:1550
translate russian character_2_1c43713d:

    # C "No quería que estuvieras por tu cuenta en estos momentos."
    C "Не хотела, чтобы ты оставались одни в таком состоянии."

# game/script.rpy:1552
translate russian character_2_0f0c331d:

    # C "¿Cómo te sientes?"
    C "Как ты себя чувствуешь?"

# game/script.rpy:1553
translate russian character_2_6f9c872b:

    # "Cindy tomó asiento en la silla a tu derecha, esta vez conservando una distancia más cordial."
    "Синди садится на стул справа от вас, теперь соблюдая более уместную дистанцию."

# game/script.rpy:1554
translate russian character_2_f40988ee:

    # "Entendible, sólo trabajan en la misma tienda."
    "Впрочем, логично — вы ведь просто коллеги."

# game/script.rpy:1555
translate russian character_2_37ca398a:

    # pov "Con algo de dolor… pero creo que dentro de todo estoy bien."
    pov "Болит немного... но, думаю, в целом всё нормально."

# game/script.rpy:1556
translate russian character_2_d1a41b96:

    # "Cindy bajó la mirada con preocupación, para después elevarla hacia ti."
    "Синди опускает взгляд, тревожно нахмурившись, а потом снова смотрит на вас."

# game/script.rpy:1557
translate russian character_2_d97b4eb7:

    # "Ella suspiró pesado, llevando los dedos hacia su frente."
    "Она тяжело вздыхает и потирает лоб кончиками пальцев."

# game/script.rpy:1559
translate russian character_2_4160d250:

    # C "Te dije que tuvieras cuidado…"
    C "Я же говорила тебе быть осторожнее..."

# game/script.rpy:1560
translate russian character_2_7dd63f9f:

    # "Ese comentario… estaba demás."
    "Это было... необязательно."

# game/script.rpy:1561
translate russian character_2_55d8752f:

    # "¿Acaso ella quería echar la culpa hacia ti?"
    "Она что, теперь обвиняет вас?"

# game/script.rpy:1562
translate russian character_2_f20cd9e9:

    # "¿Cómo si lo que te pasó fue por tus acciones y no las del desgraciado que te arrancó un ojo?"
    "Будто то, что случилось, — ваша вина, а не вина того ублюдка, что вырвал вам глаз?"

# game/script.rpy:1563
translate russian character_2_719e9721:

    # pov "Te recuerdo que me atacaron, no es mi culpa."
    pov "Напомню, на меня напали. Это не моя вина."

# game/script.rpy:1564
translate russian character_2_ef019260:

    # C "No me refiero a eso, yo-"
    C "Я не это имела в виду, я—"

# game/script.rpy:1565
translate russian character_2_6b2c0f38:

    # pov "¿Ahora se supone que eres una compañera de trabajo atenta?, que mal chiste."
    pov "Теперь ты заботливая коллега? Плохая шутка."

# game/script.rpy:1566
translate russian character_2_c36c0133_1:

    # C "¡[povname]!"
    C "[povname]!"

# game/script.rpy:1567
translate russian character_2_7ec8d295:

    # "No fue el volumen de su voz, ni tampoco el hecho de que te llamó por tu nombre."
    "Вас останавливает не то, что она повысила голос, и не то, что она впервые назвала вас по имени."

# game/script.rpy:1568
translate russian character_2_70fd5b1e:

    # "Fue su tono desgarrador lo que te hizo detenerte."
    "А её надломленный тон."

# game/script.rpy:1570
translate russian character_2_29887dc8:

    # C "Yo… tampoco me entiendo."
    C "Я... и сама себя не понимаю."

# game/script.rpy:1571
translate russian character_2_0ba71e1a:

    # C "No creí que me importaras tanto."
    C "Я не знала, что ты так важны для меня."

# game/script.rpy:1572
translate russian character_2_5c08642b:

    # pov "Oye-"
    pov "Эй—"

# game/script.rpy:1574
translate russian character_2_d77cb3fe:

    # C "Estuviste a punto de morir, y me sentí aterrada."
    C "Ты были на грани смерти, и я до ужаса напугалась."

# game/script.rpy:1575
translate russian character_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:1576
translate russian character_2_d94eb7d2:

    # "Es cómo… si hubieras empezado a desarrollar un campo gravitacional, y ahora varias personas giraban alrededor de ti. Jeff, Salazar, Cindy."
    "Вы как будто... стали центром притяжения, и теперь вокруг вас вращаются несколько человек: Джефф, Салазар, Синди."

# game/script.rpy:1577
translate russian character_2_f348cd95:

    # "Sólo bastó que un loco te acosara y te arrancara un ojo, ¿No?"
    "Всего-то понадобилось, чтобы один псих начал преследовать вас и выдрал глаз, да?"

# game/script.rpy:1578
translate russian character_2_5cda6e5e:

    # C "No tengo cómo explicarlo, pero me preocupo por ti, ¿Podrías dejar de ser idiota al respecto y aceptarlo?"
    C "Не знаю, как это объяснить, но я волнуюсь за тебя. Может, перестанешь вести себя как идиот и примешь это?"

# game/script.rpy:1579
translate russian character_2_2749a053:

    # "No pudiste evitar callarte ante la declaración de ella."
    "Вы не нашли, что ответить на её признание."

# game/script.rpy:1580
translate russian character_2_04774a0b:

    # "Estarías mintiendo si decías que tu corazón no latió fuerte."
    "Вы бы солгали, если бы сказали, что ваше сердце не забилось сильнее."

# game/script.rpy:1584
translate russian character_2_e75eae6e:

    # pov "Yo… gracias, Cindy."
    pov "Я... спасибо, Синди."

# game/script.rpy:1586
translate russian character_2_d1d86ee0:

    # "Cindy te miró en silencio, uno reconfortante."
    "Синди молча смотрит на вас; в этой тишине есть что-то успокаивающее."

# game/script.rpy:1587
translate russian character_2_2c1446a4:

    # pov "No soy… de decir estas cosas, pero gracias, por preocuparte por mi."
    pov "Я... не люблю это говорить, но спасибо, что переживаешь за меня."

# game/script.rpy:1589
translate russian character_2_9c2e5cde:

    # "Cindy bajó la mirada, para después sonreír levemente."
    "Синди опускает взгляд, а затем чуть заметно улыбается."

# game/script.rpy:1590
translate russian character_2_88c8189f:

    # C "No estás haciendo un buen trabajo en solitario… así que no me importa hacerlo por ti."
    C "Ты с этим не очень хорошо справляешься в одиночку... так что я не против сделать это за тебя."

# game/script.rpy:1591
translate russian character_2_0877f647:

    # pov "Heh, si."
    pov "Хех, да."

# game/script.rpy:1592
translate russian character_2_708d92b2:

    # "Cindy te sonrió levemente, pero de repente su expresión cambió."
    "Синди слегка улыбается, но затем выражение её лица меняется."

# game/script.rpy:1597
translate russian character_2_2a0854c6:

    # pov "¿De casualidad…. me acariciaste mientras dormía?"
    pov "Слушай... ты случайно не гладила меня, пока я спали?"

# game/script.rpy:1599
translate russian character_2_a9d05d0c:

    # "Cindy te quedó viendo inexpresiva."
    "Синди уставилась на вас с непроницаемым лицом."

# game/script.rpy:1600
translate russian character_2_96188552:

    # C "Ew, no."
    C "Фу, нет."

# game/script.rpy:1601
translate russian character_2_8e014f46:

    # "Si, esa es la Cindy que conocías."
    "Да, это та Синди, которую вы помните."

# game/script.rpy:1602
translate russian character_2_9a060320:

    # pov "Bueno, ¿entonces quién fue?"
    pov "Тогда кто?"

# game/script.rpy:1603
translate russian character_2_e2011169:

    # C "¿Qué sé yo?, no es cómo si-"
    C "Откуда я знаю? Это же—"

# game/script.rpy:1604
translate russian character_2_055ff75c:

    # "Cindy detuvo sus palabras como si un pensamiento le hubiera llegado a la cabeza."
    "Синди резко осеклась, будто ей в голову пришла какая-то мысль."

# game/script.rpy:1610
translate russian ruta_normal_14_6b41728c:

    # C "El que te atacó, ¿Fue el mismo rarito de la tienda?"
    C "Тот, кто на тебя напал — это тот же странный тип из магазина?"

# game/script.rpy:1611
translate russian ruta_normal_14_e5d04b37:

    # pov "Yo-"
    pov "Я—"

# game/script.rpy:1613
translate russian ruta_normal_14_aa3f84bb:

    # "Tras un leve toque en la puerta de tu habitación, aparecieron dos personas."
    "После лёгкого стука в дверь в палату входят двое человек."

# game/script.rpy:1614
translate russian ruta_normal_14_8432ea30:

    # "Perfecta entrada para interrumpir la conversación que estabas teniendo."
    "Как раз вовремя, чтобы прервать ваш разговор."

# game/script.rpy:1621
translate russian ruta_normal_14_e981f01c:

    # TW "Buenas, [povname]. Somos el teniente Wes y la detective Sean, ¿Podemos hacerte unas preguntas?"
    TW "Добрый вечер, [povname]. Мы лейтенант Уэс и детектив Шон. Можем задать несколько вопросов?"

# game/script.rpy:1622
translate russian ruta_normal_14_3a6328c4:

    # "Miraste con tu único ojo a los policías."
    "Вы смотрите единственным глазом на людей в форме."

# game/script.rpy:1623
translate russian ruta_normal_14_cdcc1043:

    # "Un hombre y una mujer, vestidos con ropa formal. El hombre fue el que habló, mostrando su placa, y la mujer, la detective Sean, lo imitó."
    "Мужчина и женщина, одетые в строгую форму. Говорит мужчина, показывая удостоверение, а женщина, детектив Шон, повторяет его жест."

# game/script.rpy:1624
translate russian ruta_normal_14_d18098ad:

    # "Te miraban con seriedad, pero a la vez no se veían muy preocupados por ti."
    "Они смотрят на вас серьёзно, но при этом не выглядят особенно обеспокоенными вашим состоянием."

# game/script.rpy:1625
translate russian ruta_normal_14_dc325902:

    # "Más bien, pareciera que estaban más interesados en lo que tenías que decir."
    "Скорее, кажется, их больше интересуют ваши показания."

# game/script.rpy:1626
translate russian ruta_normal_14_b339cd1c:

    # TW "Tu doctor nos dijo que tenías visita, si te es más cómodo, podemos hacer la entrevista con ella presente."
    TW "Ваш лечащий врач сказал, что у вас есть посетитель. Если так будет удобнее, можем провести беседу при ней."

# game/script.rpy:1627
translate russian ruta_normal_14_4709f701:

    # C "[povname] recién despertó, debe descansar."
    C "[povname] только проснулись, им нужен отдых."

# game/script.rpy:1628
translate russian ruta_normal_14_3fdc7f6a:

    # "Cindy les habló por encima del hombro, desinteresada en la presencia de ellos."
    "Бросает Синди через плечо, даже не повернувшись к ним, не обращая на них внимания."

# game/script.rpy:1629
translate russian ruta_normal_14_42297df1:

    # DS "Mientras más pronto hablemos, más pronto atraparemos al que te hizo esto."
    DS "Чем раньше мы поговорим, тем скорее поймаем того, кто с вами это сделал."

# game/script.rpy:1630
translate russian ruta_normal_14_c4a3b80d:

    # "El calor subió de tu pecho a tu cabeza, a tu cuenca."
    "Вашу грудь будто охватывает жар, поднимаясь к голове, к пустой глазнице."

# game/script.rpy:1631
translate russian ruta_normal_14_d670e43d:

    # "No sabías si era una respuesta de tu cuerpo o sólo enojo hacia Jeff, pero pudiste ocultarlo."
    "Вы не знаете, является ли это реакцией тела или просто злостью на Джеффа, но вам удаётся это скрыть."

# game/script.rpy:1632
translate russian ruta_normal_14_9e479590:

    # pov "Está bien, Cindy, responderé lo que pueda."
    pov "Всё в порядке, Синди. Я отвечу, на что смогу."

# game/script.rpy:1633
translate russian ruta_normal_14_786260fa:

    # "Los detectives parecieron relajarse un poco ante tus palabras."
    "Детективы немного расслабляются после ваших слов."

# game/script.rpy:1634
translate russian ruta_normal_14_c6db8d9f:

    # "Ellos se pusieron al otro lado de tu camilla, Wes se mantuvo de pie junto a ti, haciendo contacto visual contigo para transmitir más confianza, mientras Sean sacaba una libreta para tomar notas."
    "Они встают по другую сторону койки. Уэс остаётся рядом, глядя вам прямо в глаза, словно пытаясь вызвать доверие, а Шон достаёт блокнот, готовясь делать записи."

# game/script.rpy:1635
translate russian ruta_normal_14_d51d1082:

    # "Clásico, policía bueno y malo."
    "Классика — хороший полицейский, плохой полицейский."

# game/script.rpy:1636
translate russian ruta_normal_14_871aa33c:

    # TW "Empecemos con lo más importante, ¿Viste a tu atacante?"
    TW "Начнём с главного, вы видели своего нападавшего?"

# game/script.rpy:1637
translate russian ruta_normal_14_b94f4b41:

    # pov "Oh, si, no fue bonito."
    pov "О, да, зрелище не из приятных."

# game/script.rpy:1638
translate russian ruta_normal_14_e9300d7a:

    # DS "¿Podrías dar más detalles?"
    DS "Можете рассказать подробнее?"

# game/script.rpy:1639
translate russian ruta_normal_14_7b2d2828:

    # pov "¿Cómo su número social?"
    pov "Его номер социального страхования?"

# game/script.rpy:1640
translate russian ruta_normal_14_a9505768:

    # "Estabas jugando, obviamente."
    "Вы, конечно же, шутите."

# game/script.rpy:1641
translate russian ruta_normal_14_5fbfcf29:

    # "Ya estabas en camilla, sin un ojo y bajo analgésicos, tenías permitido divertirte."
    "Лежите на больничной койке, без глаза и под обезболивающими — имеете право немного повеселиться."

# game/script.rpy:1643
translate russian ruta_normal_14_53009117:

    # C "Te preguntan si era hombre o mujer, estatura, complexión, ropa-"
    C "Они имели в виду, был ли это мужчина или женщина, рост, телосложение, одежда—"

# game/script.rpy:1644
translate russian ruta_normal_14_5cda2a9c:

    # pov "Lo sé, cielos, nadie acepta un chiste…"
    pov "Знаю, боже, никто шуток не понимает..."

# game/script.rpy:1645
translate russian ruta_normal_14_333094f0:

    # pov "Era un hombre, blanco. Alto, no sé… ¿de un metro noventa?, quizás más. Llevaba una sudadera blanca, pésima ropa para un criminal si me preguntan a mí."
    pov "Это был мужчина, белый. Высокий, не знаю... где-то метр девяносто? На нём была белая толстовка — ужасная одежда для преступника, если угодно."

# game/script.rpy:1646
translate russian ruta_normal_14_dc77f6a2:

    # "Miraste a Cindy de reojo, fácil porque estaba en tu lado derecho."
    "Вы бросаете на Синди короткий взгляд — удобно, она как раз сидела справа."

# game/script.rpy:1647
translate russian ruta_normal_14_c20f2332:

    # "Ella tenía una expresión pensativa, lo más probable es que ya haya concluído que estabas hablando de Jeff, o como ella lo conocía, “el rarito de la tienda”."
    "Она сидит с задумчивым выражением лица. Скорее всего, уже поняла, что речь идёт о Джеффе — или, как она его называла, «странный тип из магазина»."

# game/script.rpy:1648
translate russian ruta_normal_14_3c92176f:

    # TW "¿… Alguna característica en especial?"
    TW "...Какие-нибудь особые приметы?"

# game/script.rpy:1649
translate russian ruta_normal_14_c798e9eb:

    # pov "Tenía la cara destrozada, si saben a lo que me refiero."
    pov "У него было изуродовано лицо, если понимаете, о чём я."

# game/script.rpy:1650
translate russian ruta_normal_14_6c55ea90:

    # "Los tres presentes te miraron en silencio por unos segundos, y te sentiste bajo presión para dar más detalles."
    "Трое присутствующих молча уставились на вас. Под этой тишиной вы чувствуете давление, будто их взгляды требуют продолжить."

# game/script.rpy:1651
translate russian ruta_normal_14_749f411c:

    # pov "… Tenía muchas cicatrices, la boca… la tenía rasgada."
    pov "...У него было много шрамов, рот... был разорван."

# game/script.rpy:1653
translate russian ruta_normal_14_00c63b53:

    # "Cindy parecía tan asqueada con la descripción que parecía a punto de vomitar."
    "Синди побледнела от одного только описания — кажется, её вот-вот вырвет."

# game/script.rpy:1654
translate russian ruta_normal_14_d1f59ce9:

    # "Wes y Sean se dedicaron una mirada silenciosa, para después volver a mirarte."
    "Уэс и Шон обмениваются молчаливыми взглядами, после чего снова поворачиваются к вам."

# game/script.rpy:1655
translate russian ruta_normal_14_e07f6adb:

    # TW "De acuerdo… ¿Pasó algo inusual el día de tu ataque?"
    TW "Хорошо... Было ли что-то необычное в день нападения?"

# game/script.rpy:1656
translate russian ruta_normal_14_cf656439:

    # pov "Creo que la cantidad normal de “raro” que todos podemos tener en un día-"
    pov "Думаю, примерно столько же «странного», сколько у любого за день—"

# game/script.rpy:1657
translate russian ruta_normal_14_acb06a1d:

    # C "¡Deja de joder!"
    C "Хватит уже валять дурака!"

# game/script.rpy:1658
translate russian ruta_normal_14_dca5840e:

    # "Cindy te regañó, no gritó pero si usó un tono elevado de voz que te hizo hacer un puchero."
    "Синди отругала вас, не крича, но достаточно резко, чтобы вы обиженно надули губы."

# game/script.rpy:1659
translate russian ruta_normal_14_60f39125:

    # C "Fue un tipo raro que apareció en la tienda."
    C "В тот день в магазин приходил какой-то подозрительный тип."

# game/script.rpy:1660
translate russian ruta_normal_14_cf949690:

    # DS "¿Qué definirías como raro?"
    DS "Подозрительный — это как?"

# game/script.rpy:1661
translate russian ruta_normal_14_2b0c69b2:

    # "Cindy rodó los ojos."
    "Синди закатывает глаза."

# game/script.rpy:1662
translate russian ruta_normal_14_e8c22d1b:

    # "Vaya, no tomabas a Cindy como alguien que se rebele ante la autoridad."
    "Вы никогда бы не подумали, что Синди способна вот так огрызнуться на людей при исполнении."

# game/script.rpy:1663
translate russian ruta_normal_14_f7a00c97:

    # C "Dió vueltas por más de una hora. Estaba muy interesado en [povname]."
    C "Шлялся там больше часа. И слишком уж интересовался [povname]."

# game/script.rpy:1664
translate russian ruta_normal_14_b334b8d9:

    # "Wes dirigió su atención a ti, alzando una ceja."
    "Уэс переводит взгляд на вас, слегка приподняв бровь."

# game/script.rpy:1665
translate russian ruta_normal_14_1c0599e1:

    # TW "¿Tuviste interacción con él?"
    TW "Вы с ним разговаривали?"

# game/script.rpy:1671
translate russian ruta_normal_14_191789ff:

    # pov "Bueno… la verdad es que coquetee un poco con él."
    pov "Ну... если честно, я немного с ним флиртовали."

# game/script.rpy:1673
translate russian ruta_normal_14_3928a113:

    # "......."
    "......."

# game/script.rpy:1674
translate russian ruta_normal_14_deacd3f3:

    # "Sentiste que todos en la habitación te estaban juzgando."
    "Вы ощутили, как все в комнате уставились на вас с осуждением."

# game/script.rpy:1675
translate russian ruta_normal_14_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:1676
translate russian ruta_normal_14_9f6a419c:

    # pov "Sí, era extraño, pero fue casi… lindo."
    pov "Да, это было странно, но и почти... мило."

# game/script.rpy:1677
translate russian ruta_normal_14_da389d35:

    # "El aire se tornó incómodo."
    "Атмосфера мгновенно становится неловкой."

# game/script.rpy:1680
translate russian ruta_normal_14_bc2cdb9a:

    # pov "Oh, fue muy incómodo."
    pov "Ох, это было жутко неловко."

# game/script.rpy:1681
translate russian ruta_normal_14_32ec8b5e:

    # pov "No paraba de mirarme, y fingió buscar algo para comprar por una eternidad."
    pov "Он не переставал на меня пялиться и целую вечность делал вид, будто выбирает, что купить."

# game/script.rpy:1682
translate russian ruta_normal_14_6b910a7b:

    # pov "Quería creer que era otro tipo de acosador."
    pov "Тогда просто хотелось верить, что он типичный сталкер."

# game/script.rpy:1684
translate russian ruta_normal_14_796f1be5:

    # "Esperaste una reacción de los detectives, pero te miraron con la misma seriedad de antes."
    "Вы ждёте от детективов хоть какой-то реакции, но их лица остаются всё такими же невозмутимыми."

# game/script.rpy:1685
translate russian ruta_normal_14_3b160322:

    # "Te giraste a Cindy, y ella estaba negando suavemente con la cabeza."
    "Вы поворачиваетесь к Синди — та тихо качает головой."

# game/script.rpy:1686
translate russian ruta_normal_14_6fcbe063:

    # "Público difícil, ¿Eh?"
    "Трудная, однако, публика, да?"

# game/script.rpy:1691
translate russian ruta_normal_15_c7d97404:

    # DS "¿Dijo algo sobre él, algún motivo o dijo por qué te dejó con vida?"
    DS "Он говорил что-нибудь о себе? Может, намекал на мотив — или почему оставил вас в живых?"

# game/script.rpy:1692
translate russian ruta_normal_15_3304f1ff:

    # "La pregunta te extrañó un poco. Era cómo si les extrañara el que hayas sobrevivido."
    "Вопрос немного вас озадачил — будто их удивляет сам факт того, что вы выжили."

# game/script.rpy:1693
translate russian ruta_normal_15_fb7e6cb7:

    # "Bueno, no estaba del todo equivocada al preguntar eso, ya que precisamente por la amenaza de Jeff es que sigues con vida."
    "Хотя, не то чтобы детектив ошибается с таким предположением, ведь именно из-за угрозы Джеффа вы всё ещё живы."

# game/script.rpy:1695
translate russian ruta_normal_15_ddcf5e02:

    # "Quizás hubieras revelado esa parte de la información por un desliz de lengua, pero Cindy interrumpió antes de que dijeras algo."
    "Может, вы бы и проговорились об этом по неосторожности, но Синди вмешивается прежде, чем вы успеваете открыть рот."

# game/script.rpy:1696
translate russian ruta_normal_15_a20a31bb:

    # C "¿Qué clase de pregunta es esa?"
    C "Что вообще за вопрос?"

# game/script.rpy:1697
translate russian ruta_normal_15_53a3fe4a:

    # DS "Estamos haciendo un perfil del sospechoso, cualquier detalle nos puede ayudar-"
    DS "Мы составляем психологический портрет подозреваемого, любая деталь может помочь—"

# game/script.rpy:1698
translate russian ruta_normal_15_b01a6cdc:

    # C "¡El tipo literalmente anda con la cara tapada!, ¡Está lleno de cicatrices!, ¿Qué más quieren? ¿Cómo no pueden encontrar a alguien así?"
    C "У парня лицо наполовину закрыто, всё в шрамах! Что вам ещё нужно? Как можно не найти такого?"

# game/script.rpy:1699
translate russian ruta_normal_15_99d4603c:

    # TW "Señorita, debes calmarte."
    TW "Мисс, прошу вас, успокойтесь."

# game/script.rpy:1700
translate russian ruta_normal_15_0c85b23f:

    # C "¡No!, para un caso como este, con la descripción física ya deberían empezar a buscarlo."
    C "Нет! В случае, как этот, при такой внешности вы уже давно должны были начать поиски!"

# game/script.rpy:1701
translate russian ruta_normal_15_b7939db5:

    # C "Mientras más pase el tiempo, puede que esté más lejos."
    C "Чем больше времени проходит, тем дальше он может быть."

# game/script.rpy:1702
translate russian ruta_normal_15_67cc23b9:

    # "La habitación quedó en silencio por unos momentos, y sentiste incomodidad ante la discusión."
    "В палате повисла тишина. Вы чувствуете себя неловко, наблюдая за этой перепалкой."

# game/script.rpy:1703
translate russian ruta_normal_15_a38238ca:

    # TW "… Tienes razón, pararemos por ahora."
    TW "...Вы правы, закончим на этом."

# game/script.rpy:1704
translate russian ruta_normal_15_814a3cb3:

    # DS "Pero teniente-"
    DS "Но, лейтенант—"

# game/script.rpy:1705
translate russian ruta_normal_15_7b517a45:

    # TW "[povname] necesita descansar."
    TW "[povname] нужно прийти в себя."

# game/script.rpy:1706
translate russian ruta_normal_15_f1dca1cc:

    # "Wes guió a Sean hacia la salida de la habitación, girándose por última vez hacia ti."
    "Уэс направляет Шон к выходу, но на мгновение оборачивается, задержав взгляд на вас."

# game/script.rpy:1707
translate russian ruta_normal_15_f089f2ff:

    # TW "Que te mejores."
    TW "Поправляйтесь."

# game/script.rpy:1712
translate russian ruta_normal_15_8bfda79c:

    # "Asentiste en silencio, observando que se retiran."
    "Вы молча киваете, провожая их взглядом."

# game/script.rpy:1713
translate russian ruta_normal_15_11167e6b:

    # "Nuevamente, quedaste a solas con Cindy."
    "И снова вы остаётесь с Синди наедине."

# game/script.rpy:1714
translate russian ruta_normal_15_462af4bd:

    # "Esta vez, el silencio pesaba con muchas preguntas, que seguramente hubieran sido útiles para atrapar a Jeff."
    "Теперь тишина давит — в ней клубятся десятки невысказанных вопросов, тех самых, что могли бы помочь найти Джеффа."

# game/script.rpy:1715
translate russian ruta_normal_15_0d2a4fb8:

    # "Cindy murmuró para sí misma, pero después se dio cuenta de tu mirada sobre ella, por lo que se enderezó en su asiento como si nada hubiera pasado."
    "Синди что-то бормочет себе под нос, но, замечая ваш взгляд, выпрямляется, будто ничего не было."

# game/script.rpy:1716
translate russian ruta_normal_15_684684f4:

    # C "No te preocupes, [povname], lo encontrarán."
    C "Не переживай, [povname], его найдут."

# game/script.rpy:1717
translate russian ruta_normal_15_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:1718
translate russian ruta_normal_15_6e91d2ee:

    # "¿Deberías mencionar la promesa de Jeff?"
    "Стоит ли рассказать об обещании Джеффа?"

# game/script.rpy:1719
translate russian ruta_normal_15_7a0250e0:

    # "Probablemente sería lo más inteligente de hacer, pero por el momento, te permitiste preguntar una sola cosa."
    "Вероятно, это было бы самым разумным решением, но пока вы позволяете себе задать лишь один вопрос."

# game/script.rpy:1720
translate russian ruta_normal_15_f016741e:

    # pov "Hey, Cindy."
    pov "Эй, Синди."

# game/script.rpy:1721
translate russian ruta_normal_15_4085f106:

    # pov "¿... No te gustan los policías?"
    pov "...Ты что, не любишь полицейских?"

# game/script.rpy:1723
translate russian ruta_normal_15_1ae53b6f:

    # "Cindy se sobresaltó en su asiento, y su tez palideció."
    "Синди вздрагивает, и её лицо бледнеет."

# game/script.rpy:1724
translate russian ruta_normal_15_d8ad7747:

    # "Ella desvió la mirada, frotó sus dedos indecisa."
    "Она отводит взгляд и принимается нерешительно теребить пальцы."

# game/script.rpy:1725
translate russian ruta_normal_15_76fbead3:

    # "Era evidente que no quería responder."
    "Очевидно — отвечать она не хочет."

# game/script.rpy:1726
translate russian ruta_normal_15_da6c857f:

    # pov "No importa, ignora eso último."
    pov "Неважно, забудь."

# game/script.rpy:1727
translate russian ruta_normal_15_bf369a1e:

    # "Restaste importancia con una sonrisa y un gesto de tu mano."
    "Вы с улыбкой отмахиваетесь."

# game/script.rpy:1729
translate russian ruta_normal_15_a95e9ade:

    # "Afortunadamente, Cindy pareció tranquilizarse."
    "К счастью, Синди, похоже, немного успокоилась."

# game/script.rpy:1730
translate russian ruta_normal_15_d824b603:

    # C "Yo… iré a desayunar, vuelvo en un rato."
    C "Я... пойду позавтракаю, скоро вернусь."

# game/script.rpy:1731
translate russian ruta_normal_15_27773c99:

    # pov "De acuerdo. ¿Me traes algo?"
    pov "Хорошо. Принесёшь мне что-нибудь?"

# game/script.rpy:1733
translate russian ruta_normal_15_970b4e54:

    # C "Claro, ¿Qué prefieres?"
    C "Конечно, что хочешь?"

# game/script.rpy:1745
translate russian character_3_16478d9b:

    # "Cindy asintió y se puso de pie."
    "Синди кивает и поднимается."

# game/script.rpy:1746
translate russian character_3_69d60587:

    # "Ella se dirigió a la puerta de la habitación, pero antes de que ella tomara la manilla, alguien más la abrió."
    "Она направляется к двери, но прежде чем успевает взяться за ручку, кто-то с другой стороны уже открывает её."

# game/script.rpy:1747
translate russian character_3_5b85991f:

    # "Cindy se movió a un lado, dejando entrar a un doctor."
    "Синди отступает в сторону, пропуская доктора внутрь."

# game/script.rpy:1748
translate russian character_3_148e382e:

    # "Ella dio un saludo breve, mirándolo de reojo antes de salir de la habitación."
    "Она коротко приветствует его, бросая короткий взгляд, и выходит из палаты."

# game/script.rpy:1754
translate russian character_3_fb8e35f6:

    # "Miraste cómo el doctor se adentraba en la habitación en silencio, cargando consigo una bandeja metálica."
    "Вы смотрите, как врач молча проходит внутрь, держа в руках металлический поднос."

# game/script.rpy:1755
translate russian character_3_a0c729ef:

    # "Recordaste que el Dr. Salazar te advirtió que te vendrían periódicamente a monitorear."
    "Вы вспоминаете, как доктор Салазар предупреждал, что вас будут периодически проверять."

# game/script.rpy:1757
translate russian character_3_929be24d:

    # "Él empezó a mover sus manos, preparando lo que fuera que tuviera en la bandeja."
    "Он принимается за работу, подготавливая то, что лежит на подносе."

# game/script.rpy:1761
translate russian character_3_2df5f182:

    # pov "Hola."
    pov "Привет."

# game/script.rpy:1762
translate russian character_3_753a7997:

    # "El doctor no respondió, te ignoró descaradamente mientras hacía lo que fuera que estaba haciendo."
    "Доктор не отвечает — откровенно игнорирует вас, продолжая свои манипуляции."

# game/script.rpy:1767
translate russian character_3_7175dc46:

    # pov "Hey, ¿Vienes a monitorearme o algo así?"
    pov "Эй, ты пришёл меня проверить или как?"

# game/script.rpy:1768
translate russian character_3_19c225d0:

    # "No obtuviste respuesta."
    "Ответа не последовало."

# game/script.rpy:1769
translate russian character_3_8b8ac98a:

    # "Suspiraste y apartaste la mirada."
    "Вы вздыхаете и отводите взгляд."

# game/script.rpy:1770
translate russian character_3_bf7bcec3:

    # "No sabías si era respuesta a un trauma u otra cosa, pero sentías cierto rechazo a ese hombre, alto, vestido de blanco con cabello negro y largo."
    "Трудно понять, связано ли это с пережитым или чем-то иным, но от этого человека исходит неприятное ощущение — высокий, в белом халате, с длинными чёрными волосами."

# game/script.rpy:1771
translate russian character_3_2fa38ab1:

    # "……."
    "......"

# game/script.rpy:1772
translate russian character_3_262a24b2:

    # "Es sospechoso, ¿No?"
    "Подозрительный тип, правда?"

# game/script.rpy:1777
translate russian ruta_normal_16_1cd6bc86:

    # "De todas formas, sentías tu garganta seca."
    "В любом случае, вы чувствуете, как пересыхает горло."

# game/script.rpy:1778
translate russian ruta_normal_16_013c5e55:

    # pov "Disculpa, ¿Podrías darme agua?"
    pov "Извини, можно воды?"

# game/script.rpy:1779
translate russian ruta_normal_16_eee229a0:

    # "El doctor se quedó quieto de repente y se mantuvo así unos segundos."
    "Доктор вдруг замирает и стоит так несколько секунд."

# game/script.rpy:1780
translate russian ruta_normal_16_90e890fc:

    # "Entonces, él volvió a moverse."
    "Затем снова двигается."

# game/script.rpy:1781
translate russian ruta_normal_16_1f54312f:

    # "Sólo podías ver desde tu lugar la espalda del doctor."
    "С вашего места видно только его спину."

# game/script.rpy:1783
translate russian ruta_normal_16_760b8586:

    # "Escuchaste el inconfundible sonido de agua siendo servida."
    "Послышался характерный звук льющейся воды."

# game/script.rpy:1784
translate russian ruta_normal_16_705ca6e2:

    # "El simple sonido te dio más sed, lo más probable porque tu garganta adolorida suplicaba ser refrescada."
    "От одного этого звука воспалённое горло пересыхает ещё сильнее, будто умоляя освежиться."

# game/script.rpy:1785
translate russian ruta_normal_16_17956473:

    # "El doctor dio unos pasos y se acercó a ti."
    "Доктор делает несколько шагов, подходя ближе."

# game/script.rpy:1789
translate russian ruta_normal_16_99e255c1:

    # "Intentaste sentarte, pero tu cuerpo pesaba mucho."
    "Вы пытаетесь приподняться, но тело кажется слишком тяжёлым."

# game/script.rpy:1791
translate russian ruta_normal_16_58194281:

    # "Sentiste cómo una mano se posaba en tu espalda y te ayudaba a enderezarte."
    "Рука ложится вам на спину, осторожно помогая сесть."

# game/script.rpy:1792
translate russian ruta_normal_16_3f991d56:

    # "El toque era suave y atento, te hizo consciente de lo vulnerable que estabas."
    "Прикосновение мягкое, почти заботливое — в этот момент вы ясно ощущаете, насколько беспомощны."

# game/script.rpy:1793
translate russian ruta_normal_16_00d58f4a:

    # "Entonces sentiste el borde de un vaso en tus labios."
    "Затем губ касается холодный край стакана."

# game/script.rpy:1795
translate russian ruta_normal_16_86f38f42:

    # "Bebiste agua lentamente, tu garganta ardiendo pero aliviada por la frescura."
    "Вы пьёте медленно; горло жжёт, но прохлада приносит облегчение."

# game/script.rpy:1796
translate russian ruta_normal_16_451d17fb:

    # "No te limitaste a un sorbo."
    "Вы не ограничиваетесь одним глотком."

# game/script.rpy:1797
translate russian ruta_normal_16_1cee69c4:

    # "Al terminar, suspiraste con alivio, mirando de reojo al doctor que te estaba atendiendo."
    "Закончив, вы выдыхаете с явным облегчением и украдкой смотрите на врача, который вас обслуживает."

# game/script.rpy:1798
translate russian ruta_normal_16_ea88bce1:

    # "Su fleco cubría sus rasgos y llevaba una mascarilla desechable."
    "Длинная чёлка закрывает его лицо, он носит одноразовую маску."

# game/script.rpy:1799
translate russian ruta_normal_16_442941ca:

    # "……"
    "......"

# game/script.rpy:1800
translate russian ruta_normal_16_4a801ede:

    # "Bueno, bueno, ¿Dónde habías visto eso antes?"
    "Ну надо же, где это вы видели что-то подобное?"

# game/script.rpy:1804
translate russian ruta_normal_16_68521b19:

    # pov "Muchas gracias, {b}doctor{/b}."
    pov "Большое спасибо, {b}доктор{/b}."

# game/script.rpy:1805
translate russian ruta_normal_16_a46d6012:

    # "Decidiste fingir ignorancia, tal vez eso te da algo de tiempo para que alguien aparezca."
    "Вы решаете притвориться, что ничего не замечаете — возможно, это даст вам немного времени, пока не появится кто-то ещё."

# game/script.rpy:1806
translate russian ruta_normal_16_6caa14af:

    # "Quizás un doctor real o Cindy."
    "Может, настоящий врач или Синди."

# game/script.rpy:1811
translate russian ruta_normal_16_056345bf:

    # pov "¿Cuantos años de medicina te costaron para saber que un paciente inconsciente debe mantenerse hidratado, {b}doc{/b}?"
    pov "И сколько лет медицинской практики понадобилось, чтобы узнать, что пациентов без сознания, вообще-то, тоже надо поить, {b}док{/b}?"

# game/script.rpy:1812
translate russian ruta_normal_16_10dee8a2:

    # "Estabas jugando con fuego, pero la situación era tan bizarra que no podías tomártelo en serio."
    "Вы играете с огнём, но ситуация настолько абсурдная, что серьёзно её воспринимать не выходит."

# game/script.rpy:1820
translate russian ruta_normal_17_02763b64:

    # "El doctor no respondió y volvió a su lugar anterior, a hacer lo que sea que estaba haciendo."
    "Доктор ничего не отвечает и возвращается на прежнее место, снова занимаясь своими делами."

# game/script.rpy:1821
translate russian ruta_normal_17_03da9579:

    # "Tras beber agua, te sentías mejor para hablar."
    "Выпив воды, вам стало полегче, и говорить стало проще."

# game/script.rpy:1822
translate russian ruta_normal_17_71e4f884:

    # "Según las indicaciones del Dr. Salazar, no debías hablar mucho, pero tenías la confianza de que te sentías lo suficientemente bien como para mantener una conversación, aunque sea unilateral."
    "Согласно указаниям доктора Салазара, вам не следует перенапрягать горло; но вы уверены, что достаточно окрепли, чтобы выдержать пусть даже односторонний разговор."

# game/script.rpy:1828
translate russian ruta_normal_17_52290b21:

    # pov "¿Realmente eres doctor?"
    pov "Ты точно врач?"

# game/script.rpy:1829
translate russian ruta_normal_17_1c371e59:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1832
translate russian ruta_normal_17_19f0439d:

    # pov "Si hubiera sabido que atienden tan bien, habría venido más seguido."
    pov "Если бы я знали, что тут так заботятся о пациентах, то приходили бы почаще."

# game/script.rpy:1833
translate russian ruta_normal_17_1c371e59_1:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1838
translate russian ruta_normal_18_ee771de8:

    # "Estaba siendo bastante obvio que este doctor no tenía interés en congeniar contigo."
    "Уже довольно очевидно, что доктор не проявляет к вам интереса."

# game/script.rpy:1839
translate russian ruta_normal_18_723378a4:

    # "No sabías si tomártelo personal o no."
    "Вы не знаете, принимать это на свой счёт или нет."

# game/script.rpy:1840
translate russian ruta_normal_18_0d010e22:

    # "Esperarías que te trataran con cuidado en el hospital. Pero todo apuntaba que no sería así."
    "В конце концов, от больницы ожидается бережное отношение. Но, похоже, рассчитывать на это не приходится."

# game/script.rpy:1844
translate russian ruta_normal_18_8ac3bb47:

    # pov "Ah, ya veo."
    pov "А, понятно."

# game/script.rpy:1845
translate russian ruta_normal_18_348b6cd7:

    # pov "No me presenté primero."
    pov "Я ведь даже не представились."

# game/script.rpy:1846
translate russian ruta_normal_18_cc32c858:

    # pov "Soy [povname], ¿con quién tengo el gusto?"
    pov "Я [povname], с кем имею честь познакомиться?"

# game/script.rpy:1847
translate russian ruta_normal_18_1c371e59:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1852
translate russian ruta_normal_18_d61d14f0:

    # pov "Hey, si no tienes ánimos de congeniar con gente, creo que deberías reevaluar tu carrera."
    pov "Эй, если тебе тяжело общаться с людьми, может, стоит пересмотреть выбор профессии?"

# game/script.rpy:1853
translate russian ruta_normal_18_1c371e59_1:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1854
translate russian ruta_normal_18_e5b58650:

    # pov "¿Me escuchaste?"
    pov "Ты меня слышишь?"

# game/script.rpy:1859
translate russian ruta_normal_19_3242deab:

    # "El doctor siguió guardando silencio."
    "Доктор по-прежнему молчит."

# game/script.rpy:1860
translate russian ruta_normal_19_151fc69a:

    # "Te estaba empezando a molestar."
    "Это начинает раздражать."

# game/script.rpy:1861
translate russian ruta_normal_19_c196e39a:

    # "Un intento más, tal vez podrías sacarle unas palabras si insistías por última vez."
    "Ещё одна попытка — может, если надавить, он хоть слово вымолвит."

# game/script.rpy:1867
translate russian ruta_normal_19_80580610:

    # pov "Sabes, alguien me atacó."
    pov "Знаешь, на меня напали."

# game/script.rpy:1868
translate russian ruta_normal_19_9d7adffa:

    # "El doctor se quedó inmóvil en su lugar."
    "Доктор всё так же не двигается."

# game/script.rpy:1869
translate russian ruta_normal_19_7928f4b4:

    # pov "Fue alguien con el que hablé en mi trabajo."
    pov "Это был парень, с которым я разговаривали на работе."

# game/script.rpy:1870
translate russian ruta_normal_19_55c975ad:

    # pov "Creo que no le gusté, haha."
    pov "Похоже, я ему не понравились, ха-ха."

# game/script.rpy:1871
translate russian ruta_normal_19_fc8f6b35:

    # Stranger "Oh, yo no diría eso."
    Stranger "О, я бы так не сказал."

# game/script.rpy:1872
translate russian ruta_normal_19_2961b1ed:

    # "El “doctor” murmuró de repente, su voz demasiado familiar."
    "«Доктор» вдруг говорит до жути знакомым голосом."

# game/script.rpy:1875
translate russian ruta_normal_19_6e8ac612:

    # pov "Ya conozco al Dr. Salazar, ¿eres su estudiante, quizás su colega?"
    pov "Я уже знакомы с доктором Салазаром. Ты его студент? Или, может, коллега?"

# game/script.rpy:1876
translate russian ruta_normal_19_1c371e59:

    # Stranger "…"
    Stranger "..."

# game/script.rpy:1877
translate russian ruta_normal_19_e6c602c5:

    # Stranger "Oh, soy algo mucho mejor que eso."
    Stranger "О, я кое-что получше."

# game/script.rpy:1891
translate russian ruta_mala_2_43f7d0f2:

    # "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    "Доктор снова подходит ближе, стягивая одноразовую маску к подбородку."

# game/script.rpy:1895
translate russian ruta_mala_2_18c89918:

    # J "Hola, [povname]."
    J "Привет, [povname]."

# game/script.rpy:1896
translate russian ruta_mala_2_cbed57d9:

    # J "¿Disfrutando tu estancia en el hospital?"
    J "Нравится отдых в больнице?"

# game/script.rpy:1897
translate russian ruta_mala_2_4de26740:

    # J "Qué pena… no soy fan de este lugar."
    J "Жаль... я не фанат этого места."

# game/script.rpy:1898
translate russian ruta_mala_2_8297fb91:

    # J "¡Pero parece que tú lo eres!"
    J "Но тебе, похоже, тут нравится!"

# game/script.rpy:1901
translate russian ruta_mala_2_83d828e7:

    # "No tuviste tiempo para hablar cuando Jeff sacó un bisturí."
    "Вы не успеваете ничего сказать — Джефф уже достаёт из кармана скальпель."

# game/script.rpy:1902
translate russian ruta_mala_2_076da34d:

    # pov "Espera, Jeff, escúchame…"
    pov "Подожди, Джефф, послушай..."

# game/script.rpy:1903
translate russian ruta_mala_2_d22ca4c3:

    # J "No, no, no hay nada que decir."
    J "Нет-нет, говорить уже не о чем."

# game/script.rpy:1904
translate russian ruta_mala_2_fd26ada5:

    # J "Prefieres a los doctores, no tienes que dar más explicaciones."
    J "Ты ведь предпочитаешь врачей, правда? Можешь ничего не объяснять."

# game/script.rpy:1907
translate russian ruta_mala_2_0cfd5351:

    # "Jeff impulsó su brazo hacia ti, perforando tu garganta con la punta del bisturí."
    "Джефф резким движением вскидывает руку, пронзая ваше горло остриём скальпеля."

# game/script.rpy:1908
translate russian ruta_mala_2_13db7fc3:

    # "Te ahogaste con tu sangre, gorgojeaste sin poder gritar ni hablar."
    "Вы давитесь собственной кровью, хрипя, не в силах кричать или говорить."

# game/script.rpy:1909
translate russian ruta_mala_2_c7252d4f:

    # J "No soy tan bueno como un cirujano…"
    J "Я, конечно, не хирург..."

# game/script.rpy:1910
translate russian ruta_mala_2_2f58ccb2:

    # "Jeff susurró contra tu oído, tu inhalas con dificultad, tosiendo sangre."
    "Он шепчет у вашего уха, пока вы с трудом хватаете воздух, захлёбываясь и кашляя кровью."

# game/script.rpy:1911
translate russian ruta_mala_2_0d7bf9b4:

    # J "¡Pero pasión no me falta!"
    J "Но страсти мне не занимать!"

# game/script.rpy:1913
translate russian ruta_mala_2_6064511a:

    # "La hoja del bisturí bajó desde tu cuello hasta tu clavícula, abriendo tu piel como un cierre, la hoja tan hundida en ti que sentías el choque del metal contra tus huesos."
    "Лезвие скальпеля скользит от шеи к ключице, вскрывая кожу, словно молнию — оно входит так глубоко, что вы чувствуете, как металл врезается в кости."

# game/script.rpy:1914
translate russian ruta_mala_2_abcbc7c9:

    # "Él rió con entusiasmo, divertido con la vista de ti estremeciéndote del dolor mientras la sangre brotaba de tu cuello y se derramaba hacia los lados, empapando la ropa de hospital y las sábanas debajo de ti."
    "Джефф смеётся, искренне увлечённый зрелищем: вы корчитесь в муках, кровь льётся из раны и растекается по бокам, пропитывая больничную рубашку и простыни под вами."

# game/script.rpy:1915
translate russian ruta_mala_2_e6dfb6f4:

    # "Dolía, pero por alguna razón no tanto."
    "Вам больно, но почему-то не так сильно."

# game/script.rpy:1916
translate russian ruta_mala_2_90f71bf7:

    # "Sentías un cosquilleo en el lugar de tus heridas, lo más probable es que estabas con analgésicos."
    "В местах порезов ощущается лишь лёгкое покалывание — видимо, обезболивающее всё ещё действует."

# game/script.rpy:1918
translate russian ruta_mala_2_96f9e185:

    # "Menos mal."
    "И слава богу."

# game/script.rpy:1919
translate russian ruta_mala_2_c2172e1f:

    # "Claro, que te hayan degollado con un bisturí no es la manera con la que hubieras preferido morir."
    "Конечно, быть зарезанным скальпелем — не та смерть, которую вы бы предпочли."

# game/script.rpy:1920
translate russian ruta_mala_2_dd16970a:

    # "Pero ciertamente, el hecho de no experimentar el dolor verdadero lo hacía mejor."
    "Но всё же отсутствие настоящей боли делает её терпимой."

# game/script.rpy:1921
translate russian ruta_mala_2_1729c08a:

    # "Tal vez consigan atrapar a Jeff una vez que alguien aparezca, por la forma en que seguía a tu lado, riéndose como el loco que es."
    "Может, Джеффа всё-таки поймают, когда кто-нибудь зайдёт в палату, ведь он всё ещё стоит рядом и смеётся, как сумасшедший."

# game/script.rpy:1922
translate russian ruta_mala_2_89550e4a:

    # "Al final, ¿Te mató porque fuiste amable con los doctores?"
    "В конце концов, он убил вас потому, что вы были слишком вежливы с врачами?"

# game/script.rpy:1923
translate russian ruta_mala_2_a8bacfac:

    # "No será que él… ¿Estaba celoso?"
    "Он что... ревновал?"

# game/script.rpy:1924
translate russian ruta_mala_2_6b73473a:

    # "Nah, no puede ser eso."
    "Нет, не может быть."

# game/script.rpy:1925
translate russian ruta_mala_2_54f9ea25:

    # "Tal vez simplemente odiaba los hospitales, como él había dicho."
    "Скорее всего, он и правда просто ненавидит больницы, как и говорил."

# game/script.rpy:1928
translate russian ruta_mala_2_c3f3b31b:

    # "{b}Final II: Ningún Doctor Pudo Salvarte{/b}"
    "{b}Концовка II: Ни один доктор не смог вас спасти{/b}"

# game/script.rpy:1935
translate russian historia_continua_2_43f7d0f2:

    # "El doctor volvió a tu lado, bajando la mascarilla desechable hasta su barbilla."
    "Доктор снова подходит ближе, стягивая одноразовую маску к подбородку."

# game/script.rpy:1940
translate russian historia_continua_2_76a20fbe:

    # pov "Jeff, qué sorpresa, no sabía que eras tú."
    pov "Джефф, какая неожиданность. Я и не знали, что это ты."

# game/script.rpy:1941
translate russian historia_continua_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:1942
translate russian historia_continua_2_8baa59f0:

    # J "No aprecio tu sarcasmo."
    J "Мне не нравится твой сарказм."

# game/script.rpy:1944
translate russian historia_continua_2_ef1b1843:

    # "Tu corazón latía con fuerza, respuesta a la cercanía de la persona que te arrancó el ojo izquierdo."
    "Сердце бешено колотится — естественная реакция на близость человека, который вырвал вам левый глаз."

# game/script.rpy:1945
translate russian historia_continua_2_a4788ae9:

    # "Tu cuerpo tenía miedo, pero tu mente no."
    "Всё ваше тело боится, но разум — нет."

# game/script.rpy:1946
translate russian historia_continua_2_90f059c1:

    # pov "Así que… ¿Viniste a darme cuidados especiales?"
    pov "Так что... пришёл оказать мне особый уход?"

# game/script.rpy:1947
translate russian historia_continua_2_e5b916b8:

    # "Jeff rió entre dientes, sacando una jeringa de su bolsillo."
    "Джефф усмехается, вытаскивая из кармана шприц."

# game/script.rpy:1948
translate russian historia_continua_2_09d1773a:

    # J "Algo así."
    J "Вроде того."

# game/script.rpy:1949
translate russian historia_continua_2_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Погоди, что ты делаешь?"

# game/script.rpy:1950
translate russian historia_continua_2_3653c69f:

    # "Él llevó la jeringa a tu intravenosa y la inyectó en la manguera."
    "Он подносит шприц к вашей капельнице и вводит содержимое в трубку."

# game/script.rpy:1951
translate russian historia_continua_2_f8eb4f5d:

    # J "Relájate, no te matará."
    J "Расслабься, это тебя не убьёт."

# game/script.rpy:1952
translate russian historia_continua_2_22f84aa2:

    # J "Te hará sentir… algo de agitación."
    J "Просто... немного взбодрит."

# game/script.rpy:1954
translate russian historia_continua_2_ba488d1d:

    # "En el momento en que él dijo eso, sentiste que tu corazón empezó a latir más rápido."
    "Стоило ему это сказать, как сердце начинает биться чаще."

# game/script.rpy:1955
translate russian historia_continua_2_38cf03a1:

    # "Empezaste a respirar aceleradamente, como si hubieras corrido una maratón."
    "Вы начинаете дышать быстро и прерывисто, будто только что пробежали марафон."

# game/script.rpy:1956
translate russian historia_continua_2_5443d4f7:

    # "Por reflejo, te llevaste una mano al pecho, apretando la tela de la bata de hospital."
    "Вы рефлекторно прижимаете руку к груди, сжимая ткань больничной рубашки."

# game/script.rpy:1957
translate russian historia_continua_2_623161fd:

    # pov "Tu…ah…. desgraciado…"
    pov "Ты... ах... ублюдок..."

# game/script.rpy:1958
translate russian historia_continua_2_3a9aebcd:

    # "Jeff chasqueó la lengua, negando con la cabeza"
    "Джефф цокает языком и качает головой."

# game/script.rpy:1959
translate russian historia_continua_2_24df739b:

    # J "Ten algo de respeto por tu doctor."
    J "Прояви хоть немного уважения к своему доктору."

# game/script.rpy:1960
translate russian historia_continua_2_959fcb31:

    # "Jeff dirigió su mano hacia ti y sujetó entre sus dedos tu barbilla, alzando tu cabeza para verlo."
    "Джефф протягивает руку и берёт вас за подбородок, заставляя поднять взгляд."

# game/script.rpy:1961
translate russian historia_continua_2_9d2eee6b:

    # "Sintiéndote débil y con cansancio, te dejaste ser, sin fuerzas para gritar por auxilio ni para soltarte de su agarre."
    "Вы ощущаете слабость и безволие — не хватает сил ни крикнуть, ни вырваться из его рук."

# game/script.rpy:1962
translate russian historia_continua_2_0640d5ea:

    # J "Recuerda, estamos jugando."
    J "Не забывай о нашей игре."

# game/script.rpy:1963
translate russian historia_continua_2_9529c18c:

    # pov "Estoy…. en el hospital…. ¿Cómo…. esperas que…. huya de ti?"
    pov "Я... в больнице... Как... я вообще должны... сбежать?"

# game/script.rpy:1964
translate russian historia_continua_2_8cff178e:

    # pov "Eres… un tramposo…"
    pov "Ты... обманщик..."

# game/script.rpy:1965
translate russian historia_continua_2_bbf84d79:

    # "Jadeaste con frustración, ya que no tenías energías ni para hablar bien."
    "Вы тяжело, с досадой выдыхаете — сил не хватает даже на то, чтобы говорить."

# game/script.rpy:1966
translate russian historia_continua_2_f0ede4b8:

    # J "Tómalo como una advertencia."
    J "Считай это предупреждением."

# game/script.rpy:1967
translate russian historia_continua_2_254db073:

    # "Jeff se encogió de hombros despreocupado."
    "Джефф беззаботно пожимает плечами."

# game/script.rpy:1969
translate russian historia_continua_2_75c08509:

    # "De repente, una alarma empezó a sonar, y el ruido de pasos rápidos llegaron de afuera de la habitación."
    "Вдруг раздаётся тревога, и из-за пределов комнаты доносится шум торопливых шагов."

# game/script.rpy:1970
translate russian historia_continua_2_3be0642a:

    # J "Esa es mi señal."
    J "Пора уходить."

# game/script.rpy:1971
translate russian historia_continua_2_e8eaf987:

    # "Jeff se colocó la mascarilla nuevamente y se puso de pie."
    "Джефф снова надевает маску и выпрямляется."

# game/script.rpy:1973
translate russian historia_continua_2_0a2cc06f:

    # J "Espero que mejores tu estrategia, sería una lástima que termines aburriendome."
    J "Надеюсь, ты улучшишь свою стратегию. Заскучать из-за тебя было бы обидно."

# game/script.rpy:1974
translate russian historia_continua_2_a02492aa:

    # "Dijo Jeff, antes de desaparecer entre la pequeña multitud de enfermeras y doctores que entraron y se dirigieron hacia ti."
    "Сказал Джефф и бесследно растворился в толпе медсестёр и врачей, ворвавшихся в палату и бросившихся к вам."

# game/script.rpy:1975
translate russian historia_continua_2_33985c4a:

    # DR "¡Tenemos una hiperpotasemia grave!"
    DR "У нас тяжёлая гиперкалиемия!"

# game/script.rpy:1976
translate russian historia_continua_2_11df6b07:

    # DR "Administra gluconato de calcio intravenoso, 10 ml al 10 por ciento en bolo lento. ¡Ahora!"
    DR "Ввести глюконат кальция внутривенно, 10 мл 10-процентного раствора болюсом. Сейчас же!"

# game/script.rpy:1977
translate russian historia_continua_2_644fe612:

    # "Entre instrucciones y palabras de lenguaje médico que no entendías del todo, miraste con recelo a Jeff, que se retiró como si nada, oculto a plena vista."
    "Сквозь поток медицинских терминов, которых вы не понимаете, вы успеваете заметить, как Джефф спокойно выходит из палаты, будто ничего не случилось, сливаясь с остальными врачами."

# game/script.rpy:1978
translate russian historia_continua_2_c0e01897:

    # "¿De verdad fue tan fácil para él infiltrarse?"
    "Неужели ему и правда удалось так легко проникнуть сюда?"

# game/script.rpy:1979
translate russian historia_continua_2_32034f33:

    # "O Jeff tenía una habilidad sobrehumana para pasar desapercibido, o la gente de este hospital era inepta."
    "Либо Джефф обладает какой-то сверхъестественной способностью оставаться незамеченным, либо персонал этой больницы просто безнадёжен."

# game/script.rpy:1980
translate russian historia_continua_2_29769bdd:

    # "Querías creer que fuera la primera opción."
    "Хочется верить в первый вариант."

# game/script.rpy:1982
translate russian historia_continua_2_60d6d30f:

    # "De todas formas, pudieron tratarte con rapidez, por lo que te sentías considerablemente mejor."
    "Так или иначе, лечение подействовало быстро, и вскоре вам стало значительно лучше."

# game/script.rpy:1985
translate russian historia_continua_2_74a1375b:

    # DR "Si notas la función renal comprometida, pide diálisis urgente."
    DR "Если заметите признаки почечной недостаточности — назначайте неотложный диализ."

# game/script.rpy:1986
translate russian historia_continua_2_dc097126:

    # "El Dr. Salazar le estaba dando unas instrucciones a otro doctor, uno que ahora tenías la seguridad de que se trataba de un residente."
    "Доктор Салазар даёт указания другому врачу — теперь вы уже точно знаете, что это ординатор."

# game/script.rpy:1987
translate russian historia_continua_2_aaec7888:

    # "El residente asintió ante las órdenes del Dr. Salazar y se retiró, dejándolos solos a ustedes dos."
    "Ординатор кивает и выходит, оставляя вас наедине."

# game/script.rpy:1989
translate russian historia_continua_2_a4b927c7:

    # "El Dr. Salazar se masajeó las sienes y se dirigió a tu camilla."
    "Доктор Салазар устало потирает виски и подходит к изголовью вашей койки."

# game/script.rpy:1990
translate russian historia_continua_2_a4b5fdd4:

    # "Su mirada reflejaba preocupación, por lo que no pudiste evitar desviar la mirada con culpabilidad."
    "В его взгляде читается искренняя тревога, от чего вы смущённо отводите взгляд."

# game/script.rpy:1991
translate russian historia_continua_2_c0f409e7:

    # DR "[povname], sufriste una hiperpotasemia severa, ¿Tienes alguna idea de lo que lo pudo haber provocado?"
    DR "[povname], у тебя была тяжёлая гиперкалиемия. Можешь предположить, что могло её вызвать?"

# game/script.rpy:1992
translate russian historia_continua_2_38b0402f:

    # "Te mordiste el labio inferior ante la pregunta."
    "Вы прикусываете нижнюю губу, слыша этот вопрос."

# game/script.rpy:1993
translate russian historia_continua_2_0b96ee01:

    # "Estabas teniendo un momento difícil, tratando de convencerte de confiar todo el tema de Jeff con alguien más."
    "Тяжело решиться: рассказать кому-нибудь правду о Джеффе или опять промолчать."

# game/script.rpy:1998
translate russian historia_continua_2_5f453a5d:

    # "Pero las acciones rápidas y el cuidado atento que él te dirigía te convenció de que era digno de confianza."
    "Но его быстрая реакция и внимательность убеждают вас, что ему можно доверять."

# game/script.rpy:1999
translate russian historia_continua_2_38c28b60:

    # pov "La verdad es que… Mi atacante vino."
    pov "На самом деле... мой нападавший приходил сюда."

# game/script.rpy:2000
translate russian historia_continua_2_97c9bb38:

    # pov "Él… me hizo algo, le puso algo a mi intravenosa."
    pov "Он... сделал что-то со мной, ввёл что-то в капельницу."

# game/script.rpy:2001
translate russian historia_continua_2_4e1edf9d:

    # "El Dr. Salazar abrió los ojos con sorpresa, para después bajar la mirada con lástima."
    "Глаза доктора Салазара округляются от удивления, а затем он с сожалением опускает взгляд."

# game/script.rpy:2003
translate russian historia_continua_2_5a89d0fd:

    # DR "Lo siento tanto, [povname], este se supone que debería ser un lugar seguro, y te falló."
    DR "Мне так жаль, [povname]. Больница должна быть безопасным местом, но мы тебя подвели."

# game/script.rpy:2004
translate russian historia_continua_2_f4ecc088:

    # DR "Yo te fallé."
    DR "Я тебя подвёл."

# game/script.rpy:2006
translate russian historia_continua_2_c16b3ac5:

    # "Tomaste la mano del doctor con la tuya, y trataste de sonreír reconfortante."
    "Вы берёте доктора за руку и пытаетесь ободряюще улыбнуться."

# game/script.rpy:2007
translate russian historia_continua_2_7f9c7eea:

    # pov "No es tu culpa, sé que haces lo mejor que puedes."
    pov "Это не твоя вина. Я знаю, что ты делаешь всё, что в твоих силах."

# game/script.rpy:2008
translate russian historia_continua_2_0e7d22cf:

    # "El Dr. Salazar miró en silencio sus manos entrelazadas, y acarició tu dorso con su pulgar."
    "Доктор Салазар молча смотрит на ваши переплетённые руки и мягко проводит большим пальцем по тыльной стороне вашей ладони."

# game/script.rpy:2009
translate russian historia_continua_2_f67a73f0:

    # "No evitaste sentir tus mejillas encenderse ligeramente."
    "Вы не можете не почувствовать, как щёки запылали."

# game/script.rpy:2010
translate russian historia_continua_2_375e0520:

    # DR "No es una idea muy convencional… pero puedo sacarte de aquí, ir a un lugar seguro."
    DR "Это не самая обыденная идея... но я могу забрать тебя отсюда, в более безопасное место."

# game/script.rpy:2011
translate russian historia_continua_2_a7b564e9:

    # "Eso… no sonaba muy profesional."
    "Это... прозвучало не слишком профессионально."

# game/script.rpy:2012
translate russian historia_continua_2_af7963b3:

    # "Era casi como si no se estuviera comportando seriamente como un doctor, más bien parecía… estar engatusado."
    "Он как будто ведёт себя не как врач, а просто... пытается вас очаровать."

# game/script.rpy:2013
translate russian historia_continua_2_6c7e8ade:

    # "Pero ya no confiabas en el hospital."
    "Но вы всё равно больше не доверяете больнице."

# game/script.rpy:2014
translate russian historia_continua_2_271f6a65:

    # "Cualquier otra cosa sonaba mejor para ti."
    "Что угодно звучит лучше, чем оставаться здесь."

# game/script.rpy:2015
translate russian historia_continua_2_f978a387:

    # pov "Hagámoslo."
    pov "Хорошо."

# game/script.rpy:2017
translate russian historia_continua_2_27927256:

    # "El Dr. Salazar hizo un rápido papeleo en el que te dio de alta, te entregó tu ropa y te transportó en silla de ruedas por los pasillos del hospital."
    "Доктор Салазар быстро оформляет бумаги на выписку, передаёт вам вашу одежду и везёт через коридоры больницы на кресле-каталке."

# game/script.rpy:2018
translate russian historia_continua_2_a706b908:

    # pov "¿A dónde vamos?"
    pov "Куда мы?"

# game/script.rpy:2021
translate russian historia_continua_2_ae66f7db:

    # DR "A mi casa."
    DR "Ко мне домой."

# game/script.rpy:2022
translate russian historia_continua_2_a0851940:

    # pov "Wow, invítame a cenar primero."
    pov "Воу, может, сначала пригласишь на ужин?"

# game/script.rpy:2024
translate russian historia_continua_2_fe272588:

    # "El Dr. Salazar rió entre dientes detrás de ti, empujando la silla de ruedas."
    "Доктор Салазар тихо смеётся у вас за спиной, продолжая толкать коляску."

# game/script.rpy:2025
translate russian historia_continua_2_36a33978:

    # DR "Te realicé cirugía, ya nos saltamos unos cuantos pasos."
    DR "Я уже провёл на тебе операцию, так что несколько этапов мы прошли."

# game/script.rpy:2026
translate russian historia_continua_2_84b058f8:

    # "Al menos podían tomarse las cosas con humor."
    "По крайней мере, вы всё ещё можете позволить себе немного юмора."

# game/script.rpy:2028
translate russian historia_continua_2_1f97f75f:

    # "Ustedes llegaron al ascensor. El Dr. Salazar te entró primero, dejándote de espaldas a las puertas."
    "Вы подходите к лифту. Доктор Салазар пропускает вас вперёд, так что вы оказываетесь спиной к закрывающимся дверям."

# game/script.rpy:2029
translate russian historia_continua_2_5d0ecdbd:

    # pov "¿Viste a Cindy?"
    pov "Ты видел Синди?"

# game/script.rpy:2032
translate russian historia_continua_2_0cc5c2c7:

    # DR "Si, linda chica, aunque un poco…"
    DR "Да, хорошая девушка, хотя и немного..."

# game/script.rpy:2033
translate russian historia_continua_2_112f6505:

    # pov "¿Criticona?"
    pov "Придирчивая?"

# game/script.rpy:2034
translate russian historia_continua_2_9dc8e642:

    # DR "… Son tus palabras, no las mías."
    DR "...Это твои слова, не мои."

# game/script.rpy:2038
translate russian historia_continua_2_b7638da9:

    # "Ustedes quedan en silencio cuando escucharon las puertas del ascensor abrirse."
    "Вы замолкаете, когда слышите, как открываются двери лифта."

# game/script.rpy:2039
translate russian historia_continua_2_15592602:

    # "Esperaste en silencio para que alguien subiera y apretara un botón, pero en cambio escuchaste un sonido ahogado y un forcejeo detrás de ti."
    "Вы молча ждёте, пока кто-то войдёт и нажмёт кнопку, но вместо этого где-то позади слышится приглушённый звук."

# game/script.rpy:2041
translate russian historia_continua_2_00dd73c3:

    # "Miraste el espejo frente a ti, y te sorprendiste al ver que el Dr. Salazar ya no estaba detrás de ti."
    "Вы смотрите на зеркало перед собой — к вашему удивлению, доктора Салазара за спиной больше нет."

# game/script.rpy:2042
translate russian historia_continua_2_cb9eafa9:

    # "Las puertas del ascensor estaban abiertas, dejando ver a un pasillo del hospital que estaba a oscuras."
    "Двери лифта всё ещё открыты, за ними тянется тёмный больничный коридор."

# game/script.rpy:2043
translate russian historia_continua_2_8510a904:

    # pov "¿Doctor?"
    pov "Доктор?"

# game/script.rpy:2044
translate russian historia_continua_2_54f6bf63:

    # "Llamaste, en un intento de recibir respuesta, pero no nada."
    "Зовёте вы, надеясь услышать ответ, но его не последовало."

# game/script.rpy:2045
translate russian historia_continua_2_57b6e6be:

    # J "Qué pena…"
    J "Какая жалость..."

# game/script.rpy:2046
translate russian historia_continua_2_3f2d45e5:

    # "Esa voz te hizo estremecer."
    "Этот голос заставляет вас вздрогнуть."

# game/script.rpy:2047
translate russian historia_continua_2_2ef3a9d3:

    # pov "¿Jeff…?"
    pov "Джефф..?"

# game/script.rpy:2048
translate russian historia_continua_2_11bf8424:

    # J "¿Quién hace trampa ahora?"
    J "И кто теперь играет нечестно?"

# game/script.rpy:2053
translate russian historia_continua_2_bfe2ca31:

    # "Tras la burla, Jeff da un paso adelante, dejándose ver en el umbral del ascensor."
    "После издёвки Джефф делает шаг вперёд, появляясь в проёме лифта."

# game/script.rpy:2054
translate russian historia_continua_2_a2a0d5dc:

    # pov "Yo…"
    pov "Я..."

# game/script.rpy:2055
translate russian historia_continua_2_f717968c:

    # J "Nuestro juego es entre tu y yo, nadie más."
    J "Наша игра ведь только между нами, без лишних участников."

# game/script.rpy:2056
translate russian historia_continua_2_2219bf95:

    # J "Pero ya no importa, el juego terminó."
    J "Но уже неважно, игра окончена."

# game/script.rpy:2059
translate russian historia_continua_2_2756808d:

    # "Jeff se adentra en el ascensor, mirándote desde el espejo."
    "Джефф входит в лифт, глядя на вас через зеркало."

# game/script.rpy:2060
translate russian historia_continua_2_129d3574:

    # "Su tono era burlesco, pero sus ojos estaban inyectados en sangre."
    "В голосе звучит насмешка, но глаза его налиты кровью."

# game/script.rpy:2061
translate russian historia_continua_2_377afe9d:

    # "Con lentitud, él sacó su cuchillo y lo dirigió con la misma lentitud hacia tu estómago."
    "Он медленно вынимает нож и с той же неторопливостью направляет его вам в живот."

# game/script.rpy:2062
translate russian historia_continua_2_85cddaf7:

    # "Jadeaste ante la expectación."
    "Вы судорожно вдыхаете от напряжения."

# game/script.rpy:2063
translate russian historia_continua_2_85557e85:

    # "Sabías lo que venía, sin embargo la ansiedad te abrumaba."
    "Вы знаете, что будет дальше, и всё же тревога подавляет всё остальное."

# game/script.rpy:2065
translate russian historia_continua_2_974b5030:

    # "De la misma manera lenta y calma, Jeff enterró la hoja del cuchillo en tu estómago, atravesando tu ropa hasta tu interior."
    "Так же спокойно и хладнокровно Джефф вонзает лезвие в ваш живот, прорывая одежду и погружая сталь в плоть."

# game/script.rpy:2066
translate russian historia_continua_2_2970ff53:

    # "Te doblaste del dolor, pero Jeff te forzó a enderezarte tras rodear tu cuello con su brazo."
    "Вы сгибаетесь от боли, но Джефф обвивает вас рукой за шею и заставляет выпрямиться."

# game/script.rpy:2067
translate russian historia_continua_2_571cc53e:

    # "Sentiste su respiración a través de la mascarilla contra tu oreja."
    "Вы чувствуете его дыхание у своего уха сквозь маску."

# game/script.rpy:2068
translate russian historia_continua_2_e9ec0ba7:

    # "Apretaste los dientes con fuerza, hasta el punto de lastimar tu boca."
    "Зубы сжимаются так сильно, что боль отзывается во рту."

# game/script.rpy:2069
translate russian historia_continua_2_edabb818:

    # J "Ssh… Ve a dormir…"
    J "Ш-ш... Иди спать..."

# game/script.rpy:2070
translate russian historia_continua_2_0d77114a:

    # "Él susurró, enterrando más la hoja en tu interior."
    "Шепчет он, вгоняя нож ещё глубже."

# game/script.rpy:2072
translate russian historia_continua_2_713c8252:

    # "Era tanto el dolor, que no podías gritar."
    "Боль настолько сильная, что крик застревает где-то внутри."

# game/script.rpy:2073
translate russian historia_continua_2_46cd4c40:

    # "Pero el trato de él, sujetándote con un abrazo mientras te consolaba con susurros te daba la impresión de que estaba tomando cierta consideración."
    "И всё же в том, как он вас держит — будто обнимая, успокаивающе шепча, — сквозит ложное, извращённое подобие заботы."

# game/script.rpy:2074
translate russian historia_continua_2_0c9ebdc7:

    # "Pudo haber sido mucho más cruel, tal vez estaba siendo un poco considerado porque fuiste un breve acompañante de juegos."
    "Он мог поступить куда более жестоко. Возможно, он проявлял некоторую учтивость только потому, что вы были его кратковременным спутником в игре."

# game/script.rpy:2077
translate russian historia_continua_2_ab8846e6:

    # "{b}Final III: No Seguiste El Juego{/b}"
    "{b}Концовка III: Вы не стали играть по правилам{/b}"

# game/script.rpy:2085
translate russian supervivencia_7_e83b19bb:

    # "Decidiste que era mejor lidiar con eso por tu propia cuenta."
    "Вы решаете, что с этим лучше разобраться в одиночку."

# game/script.rpy:2086
translate russian supervivencia_7_8e8df0a9:

    # "Que Jeff tuviese la facilidad de entrar a un hospital e inyectarte algo bajo vigilancia te decía que la protección en ese lugar no era segura."
    "Тот факт, что Джеффу удалость попасть в больницу и ввести вам что-то под наблюдением, ясно показывает: здесь безопасности можно не ждать."

# game/script.rpy:2087
translate russian supervivencia_7_191097d6:

    # pov "No lo sé, estuve inconsciente todo el tiempo."
    pov "Я не знаю, я были без сознания всё это время."

# game/script.rpy:2088
translate russian supervivencia_7_03d0f93c:

    # "El Dr. Salazar se inclinó a ti, apoyando una mano a un costado de tu cabeza."
    "Доктор Салазар наклоняется ближе, опираясь ладонью о край подушки."

# game/script.rpy:2089
translate russian supervivencia_7_6eb1e1ad:

    # DR "Lo que sea que haya pasado, puedes confiar en mí."
    DR "Что бы ни случилось — ты можешь мне доверять."

# game/script.rpy:2090
translate russian supervivencia_7_f31580f0:

    # "….."
    "..."

# game/script.rpy:2091
translate russian supervivencia_7_9f789813:

    # "Si…"
    "Ага..."

# game/script.rpy:2092
translate russian supervivencia_7_bcf6dd4d:

    # "No."
    "Нет уж."

# game/script.rpy:2093
translate russian supervivencia_7_a7cbfb4e:

    # "Te las has arreglado para sobrevivir hasta ahora, puedes seguir haciéndolo sin ayuda de nadie."
    "Вы и раньше как-то выживали — значит, сможете продолжать без чьей-либо помощи."

# game/script.rpy:2094
translate russian supervivencia_7_450e9843:

    # "Llámalo presentimiento, pero algo te decía que Jeff no te atacaría por el momento, así que tenías tiempo para formar un plan."
    "Можно назвать это интуицией, но что-то подсказывает: Джефф пока не нападёт. У вас есть время продумать план."

# game/script.rpy:2095
translate russian supervivencia_7_4679d11e:

    # "Jeff no te hizo tanto daño como antes, así que lo más seguro es que hablaba en serio cuando decía que era una advertencia."
    "В этот раз Джефф причинил меньше вреда, чем до этого; так что, похоже, он не врал, говоря, что это было предупреждением."

# game/script.rpy:2096
translate russian supervivencia_7_ef145e81:

    # "Una advertencia de que podía hacerte algo peor, y depende de ti evitarlo."
    "Предупреждением о том, что он способен на худшее — и только от вас зависит, сможет ли он это сделать."

# game/script.rpy:2097
translate russian supervivencia_7_3a8c3acc:

    # "Así que no, no tenías por qué confiar en un doctor que acabas de conocer."
    "Так что нет, не стоит слепо доверять врачу, которого вы едва знаете."

# game/script.rpy:2098
translate russian supervivencia_7_9fcd9310:

    # pov "Doctor, digo la verdad."
    pov "Доктор, я говорю правду."

# game/script.rpy:2100
translate russian supervivencia_7_bec541bf:

    # "El Dr. Salazar te miró unos segundos, no convencido, para después suspirar y tomar distancia."
    "Доктор Салазар несколько секунд всматривается в вас, не особо убеждённый, но потом вздыхает и отстраняется."

# game/script.rpy:2101
translate russian supervivencia_7_dd3f172a:

    # DR "De acuerdo… trata de descansar."
    DR "Хорошо... постарайся отдохнуть."

# game/script.rpy:2102
translate russian supervivencia_7_903b9054:

    # "Asentiste en silencio, pero a diferencia de antes, el doctor llamó a alguien de afuera de la habitación."
    "Вы молча киваете, но на этот раз доктор зовёт кого-то из коридора."

# game/script.rpy:2103
translate russian supervivencia_7_c35fdf56:

    # "Con rapidez, llegó una enfermera."
    "Почти сразу в палату входит медсестра."

# game/script.rpy:2104
translate russian supervivencia_7_685b025e:

    # DR "Estate alerta del monitor. Ante cualquier alteración, da aviso."
    DR "Следи за монитором. При любых изменениях — сообщай."

# game/script.rpy:2105
translate russian supervivencia_7_129c912f:

    # "La enfermera asintió ante la instrucción y se quedó en la habitación, cerca del monitor cardiaco que tenías conectado."
    "Медсестра кивает и остаётся в помещении, располагаясь у кардиомонитора, к которому вы подключены."

# game/script.rpy:2106
translate russian supervivencia_7_394189ee:

    # "Claramente, el Dr. Salazar no confiaba en dejarte a solas."
    "Очевидно, доктор Салазар не доверяет вам настолько, чтобы оставить наедине."

# game/script.rpy:2107
translate russian supervivencia_7_ff03ad2d:

    # DR "Vendré periódicamente."
    DR "Я буду заглядывать периодически."

# game/script.rpy:2110
translate russian supervivencia_7_6e6aad82:

    # "No sabías si se lo dijo a la enfermera o a ti, pero de todas formas asentiste y te recostaste en la camilla con un suspiro de cansancio."
    "Вы не понимаете, обращается ли он к вам или к медсестре, но всё равно киваете и ложитесь обратно на койку, устало выдыхая."

# game/script.rpy:2111
translate russian supervivencia_7_7587c487:

    # "Sobrevivir a un sádico asesino era exhausto."
    "Выживать после встречи с садистом-маньяком выматывает."

# game/script.rpy:2113
translate russian supervivencia_7_9d8f09b0:

    # "Cuando Cindy llegó y el Dr. Salazar le comentó que tuviste una pequeña crisis, ella se preocupó mucho, hasta el punto de considerar quedarse el resto del día contigo."
    "Когда Синди вернулась и доктор Салазар рассказал ей, что у вас случился небольшой приступ, она так перепугалась, что решила остаться с вами на весь день."

# game/script.rpy:2114
translate russian supervivencia_7_8032cbf9:

    # "Aunque apreciaras el gesto, no estabas del todo bien con eso. Así que la convenciste de que fuera a trabajar, pidiéndole que te cubra."
    "Вы цените её заботу, но чувствовали себя неловко, поэтому убедили её пойти на работу, пообещав, что вы справитесь."

# game/script.rpy:2115
translate russian supervivencia_7_80af0230:

    # "De todas formas, el Dr. Salazar te dio una semana de reposo."
    "Так или иначе, доктор Салазар дал вам неделю отдыха."

# game/script.rpy:2117
translate russian supervivencia_7_ffe628b8:

    # "Como te dejaron en observación, tuviste que pasar el resto del día y la noche en el hospital, pero cuando llegara la mañana del día siguiente, todo estaba listo para darte de alta."
    "Вас оставили под наблюдением, так что остаток дня с ночью пришлось провести в больнице, но к утру вас уже были готовы выписать."

# game/script.rpy:2133
translate russian supervivencia_7_854cc4a4:

    # "Al día siguiente, te dieron de alta."
    "На следующий день вас выписывают из больницы."

# game/script.rpy:2134
translate russian supervivencia_7_269c2368:

    # "Y por suerte, tenías el asunto del transporte cubierto."
    "И, к счастью, вопрос с транспортом уже улажен."

# game/script.rpy:2137
translate russian supervivencia_7_41ad32d4:

    # TW "Adelante, [povname]."
    TW "Проходи, [povname]."

# game/script.rpy:2138
translate russian supervivencia_7_6d54df8e:

    # "El Teniente Wes abrió la puerta del auto para ti, mientras la detective Sean tomaba asiento en el puesto del conductor."
    "Лейтенант Уэс распахивает перед вами дверцу машины, а детектив Шон тем временем устраивается за рулём."

# game/script.rpy:2139
translate russian supervivencia_7_c3510aa7:

    # "Te levantas de tu lugar en la silla de ruedas en la que te llevaron a la entrada del hospital."
    "Вы поднимаетесь с кресла-каталки, на котором вас довезли до входа в больницу."

# game/script.rpy:2145
translate russian supervivencia_7_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2146
translate russian supervivencia_7_8ab2a384:

    # "Te giras ante el llamado de tu nombre."
    "Вы оборачиваетесь на зов своего имени."

# game/script.rpy:2147
translate russian supervivencia_7_d3c7a0ac:

    # pov "¿Dr. Salazar, qué sucede?"
    pov "Доктор Салазар, что такое?"

# game/script.rpy:2148
translate russian supervivencia_7_5174155d:

    # "El Dr. Salazar se toma un momento para tomar aire, para después extenderte una tarjeta de presentación."
    "Доктор Салазар делает паузу, чтобы перевести дух, а затем протягивает вам визитную карточку."

# game/script.rpy:2154
translate russian supervivencia_7_b4a00926:

    # DR "Mi tarjeta, puedes llamarme cuando quieras… o si necesitas algo."
    DR "Моя визитка. Можешь звонить, когда захочешь... или если что-то понадобится."

# game/script.rpy:2156
translate russian supervivencia_7_c8424d49:

    # "Recibiste el pedazo de papel y lo agitaste juguetonamente."
    "Вы берёте картонку и игриво трясёте ею."

# game/script.rpy:2157
translate russian supervivencia_7_c0c38372:

    # pov "¿Quién diría que podría conseguir el número de alguien si me lastimaba un poco?"
    pov "Кто бы мог подумать, что достаточно немного пострадать, чтобы получить чей-то номер?"

# game/script.rpy:2159
translate russian supervivencia_7_14e047c9:

    # "El Dr. Salazar abre la boca con impresión, para después carraspear con las mejillas encendidas."
    "Доктор Салазар удивлённо приоткрывает рот, потом смущённо кашляет, его щёки краснеют."

# game/script.rpy:2160
translate russian supervivencia_7_65c67a35:

    # DR "Esto… es preocupación profesional."
    DR "Это... профессиональная забота."

# game/script.rpy:2161
translate russian supervivencia_7_4f6feb5d:

    # "Wes alzó una ceja al doctor, el cual se rascó la cabeza con incomodidad y se retiró."
    "Уэс приподнимает бровь, глядя на доктора. Тот неловко почесал затылок и поспешил уйти."

# game/script.rpy:2165
translate russian supervivencia_7_1045acd9:

    # TW "¿Ese doctor no se ha sobrepasado contigo?"
    TW "Этот врач неподобающе вёл себя с тобой?"

# game/script.rpy:2166
translate russian supervivencia_7_e2082dd3:

    # pov "Para nada, ha sido bastante atento."
    pov "Вовсе нет, он был довольно любезен."

# game/script.rpy:2167
translate russian supervivencia_7_600a2630:

    # "Wes se encogió de hombros y volvió a apuntar al interior del auto."
    "Уэс пожимает плечами и указывает на машину."

# game/script.rpy:2170
translate russian supervivencia_7_5919879c:

    # "Esta vez, sin interrupciones, te sentaste en los asientos traseros."
    "На этот раз без всяких помех, вы садитесь на заднее сиденье."

# game/script.rpy:2171
translate russian supervivencia_7_fe311ec5:

    # "Cuando Wes tomó asiento en el lado del copiloto, el auto encendió y avanzó."
    "Когда Уэс занимает переднее сиденье, машина заводится и трогается."

# game/script.rpy:2172
translate russian supervivencia_7_9da7b463:

    # "La mayoría del tiempo, hubo silencio, hasta que viste disimuladamente cómo Wes le daba un leve codazo a Sean."
    "Большую часть времени в салоне царит тишина, пока вы украдкой не замечаете, как Уэс слегка толкает Шон локтём."

# game/script.rpy:2177
translate russian supervivencia_7_9fe86a32:

    # DS "Ehem."
    DS "Кхм."

# game/script.rpy:2178
translate russian supervivencia_7_179f04b9:

    # "Ella carraspeó, mirándote por el espejo retrovisor."
    "Она откашлялась, глянув на вас в зеркало заднего вида."

# game/script.rpy:2179
translate russian supervivencia_7_20be4162:

    # DS "Así que… [povname], ¿Cómo te sientes hasta el momento?"
    DS "Итак... [povname], как ты себя чувствуешь?"

# game/script.rpy:2180
translate russian supervivencia_7_caf5b14f:

    # "Te extrañó el que la policía más distante esté intentando conversar contigo, pero no tenías por qué ser idiota y rechazar sus esfuerzos."
    "Вас немного удивляет, что именно самая сдержанная из копов решила заговорить, но грубить и отмахиваться повода нет."

# game/script.rpy:2181
translate russian supervivencia_7_90901f6c:

    # pov "Bien, aunque en su mayoría es por los analgésicos."
    pov "Хорошо, в основном из-за обезболивающих."

# game/script.rpy:2182
translate russian supervivencia_7_3a7a25ea:

    # "No pudiste evitar acariciar con la punta de tus dedos el parche clínico que cubría tu cuenca izquierda."
    "Вы невольно проводите пальцами по медицинской повязке, закрывающей вашу левую глазницу."

# game/script.rpy:2183
translate russian supervivencia_7_99df20b2:

    # "Sean dio una pausa, para después responder."
    "Шон на мгновение замолкает, а затем снова говорит."

# game/script.rpy:2184
translate russian supervivencia_7_8bf2ade2:

    # DS "… Tal vez tengas cicatrices, pero son la evidencia de que sobreviviste."
    DS "...Может, у тебя и останутся шрамы, но они являются доказательством того, что ты выжили."

# game/script.rpy:2185
translate russian supervivencia_7_8ffc9f45:

    # "No pudiste evitar sorprenderte por un momento ante el comentario alentador, pero debes admitir que te hizo el día."
    "Вас немного удивляют слова поддержки, но стоит признать — этот комментарий сделал ваш день немного лучше."

# game/script.rpy:2186
translate russian supervivencia_7_d1e890a4:

    # pov "Gracias."
    pov "Спасибо."

# game/script.rpy:2187
translate russian supervivencia_7_087cbbee:

    # "Sean miró al frente, concentrada en el camino, pero algo te hace pensar que se siente más tranquila."
    "Шон смотрит прямо перед собой, сосредоточенно ведя машину, но вам почему-то кажется, что она стала чуть спокойнее."

# game/script.rpy:2188
translate russian supervivencia_7_6e0b6066:

    # TW "¿Tu novia irá a verte a tu hogar?"
    TW "Твоя девушка придёт навестить тебя?"

# game/script.rpy:2189
translate russian supervivencia_7_e9643459:

    # "Tu mente se congela por instantes ante la pregunta de Wes."
    "От вопроса Уэса ваши мысли на мгновение застопорились."

# game/script.rpy:2190
translate russian supervivencia_7_74267743:

    # pov "¿Disculpa?"
    pov "Что?"

# game/script.rpy:2191
translate russian supervivencia_7_e9c3f5a4:

    # TW "La señorita Cindy."
    TW "Мисс Синди."

# game/script.rpy:2192
translate russian supervivencia_7_4a2bd410:

    # pov "Ah."
    pov "А."

# game/script.rpy:2193
translate russian supervivencia_7_9016db8c:

    # "No sabías si ofenderte o avergonzarte."
    "Вы не знаете, обижаться или смущаться."

# game/script.rpy:2194
translate russian supervivencia_7_133dab0c:

    # pov "Es sólo una compañera de trabajo, ni siquiera es mi amiga."
    pov "Она просто коллега, мы не настолько близки."

# game/script.rpy:2195
translate russian supervivencia_7_0fd21e0f:

    # TW "Oh, yo pensé…"
    TW "Ох, я подумал..."

# game/script.rpy:2196
translate russian supervivencia_7_f412babb:

    # "Él se giró a Sean, con una mirada que pedía ayuda, pero fue completamente ignorado."
    "Он бросает взгляд на Шон, будто ища поддержки, но та полностью его игнорирует."

# game/script.rpy:2197
translate russian supervivencia_7_7d3cfe72:

    # TW "La vi muy atenta y protectora de ti, lo siento, no quise…"
    TW "Просто она показалась мне очень заботливой и внимательной, прошу прощения, я не хотел..."

# game/script.rpy:2198
translate russian supervivencia_7_28fe49be:

    # pov "Está bien, también me llama la atención que sea así."
    pov "Всё в порядке, меня тоже это удивило."

# game/script.rpy:2199
translate russian supervivencia_7_6a9963dc:

    # pov "Pero… es agradable ver que alguien se preocupa de mí en esta ciudad."
    pov "Но... приятно осознавать, что хоть кто-то здесь обо мне беспокоится."

# game/script.rpy:2200
translate russian supervivencia_7_579af3ec:

    # TW "Estás por tu cuenta tengo entendido."
    TW "Насколько я понимаю, ты живёшь одни."

# game/script.rpy:2201
translate russian supervivencia_7_8831ab95:

    # pov "Si, pero lidio con eso."
    pov "Да, но я как-то справляюсь."

# game/script.rpy:2202
translate russian supervivencia_7_273b423c:

    # DS "Podemos pedir protección para ti."
    DS "Мы можем обеспечить тебе защиту."

# game/script.rpy:2203
translate russian supervivencia_7_419ad3d2:

    # pov "Oh, ¿Como vigilar donde vivo?"
    pov "О, чтобы следили, где я живу?"

# game/script.rpy:2204
translate russian supervivencia_7_a7f8607a:

    # DS "Si, ahora asumimos que tu atacante está en la fuga, pero no podemos suponer que no volverá para terminar el trabajo."
    DS "Да, мы предполагаем, что твой нападавший в бегах, но нельзя исключать, что он может вернуться, чтобы закончить начатое."

# game/script.rpy:2205
translate russian supervivencia_7_9e5d0d64:

    # "Wes se removió incómodo en su lugar."
    "Уэс неловко ёрзает на месте."

# game/script.rpy:2206
translate russian supervivencia_7_7c1a1a67:

    # TW "Elise…"
    TW "Элиз..."

# game/script.rpy:2207
translate russian supervivencia_7_59cbfea6:

    # pov "Está bien, no me importa."
    pov "Всё в порядке, я не возражаю."

# game/script.rpy:2208
translate russian supervivencia_7_57016c31:

    # "En realidad, que te estén protegiendo te da cierta seguridad, considerando que Jeff irá a buscarte."
    "На самом деле, мысль о защите придаёт вам уверенности — особенно с учётом того, что Джефф, вероятно, попытается вас найти."

# game/script.rpy:2209
translate russian supervivencia_7_8fd34851:

    # "Eres consciente de que estás entorpeciendo la investigación al ocultar información clave, como el nombre de Jeff y el juego que él instauró."
    "Вы прекрасно понимаете, что мешаете расследованию, скрывая ключевую информацию — имя Джеффа и ту игру, которую он устроил."

# game/script.rpy:2210
translate russian supervivencia_7_9671a893:

    # "Pero tras presenciar cómo él se salía con la suya muy fácilmente en el hospital, algo te decía que el universo estaba a favor de él."
    "Но, увидев, как легко он выкрутился в больнице, теперь вам кажется, что сама вселенная на его стороне."

# game/script.rpy:2211
translate russian supervivencia_7_8dcff2f8:

    # pov "La verdad, me hace sentir mejor."
    pov "Если честно, от этого даже спокойнее."

# game/script.rpy:2212
translate russian supervivencia_7_647a8c4b:

    # "Un escalofrío de peligro se enraíza desde tu nuca, como si tu cuerpo sintiera la presencia de Jeff cerca."
    "Озноб пробегает по шее, словно ваше тело чувствует присутствие Джеффа поблизости."

# game/script.rpy:2214
translate russian supervivencia_7_e863b50c:

    # "El recuerdo del dolor punzante de tu ojo siendo arrancado te hace acomodarte en tu asiento."
    "Воспоминание о той пронзительной боли, с которой вырвали ваш глаз, заставляет вас поёжиться и вжаться в сиденье."

# game/script.rpy:2215
translate russian supervivencia_7_cac656f4:

    # "Tal vez, sólo tal vez, te estaba afectando más de lo que te gustaría."
    "Возможно — лишь возможно — всё это задевает вас куда сильнее, чем вы хотели бы признаться."

# game/script.rpy:2216
translate russian supervivencia_7_74e055de:

    # DS "Llegamos."
    DS "Приехали."

# game/script.rpy:2217
translate russian supervivencia_7_c51e7fd2:

    # "Ves por la ventana del auto la entrada a tu edificio, lo que te hace suspirar de alivio."
    "В окно машины вы видите вход в свой дом, и невольно выдыхаете с облегчением."

# game/script.rpy:2218
translate russian supervivencia_7_faa04ad0:

    # "Por fin puedes volver a tu cama."
    "Наконец-то можно вернуться в свою кровать."

# game/script.rpy:2219
translate russian supervivencia_7_cec94954:

    # TW "Vamos a estar al pendiente, cualquier actualización te avisaremos."
    TW "Мы будем держать всё под контролем. Сообщим, если появится что-то новое."

# game/script.rpy:2225
translate russian supervivencia_7_594526dc:

    # TW "Este es mi número, llama si necesitas algo, y te aseguro que mi preocupación es estrictamente profesional."
    TW "Вот мой номер. Звони, если что-то понадобится. И уверяю — моя забота носит строго профессиональный характер."

# game/script.rpy:2226
translate russian supervivencia_7_aa401881:

    # "Recibes la tarjeta de presentación con la punta de tus dedos, viendo el nombre impreso, “W. Wes”."
    "Вы берёте визитку кончиками пальцев и читаете напечатанное на ней имя: «У. Уэс»."

# game/script.rpy:2231
translate russian supervivencia_7_a7856b9d:

    # pov "Oh, W, ¿será de William?"
    pov "О, «У» — это, случайно, не Уильям?"

# game/script.rpy:2233
translate russian supervivencia_7_8623e9c5:

    # "Wes se ríe entre dientes, su voz grave vibrante es un dulce para los oídos."
    "Уэс усмехается, и его низкий, звучный голос даже неожиданно приятно слышать."

# game/script.rpy:2234
translate russian supervivencia_7_6d116769:

    # TW "No, pero buen intento."
    TW "Нет, но хорошая попытка."

# game/script.rpy:2235
translate russian supervivencia_7_e81521d4:

    # pov "¿Al menos puedo saber si hay señora Wes esperando en casa?"
    pov "А можно узнать, не ждёт ли дома миссис Уэс?"

# game/script.rpy:2236
translate russian supervivencia_7_bd02e432:

    # "Wes se sorprende por unos segundos, para después soltar una carcajada ligera."
    "Уэс на секунду удивляется, а затем тихо смеётся."

# game/script.rpy:2238
translate russian supervivencia_7_b7023bb1:

    # "Escuchas a un lado que Sean suelta un quejido lastimero."
    "Сбоку слышится недовольный стон Шон."

# game/script.rpy:2239
translate russian supervivencia_7_e7fa0442:

    # DS "La W es de Wallace, ¿Feliz?"
    DS "Эта «У» — Уоллес. Довольны?"

# game/script.rpy:2240
translate russian supervivencia_7_b3a484cc:

    # "Alzas las manos en rendición, con una pequeña sonrisa traviesa."
    "Вы поднимаете руки, сдаваясь, с лукавой улыбкой на лице."

# game/script.rpy:2241
translate russian supervivencia_7_a01f58a9:

    # "Abres la puerta del auto y te tomas un momento para despedirte."
    "Вы открываете дверцу машины и на мгновение задерживаетесь, чтобы попрощаться."

# game/script.rpy:2242
translate russian supervivencia_7_b76b4043:

    # pov "De acuerdo, geez. Fue un gusto, detective."
    pov "Ладно, боже. Было приятно познакомиться, детектив."

# game/script.rpy:2243
translate russian supervivencia_7_334493b0:

    # "Sean hace un ademán de despedida con la mano, como si te estuviera apresurando."
    "Шон машет рукой на прощание, будто торопя вас."

# game/script.rpy:2244
translate russian supervivencia_7_62934f2a:

    # pov "Wallace, ¿Puedo llamarte Wallace?"
    pov "Уоллес, можно называть тебя просто Уоллес?"

# game/script.rpy:2245
translate russian supervivencia_7_b80127c9:

    # "Wes alzó una ceja con una sonrisa sarcástica."
    "Уэс с усмешкой приподнимает бровь."

# game/script.rpy:2246
translate russian supervivencia_7_bd831bd5:

    # TW "Ya lo hiciste."
    TW "Ты уже это сделали."

# game/script.rpy:2247
translate russian supervivencia_7_9fe64b69:

    # pov "Fue un placer, Wallace."
    pov "Было приятно познакомиться, Уоллес."

# game/script.rpy:2248
translate russian supervivencia_7_dea47636:

    # "Él vuelve a reír levemente, despidiéndote con la mano."
    "Он снова тихо смеётся, прощаясь с вами."

# game/script.rpy:2249
translate russian supervivencia_7_20334c32:

    # TW "Ya nos veremos, player."
    TW "Увидимся, игрок."

# game/script.rpy:2253
translate russian supervivencia_7_6c158f2f:

    # pov "¿Puedo tener su número, detective?"
    pov "Можно ваш номер, детектив?"

# game/script.rpy:2255
translate russian supervivencia_7_c61f0fa2:

    # "Ves por el espejo retrovisor que los ojos de Sean se abren con sorpresa."
    "В зеркале заднего вида вы замечаете, как глаза Шон удивлённо распахиваются."

# game/script.rpy:2256
translate russian supervivencia_7_106b82e3:

    # DS "¿Disculpa?"
    DS "Прошу прощения?"

# game/script.rpy:2257
translate russian supervivencia_7_02efd91a:

    # pov "El teniente me dió el de él, ¿Puedo tener el suyo?"
    pov "Лейтенант дал мне свой, можно и ваш?"

# game/script.rpy:2258
translate russian supervivencia_7_2efaf03a:

    # "Sean mira de reojo a Wes, el cual se encoge de hombros."
    "Шон глядит на Уэса, но он только пожимает плечами."

# game/script.rpy:2260
translate russian supervivencia_7_fd8550e3:

    # DS "Bueno… yo…"
    DS "Ну... я..."

# game/script.rpy:2261
translate russian supervivencia_7_e61fc35a:

    # TW "Discúlpala, no tiene muchas habilidades sociales."
    TW "Прости её, с социальными навыками у неё не всё гладко."

# game/script.rpy:2262
translate russian supervivencia_7_b0115458:

    # "Sean le da un codazo a Wes, quién se ríe levemente con burla."
    "Шон толкает Уэса локтём, а тот тихо смеётся."

# game/script.rpy:2263
translate russian supervivencia_7_055318f6:

    # DS "¡Wallace!"
    DS "Уоллес!"

# game/script.rpy:2264
translate russian supervivencia_7_edf0575d:

    # pov "Eso es lindo."
    pov "Мило."

# game/script.rpy:2265
translate russian supervivencia_7_a5092d8b:

    # "Sean se queda en silencio por un momento, para después sacar a regañadientes su billetera."
    "Шон на мгновение замирает, потом нехотя достаёт из кошелька визитную карточку."

# game/script.rpy:2272
translate russian supervivencia_7_22fcf735:

    # DS "Este… es mi número, llama cuando quieras- digo, cuando necesites."
    DS "Вот... мой номер. Звони, когда захочешь— Точнее, когда понадобится."

# game/script.rpy:2273
translate russian supervivencia_7_092ee1c6:

    # "Ves por el rabillo de tu ojo restante cómo Wes alza una ceja ante los murmullos de Sean, quien desvía la mirada de ti."
    "Краем уцелевшего глаза вы замечаете, как Уэс приподнимает бровь, а Шон, пробормотав что-то себе под нос, поспешно отводит взгляд."

# game/script.rpy:2274
translate russian supervivencia_7_9d85e64f:

    # pov "Entendido."
    pov "Понятно."

# game/script.rpy:2275
translate russian supervivencia_7_fbbc3b23:

    # "Asientes firmemente."
    "Вы решительно киваете."

# game/script.rpy:2279
translate russian supervivencia_7_f4225670:

    # pov "¿Puedo… preguntarles algo?"
    pov "Можно... спросить кое-что?"

# game/script.rpy:2280
translate russian supervivencia_7_7e125fc5:

    # "Ellos te miran desde sus lugares, expectantes a tus próximas palabras."
    "Они поворачиваются к вам, ожидая, что вы скажете дальше."

# game/script.rpy:2281
translate russian supervivencia_7_058f65a3:

    # pov "No pude evitar darme cuenta… que les sorprendió ver que sobreviví."
    pov "Я не могли не заметить... вы были удивлены, когда увидели, что я выжили."

# game/script.rpy:2282
translate russian supervivencia_7_835c9619:

    # "Wes mira un momento a Sean, con seriedad. Ella asiente firmemente."
    "Уэс смотрит на Шон с серьёзным выражением лица. Та утвердительно кивает."

# game/script.rpy:2283
translate russian supervivencia_7_fa263165:

    # DS "Hay que decirle, Wallace."
    DS "Стоит рассказать, Уоллес."

# game/script.rpy:2284
translate russian supervivencia_7_0c6d21a6:

    # "Wes hace una pausa, para después suspirar pesado."
    "Уэс мнётся, потом тяжело вздыхает."

# game/script.rpy:2285
translate russian supervivencia_7_bc674072:

    # TW "… Sospechamos de alguien que puede ser el hombre que te atacó."
    TW "...У нас есть подозреваемый. Возможно, именно он напал на тебя."

# game/script.rpy:2286
translate russian supervivencia_7_144c9fb4:

    # "Tragas fuertemente."
    "Вы с трудом сглатываете."

# game/script.rpy:2287
translate russian supervivencia_7_285aa2ba:

    # pov "¿... Quién creen que es?"
    pov "...И кого вы подозреваете?"

# game/script.rpy:2288
translate russian supervivencia_7_aff88bd5:

    # DS "Creemos que es alguien llamado Jeff, su apellido no lo sabemos con exactitud. Es un hombre muy peligroso, lleva escapando de la ley por más de una década."
    DS "Мы думаем, это некто по имени Джефф, фамилию точно не знаем. Очень опасный человек — уже больше десяти лет уходит от правосудия."

# game/script.rpy:2289
translate russian supervivencia_7_eca2b8ad:

    # "Wes se acomoda en su asiento para enfrentarte."
    "Уэс разворачивается, чтобы посмотреть прямо на вас."

# game/script.rpy:2290
translate russian supervivencia_7_a15ec728:

    # TW "[povname]... Es un asesino demente, y si tenemos razón respecto a esto… Serías la primera víctima de la que sabemos que él deja viva."
    TW "[povname]... Он безумный убийца, и если мы правы... ты первая его жертва, которую он оставил в живых."

# game/script.rpy:2291
translate russian supervivencia_7_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2292
translate russian supervivencia_7_08e3a901:

    # "Bueno, eso fue un gran volcado de información, presuntamente valiosa."
    "Ну, это довольно ценная информация, наверное."

# game/script.rpy:2293
translate russian supervivencia_7_b9fe1b5c:

    # pov "De acuerdo, entiendo."
    pov "Хорошо, понимаю."

# game/script.rpy:2294
translate russian supervivencia_7_8d77837c:

    # TW "¿Vas a estar bien por tu cuenta?, ¿No quieres que te consigamos un hotel?"
    TW "Ты точно справишься? Может, снять тебе номер в отеле?"

# game/script.rpy:2295
translate russian supervivencia_7_1fbf6da9:

    # pov "No, gracias… estaré bien."
    pov "Нет, спасибо... со мной всё будет нормально."

# game/script.rpy:2296
translate russian supervivencia_7_1e74ec06:

    # "Wes te miró indeciso por un momento, pero cedió al verte que bajas del auto."
    "Уэс несколько секунд колеблется, но, увидев, как вы выходите из машины, всё же успокаивается."

# game/script.rpy:2304
translate russian charla_1_3e23d177:

    # "Cierras la puerta y te quedas un momento sobre la acera, observando cómo el auto se mezcla en el tráfico."
    "Вы закрываете дверцу и на миг задерживаетесь на тротуаре, наблюдая, как машина растворяется в потоке."

# game/script.rpy:2305
translate russian charla_1_7e1dbd33:

    # "Suspiras con alivio, girándote al vestíbulo de tu edificio."
    "С облегчением вздыхая, вы поворачиваетесь к входу в свой дом."

# game/script.rpy:2307
translate russian charla_1_970f18c5:

    # "Cuando llegas a tu departamento, está igual a cómo lo dejaste hace dos días."
    "Когда вы входите в квартиру, она выглядит ровно так же, как и два дня назад."

# game/script.rpy:2308
translate russian charla_1_5985f91d:

    # "Te entregaron el departamento amueblado y tenías pocas cosas propias, así que no había desorden, pero definitivamente haber dejado el lugar por dos días hizo que se acumulara algo de polvo."
    "Жильё досталось вам уже с мебелью, а своих вещей было немного, так что беспорядка вы не замечаете; разве что тонкий слой пыли за два дня простоя."

# game/script.rpy:2310
translate russian charla_1_661a8bb4:

    # "Así que lo primero que haces es ponerte a barrer y sacudir."
    "Поэтому сперва вы решаете взяться за уборку — подмести пол и протереть пыль."

# game/script.rpy:2311
translate russian charla_1_f1ebc1f5:

    # "Abres las ventanas mientras agitas los cojines del sofá, y después sacudes el polvo de la tv."
    "Вы открываете окна, вытряхиваете подушки на диване и смахиваете пыль с телевизора."

# game/script.rpy:2314
translate russian charla_1_6773f2ee:

    # "Deshechas todo de la nevera que está en mal estado y limpias el interior."
    "Выбрасываете испорченные продукты из холодильника и чистите его изнутри."

# game/script.rpy:2316
translate russian charla_1_5c8f4564:

    # "Pasas al baño, donde limpias las superficies hasta que no puedes ver ni un rastro de suciedad."
    "Затем переходите в ванную и моете поверхности, пока не исчезает последняя пылинка."

# game/script.rpy:2319
translate russian charla_1_cfd9eb9a:

    # "Por último, llegas a tu habitación. Está más vacía de lo que te gustaría."
    "Наконец, вы доходите до спальни — пустовата, как и раньше."

# game/script.rpy:2320
translate russian charla_1_887a93a3:

    # "Te gustaría tener…"
    "Вы бы приобрели..."

# game/script.rpy:2324
translate russian charla_1_9958e21b:

    # "Lo que sea para cubrir las paredes blancas."
    "Что угодно, лишь бы прикрыть белые стены."

# game/script.rpy:2327
translate russian charla_1_e5bba708:

    # "Iluminación extra y estética le vendría bien."
    "Немного света и уюта явно не помешало бы."

# game/script.rpy:2330
translate russian charla_1_00db2001:

    # "Más que adornos, preferirías tener muebles para guardar tus cosas."
    "Вместо безделушек вы бы предпочли шкафы, чтобы хоть где-то хранить вещи."

# game/script.rpy:2335
translate russian character_4_95f06fba:

    # "De todas formas, ahora no tienes tiempo para preocuparte por eso."
    "Впрочем, сейчас не время об этом думать."

# game/script.rpy:2336
translate russian character_4_d82049e2:

    # "Tienes que lidiar con lo más importante…"
    "Вам нужно заняться куда более важным..."

# game/script.rpy:2339
translate russian character_4_0aa4328b:

    # "Cierras todas las ventanas a tu alcance con seguro, luego vas a la entrada y pones doble llave a la cerradura."
    "Вы запираете все доступные окна, затем подходите к двери и проворачиваете замок дважды."

# game/script.rpy:2340
translate russian character_4_b6b7faa7:

    # "Te asomas por una ventana, y ves que en la calle de enfrente hay una patrulla estacionada."
    "Заглянув в окно, вы замечаете на другой стороне улицы припаркованный патрульный автомобиль."

# game/script.rpy:2342
translate russian character_4_4ebb7a9d:

    # "Suspiras, sentándote en el sofá, recuperando el aire y la sensación de seguridad que habías perdido hace tiempo."
    "Вы вздыхаете, опускаясь на диван, наконец восстанавливая дыхание и то давно утраченное чувство безопасности."

# game/script.rpy:2343
translate russian character_4_14d6a519:

    # "Técnicamente, Jeff no podría alcanzarte. No debería."
    "Технически, Джефф не сможет вас достать. Не должен."

# game/script.rpy:2344
translate russian character_4_464170cf:

    # "Pero uno nunca puede estar seguro, para conveniencias del guión."
    "Но никогда нельзя быть полностью уверенным, ради сценария."

# game/script.rpy:2346
translate russian character_4_77db2485:

    # "Para distraerte, enciendes la tv y cambias de canal hasta alguno que te interese, hasta que llegas a un noticiario mostrando un escenario muy familiar."
    "Чтобы отвлечься, вы включаете телевизор и начинаете пролистывать каналы, пока взгляд не цепляется за новости, показывающие до боли знакомое место."

# game/script.rpy:2347
translate russian character_4_05fe7baa:

    # "Esa es… ¿La calle donde está la tienda de películas?"
    "Это же... та самая улица, где находится видеопрокат?"

# game/script.rpy:2348
translate russian character_4_59d4805a:

    # "Subes el volúmen, con mayor interés."
    "Вы прибавляете звук, заинтересовавшись."

# game/script.rpy:2349
translate russian character_4_7c138c67:

    # Peri "… Una persona fue atacada a las 9 horas de la noche el día jueves, con heridas graves. Fuentes médicas informaron que la víctima se encuentra en recuperación."
    Peri "...В четверг около 9 часов вечера на человека было совершено нападение. Пострадавший получил тяжёлые травмы, но, по данным врачей, сейчас его состояние стабильно."

# game/script.rpy:2350
translate russian character_4_b7b4970a:

    # Peri "Descripciones del atacante indican que es un hombre alto, blanco, entre 20 y 30 años con cicatrices en el rostro. Lleva ropa blanca y negra, y frecuenta cubrirse el rostro."
    Peri "По описаниям очевидцев, нападавший — высокий белый мужчина, в возрасте от 20 до 30 лет, со шрамами на лице. Обычно он носит одежду чёрно-белых тонов и старается скрывать лицо."

# game/script.rpy:2351
translate russian character_4_1daa3ac5:

    # Peri "Al sospechoso se le atribuyen 27 víctimas de asesinato, pero los investigadores estiman que el número real podría superar al centenar."
    Peri "Подозреваемому приписывают 27 убийств, однако следователи считают, что реальное число жертв может превышать сотню."

# game/script.rpy:2352
translate russian character_4_79ee9085:

    # "Era bastante obvio que estaban hablando de tu ataque."
    "Довольно очевидно, что речь идёт о вашем нападении."

# game/script.rpy:2353
translate russian character_4_9a412531:

    # "Sientes que pierdes fuerzas en las manos mientras más escuchas a la periodista, mientras más sabes de Jeff."
    "Чем дольше вы слушаете репортёра и чем больше узнаёте о Джеффе, тем сильнее слабеют ваши руки."

# game/script.rpy:2354
translate russian character_4_e3bd9b29:

    # "¿Tantas personas había matado?"
    "Неужели он и правда убил столько людей?"

# game/script.rpy:2355
translate russian character_4_bd9017a0:

    # "¿Realmente te había dejado con vida?"
    "И действительно пощадил вас?"

# game/script.rpy:2356
translate russian character_4_b775e333:

    # "Recuerdas vagamente que Wes había discutido con unas personas fuera de tu habitación en el hospital, seguramente estaba ahuyentando a periodistas que querían hablar contigo."
    "Вы смутно припоминаете, как Уэс с кем-то спорил за дверью вашей палаты — вероятно, отгонял репортёров, пытавшихся пробиться к вам."

# game/script.rpy:2357
translate russian character_4_6e1df953:

    # "Mejor, así hubieras tenido menos chance de meter la pata."
    "Оно и к лучшему — меньше шанс ляпнуть что-нибудь лишнее."

# game/script.rpy:2358
translate russian character_4_55de361a:

    # "Si te hubieran puesto ante las cámaras, con micrófonos en la boca y periodistas viéndote con hambre de información, hubieras revelado información que no te convendría por el acecho de Jeff."
    "Если бы вас посадили перед камерами, тыкая микрофонами в лицо, под жадными взглядами репортёров вы бы непременно проболтались о том, о чём лучше молчать. Особенно с учётом того, что Джефф где-то рядом."

# game/script.rpy:2359
translate russian character_4_41bb9c8c:

    # "Ya que todo indicaba que no importaba a donde fueras, Jeff te encontraría."
    "Потому что всё указывает на то, что куда бы вы ни пошли — Джефф всё равно найдёт вас."

# game/script.rpy:2362
translate russian character_4_2418e16c:

    # "Sintiendo que el sudor baja por tu frente, vas a al baño y te lavas la cara, suspirando frente al lavabo."
    "Чувствуя, как по лбу стекает пот, вы направляетесь в ванную, умываетесь и выдыхаете, уставившись в раковину."

# game/script.rpy:2363
translate russian character_4_0048272b:

    # "Te miras en el espejo, y por primera vez presencias tu apariencia actual."
    "Затем поднимаете взгляд на зеркало — и впервые видите свой нынешний вид."

# game/script.rpy:2364
translate russian character_4_436ce400:

    # "Tu expresión se ve cansada, no llegaba a ser demacrada, pero estaba a punto."
    "Лицо уставшее, ещё не измождённое, но близкое к этому."

# game/script.rpy:2365
translate russian character_4_1c5e571e:

    # "Marcas moradas en forma de dedos rodeaban la piel de tu cuello, lo que te hizo tragar."
    "На шее темнеют фиолетовые следы от его пальцев. От этого вы невольно сглатываете."

# game/script.rpy:2366
translate russian character_4_5f89f852:

    # "Pero entonces caes en cuenta del parche sobre tu ojo izquierdo."
    "Но потом вы замечаете повязку на своём левом глазу."

# game/script.rpy:2368
translate russian character_4_a1eec882:

    # "Con dedos temblorosos, desenganchas los elásticos del parche de tu cabeza, dejando a la vista un parche adhesivo. Remueves esa pieza, y sólo queda una gasa."
    "Дрожащими пальцами вы осторожно снимаете резинки повязки, освобождая голову и медицинский пластырь. Вы отклеиваете и его, остаётся только слой марли."

# game/script.rpy:2369
translate russian character_4_c7cf1e93:

    # "Pacientemente, quitas la gasa, para finalmente ver lo que había hecho Jeff de ti."
    "Вы терпеливо убираете марлю, чтобы наконец увидеть, что Джефф с вами сделал."

# game/script.rpy:2370
translate russian character_4_0e558445:

    # "Tras quitar el pedazo de tela, ves tu párpado caído, y cuando intentas pestañear, tu párpado tiembla, dejando ver el interior de tu cuenca, recubierto con piel rosada y brillante."
    "Убрав кусочек ткани, вы видите опущенное вялое веко. Попробовав моргнуть, замечаете, как оно судорожно дёргается, открывая внутреннюю полость — розовую, блестящую, будто свежий шрам."

# game/script.rpy:2371
translate russian character_4_a2b4e1b4:

    # "Sientes curiosidad y extiendes tu párpado inferior para ver mejor el interior de tu cuenca."
    "Из любопытства вы слегка оттягиваете нижнее веко, чтобы рассмотреть то, что осталось внутри."

# game/script.rpy:2372
translate russian character_4_e538b6bd:

    # "Es curioso, porque de alguna forma, sientes que tu ojo sigue ahí."
    "Странное чувство — будто глаз всё ещё на месте."

# game/script.rpy:2373
translate russian character_4_15e0e58c:

    # "¿Cómo se llamaba?, ¿Sensación fantasma?"
    "Как это называлось? Фантомное ощущение?"

# game/script.rpy:2374
translate russian character_4_565bdf76:

    # "Si giras tu ojo derecho a algún lado, sientes que tu ojo izquierdo hace lo mismo, aunque claramente ya no se encuentra ahí."
    "Когда вы двигаете правым глазом, чувствуете, будто левый делает то же самое, хотя его уже давно нет."

# game/script.rpy:2375
translate russian character_4_935dcc7e:

    # J "Es uno de mis mejores trabajos."
    J "Одно из моих лучших творений."

# game/script.rpy:2378
translate russian character_4_832f7687:

    # "Te congelas ante la voz."
    "Вы замираете, услышав голос."

# game/script.rpy:2384
translate russian character_4_36bb159b:

    # "Tu visión se aclara, y en el reflejo del espejo, detrás de ti, puedes ver la silueta de Jeff."
    "Зрение проясняется, и в отражении зеркала за вашей спиной проступает силуэт Джеффа."

# game/script.rpy:2385
translate russian character_4_06e9e468:

    # "Te giras repentinamente, con el corazón acelerado."
    "Вы резко оборачиваетесь, сердце бешено колотится."

# game/script.rpy:2386
translate russian character_4_1eca6826:

    # "Pero no hay nadie."
    "Но за спиной — никого."

# game/script.rpy:2387
translate russian character_4_f19ad975:

    # "Te tomas un momento para recuperar la respiración, para luego llevarte una mano a la cara."
    "Вы делаете глубокий вдох, пытаясь восстановить дыхание, и проводите рукой по лицу."

# game/script.rpy:2388
translate russian character_4_5563a14a:

    # "¿Realmente estabas empezando a alucinar?"
    "Вам что, уже начинает мерещиться всякое?"

# game/script.rpy:2389
translate russian character_4_ddaf4c4c:

    # "Parece que Jeff había causado una gran impresión en ti."
    "Видимо, Джефф серьёзно пошатнул вашу психику."

# game/script.rpy:2390
translate russian character_4_a7596b4a:

    # "¿Puede que realmente…. tengas miedo?"
    "Может, вы правда... просто боитесь?"

# game/script.rpy:2396
translate russian character_4_ec91358c:

    # "No querías admitirlo… pero parece que es el caso."
    "Вы не хотите в этом признаваться... но, похоже, так и есть."

# game/script.rpy:2397
translate russian character_4_7ebfdb1c:

    # "Pero tu miedo no es el de morir precisamente, es… de recibir más daño."
    "Только боитесь вы не самой смерти, а того... что вам причинят ещё больше боли."

# game/script.rpy:2401
translate russian character_4_ea81ff4a:

    # "Nah, no era para tanto."
    "Нет, это не так уж и страшно."

# game/script.rpy:2402
translate russian character_4_dc802691:

    # "Ese era tu cuerpo reaccionando al trauma, nada más."
    "Просто тело реагирует на пережитое, не более."

# game/script.rpy:2409
translate russian character_5_c32adeca:

    # "Tanto pensar en ese desquiciado te estaba cansando."
    "Одни лишь мысли об этом психе начинают выматывать."

# game/script.rpy:2411
translate russian character_5_18f4962d:

    # "Vas a la cocina a comer algo."
    "Вы отправляетесь на кухню, чтобы перекусить."

# game/script.rpy:2413
translate russian character_5_94eab407:

    # "Tenías un par de donas en buen estado guardadas en la alacena."
    "В шкафичке вы находите пару пончиков, ещё вполне съедобных."

# game/script.rpy:2414
translate russian character_5_41716333:

    # "Bebes un poco de jugo y te tomas los analgésicos que te corresponden, y te vas a la cama."
    "Вы выпиваете немного сока, принимаете положенные обезболивающие и уходите спать."

# game/script.rpy:2416
translate russian character_5_6e269041:

    # "Decides hacerte un ramen instantáneo."
    "Вы решаете приготовить упаковку лапши быстрого приготовления."

# game/script.rpy:2417
translate russian character_5_b086fe2d:

    # "Lo acompañas con soda y te tomas los analgésicos que te corresponden, y te vas a la cama."
    "Вы запиваете её газировкой, принимаете положенные обезболивающие и уходите спать."

# game/script.rpy:2421
translate russian character_5_40c200ae:

    # "Quieres ir a dormir sintiendo que estás a salvo, pensando que estarás bien."
    "Вам хочется заснуть с мыслью, что теперь вы в безопасности, что всё будет хорошо."

# game/script.rpy:2422
translate russian character_5_640cdfa9:

    # "Pero como alguien está leyendo esto, eso no pasa."
    "Но поскольку кто-то это читает, очевидно, что всё не так просто."

# game/script.rpy:2425
translate russian character_5_0d2d99c4:

    # "Escuchas un crujido, lo que te despierta de inmediato."
    "Раздаётся тихий скрип, моментально вас разбудивший."

# game/script.rpy:2426
translate russian character_5_199d40c8:

    # "No sabes si es por tener el sueño ligero o porque estás alerta, pero agradeces que sea así."
    "Вы не знаете, сработал ли ваш чуткий сон или инстинкт тревоги. В любом случае вы рады, что вообще проснулись."

# game/script.rpy:2428
translate russian character_5_0f86233a:

    # "Te quedas un momento en tu lugar, esperando que se trate de tu imaginación nuevamente, pero vuelves a escuchar un crujido, esta vez sabes que es por que hay alguien en la casa."
    "Вы остаётесь на месте, надеясь, что это просто снова ваше воображение, но скрип повторяется. На этот раз вы точно знаете — в доме кто-то есть."

# game/script.rpy:2430
translate russian character_5_6ca1be20:

    # "¡Tienes que esconderte!"
    "Нужно спрятаться!"

# game/script.rpy:2439
translate russian game_over_227d368c:

    # J "¡Te encontré!"
    J "Нашёл!"

# game/script.rpy:2450
translate russian muerte_cama_debd40ba:

    # "Es un buen escondite."
    "Неплохое укрытие."

# game/script.rpy:2451
translate russian muerte_cama_9c64c59e:

    # "Aunque un poco predecible."
    "Хотя и немного предсказуемое."

# game/script.rpy:2452
translate russian muerte_cama_5f9b772e:

    # "...."
    "...."

# game/script.rpy:2457
translate russian muerte_cama_b8691e1d:

    # J "¡Boo!"
    J "Бу!"

# game/script.rpy:2458
translate russian muerte_cama_2b928eff:

    # "Tal vez demasiado."
    "Может, даже слишком."

# game/script.rpy:2461
translate russian muerte_cama_946aaa9f:

    # "Te arrastras hasta el fondo, y Jeff te sigue a gatas, mientras se ríe."
    "Вы отползаете дальше под кровать, а Джефф ползёт следом, смеясь."

# game/script.rpy:2462
translate russian muerte_cama_8c52690f:

    # J "¡[povname]!, ¡Qué movimiento tan travieso!"
    J "[povname]! Какой дерзкий ход!"

# game/script.rpy:2463
translate russian muerte_cama_1c647f2d:

    # "El espacio es tan reducido que pronto sientes la respiración de Jeff en tu oído."
    "Места так мало, что вскоре вы ощущаете его дыхание прямо у уха."

# game/script.rpy:2464
translate russian muerte_cama_ee733ec5:

    # J "Pierdes de nuevo…"
    J "Снова проиграли..."

# game/script.rpy:2466
translate russian muerte_cama_265621ed:

    # "Sientes la fría hoja del cuchillo en tu cuello, y con un chirrido, sientes que el ardor te atraviesa."
    "Холодное лезвие скользит по вашей шее — с визгом вы чувствуете, как вас пронзает резкая, жгучая боль."

# game/script.rpy:2476
translate russian muerte_closet_8683ebd2:

    # "Esperas unos segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    "Вы ждёте — несколько секунд кажутся бесконечностью, пока вы слышите, как кто-то открывает двери и роется в вещах."

# game/script.rpy:2478
translate russian muerte_closet_c649c8a1:

    # "Pero tus esperanzas de haber escogido un buen escondite se van cuando escuchas que la puerta del closet se abre."
    "Но надежда на то, что вы выбрали хорошее укрытие, исчезает, как только раздаётся скрип двери шкафа."

# game/script.rpy:2482
translate russian muerte_closet_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:2483
translate russian muerte_closet_3547e498:

    # "Jeff suena encantado por verte, pero el gran cuchillo en su mano no inspira nada bueno."
    "Джефф, кажется, рад вас видеть. Вот только огромный нож в его руке не внушает ничего хорошего."

# game/script.rpy:2484
translate russian muerte_closet_ad0c25ee:

    # J "Volviste a perder, jeje."
    J "И снова проиграли, хе-хе."

# game/script.rpy:2488
translate russian muerte_closet_1d67348d:

    # "No tienes momento para pensar cuando Jeff te apuñala en el estómago."
    "Вы не успеваете даже подумать, как Джефф вонзает нож вам в живот."

# game/script.rpy:2490
translate russian muerte_closet_ed2f83fb:

    # "Caes en el suelo, por el dolor intenso y la pérdida de sangre."
    "Вы падаете на пол от невыносимой боли и потери крови."

# game/script.rpy:2492
translate russian muerte_closet_5c6ab507:

    # J "No sabes jugar muy bien, [povname]."
    J "Не очень-то ты умеешь играть, [povname]."

# game/script.rpy:2493
translate russian muerte_closet_3c529790:

    # "Sintiendo la luz de la luna fría filtrándose por las ventanas, caes en el inconsciente."
    "Чувствуя, как холодный лунный свет проникает сквозь окно, вы теряете сознание."

# game/script.rpy:2501
translate russian muerte_baño_503dcb72:

    # "Te sientes a salvo."
    "Кажется, тут безопасно."

# game/script.rpy:2503
translate russian muerte_baño_5172f0a6:

    # "Pero entonces, escuchas como el pomo se agita."
    "Но вдруг дверная ручка начинает греметь."

# game/script.rpy:2504
translate russian muerte_baño_4328316e:

    # J "¡[povname]!, ¡Te atrapé!"
    J "[povname]! Нашёл!"

# game/script.rpy:2505
translate russian muerte_baño_39c9e21f:

    # "No respondes."
    "Вы не отвечаете."

# game/script.rpy:2507
translate russian muerte_baño_269c9c28:

    # "La puerta es golpeada y se escuchan golpes estruendosos."
    "Дверь сотрясается от ударов, грохот гулко раздаётся в помещении."

# game/script.rpy:2508
translate russian muerte_baño_a553fa9d:

    # J "¡Déjame entrar!, ¡Ya gané!"
    J "Пусти меня! Я победил!"

# game/script.rpy:2509
translate russian muerte_baño_9790d876:

    # "Te quedas en silencio."
    "Вы продолжаете молчать."

# game/script.rpy:2510
translate russian muerte_baño_883eb8e0:

    # "Quizás se canse y se vaya."
    "Может, он устанет и уйдёт."

# game/script.rpy:2511
translate russian muerte_baño_14360a18:

    # J "…"
    J "..."

# game/script.rpy:2513
translate russian muerte_baño_47accf77:

    # J "¡Ábreme!"
    J "Открывай!"

# game/script.rpy:2514
translate russian muerte_baño_83b0fc52:

    # "La puerta se sacude y te encoges ante la sorpresa."
    "Дверь начинает дрожать, и вы вздрагиваете от удивления."

# game/script.rpy:2515
translate russian muerte_baño_9bb27832:

    # "Un golpe contundente choca contra la puerta, luego otro, y otro."
    "За первым ударом следует ещё один, и ещё."

# game/script.rpy:2517
translate russian muerte_baño_45fa5a2d:

    # "Hasta que la madera cede."
    "Пока, наконец, дерево не трескается."

# game/script.rpy:2520
translate russian muerte_baño_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:2521
translate russian muerte_baño_411c2304:

    # "El modo en que dice tu nombre es tenebroso, con los dientes apretados y en un gruñido."
    "То, как он произносит ваше имя, звучит жутко: сквозь стиснутые зубы, с глухим рычанием."

# game/script.rpy:2523
translate russian muerte_baño_8c3abdc5:

    # "No alcanzas a hacer nada cuando Jeff se abalanza sobre ti con cuchillo en mano."
    "Вы не успеваете ничего предпринять, как Джефф бросается на вас с ножом."

# game/script.rpy:2534
translate russian muerte_sala_8a9907ec:

    # "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    "Вы терпеливо сидите в тишине, надеясь, что время пролетит быстрее."

# game/script.rpy:2536
translate russian muerte_sala_68fc838e:

    # "Pero un crujido frente a ti te pretrifica."
    "Но скрип прямо перед вами заставляет застыть."

# game/script.rpy:2539
translate russian muerte_sala_14360a18:

    # J "…"
    J "..."

# game/script.rpy:2540
translate russian muerte_sala_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2541
translate russian muerte_sala_65711022:

    # J "¿Si sabes que tienes que esconderte?"
    J "Ты же знаешь, что нужно было прятаться?"

# game/script.rpy:2542
translate russian muerte_sala_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:2543
translate russian muerte_sala_0d97ff77:

    # J "Oh bueno, será."
    J "Ну, уже поздно."

# game/script.rpy:2545
translate russian muerte_sala_17198994:

    # "Jeff te sujeta del cuello, ahorcándote."
    "Джефф хватает вас за горло и начинает душить."

# game/script.rpy:2549
translate russian muerte_sala_ac1e07ed:

    # "Y entonces sientes que te perforan en el costado."
    "А потом вы чувствуете, как бок пронзает резкая боль."

# game/script.rpy:2551
translate russian muerte_sala_b230520b:

    # J "Esto fue… demasiado fácil."
    J "...Слишком легко."

# game/script.rpy:2560
translate russian supervivencia_8_0c2bf72f:

    # "Te arrastras lo más silenciosamente posible debajo de la cama, y esperas."
    "Вы как можно тише заползаете под кровать и замираете в ожидании."

# game/script.rpy:2562
translate russian supervivencia_8_cec7c6dd:

    # "Escuchas crujidos suaves y continuos."
    "Раздаётся тихий, непрерывный скрип пола."

# game/script.rpy:2563
translate russian supervivencia_8_00a46ad7:

    # "De repente ves unos pies atravesando la puerta de tu habitación, y tu respiración se detiene."
    "Вдруг вы видите ноги, пересекающие дверной проём вашей спальни, и ваше дыхание замирает."

# game/script.rpy:2564
translate russian supervivencia_8_7de54985:

    # "Los zapatos negros de combate avanzan con lentitud, rodeando tu cama."
    "Чёрные армейские ботинки движутся медленно, обходя вашу кровать по кругу."

# game/script.rpy:2565
translate russian supervivencia_8_e1168643:

    # "Tu observas, rezando porque se vaya pronto."
    "Вы следите за ними, молясь, чтобы он поскорее ушёл."

# game/script.rpy:2566
translate russian supervivencia_8_64d1793c:

    # "La persona se queda unos momentos más, para después retirarse con la misma lentitud."
    "Он ещё несколько секунд стоит неподвижно, затем так же медленно удаляется."

# game/script.rpy:2567
translate russian supervivencia_8_78463db0:

    # "Sientes que puedes respirar."
    "Вы наконец можете вдохнуть."

# game/script.rpy:2568
translate russian supervivencia_8_417015fd:

    # "Te quedas unos momentos, para después volver a pensar en qué hacer."
    "Несколько секунд вы лежите неподвижно, потом начинаете думать, что делать дальше."

# game/script.rpy:2575
translate russian supervivencia_9_3235a01c:

    # "Corres de puntillas al baño y cierras la puerta con seguro."
    "Вы на цыпочках добираетесь до ванной и запираете дверь."

# game/script.rpy:2576
translate russian supervivencia_9_9fd87df2:

    # "Te metes en la tina, tomando resguardo detrás de la cortina."
    "Затем забираетесь в ванну, укрываясь за занавеской."

# game/script.rpy:2578
translate russian supervivencia_9_f727f90f:

    # "Esperas pacientemente, escuchando el sonido de alguien abriendo puertas y moviendo cosas."
    "Вы терпеливо ждёте, прислушиваясь — слышно, как кто-то открывает двери и передвигает вещи."

# game/script.rpy:2579
translate russian supervivencia_9_2f4ff68d:

    # "De repente, silencio."
    "И вдруг — тишина."

# game/script.rpy:2586
translate russian supervivencia_10_3c33d576:

    # "Disimuladamente, vas a la sala y te escondes detrás del sofá."
    "Вы незаметно выбираетесь в гостиную и прячетесь за диваном."

# game/script.rpy:2587
translate russian supervivencia_10_8a9907ec:

    # "Esperas pacientemente, en silencio, esperando que el tiempo pase rápidamente."
    "Затаившись, молча ждёте, надеясь, что время пролетит быстрее."

# game/script.rpy:2588
translate russian supervivencia_10_ce617998:

    # "…"
    "..."

# game/script.rpy:2589
translate russian supervivencia_10_807ef186:

    # "Aunque… estás en un lugar demasiado expuesto."
    "Хотя... место слишком открытое."

# game/script.rpy:2597
translate russian supervivencia_11_e25e3544:

    # "Entras al closet y te quedas en silencio, escuchando el latido de tu corazón en tus oídos."
    "Вы забираетесь в шкаф и замираете, слыша, как громко стучит в ушах ваше сердце."

# game/script.rpy:2598
translate russian supervivencia_11_dd5f1273:

    # "Esperas segundos, que se vuelven eternos mientras escuchas el sonido de una persona abriendo puertas y removiendo cosas."
    "Вы ждёте — несколько секунд кажутся бесконечностью, пока вы слышите, как кто-то открывает двери и передвигает вещи."

# game/script.rpy:2599
translate russian supervivencia_11_223c4185:

    # "Tus esperanzas se están agotando."
    "Надежда понемногу угасает."

# game/script.rpy:2600
translate russian supervivencia_11_d72a9fd9:

    # "No puedes ir de un lugar a otro durante toda la noche."
    "Вы ведь не можете носиться по квартире всю ночь."

# game/script.rpy:2601
translate russian supervivencia_11_e2a0e0b9:

    # "¿Cómo puede ser tan insistente?"
    "Как он может быть таким настойчивым?"

# game/script.rpy:2602
translate russian supervivencia_11_cc7fca97:

    # "El cansancio te está invadiendo, pierdes fuerzas en tus piernas."
    "Накатывает усталость — вы с трудом держитесь на ногах."

# game/script.rpy:2603
translate russian supervivencia_11_f0ceb37a:

    # "Caes lentamente sobre tus rodillas, y te apoyas contra la pared."
    "Вы медленно опускаетесь на колени и прислоняетесь к стене."

# game/script.rpy:2604
translate russian supervivencia_11_c1568c83:

    # "Ya no te importa si Jeff te atrapa."
    "Вам уже всё равно, поймает ли вас Джефф."

# game/script.rpy:2605
translate russian supervivencia_11_67c49334:

    # "Que se joda él y su estúpido juego."
    "К чёрту его и эту тупую игру."

# game/script.rpy:2606
translate russian supervivencia_11_2c222d01:

    # "De repente, escuchas un suspiro pesado desde algún lugar de tu departamento."
    "Вдруг из глубины квартиры доносится тяжёлый, протяжный вздох."

# game/script.rpy:2608
translate russian supervivencia_11_0c22c3d8:

    # "Lentamente y con sigilo, te asomas por la abertura del closet."
    "Вы медленно, стараясь не шуметь, выглядываете через щель в дверце шкафа."

# game/script.rpy:2613
translate russian supervivencia_11_1ea55987:

    # "Jeff está en tu sala, iluminado sutilmente por la luz de la luna que se filtra por la ventana."
    "В гостиной стоит Джефф, освещённый тусклым лунным светом, пробивающимся сквозь окно."

# game/script.rpy:2614
translate russian supervivencia_11_d16bb677:

    # "Tiene el cuchillo a la mano, lo que te hace pensar que tuviste suerte de poder evitarlo."
    "В руке у него нож — в этот момент вы понимаете, что вам невероятно повезло ускользнуть от него."

# game/script.rpy:2615
translate russian supervivencia_11_d8b555fb:

    # J "¡Sé que me escuchas [povname]!"
    J "Я знаю, что ты меня слышишь, [povname]!"

# game/script.rpy:2616
translate russian supervivencia_11_6a59e688:

    # J "¡Tu ganas esta ronda!"
    J "Этот раунд за тобой!"

# game/script.rpy:2617
translate russian supervivencia_11_afdb86b5:

    # "El cansancio te abandona por un instante, reemplazado por euforia."
    "Усталость на миг отступает, сменяясь эйфорией."

# game/script.rpy:2618
translate russian supervivencia_11_615deda3:

    # J "Pero no olvides que te estaré vigilando."
    J "Но не забывай — я буду следить за тобой."

# game/script.rpy:2619
translate russian supervivencia_11_4f075332:

    # "Eso era un hecho que ya tenías claro."
    "Вы и так это знаете."

# game/script.rpy:2622
translate russian supervivencia_11_c726c171:

    # "Ya te visitó al hospital y te siguió a tu casa."
    "Он уже приходил в больницу и преследовал вас до дома."

# game/script.rpy:2623
translate russian supervivencia_11_8955a1e2:

    # "No está de más decir que ya no te sientes a salvo en ninguna parte."
    "Так что неудивительно, что теперь вы нигде не чувствуете себя в безопасности."

# game/script.rpy:2626
translate russian supervivencia_11_0f2e0ca2:

    # "Escuchas que la puerta principal se abre y se cierra, y eso te llena de un alivio que te hizo caer inconsciente en tu lugar."
    "Вы слышите, как хлопает входная дверь — это приносит такое облегчение, что вы просто теряете сознание на месте."

# game/script.rpy:2627
translate russian supervivencia_11_c7c6f2d0:

    # "De todas maneras, ¿Cómo pudo burlar a los policías ese maniaco?"
    "Хотя, как вообще этот псих смог перехитрить полицию?"

# game/script.rpy:2628
translate russian supervivencia_11_baeb4af9:

    # "Una de tres."
    "Есть три варианта."

# game/script.rpy:2629
translate russian supervivencia_11_0273c1af:

    # "Uno, mató a los policías. Es el escenario más latoso, ya que eso involucraría muchos más policías."
    "Первый — он убил полицейских. Самый утомительный сценарий, ведь тогда подключатся ещё больше копов."

# game/script.rpy:2630
translate russian supervivencia_11_3f0caf85:

    # "Dos, los policías no lo vieron. Lo que te causa una decepción inmensa."
    "Второй — полицейские просто его не заметили. И это вызывает у вас горькое разочарование."

# game/script.rpy:2631
translate russian supervivencia_11_f6a136af:

    # "Y tres, Jeff es muy bueno escabulléndose."
    "И третий — Джефф слишком хорошо умеет скрываться."

# game/script.rpy:2633
translate russian supervivencia_11_867f8734:

    # "Aún no sabías cómo lo hacía."
    "Вы всё ещё понятия не имеете, как у него это выходит."

# game/script.rpy:2634
translate russian supervivencia_11_9d31e13f:

    # "Quizás lo sepas en un futuro, o quizás no."
    "Может, когда-нибудь и узнаете. А может, и нет."

# game/script.rpy:2635
translate russian supervivencia_11_6efa74f7:

    # "El tiempo lo dirá."
    "Время покажет."

# game/script.rpy:2652
translate russian supervivencia_11_26da947c:

    # "El día siguiente estaba… extrañamente calmo."
    "Следующий день выдался... странно спокойным."

# game/script.rpy:2653
translate russian supervivencia_11_8cf397f4:

    # "La noche anterior apenas pudiste dormir decentemente, dentro del closet cabe decir."
    "Прошлой ночью вам почти не удалось нормально выспаться — если сон в шкафу вообще можно было назвать сном."

# game/script.rpy:2654
translate russian supervivencia_11_1cff0ed2:

    # "El alivio de sentir que el acecho hacia ti terminó, aunque sea un día, agotó las fuerzas de tu cuerpo."
    "Ощущение, что преследование хотя бы на день прекратилось, словно выжало из вас все силы."

# game/script.rpy:2655
translate russian supervivencia_11_8de1c803:

    # "Por lo que despertaste en el espacio reducido del closet, con un cuerpo adolorido."
    "Проснувшись в тесном пространстве шкафа, вы чувствуете ломоту во всём теле."

# game/script.rpy:2657
translate russian supervivencia_11_973ee163:

    # "Lo primero que haces al despertar es asomarte por la ventana, y no sabes si reír o llorar cuando ves la misma patrulla de ayer en el mismo lugar."
    "Первое, что вы делаете — выглядываете в окно. И не знаете, смеяться или злиться, когда видите ту же патрульную машину, стоящую на том же месте."

# game/script.rpy:2658
translate russian supervivencia_11_6d297368:

    # "¿En serio Jeff se coló a tu departamento tan fácilmente?"
    "Неужели Джефф действительно так просто проник в вашу квартиру?"

# game/script.rpy:2659
translate russian supervivencia_11_c2789734:

    # "Revisas las cerraduras, y no están rotas."
    "Вы проверяете все замки — никаких поломок."

# game/script.rpy:2660
translate russian supervivencia_11_6a4b7a71:

    # "Eso quiere decir que Jeff, además de burlar a los policías, no forzó la entrada."
    "Значит, Джефф не только обошёл полицию, но и как-то проник без взлома."

# game/script.rpy:2661
translate russian supervivencia_11_67c38527:

    # "¿Qué mierda?"
    "Какого чёрта?"

# game/script.rpy:2662
translate russian supervivencia_11_c7c92968:

    # "Todo se estaba volviendo demasiado conveniente, sobre todo para una historia de suspenso."
    "Всё становится подозрительно удобным, особенно для истории с напряжённым сюжетом."

# game/script.rpy:2663
translate russian supervivencia_11_4218019b:

    # "Antes, sabías con seguridad que Jeff se trataba de un humano, pero ahora… estabas empezando a considerar otras opciones."
    "Раньше вы были уверены, что Джефф — просто человек, но теперь... начинаете допускать и другие варианты."

# game/script.rpy:2664
translate russian supervivencia_11_5d0a5525:

    # "Aseguras nuevamente la puerta de entrada, y consideras comprar un nuevo pestillo."
    "Вы снова запираете входную дверь и задумываетесь, не купить ли дополнительный засов."

# game/script.rpy:2665
translate russian supervivencia_11_f7478a4d:

    # "Pero primero lo primero, tienes que desayunar."
    "Но сперва завтрак."

# game/script.rpy:2668
translate russian supervivencia_11_a8299a43:

    # "Abres tu nevera, y la decepción te invade al ver que está prácticamente vacía."
    "Открыв холодильник, вы чувствуете прилив разочарования — внутри почти пусто."

# game/script.rpy:2669
translate russian supervivencia_11_11222b78:

    # "Hay dos tomates arrugados, una caja de jugo que tras agitarla ves que está media vacía y la mitad de un limón."
    "Пара сморщенных помидоров, наполовину пустой пакет сока — вы потрясли его, чтобы проверить — и половинка лимона."

# game/script.rpy:2670
translate russian supervivencia_11_5834a163:

    # "Recuerdas que desechaste lo que estaba en mal estado el día anterior, pero también que no fuiste de compras."
    "Вы вспоминаете, что вчера выбросили всё испорченное, но в магазин так и не сходили."

# game/script.rpy:2673
translate russian supervivencia_11_c57b6a18:

    # "Te preparas para salir, tomas tu billetera y te diriges al recibidor de tu departamento, jugando con tus llaves."
    "Собираясь уходить, вы берёте кошелёк и подходите к прихожей, играя ключами в руке."

# game/script.rpy:2674
translate russian supervivencia_11_c928dbb5:

    # "Miras por última vez el interior de tu departamento y te retiras, colocando llave a todas las cerraduras."
    "Вы в последний раз оглядываетесь на свою квартиру и выходите, запирая все замки."

# game/script.rpy:2675
translate russian supervivencia_11_68216be4:

    # "Un momento de duda te detiene, y revisas la ampolleta que está en la esquina superior de tu puerta."
    "Но в последний момент сомнение заставляет вас остановиться — вы поднимаете взгляд на лампочку в углу над дверью."

# game/script.rpy:2676
translate russian supervivencia_11_0dbfbecb:

    # "Excelente, ahí estaba la habilidad superhumana de Jeff para meterse en tu departamento, se llamaba llaves de repuesto."
    "Вот оно, сверхчеловеческое умение Джеффа проникать в вашу квартиру — запасные ключи."

# game/script.rpy:2677
translate russian supervivencia_11_64f32b62:

    # "No puedes creer que realmente te hayas olvidado de eso."
    "Трудно поверить, что вы действительно забыли об этом."

# game/script.rpy:2683
translate russian supervivencia_11_77b85f45:

    # "El minimarket que visitas es uno que está a dos calles de tu departamento, al lado contrario donde se encuentra la tienda de películas."
    "Минимаркет, куда вы заходите, находится всего в двух кварталах от вашей квартиры, с противоположной стороны от видеопроката."

# game/script.rpy:2684
translate russian supervivencia_11_53b9be7a:

    # "No tiene tantas cosas, pero sirve para momentos desesperados como el de ahora."
    "Ассортимент там небогат, но для срочного случая, вроде сегодняшнего, вполне сгодится."

# game/script.rpy:2685
translate russian supervivencia_11_52d85d04:

    # "Buscas los esenciales entre los pasillos y las neveras."
    "Вы проходите между рядами и холодильниками, выбирая самое необходимое."

# game/script.rpy:2698
translate russian character_6_05eb9169:

    # "Yendo a la caja, sientes un movimiento por el rabillo del ojo derecho. Un movimiento de color blanco."
    "Подходя к кассе, краем правого глаза замечаете движение. Что-то белое."

# game/script.rpy:2701
translate russian character_6_3bf44f40:

    # "Tu corazón se agita, pero la presencia de muchas personas te regresa algo de confianza, por lo que disimuladamente sigues el movimiento."
    "Сердце ускоряет ритм, но толпа людей вокруг возвращает немного уверенности, и вы незаметно следуете за движением."

# game/script.rpy:2702
translate russian character_6_7213ea58:

    # "Te acercas a un estante de bocadillos."
    "Вы подходите к полке со снеками."

# game/script.rpy:2706
translate russian character_6_e4bf0893:

    # "Entre las etiquetas de los precios, bolsas coloridas y envases brillantes, puedes percibir un destello blanco, oculto del otro lado de la estantería."
    "Между ценниками, пёстрыми упаковками и блестящими банками виднеется слабый белый отблеск, будто кто-то прячется по ту сторону стеллажа."

# game/script.rpy:2707
translate russian character_6_687a84d7:

    # "Te inclinas en la esquina, asomándote lentamente por el costado."
    "Вы осторожно наклоняетесь за угол, медленно выглядывая из-за него."

# game/script.rpy:2708
translate russian character_6_96f69104:

    # "Puedes percibir la postura de alguien agachado, usando ropa blanca."
    "Вы можете различить только силуэт пригнувшегося человека в белой одежде."

# game/script.rpy:2710
translate russian character_6_aecd6a06:

    # Stranger "¡[povname]!"
    Stranger "[povname]!"

# game/script.rpy:2714
translate russian character_6_31dcdf50:

    # "El llamado de tu nombre te sobresalta, lo que te hace caer tus compras."
    "Неожиданный оклик заставляет вас вздрогнуть, и корзинки выскальзывают из рук."

# game/script.rpy:2718
translate russian character_6_f089efd8:

    # DR "Oh, lo siento mucho."
    DR "Ох, извини!"

# game/script.rpy:2720
translate russian character_6_815988b2:

    # "Ves con asombro al Dr. Salazar apoyándose en una rodilla, empezando a recoger tus compras."
    "С изумлением вы видите, как доктор Салазар опускается на одно колено и начинает собирать ваши продукты."

# game/script.rpy:2721
translate russian character_6_97213182:

    # pov "¿Dr. Salazar?"
    pov "Доктор Салазар?"

# game/script.rpy:2723
translate russian character_6_5fc03f89:

    # DR "Puedes llamarme Paul."
    DR "Можешь звать меня Пол."

# game/script.rpy:2724
translate russian character_6_e47b23e0:

    # pov "… Ok, Paul, ¿Qué haces aquí?"
    pov "...Ладно, Пол, что ты тут делаешь?"

# game/script.rpy:2725
translate russian character_6_1f9a1a27:

    # "No sabes si es que el acoso de Jeff te estaba empezando a afectar más de lo que te gustaría, pero te convenciste de que sólo estabas tomando precauciones."
    "Вы сами не понимаете, от страха ли перед Джеффом становитесь такими подозрительными, но вы убеждаете себя, что просто принимаете меры предосторожности."

# game/script.rpy:2726
translate russian character_6_62c93f76:

    # "No necesitabas otro acosador en la lista."
    "Вам и так хватает одного сталкера."

# game/script.rpy:2727
translate russian character_6_cd144de8:

    # DR "Terminé mi turno hace unas horas. Me gusta venir a un café que está por aquí y no pude evitar verte por la ventana, ¿Espero no te moleste?"
    DR "Моя смена закончилась пару часов назад. Я заходил в кафе поблизости, но случайно увидел тебя в окне. Надеюсь, не мешаю?"

# game/script.rpy:2728
translate russian character_6_6d8913c8:

    # "Salazar se ríe levemente, incómodo, como si quisiera sacarse de encima una mala imagen."
    "Салазар нервно усмехается, словно пытаясь избавиться от плохого впечатления."

# game/script.rpy:2729
translate russian character_6_b33a44f1:

    # pov "Oh, ok."
    pov "А, ладно."

# game/script.rpy:2731
translate russian character_6_4dc51fa0:

    # "Te agachas también, terminando de recoger tus cosas."
    "Вы тоже приседаете, помогая собрать оставшиеся продукты."

# game/script.rpy:2733
translate russian character_6_f40d0710:

    # DR "¿Cómo te sientes?, ¿Cómo está tu… eh, ojo?"
    DR "Как ты себя чувствуешь? Как там твой... э-э, глаз?"

# game/script.rpy:2734
translate russian character_6_0afd9c3e:

    # "Te llevas instintivamente una mano a tu párpado izquierdo, cubierto por el parche."
    "Вы машинально касаетесь левого века, скрытого под повязкой."

# game/script.rpy:2735
translate russian character_6_303da67a:

    # pov "Ya no duele."
    pov "Уже не болит."

# game/script.rpy:2737
translate russian character_6_255f15a7:

    # DR "Eso es bueno. ¿Vas a querer una prótesis?"
    DR "Хорошо. Думаешь поставить протез?"

# game/script.rpy:2738
translate russian character_6_e055bbf8:

    # pov "Depende, ¿Puedo escoger el color?"
    pov "Не знаю, а цвет можно выбрать?"

# game/script.rpy:2739
translate russian character_6_469bddb4:

    # DR "Por supuesto, puedes escoger el color y tamaño de la iris, de la pupila e incluso de la esclerótica."
    DR "Конечно, можно подобрать цвет и размер радужки, зрачка и даже склеры."

# game/script.rpy:2740
translate russian character_6_32d1fbee:

    # pov "Eso es genial, lo pensaré."
    pov "Отлично, тогда подумаю об этом."

# game/script.rpy:2741
translate russian character_6_af08cda3:

    # "El Dr. Salazar asiente con una leve sonrisa."
    "Доктор Салазар кивает, слегка улыбаясь."

# game/script.rpy:2742
translate russian character_6_267ba007:

    # DR "¿Te ayudo con tus compras?"
    DR "Помочь донести продукты?"

# game/script.rpy:2743
translate russian character_6_cd2823d8:

    # pov "Gracias, eres muy amable."
    pov "Спасибо, мило с твоей стороны."

# game/script.rpy:2744
translate russian character_6_0cde97e4:

    # DR "Lo que sea por mi paciente."
    DR "Для моего пациента — что угодно."

# game/script.rpy:2746
translate russian character_6_7ee2abaf:

    # "Salazar te ayuda a llevar tus cosas a la caja, y tú pagas."
    "Салазар помогает вам отнести покупки к кассе, и вы расплачиваетесь."

# game/script.rpy:2748
translate russian character_6_533ade6e:

    # "Ustedes salen de la tienda, y se quedan un momento en la acera. Llevas una de las bolsas en tu mano, mientras él lleva la otra."
    "Вы выходите из магазина и на минуту задерживаетесь на тротуаре: один пакет в вашей руке, второй несёт он."

# game/script.rpy:2751
translate russian character_6_7dd1623a:

    # DR "¿Haces las compras?"
    DR "Закупаешься?"

# game/script.rpy:2752
translate russian character_6_622c7d22:

    # pov "Es para mi desayuno."
    pov "Да, кое-что к завтраку."

# game/script.rpy:2754
translate russian character_6_73ee964d:

    # "Salazar te mira con ojos sorprendidos, para después negar con la cabeza."
    "Салазар смотрит на вас с удивлением, а потом качает головой."

# game/script.rpy:2755
translate russian character_6_f683b72e:

    # DR "Ya es mediodía, [povname]."
    DR "Уже полдень, [povname]."

# game/script.rpy:2756
translate russian character_6_f176499f:

    # "Te encoges ante el regaño. El te lo diga un doctor te hace sentir más culpable."
    "Вы съёживаетесь от упрёка. Слышать такое от доктора вдвойне стыдно."

# game/script.rpy:2757
translate russian character_6_998e4620:

    # pov "Lo sé… Hubo circunstancias, pero ahora estoy en eso."
    pov "Знаю... были обстоятельства, но я уже исправляюсь."

# game/script.rpy:2758
translate russian character_6_a96da2e2:

    # "Él te mira en silencio unos segundos, para después carraspear contra su puño."
    "Он молча смотрит на вас несколько секунд, затем прочищает горло, прикрыв рот кулаком."

# game/script.rpy:2760
translate russian character_6_bb37a5b2:

    # DR "Puedo… Invitarte a desayunar."
    DR "Я мог бы... пригласить тебя на завтрак."

# game/script.rpy:2761
translate russian character_6_8ee09a5d:

    # pov "¿Cómo dices?"
    pov "Что?"

# game/script.rpy:2762
translate russian character_6_bc99059a:

    # DR "Ehem, dije que quisiera invitarte a desayunar."
    DR "Кхм, я сказал, что хотел бы пригласить тебя на завтрак."

# game/script.rpy:2763
translate russian character_6_8993a8bd:

    # "Ves la postura nerviosa de Salazar y el evidente color en sus mejillas."
    "Вы замечаете нервозную позу Салазара и явный румянец на его щеках."

# game/script.rpy:2764
translate russian character_6_4358d10c:

    # "Ladeas la cabeza, con curiosidad."
    "Вы с любопытством наклоняете голову."

# game/script.rpy:2765
translate russian character_6_36d56e5e:

    # pov "¿Cómo en una cita?"
    pov "Как на свидание?"

# game/script.rpy:2767
translate russian character_6_826fda20:

    # "Salazar tose contra su mano, pero se recupera rápidamente."
    "Салазар кашляет в кулак, но быстро берёт себя в руки."

# game/script.rpy:2768
translate russian character_6_4953c45c:

    # DR "No quisiera que me malinterpretaras, pero… "
    DR "Не хочу, чтобы ты поняли меня неправильно, но..."

# game/script.rpy:2770
translate russian character_6_0a2071ff:

    # DR "Sí, supongo que sí, te estoy invitando a una cita."
    DR "Да, пожалуй, я приглашаю тебя на свидание."

# game/script.rpy:2771
translate russian character_6_68b49a5f:

    # "Te quedas un momento en silencio, considerando la propuesta."
    "Вы на мгновение замолкаете, обдумывая предложение."

# game/script.rpy:2772
translate russian character_6_020aca84:

    # "Siempre tienes la opción de coquetear con las personas que te encuentres, pero eso no quiere decir que vayas en serio."
    "Вы всегда могли позволить себе немного флирта в общении с людьми — но это никогда не означало чего-то серьёзного."

# game/script.rpy:2773
translate russian character_6_e96ca752:

    # "Es divertido ver la reacción de los demás con tus provocaciones, y quizás había un poco de esperanza en ti de que eso te llevara a algún lado."
    "Было забавно наблюдать за реакцией людей на ваши поддразнивания; и, возможно, ещё теплилась надежда, что однажды это перерастёт во что-то большее."

# game/script.rpy:2774
translate russian character_6_ac5bd01b:

    # "Y ahora, tienes la opción, de ir más allá."
    "И теперь у вас есть возможность зайти дальше."

# game/script.rpy:2778
translate russian character_6_e88686cd:

    # pov "Me encantaría."
    pov "С удовольствием."

# game/script.rpy:2779
translate russian character_6_ca90f25e:

    # "La expresión de Salazar se iluminó ante tu respuesta."
    "Лицо Салазара просияло от вашего ответа."

# game/script.rpy:2780
translate russian character_6_577d3f71:

    # "Con timidez, él alzó su mano libre hacia ti."
    "Он немного застенчиво протягивает вам свободную руку."

# game/script.rpy:2782
translate russian character_6_4a559a8f:

    # "Tomas la mano de él con la tuya, entrelazando tus dedos con los de él."
    "Вы берёте его за руку, переплетая пальцы."

# game/script.rpy:2784
translate russian character_6_dfbd0bec:

    # "Caminan en silencio por la calle, y dejas que él te guíe, ya que era él el que te estaba invitando."
    "Вы идёте по улице молча, позволяя ему вести вас — ведь это он вас пригласил."

# game/script.rpy:2786
translate russian character_6_9b30cebb:

    # "De repente, ante ustedes, un niño se cae sobre el asfalto y pega un grito desgarrador."
    "Внезапно перед вами на асфальт падает ребёнок, издавая душераздирающий крик."

# game/script.rpy:2787
translate russian character_6_0d7134b5:

    # "Los padres se acercan con rapidez, levantándolo sobre el suelo y dejando ver que su rodilla tenía una herida sangrante."
    "Родители бросаются к нему, поднимают с земли, и становится видно окровавленную ссадину на колене."

# game/script.rpy:2790
translate russian character_6_8ff1257a:

    # DR "Déjenme ver, soy doctor."
    DR "Позвольте, я врач."

# game/script.rpy:2791
translate russian character_6_43dd9291:

    # "Observas que Salazar se acerca con rapidez y seriedad, sacando de uno de sus bolsillos desinfectante para manos."
    "Вы наблюдаете, как Салазар быстро и сосредоточенно подходит к ребёнку, доставая из кармана антисептик для рук."

# game/script.rpy:2792
translate russian character_6_02ee6558:

    # "Sonríes levemente ante la atención de Salazar."
    "Вы невольно улыбаетесь, глядя на его заботливость."

# game/script.rpy:2793
translate russian character_6_03862fdb:

    # "Tal vez… Necesitabas un hombre atento después de todo, que respetara la vida."
    "Возможно... вам и вправду нужен был внимательный мужчина — тот, кто ценит жизнь."

# game/script.rpy:2794
translate russian character_6_c67f906d:

    # "Incomparable con…"
    "В отличие от..."

# game/script.rpy:2795
translate russian character_6_e73d7375:

    # "Bueno, ya no tenías por qué pensar en él."
    "Впрочем, теперь вам вовсе незачем думать о нём."

# game/script.rpy:2803
translate russian character_6_7082cb48:

    # "De repente, un gran peso te derrumba sobre el suelo, y te inmoviliza."
    "Внезапно тяжёлый вес сбивает вас с ног, обездвиживая."

# game/script.rpy:2804
translate russian character_6_aa32fcfa:

    # "Sientes que algo húmedo cae sobre tus mejillas, es tibio."
    "Что-то влажное падает вам на щёки. Оно тёплое."

# game/script.rpy:2809
translate russian character_6_0f74d63c:

    # "Miras arriba, y presencias una expresión que no esperabas ver nunca."
    "Вы поднимаете взгляд и наблюдаете выражение, которого никогда не ожидали увидеть."

# game/script.rpy:2810
translate russian character_6_8fdf740a:

    # "Jeff lloraba inconsolablemente sobre ti."
    "Джефф безутешно рыдает над вами."

# game/script.rpy:2811
translate russian character_6_0b612e01:

    # J "¿Cómo pudiste [povname]...?"
    J "Как ты могли, [povname]..?"

# game/script.rpy:2812
translate russian character_6_3729e321:

    # J "¿No soy suficiente para ti…?"
    J "Разве меня тебе не достаточно..?"

# game/script.rpy:2813
translate russian character_6_218a5cd7:

    # "Sientes que tu voz se quiebra ante el desconcierto."
    "Вы чувствуете, как голос дрожит от недоумения."

# game/script.rpy:2814
translate russian character_6_caf5688d:

    # "Por suerte, aparentemente las personas presenciaron todo, lo que indicaba que todo acabaría."
    "К счастью, вокруг есть люди — свидетели происходящего. Значит, скоро всё должно закончиться."

# game/script.rpy:2815
translate russian character_6_b8ac4475:

    # "Jeff sería atrapado, y tú podrías volver a tu vida."
    "Джеффа поймают, и вы наконец сможете вернуться к своей жизни."

# game/script.rpy:2816
translate russian character_6_ebbe04c7:

    # J "¡¿No soy suficiente para ti?!"
    J "Разве меня тебе не достаточно?!"

# game/script.rpy:2820
translate russian character_6_c236e479:

    # "El estruendoso alarido de Jeff te saca de tus pensamientos, y es tarde cuando ves que él alza un cuchillo, y lo entierra en tu pecho."
    "Оглушительный крик Джеффа вырывает вас из ступора, и вы слишком поздно замечаете, как он взмахивает ножом и вгоняет лезвие в вашу грудь."

# game/script.rpy:2822
translate russian character_6_8c9097ed:

    # J "¡[povname]! ¡[povname]!"
    J "[povname]! [povname]!"

# game/script.rpy:2824
translate russian character_6_a814095e:

    # "Con cada pronunciación de tu nombre, te ganabas una nueva a apuñalada, que agitaba tu cuerpo y derramaba más sangre."
    "Каждый раз, произнося ваше имя, он наносит новый удар — тело сотрясается, и кровь хлещет всё сильнее."

# game/script.rpy:2826
translate russian character_6_ff7e2fda:

    # "Y la expresión de él no cambió, estaba llena de dolor."
    "А выражение его лица не меняется — всё так же полно боли."

# game/script.rpy:2831
translate russian character_6_90d48e96:

    # "Con tu visión borrosa, alcanzas a ver que Jeff es sujetado e inmovilizado al suelo, mientras sigue gritando."
    "Сквозь мутнеющее зрение вы успеваете заметить, как Джеффа валят на землю и обездвиживают, пока он по-прежнему кричит."

# game/script.rpy:2832
translate russian character_6_64bca0e6:

    # "Tu párpado pesa, y lo cierras."
    "Веко тяжелеет, и вы закрываете глаз."

# game/script.rpy:2834
translate russian character_6_2f61cc9b:

    # "Suspiras por última vez, con el alivio de que Jeff pudo ser atrapado."
    "Вы вздыхаете в последний раз, ощущая облегчение — Джеффа поймали."

# game/script.rpy:2835
translate russian character_6_927655ce:

    # "A costa tuya, claro."
    "Пусть и ценой вашей жизни."

# game/script.rpy:2836
translate russian character_6_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2837
translate russian character_6_4d8c8a5b:

    # "Sientes que tus mejillas son sujetadas por manos mojadas y pegajosas."
    "Чьи-то влажные, липкие ладони обхватывают ваши щёки."

# game/script.rpy:2839
translate russian character_6_880e2969:

    # "Escuchas la voz desgarradora de Salazar, quien te sujeta desesperado."
    "Вы слышите надрывный голос Салазара, который в отчаянии держит вас."

# game/script.rpy:2840
translate russian character_6_eb222b0a:

    # DR "¡Quédate conmigo!, ¡T-te ayudaré!"
    DR "Держись! Я-я помогу!"

# game/script.rpy:2841
translate russian character_6_56c83cbd_1:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:2842
translate russian character_6_71250745:

    # "Sonríes levemente, sintiendo la calidez del abrazo de Salazar."
    "Вы слабо улыбаетесь, ощущая тепло его объятий."

# game/script.rpy:2843
translate russian character_6_cab4b5cc:

    # "Eso era lo que querías, ¿No?"
    "Этого вы и хотели, верно?"

# game/script.rpy:2846
translate russian character_6_e899acaa:

    # "{b}Final IV: Ninguno De Ustedes Ganó{/b}"
    "{b}Концовка IV: Никто из вас не победил{/b}"

# game/script.rpy:2853
translate russian historia_continua_3_6e478ad6:

    # pov "Lo siento, pero no puedo."
    pov "Прости, но я не могу."

# game/script.rpy:2855
translate russian historia_continua_3_4ff694b6:

    # "La decepción se refleja en la expresión de Salazar."
    "Разочарование отражается на лице Салазара."

# game/script.rpy:2856
translate russian historia_continua_3_63fa2dad:

    # DR "O-oh, ¿Tienes a alguien más…?"
    DR "О-ох, у тебя уже есть кто-то..?"

# game/script.rpy:2857
translate russian historia_continua_3_e3b8f462:

    # pov "No es eso. Hoy tengo cosas que hacer, pero otro día podríamos salir, ¿Si?"
    pov "Дело не в этом. Просто у меня на сегодня другие планы, но мы можем встретиться в другой раз, ладно?"

# game/script.rpy:2858
translate russian historia_continua_3_cbebe1b6:

    # "La mueca de Salazar no parece cambiar ante tus palabras, pero con tu silencio expectante, Salazar sonríe levemente."
    "Выражение лица Салазара остаётся таким же, но после вашего молчаливого ожидания он всё-таки слегка улыбается."

# game/script.rpy:2860
translate russian historia_continua_3_c53042ff:

    # DR "Entiendo, otro día será."
    DR "Понимаю, тогда в другой раз."

# game/script.rpy:2861
translate russian historia_continua_3_b7451d16:

    # DR "Al menos déjame acompañarte a dejar tus compras."
    DR "Тогда позволь хотя бы проводить тебя."

# game/script.rpy:2862
translate russian historia_continua_3_47f77fee:

    # "Reflexionas sus palabras por un momento."
    "Вы на мгновение задумываетесь над его словами."

# game/script.rpy:2863
translate russian historia_continua_3_880f22d8:

    # "Definitivamente, no estaría demás que te acompañe."
    "В самом деле, ничего плохого не случится, если он вас проводит."

# game/script.rpy:2864
translate russian historia_continua_3_05f76a79:

    # "Se sentiría seguro, de hecho."
    "Да и с ним куда безопаснее."

# game/script.rpy:2865
translate russian historia_continua_3_c0662a5c:

    # pov "Claro."
    pov "Хорошо."

# game/script.rpy:2866
translate russian historia_continua_3_d96ad88a:

    # "Guías el camino, y ustedes caminan en silencio durante todo el trayecto."
    "Вы идёте впереди, и всю дорогу молчите."

# game/script.rpy:2868
translate russian historia_continua_3_8ab55e4e:

    # "Ustedes llegan a la entrada de tu edificio, y al ver que Salazar no tenía intenciones de dejarte ahí, seguiste guiando el camino hasta detenerte en la puerta de tu departamento."
    "Когда вы доходите до входа в ваш дом, становится ясно, что Салазар не собирается останавливаться; вы ведёте его дальше, пока не останавливаетесь у двери вашей квартиры."

# game/script.rpy:2869
translate russian historia_continua_3_cdcf2858:

    # pov "Aquí es."
    pov "Пришли."

# game/script.rpy:2873
translate russian historia_continua_3_8ed0c5b2:

    # "Salazar se queda mirando la puerta por unos segundos, para después sonreír levemente, mientras extendía la bolsa que él cargaba hacia ti."
    "Салазар несколько секунд смотрит на дверь, потом легко улыбается и протягивает вам пакет, который нёс."

# game/script.rpy:2875
translate russian historia_continua_3_557c98d0:

    # DR "Fue un placer verte, [povname]."
    DR "Было приятно встретиться, [povname]."

# game/script.rpy:2876
translate russian historia_continua_3_8285c797:

    # pov "Igualmente, Dr- digo, Paul."
    pov "Взаимно, док— То есть, Пол."

# game/script.rpy:2877
translate russian historia_continua_3_3bdd1c5d:

    # "La sonrisa de Salazar se extiende, recuperando un poco de la energía que había perdido desde tu rechazo."
    "Улыбка Салазара становится чуть шире — в ней снова появляется жизнь, утраченная после вашего отказа."

# game/script.rpy:2878
translate russian historia_continua_3_9b6f9b74:

    # DR "Puedes llamarme cuando quieras."
    DR "Можешь звонить в любое время."

# game/script.rpy:2879
translate russian historia_continua_3_17f813e3:

    # pov "Lo tengo en cuenta."
    pov "Буду иметь в виду."

# game/script.rpy:2880
translate russian historia_continua_3_8fb45874:

    # "Salazar se dirige a la salida, no sin antes voltearse por un momento hacia ti para despedirse con la mano."
    "Салазар направляется к выходу, но перед тем, как уйти, оборачивается и машет вам рукой на прощание."

# game/script.rpy:2882
translate russian historia_continua_3_63d3a8c2:

    # "Tu le correspondiste la despedida, y te quedaste en el pasillo hasta que ya no lo viste."
    "Вы машете ему в ответ и остаётесь в коридоре, пока его фигура не скрывается из виду."

# game/script.rpy:2883
translate russian historia_continua_3_66eed3d3:

    # "Suspiras levemente, volviendo a la realidad de tu situación."
    "Вы тихо вздыхаете, возвращаясь к реальности."

# game/script.rpy:2884
translate russian historia_continua_3_b4ec8c82:

    # "Cierto, debes tener cuidado."
    "Точно, нужно быть осторожнее."

# game/script.rpy:2886
translate russian historia_continua_3_99ed2004:

    # "Desbloqueas cada cerradura y entras a tu departamento, volviendo a cerrar con llave. También te cercioras de ocultar las llaves de repuesto dentro de tu departamento."
    "Вы открываете замки один за другим и входите в квартиру, сразу же запирая за собой дверь. На всякий случай убеждаетесь, что запасные ключи надёжно спрятаны внутри."

# game/script.rpy:2889
translate russian historia_continua_3_580ae45f:

    # "Dejas tus compras en la cocina y guardas todo donde corresponde y te quedas con lo que harás el desayuno."
    "Вы разбираете пакеты на кухне, раскладываете покупки по местам и задумываетесь, что приготовить на завтрак."

# game/script.rpy:2890
translate russian historia_continua_3_b4c12402:

    # "Enciendes la cafetera, con el nuevo café que compraste, y pones dos rebanadas de pan en la tostadora."
    "Включаете кофеварку со свежими зёрнами, и кладёте в тостер два ломтика хлеба."

# game/script.rpy:2891
translate russian historia_continua_3_6f628d8c:

    # "No te habías dado cuenta lo tarde que era cuando Salazar te lo señaló."
    "Вы и не заметили, насколько было поздно, пока Салазар не указал вам на это."

# game/script.rpy:2892
translate russian historia_continua_3_f872d74f:

    # "Debiste tener mucho cansancio como para haber dormido casi 10 horas después de que Jeff entrara a tu departamento en la madrugada."
    "Должно быть, вы и вправду сильно устали — проспали почти 10 часов после того, как Джефф вломился в вашу квартиру под утро."

# game/script.rpy:2893
translate russian historia_continua_3_a51cd2ee:

    # "Te asomas en la ventana nuevamente, y la patrulla sigue ahí. No sabes si es la misma o es otra diferente, pero al menos tienes protección, ¿No?"
    "Вы снова заглядываете в окно — патрульная машина всё ещё там. Вы не знаете, та же это машина или другая, но, по крайней мере, у вас есть защита, верно?"

# game/script.rpy:2894
translate russian historia_continua_3_f3aae7ee:

    # "Que chiste."
    "Смешно."

# game/script.rpy:2895
translate russian historia_continua_3_7dfce5f3:

    # "Con tu café listo y tus tostadas, tomas asiento en la pequeña mesa que tú llamas comedor."
    "С чашкой кофе и тостами вы садитесь за небольшой столик, который называете обеденным."

# game/script.rpy:2898
translate russian historia_continua_3_b8ff8107:

    # "Estás a media mordida, cuando escuchas un toque en la puerta."
    "Вы уже откусили кусочек, как вдруг раздаётся стук в дверь."

# game/script.rpy:2899
translate russian historia_continua_3_315084b7:

    # "Miras con sigilo la puerta, en silencio."
    "Вы настораживаетесь и молча смотрите на дверь."

# game/script.rpy:2900
translate russian historia_continua_3_e8adb890:

    # C "¡[povname]!, ¡Soy yo!"
    C "[povname]! Это я!"

# game/script.rpy:2902
translate russian historia_continua_3_4b0806eb:

    # "Te relajas cuando te das cuenta de que se trata de Cindy."
    "Вы расслабляетесь, поняв, что это Синди."

# game/script.rpy:2903
translate russian historia_continua_3_0692bb80:

    # "Vaya, estás siendo bastante popular hoy."
    "Ого, сегодня вы, кажется, в центре внимания."

# game/script.rpy:2909
translate russian historia_continua_3_4be66cfe:

    # "Vas y abres la puerta, dejando espacio para que ella entre. Cindy pasa con rapidez."
    "Вы подходите и открываете дверь, освобождая место, чтобы она могла войти. Синди быстро заскакивает внутрь."

# game/script.rpy:2910
translate russian historia_continua_3_fc361df2:

    # pov "¿Qué te trae por aquí?"
    pov "Что тебя сюда привело?"

# game/script.rpy:2911
translate russian historia_continua_3_8d3ebc3a:

    # "No era sorpresa que ella supiera donde vivías, ya que no es la primera vez que viene."
    "Неудивительно, что она знает, где вы живёте — она у вас уже не в первый раз."

# game/script.rpy:2912
translate russian historia_continua_3_af62866e:

    # "Al ser ella y su padre, tu jefe, las únicas dos personas que conoces en la ciudad, cuando sucedía un imprevisto como un cheque rebotado o algún percance en la tienda, te iban a avisar personalmente a tu departamento."
    "Поскольку она и её отец, ваш начальник, единственные, кого вы знаете в этом городе, при любом непредвиденном случае — например, с чеком или какой-нибудь заминкой в магазине — они всегда приходили сообщить вам лично."

# game/script.rpy:2913
translate russian historia_continua_3_4d61f914:

    # C "¿Han atrapado al tipo?"
    C "Того парня поймали?"

# game/script.rpy:2914
translate russian historia_continua_3_c191c049:

    # "Te encoges de hombros."
    "Вы пожимаете плечами."

# game/script.rpy:2915
translate russian historia_continua_3_beae822b:

    # pov "Nop."
    pov "Нет."

# game/script.rpy:2917
translate russian historia_continua_3_bd074926:

    # C "Tienes que tomarte en serio esto, aunque hayan pedido protección para ti, no es seguro confiar 100 por ciento en eso."
    C "Тебе нужно отнестись к этому серьёзнее. Даже если тебе дали охрану, полагаться на неё на все сто нельзя."

# game/script.rpy:2918
translate russian historia_continua_3_9f749202:

    # pov "Así que viste la patrulla de afuera."
    pov "Значит, ты видела патрульную машину снаружи."

# game/script.rpy:2919
translate russian historia_continua_3_236f4eec:

    # "Cindy se lleva una mano a la frente."
    "Синди кладёт ладонь на лоб."

# game/script.rpy:2920
translate russian historia_continua_3_29bfff94:

    # C "Si... también fueron muchos periodistas a la tienda. Se filtró que trabajas ahí, así que tuve que cerrar temporalmente."
    C "Ага... и ещё куча журналистов припёрлась в магазин. Просочилось, что ты там работаешь, так что пришлось временно закрыться."

# game/script.rpy:2921
translate russian historia_continua_3_df0e7779:

    # pov "Oh, lo siento…"
    pov "Ох, прости..."

# game/script.rpy:2924
translate russian historia_continua_3_46966592:

    # "Cindy suspira, tomando asiento en el sofá."
    "Синди вздыхает и садится на диван."

# game/script.rpy:2925
translate russian historia_continua_3_aee14885:

    # C "Nada de esto es tu culpa, [povname]. Debí haberte acompañado ese día."
    C "Это не твоя вина, [povname]. Я должна была пойти с тобой тогда."

# game/script.rpy:2927
translate russian historia_continua_3_ba993bdc:

    # "Tu la acompañas, tomando asiento junto a ella."
    "Вы садитесь рядом с ней."

# game/script.rpy:2928
translate russian historia_continua_3_185493bf:

    # pov "No digas eso. No tenías cómo saberlo."
    pov "Не говори так. Ты никак не могла это предугадать."

# game/script.rpy:2929
translate russian historia_continua_3_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:2930
translate russian historia_continua_3_a0c93c73:

    # "Cindy carraspea, cambiando de tema."
    "Синди откашливается, пытаясь сменить тему."

# game/script.rpy:2931
translate russian historia_continua_3_8ed23b80:

    # C "Así que… ¿Sabes detalles de tu caso?"
    C "Так... ты знаешь какие-нибудь подробности по делу?"

# game/script.rpy:2932
translate russian historia_continua_3_59363691:

    # pov "Oh, bueno, parece que saben quién es."
    pov "Ну, похоже, они уже знают, кто он."

# game/script.rpy:2933
translate russian historia_continua_3_ae6301f1:

    # "El interés de Cindy fue picado."
    "Синди явно заинтересовалась."

# game/script.rpy:2934
translate russian historia_continua_3_f098d53b:

    # C "¿En serio, quién?"
    C "Серьёзно? Кто?"

# game/script.rpy:2935
translate russian historia_continua_3_08c59881:

    # pov "Un tipo que tiene un body count de 27… De víctimas me refiero."
    pov "Тип с рекордом в 27 тел... я имею в виду жертв."

# game/script.rpy:2936
translate russian historia_continua_3_e5231df3:

    # "Cindy te miró expectante, ignorando tu broma. Parece que ella no ha visto las noticias."
    "Синди внимательно на вас смотрит, проигнорировав шутку. Видимо, она ещё не успела посмотреть новости."

# game/script.rpy:2937
translate russian historia_continua_3_150467e1:

    # "Claro, en qué momento si tenía que lidiar con ahuyentar a los periodistas invasivos."
    "Ну да, ей не до этого — она и так возилась с навязчивыми репортёрами."

# game/script.rpy:2938
translate russian historia_continua_3_36d0d8fc:

    # pov "Parece que soy la primera víctima que dejó con vida."
    pov "Видимо, я первая жертва, которую он оставил в живых."

# game/script.rpy:2939
translate russian historia_continua_3_7f76495a_1:

    # C "…"
    C "..."

# game/script.rpy:2941
translate russian historia_continua_3_7c8042a4:

    # "Cindy deja escapar un quejido."
    "Синди недовольно простонала."

# game/script.rpy:2942
translate russian historia_continua_3_94273819:

    # C "Lo que faltaba, un asesino serial se fijó en ti."
    C "Ещё не хватало, чтобы серийный убийца к тебе привязался."

# game/script.rpy:2943
translate russian historia_continua_3_0d380f65:

    # "Ella no está equivocada."
    "Она, впрочем, не ошибается."

# game/script.rpy:2944
translate russian historia_continua_3_be8b6c00:

    # pov "No dijeron que fuera un asesino serial."
    pov "Вообще, они не говорили, что он серийный убийца."

# game/script.rpy:2945
translate russian historia_continua_3_0a0b6675:

    # C "Si asesinó a más de tres personas y lleva haciéndolo desde hace años, cae en la categoría de asesino serial."
    C "Если он убил больше трёх человек и делает это годами — это и есть серийный убийца."

# game/script.rpy:2946
translate russian historia_continua_3_9fba3a17:

    # pov "¿... De acuerdo?"
    pov "...Ладно?"

# game/script.rpy:2947
translate russian historia_continua_3_35d7c0d4:

    # C "¿Viste si sentía placer al atacarte?"
    C "Ты не заметили, испытывал ли он удовольствие при нападении?"

# game/script.rpy:2948
translate russian historia_continua_3_7b9f7faa:

    # pov "Oh, si, definitivamente."
    pov "О да, ещё какое."

# game/script.rpy:2949
translate russian historia_continua_3_3df569b1:

    # "Recordabas cómo él insistía que admitieras que tenías miedo, incluso querer saber los detalles."
    "Вы вспоминаете, как он требовал, чтобы вы признали свой страх — даже хотел услышать подробности."

# game/script.rpy:2950
translate russian historia_continua_3_c19dc43b:

    # "Ups, ¿quizás debiste guardarte eso para ti?"
    "Ой, может, стоило держать это при себе?"

# game/script.rpy:2951
translate russian historia_continua_3_57673a71:

    # "Cindy se llevó unos dedos a la barbilla, pensativa mientras murmuraba para sí misma."
    "Синди касается пальцами подбородка и задумчиво бормочет себе под нос."

# game/script.rpy:2952
translate russian historia_continua_3_9cb9b2b7:

    # C "Entonces caería en la categoría dos…"
    C "Тогда он попадает во вторую категорию..."

# game/script.rpy:2953
translate russian historia_continua_3_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:2954
translate russian historia_continua_3_685f2ad0:

    # pov "¿Cindy?"
    pov "Синди?"

# game/script.rpy:2956
translate russian historia_continua_3_77b5f57c:

    # C "¿Si?"
    C "А?"

# game/script.rpy:2957
translate russian historia_continua_3_9088b2fd:

    # pov "¿Puedo preguntarte algo, sin que te enojes?"
    pov "Можно спросить кое-что? Только не злись."

# game/script.rpy:2958
translate russian historia_continua_3_26a803bc:

    # C "..."
    C "..."

# game/script.rpy:2959
translate russian historia_continua_3_a1d004ff:

    # C "¿De acuerdo?"
    C "Хорошо?"

# game/script.rpy:2960
translate russian historia_continua_3_674cadde:

    # pov "Tu… ¿cómo sabes tanto término policial?"
    pov "Откуда ты... знаешь столько полицейских терминов?"

# game/script.rpy:2962
translate russian historia_continua_3_7f76495a_2:

    # C "…"
    C "..."

# game/script.rpy:2963
translate russian historia_continua_3_e427fb3d:

    # "Cindy se quedó congelada, mirándote con sorpresa."
    "Синди замирает, удивлённо глядя на вас."

# game/script.rpy:2964
translate russian historia_continua_3_edaefa11:

    # C "… Yo…"
    C "Я..."

# game/script.rpy:2965
translate russian historia_continua_3_17cdfe7f:

    # "Entonces, ella suspiró pesadamente."
    "Она глубоко вздыхает."

# game/script.rpy:2966
translate russian historia_continua_3_38b8fcfd:

    # C "Yo… nunca quise ser una clerk en la tienda de mi padre."
    C "Я... никогда не хотела работать в отцовском магазине продавщицей."

# game/script.rpy:2967
translate russian historia_continua_3_39d30cc7:

    # pov "Si, nadie quiere serlo."
    pov "Ага, никто не хочет."

# game/script.rpy:2969
translate russian historia_continua_3_db5c18cc:

    # "Cindy te dedicó una mirada reprochadora ante tu comentario sarcástico, pero continuó."
    "Синди бросает на вас укоризненный взгляд за сарказм, но всё же продолжает."

# game/script.rpy:2971
translate russian historia_continua_3_0a34c7c7:

    # C "… Estudié criminología por 4 años, y luego entré a la academia de policía."
    C "...Я 4 года изучала криминологию, а потом поступила в полицейскую академию."

# game/script.rpy:2972
translate russian historia_continua_3_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:2973
translate russian historia_continua_3_e60958a4:

    # "Vaya, eso no te lo esperabas."
    "Ого, вот этого вы точно не ожидали."

# game/script.rpy:2974
translate russian historia_continua_3_efb29312:

    # "Cindy… no daba la imagen de querer ser algo en la vida, mucho menos policía."
    "Синди... никогда не производила впечатление человека, у которого есть цели в жизни — уж тем более стать полицейским."

# game/script.rpy:2975
translate russian historia_continua_3_5eff10dd:

    # C "Desde que tengo memoria, quise ser detective, y me esforcé mucho para graduarme con honores."
    C "Сколько себя помню, я хотела стать детективом и очень старалась, чтобы окончить учёбу с отличием."

# game/script.rpy:2977
translate russian historia_continua_3_dba45f40:

    # C "Pero cuando entré a la academia, la tienda de mi papá fue robada."
    C "Но когда я поступила в академию, магазин моего отца ограбили."

# game/script.rpy:2978
translate russian historia_continua_3_96471828:

    # C "Atraparon a los culpables, pero como uno de ellos era el sobrino de un teniente, los dejaron libres."
    C "Виновных, конечно, поймали, но один из них оказался племянником лейтенанта — и их просто отпустили."

# game/script.rpy:2979
translate russian historia_continua_3_4973b8f8:

    # C "El sistema se jacta de ser una red justa, pero tiene demasiados agujeros."
    C "Система хвалится своей справедливостью, но в ней слишком много дыр."

# game/script.rpy:2980
translate russian historia_continua_3_51e63619:

    # C "Abandoné la academia y trabajo para papá desde entonces."
    C "Я ушла из академии и с тех пор работаю у отца."

# game/script.rpy:2981
translate russian historia_continua_3_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:2982
translate russian historia_continua_3_379b78fc:

    # pov "Vaya, quién lo diría."
    pov "Вот так сюрприз."

# game/script.rpy:2983
translate russian historia_continua_3_33e75352:

    # "Cindy farfulló entre dientes."
    "Синди что-то ворчит сквозь зубы."

# game/script.rpy:2984
translate russian historia_continua_3_e17d2dcb:

    # C "No seas condescendiente conmigo."
    C "Только не надо меня жалеть."

# game/script.rpy:2985
translate russian historia_continua_3_773064b2:

    # pov "¡No, no!, para nada. Me llama la atención, eso es todo."
    pov "Нет-нет! Вовсе не жалею. Мне просто стало интересно, и всё."

# game/script.rpy:2986
translate russian historia_continua_3_dde94ff2:

    # pov "Eso explica porque fuiste tan… hosca con el teniente Wes y la detective Sean."
    pov "Это объясняет, почему ты была такой... жёсткой с лейтенантом Уэсом и детективом Шон."

# game/script.rpy:2987
translate russian historia_continua_3_a75b9407:

    # "Cindy resopló, desviando la mirada."
    "Синди фыркает и отводит взгляд."

# game/script.rpy:2988
translate russian historia_continua_3_5bd494a4:

    # C "… ¿Tú crees que ellos están haciendo un buen trabajo?"
    C "...Думаешь, они хорошо справляются со своей работой?"

# game/script.rpy:2989
translate russian historia_continua_3_50d7397c:

    # pov "Bueno, no sé en qué estarán ahora, pero tengo el presentimiento de que están esforzándose."
    pov "Ну, не знаю, чем они занимаются сейчас, но у меня есть ощущение, что они стараются."

# game/script.rpy:2991
translate russian historia_continua_3_e768f91b:

    # "Cindy bajó la mirada, desganada."
    "Синди уныло опускает взгляд."

# game/script.rpy:2992
translate russian historia_continua_3_cc6a8bcf:

    # C "Espero que el sistema no te falle como me falló a mí, [povname]."
    C "Надеюсь, система не подведёт тебя так, как подвела меня, [povname]."

# game/script.rpy:2993
translate russian historia_continua_3_bedd6fae_3:

    # pov "…"
    pov "..."

# game/script.rpy:2994
translate russian historia_continua_3_2c8b7da9:

    # pov "Creo que eso es lo segundo más lindo que me has dicho."
    pov "Думаю, это вторая приятная вещь, что ты мне когда-либо говорила."

# game/script.rpy:2995
translate russian historia_continua_3_652599d5:

    # "Cindy alza una ceja."
    "Синди поднимает бровь."

# game/script.rpy:2996
translate russian historia_continua_3_5162cf85:

    # C "¿Qué fue lo primero?"
    C "А какая первая?"

# game/script.rpy:2997
translate russian historia_continua_3_b4d1e299:

    # pov "Que sientes paz conmigo."
    pov "Ты говорила, что со мной спокойно."

# game/script.rpy:2998
translate russian historia_continua_3_7f76495a_3:

    # C "…"
    C "..."

# game/script.rpy:2999
translate russian historia_continua_3_5bee2644:

    # C "Si, bueno, sigo pensando eso."
    C "Ну, да, я всё ещё так считаю."

# game/script.rpy:3000
translate russian historia_continua_3_c2f5a848:

    # "Ustedes se quedan un momento en silencio, hasta que tu lo rompes."
    "На некоторое время повисла тишина, пока вы не нарушили её."

# game/script.rpy:3001
translate russian historia_continua_3_f01ece38:

    # pov "Me alegra que nos estemos llevando bien, Cin."
    pov "Я рады, что мы нашли общий язык, Син."

# game/script.rpy:3002
translate russian historia_continua_3_7f76495a_4:

    # C "…"
    C "..."

# game/script.rpy:3004
translate russian historia_continua_3_7bcd459a:

    # "Ella sonríe levemente."
    "Она слегка улыбается."

# game/script.rpy:3005
translate russian historia_continua_3_04d03096:

    # C "Yo también."
    C "Я тоже."

# game/script.rpy:3007
translate russian historia_continua_3_49dfef4e:

    # C "Bueno, ya es hora de irme."
    C "Ну ладно, мне пора."

# game/script.rpy:3008
translate russian historia_continua_3_591d5e9a:

    # pov "¿Tan pronto?"
    pov "Уже уходишь?"

# game/script.rpy:3009
translate russian historia_continua_3_d9e4690d:

    # C "Sólo vine a ver cómo estabas. Por lo que veo, estás bien."
    C "Я зашла только убедиться, что с тобой всё в порядке. Похоже, так и есть."

# game/script.rpy:3010
translate russian historia_continua_3_b0adbbb3:

    # pov "Pero…"
    pov "Но..."

# game/script.rpy:3011
translate russian historia_continua_3_e6774950:

    # "Cindy se gira hacia ti, interrogante."
    "Синди оборачивается к вам с вопросительным взглядом."

# game/script.rpy:3012
translate russian historia_continua_3_0e11cf84:

    # C "¿Sucede algo?"
    C "Что такое?"

# game/script.rpy:3013
translate russian historia_continua_3_bedd6fae_4:

    # pov "…"
    pov "..."

# game/script.rpy:3014
translate russian historia_continua_3_93b41066:

    # "No, no podías decirle sobre el juego de Jeff."
    "Нет, вы не можете рассказать ей об игре Джеффа."

# game/script.rpy:3015
translate russian historia_continua_3_b1b4e2b6:

    # pov "No, nada, regresa segura."
    pov "Нет, ничего. Береги себя."

# game/script.rpy:3016
translate russian historia_continua_3_d979128e:

    # "Cindy te miró un par de segundos en silencio, para después marcharse."
    "Синди несколько секунд молча смотрит на вас, а потом уходит."

# game/script.rpy:3018
translate russian historia_continua_3_04040263:

    # "Viendo que estabas por tu cuenta, suspiras pesadamente."
    "Оставшись наедине, вы тяжело вздыхаете."

# game/script.rpy:3020
translate russian historia_continua_3_0d299175:

    # "Pasas el resto del día en tu departamento. Sentías que iba a ser una noche tranquila."
    "Остаток дня вы проводите в квартире. Кажется, что ночь будет спокойной."

# game/script.rpy:3022
translate russian historia_continua_3_52bfd283:

    # "Pero cuando llegó la noche, cambiaste de parecer."
    "Но когда ночь наступила, вы передумали."

# game/script.rpy:3023
translate russian historia_continua_3_b1b7917d:

    # "Jeff dijo que cada vez que lo evadieras, él se alejaría. Así que técnicamente, deberías estar a salvo esta noche."
    "Джефф говорил, что каждый раз, когда вы сумеете скрыться, он будет отступать. Значит, по логике, сегодня вам ничего не грозит."

# game/script.rpy:3024
translate russian historia_continua_3_49481fcc:

    # "Pero por otro lado, era Jeff de quien se estaba hablando."
    "Но с другой стороны — речь шла о Джеффе."

# game/script.rpy:3025
translate russian historia_continua_3_b9d0a718:

    # "El tipo es un demente cobarde tramposo, no puedes confiar en las palabras de él."
    "Он — трусливый и лживый маньяк; доверять его словам нельзя."

# game/script.rpy:3026
translate russian historia_continua_3_38d35ff0:

    # "Así que decides salir."
    "Поэтому вы решаете выйти наружу."

# game/script.rpy:3027
translate russian historia_continua_3_3c7d5376:

    # "¿A dónde?, No importa, sólo te vas a donde haya una gran multitud de gente, donde sea imposible atacarte."
    "Куда? Неважно. Главное — туда, где много людей, где вас никто не сможет атаковать."

# game/script.rpy:3031
translate russian historia_continua_3_00d75c6d:

    # "Entonces llegas a una calle llena de bares."
    "Вскоре вы оказываетесь на улице, полной баров."

# game/script.rpy:3032
translate russian historia_continua_3_1536b002:

    # "Las luces pintan de colores las calles y la música se escapa suavemente de los lugares."
    "Огни раскрашивают асфальт в мягкие цвета, а из дверей просачивается музыка."

# game/script.rpy:3033
translate russian historia_continua_3_259cb52c:

    # "Te encoges de hombros y escoges un bar para entrar."
    "Вы пожимаете плечами и выбираете бар."

# game/script.rpy:3035
translate russian historia_continua_3_e47b98c0:

    # "El lugar es tranquilo y una cantidad considerable de gente, perfecto."
    "Внутри довольно людно, но спокойно — в самый раз."

# game/script.rpy:3036
translate russian historia_continua_3_c585b154:

    # "No querías ir a un lugar medio vacío, era como ser un ciervo e ir a la pradera."
    "Вы не хотели попасть в полупустое место — это всё равно, что оленю выйти на открытую поляну."

# game/script.rpy:3037
translate russian historia_continua_3_6eb35a29:

    # "Pero tampoco a un lugar concurrido, es lo que menos necesitas en tu estado paranóico."
    "Но и не в чересчур многолюдное место. Это последнее, что вам нужно в вашем параноидальном состоянии."

# game/script.rpy:3038
translate russian historia_continua_3_1757ebc6:

    # "Así que te sientas en la barra y te preparas para pedir."
    "Так что вы садитесь у стойки и готовитесь сделать заказ."

# game/script.rpy:3048
translate russian character_7_ae51851c:

    # "Te sientas a esperar pacientemente por tu pedido."
    "Вы спокойно ждёте свой заказ."

# game/script.rpy:3050
translate russian character_7_0be6b95e:

    # "Y es entonces que sientes que alguien toma el lugar junto a ti."
    "И тут чувствуете, как кто-то садится рядом."

# game/script.rpy:3055
translate russian character_7_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3056
translate russian character_7_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:3057
translate russian character_7_4f58d838:

    # J "¿Qué?"
    J "Что?"

# game/script.rpy:3058
translate russian character_7_4a819460:

    # J "Puedo ir a donde quiera, este es un lugar público."
    J "Я могу ходить, куда захочу. Это общественное место."

# game/script.rpy:3059
translate russian character_7_27eb3e50:

    # pov "¿Y no crees que con sólo gritar puedo hacer que te arresten?"
    pov "А ты не думаешь, что стоит мне закричать — тебя сразу схватят?"

# game/script.rpy:3060
translate russian character_7_ceb04f78:

    # "Jeff te mira por encima del hombro, con desinterés ante tu amenaza."
    "Джефф глядит на вас через плечо, явно не впечатлённый угрозой."

# game/script.rpy:3061
translate russian character_7_ddb12ed8:

    # J "Claro, puedes hacer eso, y en lo que se tarda en venir un policía, puedo arrancarte el otro ojo y huir de nuevo."
    J "Конечно, можешь попробовать. За то время, что придёт полиция, я успею выдрать тебе второй глаз и снова сбежать."

# game/script.rpy:3062
translate russian character_7_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3063
translate russian character_7_0ed17e2e:

    # pov "Eres un cobarde."
    pov "Трус."

# game/script.rpy:3064
translate russian character_7_619e8b75:

    # J "Heh."
    J "Хех."

# game/script.rpy:3065
translate russian character_7_d0bb4f6e:

    # J "Soy muchas cosas."
    J "Я многое из себя представляю."

# game/script.rpy:3066
translate russian character_7_14719ca7:

    # "El bartender se acerca y Jeff le hace una seña para hacer un pedido."
    "Бармен подходит, и Джефф жестом показывает, что готов сделать заказ."

# game/script.rpy:3067
translate russian character_7_f8c65899:

    # J "Un whisky, seco."
    J "Виски. Без льда."

# game/script.rpy:3068
translate russian character_7_b5fa365e:

    # pov "¿Oh?, ¿A la vieja escuela?, ¿O sólo te estás luciendo?"
    pov "О, по старинке? Или просто выпендриваешься?"

# game/script.rpy:3069
translate russian character_7_c8a16db8:

    # J "¿Ante quién me voy a lucir?, ¿Tú?"
    J "Перед кем мне выпендриваться? Перед тобой?"

# game/script.rpy:3075
translate russian character_7_793ab315:

    # pov "Parece que te esfuerzas mucho en llamar mi atención."
    pov "Кажется, ты уж слишком стараешься привлечь моё внимание."

# game/script.rpy:3076
translate russian character_7_e6054fc3:

    # J "Yo no…"
    J "Я не..."

# game/script.rpy:3077
translate russian character_7_87867b62:

    # J "Cállate…"
    J "Заткнись..."

# game/script.rpy:3080
translate russian character_7_fed5583c:

    # pov "No fuiste tan sutil al dejarme vivir."
    pov "Было не очень-то незаметно с твоей стороны оставить меня в живых."

# game/script.rpy:3081
translate russian character_7_93227467:

    # "Escuchas como él chasquea la lengua con molestia bajo la bandana."
    "Вы слышите, как он раздражённо цокает языком под повязкой."

# game/script.rpy:3086
translate russian ruta_normal_21_9734f240:

    # pov "Soy la primera persona que dejas con vida."
    pov "Я же первый человек, которого ты оставил в живых."

# game/script.rpy:3087
translate russian ruta_normal_21_f3b9b8f0:

    # pov "Creo que eso me hace al menos relevante para ti."
    pov "Полагаю, это делает меня как минимум значимыми для тебя."

# game/script.rpy:3088
translate russian ruta_normal_21_2dd0672f:

    # "Tus palabras parecen llamar la atención de él."
    "Кажется, ваши слова зацепили его."

# game/script.rpy:3089
translate russian ruta_normal_21_f47a32d5:

    # J "No te creas tan especial, no eres la primera."
    J "Не льсти себе, ты не первые."

# game/script.rpy:3090
translate russian ruta_normal_21_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3091
translate russian ruta_normal_21_9175b202:

    # pov "¿Oh?"
    pov "Да ну?"

# game/script.rpy:3092
translate russian ruta_normal_21_fe9f694b:

    # "El bartender llega con tu pedido y el de él."
    "Бармен подходит и ставит на стойку ваши заказы."

# game/script.rpy:3096
translate russian ruta_normal_21_8e268cc4:

    # "Jeff envuelve con sus dedos el vaso de vidrio, y baja un poco la bandana de su boca. Puedes ver un poco de su perfil."
    "Джефф обхватывает пальцами стакан и чуть спускает повязку со рта. Вы замечаете часть его профиля."

# game/script.rpy:3097
translate russian ruta_normal_21_a802543e:

    # "Es raro verlo… tan tranquilo."
    "Странно видеть его... таким спокойным."

# game/script.rpy:3098
translate russian ruta_normal_21_867d10ca:

    # J "Fue un error de principiante… La chica era linda conmigo, y sufrió lo mismo que yo, así que me compadecí."
    J "Ошибка новичка... Девушка была добра ко мне и пережила то же, что и я. Я сжалился."

# game/script.rpy:3099
translate russian ruta_normal_21_fd3f1530:

    # "Jeff bebió un sorbo, para después dar vueltas el vaso, revolviendo la bebida en su interior."
    "Джефф делает глоток, затем начинает вращать стакан, перемешивая жидкость внутри."

# game/script.rpy:3100
translate russian ruta_normal_21_c635a4a6:

    # J "No sé si sigue viva, pero la última vez que la vi quería matarme, así que ya no me importa."
    J "Не знаю, жива ли она ещё. Но в последний раз, когда я её видел, она хотела меня убить. Так что мне уже всё равно."

# game/script.rpy:3101
translate russian ruta_normal_21_193fb22c:

    # pov "Wow, tú siendo compasivo, eso es nuevo."
    pov "Ого, ты можешь быть сострадательным? Вот это новости."

# game/script.rpy:3102
translate russian ruta_normal_21_c599da4c:

    # pov "¿Y qué fue lo que ustedes sufrieron, sí se puede saber?"
    pov "И что же вы оба пережили, если не секрет?"

# game/script.rpy:3103
translate russian ruta_normal_21_d49e5dbf:

    # "Él señaló con la punta de su índice su propio rostro."
    "Он указывает пальцем на своё лицо."

# game/script.rpy:3104
translate russian ruta_normal_21_eec8464c:

    # J "Las quemaduras."
    J "Ожоги."

# game/script.rpy:3105
translate russian ruta_normal_21_4a2bd410:

    # pov "Ah."
    pov "А."

# game/script.rpy:3106
translate russian ruta_normal_21_50ec702c:

    # pov "¿Puedo… preguntar cómo pasó?"
    pov "Можно... спросить, как это случилось?"

# game/script.rpy:3107
translate russian ruta_normal_21_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3108
translate russian ruta_normal_21_ac7ea2df:

    # J "En un accidente… me vertí ácido encima."
    J "Несчастный случай... облил себя кислотой."

# game/script.rpy:3109
translate russian ruta_normal_21_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3113
translate russian ruta_normal_21_00be0d9b:

    # pov "Yo… lamento que te pasó eso."
    pov "Мне... жаль, что с тобой это случилось."

# game/script.rpy:3114
translate russian ruta_normal_21_25effc38:

    # J "… Seh. "
    J "...Ага."

# game/script.rpy:3115
translate russian ruta_normal_21_e1aa7efd:

    # "Jeff bebió otro sorbo de su whisky."
    "Джефф делает ещё один глоток виски."

# game/script.rpy:3120
translate russian ruta_normal_21_e5bb0ccb:

    # pov "Con accidentalmente… ¿Te refieres a que lo derramaste o te lo echaste?"
    pov "Случайно, говоришь... Ты её пролил или вылил на себя специально?"

# game/script.rpy:3121
translate russian ruta_normal_21_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3122
translate russian ruta_normal_21_6100450e:

    # J "¿Un poco las dos?"
    J "И то, и другое?"

# game/script.rpy:3123
translate russian ruta_normal_21_3ee9947e:

    # pov "Wow, simplemente… Wow."
    pov "Вау, просто... вау."

# game/script.rpy:3124
translate russian ruta_normal_21_1dcf767e:

    # "Jeff resopla. Aparenta molestarse, pero percibes la diversión en su voz."
    "Джефф фыркает. Он кажется раздражённым, но в голосе слышится веселье."

# game/script.rpy:3125
translate russian ruta_normal_21_c8d530bd:

    # J "Oh, cállate, no eres quien juzgarme."
    J "Ой, заткнись. Не тебе меня судить."

# game/script.rpy:3126
translate russian ruta_normal_21_578970d8:

    # pov "¿Eso qué quiere decir?"
    pov "Это ещё что значит?"

# game/script.rpy:3127
translate russian ruta_normal_21_f1fc5595:

    # J "Averígualo tú."
    J "Догадайся."

# game/script.rpy:3128
translate russian ruta_normal_21_e1aa7efd_1:

    # "Jeff bebió otro sorbo de su whisky."
    "Джефф делает ещё один глоток виски."

# game/script.rpy:3133
translate russian ruta_normal_22_0c4f3680:

    # pov "De todas formas, ¿A qué viniste aquí?"
    pov "Так зачем ты сюда пришёл?"

# game/script.rpy:3134
translate russian ruta_normal_22_118652d1:

    # pov "Pensé que querías mantener… “esto” entre nosotros, sin público."
    pov "Я думали, ты предпочитаешь держать... «это» между нами, без зрителей."

# game/script.rpy:3135
translate russian ruta_normal_22_1d908765:

    # J "Relájate, no te haré nada. Cumpliré con mi promesa."
    J "Расслабься, я тебя не трону. Сдержу обещание."

# game/script.rpy:3136
translate russian ruta_normal_22_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3137
translate russian ruta_normal_22_e1187afd:

    # pov "“Por ahora”, ¿No?"
    pov "«Пока что», да?"

# game/script.rpy:3138
translate russian ruta_normal_22_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3140
translate russian ruta_normal_22_5a87224c:

    # "Pones los ojos en blanco y bebes tu propia bebida."
    "Вы закатываете глаза и делаете глоток своего напитка."

# game/script.rpy:3141
translate russian ruta_normal_22_b06c570b:

    # "Ustedes se mantienen en silencio por un rato, escuchando la música del bar y el ruido de las demás personas conversando entre sí."
    "Вы оба молча сидите несколько минут, слушая музыку в баре и приглушённый гул разговоров вокруг."

# game/script.rpy:3145
translate russian ruta_normal_22_8c76e806:

    # pov "Así que… hoy fui de compras."
    pov "Ну... я сегодня ходили за покупками."

# game/script.rpy:3146
translate russian ruta_normal_22_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3147
translate russian ruta_normal_22_77e3ad29:

    # pov "Me encontré con mi doctor. No fue tan impactante como encontrarte a ti, pero fue… algo."
    pov "По дороге встретили своего врача. Не такое впечатляющее событие, как твоё появление, но... всё же."

# game/script.rpy:3148
translate russian ruta_normal_22_8c51a72f:

    # "Jeff resopla, con el borde del vaso contra sus labios."
    "Джефф фыркает, прижимая край стакана к губам."

# game/script.rpy:3149
translate russian ruta_normal_22_6546a324:

    # J "Llevar tus comestibles por ti, clásico."
    J "Ага, и помог донести сумки. Классика."

# game/script.rpy:3150
translate russian ruta_normal_22_8215b681:

    # J "No tienes que fingir que te agrada frente a él, ¿Sabes?"
    J "Можешь не делать вид, что он тебе нравится, если что."

# game/script.rpy:3151
translate russian ruta_normal_22_36c53943:

    # pov "Yo no- espera, ¿Cómo sabes eso?"
    pov "Я не— Погоди, откуда ты это знаешь?"

# game/script.rpy:3152
translate russian ruta_normal_22_6a8a3250:

    # "Jeff ladeó la cabeza burlonamente."
    "Джефф насмешливо наклоняет голову."

# game/script.rpy:3157
translate russian ruta_normal_22_38dbdc3c:

    # pov "¿Qué hiciste hoy?"
    pov "Чем ты сегодня занимался?"

# game/script.rpy:3158
translate russian ruta_normal_22_52e5fdec:

    # "Jeff se gira a ti con sorpresa."
    "Джефф с удивлением смотрит на вас."

# game/script.rpy:3159
translate russian ruta_normal_22_d314e011:

    # J "Yo… no hice mucho."
    J "Я... ничего особенного."

# game/script.rpy:3160
translate russian ruta_normal_22_afaa60ae:

    # "Él regresó su mirada al frente."
    "Он отводит взгляд вперёд."

# game/script.rpy:3161
translate russian ruta_normal_22_a99ad301:

    # J "Fui de compras…"
    J "Ходил по магазинам..."

# game/script.rpy:3162
translate russian ruta_normal_22_ac10e2fa:

    # J "Recorrí las calles…"
    J "Бродил по улицам..."

# game/script.rpy:3163
translate russian ruta_normal_22_25e9b76b:

    # J "Descansé un poco…"
    J "Немного отдохнул..."

# game/script.rpy:3164
translate russian ruta_normal_22_943e6cc7:

    # J "Y vine a este bar."
    J "И решил зайти в этот бар."

# game/script.rpy:3165
translate russian ruta_normal_22_d8be11d5:

    # "Mientras escuchas atentamente, miras que la comisura de Jeff se alarga en una sonrisa burlona, a la vez que te das cuenta."
    "Пока вы вслушиваетесь в его голос, замечаете, как уголки его рта изгибаются в язвительной улыбке — и до вас доходит."

# game/script.rpy:3170
translate russian ruta_normal_23_c6c3b4bf:

    # pov "¡Si eras tú el me estaba siguiendo!"
    pov "Так это ты за мной ходил!"

# game/script.rpy:3172
translate russian ruta_normal_23_597fec25:

    # J "¡Hahaha!"
    J "Ха-ха-ха!"

# game/script.rpy:3173
translate russian ruta_normal_23_2476690b:

    # "Lo miras con enojo, pero lejos de estar molesto, a Jeff parecía agradarle causar esa reacción en ti."
    "Вы смотрите на него сердито, но Джефф вовсе не злится — наоборот, ему явно нравится вас провоцировать."

# game/script.rpy:3174
translate russian ruta_normal_23_58c4b40a:

    # "Tomas un sorbo de tu bebida, y él hace lo mismo."
    "Вы делаете глоток своего напитка, и он делает то же самое."

# game/script.rpy:3175
translate russian ruta_normal_23_883bedb7:

    # "Cada vez que él termina de beber, se sube la bandana de nuevo, cubriendo su rostro."
    "Каждый раз, заканчивая пить, он поднимает повязку обратно, закрывая лицо."

# game/script.rpy:3176
translate russian ruta_normal_23_a73a9834:

    # "Tienen una pausa, un momento para tranquilizar la emoción anterior."
    "Вы оба делаете паузу, чтобы немного успокоиться."

# game/script.rpy:3177
translate russian ruta_normal_23_8fa24223:

    # pov "¿De… verdad no me harás nada esta noche?"
    pov "Ты... правда не будешь ничего делать сегодня?"

# game/script.rpy:3179
translate russian ruta_normal_23_a898f5e6:

    # "Jeff apoya su mejilla en su mano con aburrimiento."
    "Джефф устало опирается щекой на ладонь."

# game/script.rpy:3180
translate russian ruta_normal_23_916fd24c:

    # J "¿Por qué, ahora me tienes miedo?"
    J "А что такое, теперь ты меня боишься?"

# game/script.rpy:3181
translate russian ruta_normal_23_e431dac1:

    # pov "No es por eso… Apreciaría no ir de nuevo al hospital tan pronto después de haber salido."
    pov "Не в этом дело... Просто не хочется снова в больницу сразу после выписки."

# game/script.rpy:3182
translate russian ruta_normal_23_27dfc42a:

    # "Jeff chasquea la lengua."
    "Джефф цокает языком."

# game/script.rpy:3183
translate russian ruta_normal_23_7f1b271a:

    # J "No te preocupes, mejor disfruta que no te estoy destripando donde estás."
    J "Не волнуйся. Лучше радуйся, что я не выпотрошил тебя прямо тут."

# game/script.rpy:3184
translate russian ruta_normal_23_898b2b8f:

    # pov "Ok, eso no es tranquilizador."
    pov "Прям успокоил."

# game/script.rpy:3185
translate russian ruta_normal_23_65c6c85f:

    # "Jeff suspira, girándose hacia ti."
    "Джефф вздыхает и поворачивается к вам."

# game/script.rpy:3186
translate russian ruta_normal_23_2ed81fc1:

    # "Sus ojos, azules como el cielo, lechosos como un día nublado, te miran fijamente."
    "Его глаза — голубые, мутноватые, как небо в пасмурный день — пристально уставились на вас."

# game/script.rpy:3187
translate russian ruta_normal_23_6daada17:

    # J "Prometo que no haré nada."
    J "Обещаю, я ничего не сделаю."

# game/script.rpy:3193
translate russian ruta_normal_23_fa4b1cd9:

    # pov "¿No podrías ser así de lindo la mayoría del tiempo?"
    pov "Не мог бы ты быть таким же милым большую часть времени?"

# game/script.rpy:3194
translate russian ruta_normal_23_054948c3:

    # pov "Es una pérdida de tiempo que actúes como un loco todo el tiempo."
    pov "Зря ты постоянно строишь из себя психопата, только время тратишь."

# game/script.rpy:3195
translate russian ruta_normal_23_0cca5aa2:

    # "Crees que Jeff hizo el ademán de alzar una ceja, porque… él no tiene cejas, duh."
    "Вы подумали, что Джефф сейчас приподнял бы бровь, потому что... бровей у него нет, конечно."

# game/script.rpy:3196
translate russian ruta_normal_23_a1a780e8:

    # J "¿Y que sea un asesino?"
    J "А как же тот факт, что я убийца?"

# game/script.rpy:3197
translate russian ruta_normal_23_eec302f8:

    # pov "Sí, eso también."
    pov "Ну да, это тоже."

# game/script.rpy:3198
translate russian ruta_normal_23_8a93848e:

    # J "Huh."
    J "Хм."

# game/script.rpy:3199
translate russian ruta_normal_23_ac456684:

    # "Jeff regresa a su lugar en silencio, como si no se esperara tu respuesta."
    "Джефф откидывается назад и замолкает, будто не ожидал такого ответа."

# game/script.rpy:3200
translate russian ruta_normal_23_c0eb1e23:

    # "No lo puedes ver con claridad, pero jurarías que debajo de sus párpados negros, puedes ver un tono de rosa distinto al de las llagas de su piel."
    "Вы не видите его ясно, но готовы поклясться, что под тёмными веками мелькает розовый оттенок, не похожий на цвет ожогов."

# game/script.rpy:3203
translate russian ruta_normal_23_2ee3dfc5:

    # "Entrecierras los ojos con sospecha, y bebes un sorbo de tu bebida."
    "Вы подозрительно прищуриваетесь и делаете глоток своего напитка."

# game/script.rpy:3204
translate russian ruta_normal_23_e091b0dd:

    # pov "Eso veremos."
    pov "Посмотрим."

# game/script.rpy:3205
translate russian ruta_normal_23_968422c3:

    # "Jeff pone los ojos en blanco."
    "Джефф закатывает глаза."

# game/script.rpy:3210
translate russian ruta_normal_24_772d11fe:

    # "Ustedes guardan silencio nuevamente, esta vez se sienten más tranquilos, como si se hubieran sacudido la incomodidad anterior."
    "Вы снова замолкаете, но на этот раз тишина спокойная, словно неловкость рассеялась."

# game/script.rpy:3211
translate russian ruta_normal_24_406d6eae:

    # pov "¿Por qué haces esto, de todos modos?"
    pov "Зачем ты вообще всё это делаешь?"

# game/script.rpy:3212
translate russian ruta_normal_24_c750ec27:

    # "Jeff te mira interrogativamente."
    "Джефф смотрит на вас вопросительно."

# game/script.rpy:3213
translate russian ruta_normal_24_011a4b11:

    # pov "No sé… lo que piensas. No sé si me odias o te agrado, no sé si me quieres matar u observar."
    pov "Я не понимаю... что у тебя на уме. Не знаю, ненавидишь ты меня или я тебе нравлюсь, хочешь убить или просто понаблюдать."

# game/script.rpy:3214
translate russian ruta_normal_24_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3215
translate russian ruta_normal_24_6befebaf:

    # J "Yo tampoco lo sé con claridad."
    J "Я и сам не уверен."

# game/script.rpy:3216
translate russian ruta_normal_24_4bf18d0e:

    # J "Pierdo el control cuando se trata de ti."
    J "Я теряю контроль, когда дело касается тебя."

# game/script.rpy:3217
translate russian ruta_normal_24_2b0c247f:

    # "Jeff suelta una carcajada seca."
    "Джефф сухо усмехается."

# game/script.rpy:3219
translate russian ruta_normal_24_30a7abdf:

    # J "Siempre fui bueno improvisando, pero desde que te conocí, no sé qué mierda estoy haciendo."
    J "Раньше я всегда умел импровизировать. Но с тех пор, как встретил тебя, я понятия не имею, что вообще творю."

# game/script.rpy:3225
translate russian ruta_normal_24_5e49003c:

    # pov "Siempre fuiste bueno en esto de… matar personas."
    pov "Ты всегда хорошо справлялся... с убийствами."

# game/script.rpy:3226
translate russian ruta_normal_24_89742677:

    # pov "¿Qué es diferente ahora?"
    pov "А сейчас что изменилось?"

# game/script.rpy:3229
translate russian ruta_normal_24_d9a5fc94:

    # pov "Supongo que es cómo encontrar un obstáculo nuevo."
    pov "Наверное, это как встретить новое препятствие."

# game/script.rpy:3230
translate russian ruta_normal_24_c0afeac1:

    # "Jeff niega levemente con la cabeza."
    "Джефф едва заметно качает головой."

# game/script.rpy:3236
translate russian ruta_normal_25_ade66aab:

    # J "Tú… eres un enigma. Creí entender a toda la humanidad, por eso la odiaba, pero contigo… es como si quisiera averiguar más."
    J "Ты... ты загадка. Я думал, что понимаю уже всё человечество, поэтому и ненавидел его, но с тобой... как будто хочется узнать больше."

# game/script.rpy:3237
translate russian ruta_normal_25_f634d120:

    # J "Me llamas la atención, en eso estoy seguro."
    J "Ты меня зацепили, в этом я уверен."

# game/script.rpy:3239
translate russian ruta_normal_25_7a1d28e9:

    # "Él lentamente dirigió su mano hacia ti."
    "Он медленно тянет к вам руку."

# game/script.rpy:3240
translate russian ruta_normal_25_a35964b7:

    # "No te mueves, no sabes si es por temor a que haga algo, o si quieres que te alcance."
    "Вы не шевелитесь — не знаете, то ли боитесь, что он что-то сделает, то ли наоборот хотите, чтобы он дотронулся."

# game/script.rpy:3241
translate russian ruta_normal_25_d4c8d459:

    # "Los dedos de Jeff rodean tu cuello, y aprietan suavemente. No llega a ahorcarte, pero su agarre es firme."
    "Пальцы Джеффа обхватывают вашу шею и слегка сжимают. Он не душит, но хватка у него крепкая."

# game/script.rpy:3242
translate russian ruta_normal_25_b51a783a:

    # J "Aún estoy pensando qué hacer contigo una vez me aburra de nuestro juego."
    J "Я всё ещё думаю, что сделаю с тобой, когда эта игра мне наскучит."

# game/script.rpy:3243
translate russian ruta_normal_25_5dea302d:

    # "Él te acerca a él, su respiración rozando con tu rostro mientras él habla suavemente."
    "Он притягивает вас ближе, его дыхание касается вашего лица, а голос звучит почти ласково."

# game/script.rpy:3244
translate russian ruta_normal_25_087d03e9:

    # J "Ya que me aburro fácilmente."
    J "Потому что мне легко наскучить."

# game/script.rpy:3248
translate russian ruta_normal_25_cc9a7052:

    # "Tomas la mano de Jeff entre la tuya, y afortunadamente, él no se resiste a tu toque."
    "Вы берёте Джеффа за руку — к счастью, он не сопротивляется вашему прикосновению."

# game/script.rpy:3250
translate russian ruta_normal_25_e449308b:

    # "Liberas tu cuello de la mano de él, alejándola de ti mientras te acaricias el cuello."
    "Вы освобождаете шею из его хватки, отталкивая его руку и машинально проводя пальцами по коже."

# game/script.rpy:3251
translate russian ruta_normal_25_5097a720:

    # pov "Geez, ok, ya entendí."
    pov "Господи, ладно, я поняли."

# game/script.rpy:3252
translate russian ruta_normal_25_582d850e:

    # J "Más te vale."
    J "Так-то лучше."

# game/script.rpy:3253
translate russian ruta_normal_25_20ca486d:

    # "Él volvió a su lugar, y siguió bebiendo su whisky."
    "Он возвращатеся на своё место и продолжает пить виски."

# game/script.rpy:3258
translate russian ruta_normal_25_09edf0e4:

    # pov "Ngh~"
    pov "Нгх~"

# game/script.rpy:3259
translate russian ruta_normal_25_f6b92c46:

    # "Jeff abrió en grande los ojos, soltándote, como si contagiaras."
    "Глаза Джеффа широко распахиваются и он отпускает вас так, будто обжёгся."

# game/script.rpy:3260
translate russian ruta_normal_25_b6fa1ff1:

    # "Él te miró con asombro un par de segundos, para después farfullar."
    "Пару секунд он смотрит на вас в изумлении, потом бормочет:"

# game/script.rpy:3261
translate russian ruta_normal_25_b77121c2:

    # J "De nuevo caí en eso…"
    J "Опять повёлся..."

# game/script.rpy:3262
translate russian ruta_normal_25_74a20463:

    # "Él gruñó por lo bajo, y siguió bebiendo su whisky."
    "Он глухо ругается и делает ещё глоток."

# game/script.rpy:3267
translate russian ruta_normal_26_ad1b6c7e:

    # pov "Hey, así que… ¿Cuál es el plan?"
    pov "Эй, так что... какой у нас план?"

# game/script.rpy:3268
translate russian ruta_normal_26_0eb96dcd:

    # J "¿Huh?"
    J "А?"

# game/script.rpy:3269
translate russian ruta_normal_26_d8bb2dbf:

    # pov "¿Vamos a charlar como si fuéramos amigos, a pesar de que me arrancaste un ojo y me estás acosando?"
    pov "Мы что, будем болтать как приятели даже несмотря на то, что ты выдрал мне глаз и теперь преследуешь?"

# game/script.rpy:3270
translate russian ruta_normal_26_fc177ac5:

    # "Jeff resopla una carcajada, alzando su vaso."
    "Джефф фыркает, усмехаясь, и поднимает свой стакан."

# game/script.rpy:3272
translate russian ruta_normal_26_43eff71f:

    # J "¡Brindo por eso!"
    J "За это можно выпить!"

# game/script.rpy:3278
translate russian ruta_normal_26_4a04a202:

    # pov "Lo que tú digas."
    pov "Как скажешь."

# game/script.rpy:3280
translate russian ruta_normal_26_bb5552e4:

    # "Alzas el contenedor de tu bebida y chocas el vaso de él en un pequeño brindis."
    "Вы поднимаете свой стакан и легко стукаетесь им о его — небольшой тост."

# game/script.rpy:3281
translate russian ruta_normal_26_5c1cf14e:

    # "Él te queda mirando en silencio, pensativo."
    "Он молча смотрит на вас, задумавшись."

# game/script.rpy:3282
translate russian ruta_normal_26_291482a1:

    # J "… Eres una persona muy rara, [povname]."
    J "...Ты странный человек, [povname]."

# game/script.rpy:3283
translate russian ruta_normal_26_4f9c0089:

    # pov "¿Eso te gusta? "
    pov "Тебе это нравится?"

# game/script.rpy:3284
translate russian ruta_normal_26_2c836599:

    # "Jeff ríe levemente."
    "Джефф тихо усмехается."

# game/script.rpy:3285
translate russian ruta_normal_26_069571c9:

    # J "Ya veremos."
    J "Поглядим."

# game/script.rpy:3288
translate russian ruta_normal_26_98a4fb8a:

    # pov "Estás loco."
    pov "Ты сумасшедший."

# game/script.rpy:3289
translate russian ruta_normal_26_652521b6:

    # J "Ese es mi encanto, por si no lo has notado."
    J "В этом вся моя прелесть, если ты не заметили."

# game/script.rpy:3290
translate russian ruta_normal_26_3ddec117:

    # "Pones los ojos en blanco, ignorándolo."
    "Вы закатываете глаз и стараетесь его не слушать."

# game/script.rpy:3295
translate russian ruta_normal_27_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3296
translate russian ruta_normal_27_ea954a60:

    # pov "Gracias, por dejarme en paz esta noche."
    pov "Спасибо, что хотя бы сегодня оставил меня в покое."

# game/script.rpy:3298
translate russian ruta_normal_27_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3299
translate russian ruta_normal_27_ca9e1581:

    # J "Tus estándares son muy bajos, ¿No?"
    J "Стандарты у тебя низковаты, как погляжу."

# game/script.rpy:3300
translate russian ruta_normal_27_6dada04a:

    # pov "Hey, dije gracias, no que te volviste mágicamente decente porque hiciste una sola cosa buena por mí."
    pov "Эй, я сказали только «спасибо», а не то, что ты вдруг стал приличным человеком только потому, что единожды сделал что-то хорошее."

# game/script.rpy:3301
translate russian ruta_normal_27_d97fdb34:

    # "Esto no es un dark romance."
    "Это же не какая-нибудь тёмная романтика."

# game/script.rpy:3302
translate russian ruta_normal_27_ce617998:

    # "…"
    "..."

# game/script.rpy:3303
translate russian ruta_normal_27_63b2d046:

    # "Quizás."
    "Наверное."

# game/script.rpy:3304
translate russian ruta_normal_27_9a4f30dc:

    # "Jeff alzó sus manos en rendición, su postura despreocupada."
    "Джефф поднимает руки в притворной капитуляции, оставаясь при этом расслабленным."

# game/script.rpy:3305
translate russian ruta_normal_27_b7513d45:

    # J "Estoy de buen humor, sólo puedo decir eso."
    J "У меня сегодня хорошее настроение, вот и всё."

# game/script.rpy:3306
translate russian ruta_normal_27_fe3b7119:

    # pov "¿Tiene algo que ver a que rechacé la cita con Paul?"
    pov "Это как-то связано с тем, что я отказались идти на свидание с Полом?"

# game/script.rpy:3307
translate russian ruta_normal_27_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:3308
translate russian ruta_normal_27_8a5554d2:

    # J "Piensa lo que quieras."
    J "Думай что хочешь."

# game/script.rpy:3309
translate russian ruta_normal_27_7532ae70:

    # "Sonríes levemente, y bebes de tu bebida."
    "Вы слабо улыбаетесь и делаете глоток своего напитка."

# game/script.rpy:3310
translate russian ruta_normal_27_588d8c9b:

    # "Ustedes se quedan en silencio, escuchando la música del bar."
    "Вы оба замолкаете, слушая музыку в баре."

# game/script.rpy:3311
translate russian ruta_normal_27_c28b39a2:

    # "El jazz es relajante, y extrañamente, no te sientes mal."
    "Джазз успокаивает, и, как ни странно, вам кажется, что всё не так уж и плохо."

# game/script.rpy:3312
translate russian ruta_normal_27_6548bb03:

    # "Era increíble cómo podías pasar de un momento temiendo que te encontrara en tu escondite, y en otro parece que ustedes están teniendo una…"
    "Поразительно, как в один момент вы могли бояться, что он выследит вас в вашем убежище, а в другой момент уже казалось, что вы..."

# game/script.rpy:3313
translate russian ruta_normal_27_abab1354:

    # "¿Oh?"
    "О?"

# game/script.rpy:3314
translate russian ruta_normal_27_fd70c5ba:

    # "¿Era tu idea o esto parecía una cita?"
    "Вам кажется, или это похоже на свидание?"

# game/script.rpy:3315
translate russian ruta_normal_27_743b8537:

    # "Saliendo con el tipo que te arrancó el ojo y amenaza con matarte, ¿Tal vez sí es un dark romance después de todo?"
    "Встречаться с парнем, который вырвал вам глаз и грозится убить... Может, это и правда тёмная романтика?"

# game/script.rpy:3319
translate russian ruta_normal_27_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:3320
translate russian ruta_normal_27_a4161811:

    # J "¿A qué viene eso?"
    J "К чему ты это вообще?"

# game/script.rpy:3321
translate russian ruta_normal_27_961ddd40:

    # pov "No pude evitar notar que realmente odias cuando alguien es… amable conmigo."
    pov "Трудно было не заметить, как сильно тебе не нравится, когда кто-то... добр ко мне."

# game/script.rpy:3322
translate russian ruta_normal_27_9d9285f9:

    # pov "¿Eres del tipo celoso, Jeff?"
    pov "Ты что, из ревнивых, Джефф?"

# game/script.rpy:3323
translate russian ruta_normal_27_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:3324
translate russian ruta_normal_27_efe6af85:

    # J "Estás jugando con fuego, [povname]."
    J "С огнём играешь, [povname]."

# game/script.rpy:3329
translate russian ruta_normal_27_06316e8b:

    # pov "¿Por qué?"
    pov "Почему?"

# game/script.rpy:3330
translate russian ruta_normal_27_a50ffdb3:

    # pov "¿Porque es insensato provocar a un asesino serial que me tiene en la mira?"
    pov "Потому что глупо дразнить серийного убийцу, который меня преследует?"

# game/script.rpy:3331
translate russian ruta_normal_27_bc41ba1b:

    # "Tal vez no estabas tan bien mentalmente por meterte con alguien tan peligroso, pero definitivamente tienes sentido común como para reconocer lo jodida que es la situación."
    "Может, у вас и не всё в порядке с головой, раз вы решили связаться с кем-то настолько опасным; но здравого смысла у вас хватает, чтобы понимать, насколько это всё безумно."

# game/script.rpy:3332
translate russian ruta_normal_27_c8b59c30:

    # J "Ha, veo que entiendes a lo que me refiero."
    J "Ха, всё-таки понимаешь, о чём я."

# game/script.rpy:3335
translate russian ruta_normal_27_c9ad646a:

    # pov "Quizás quiera quemarme."
    pov "Может, я и хочу обжечься."

# game/script.rpy:3336
translate russian ruta_normal_27_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:3337
translate russian ruta_normal_27_612ebbec:

    # J "No lo recomiendo."
    J "Не советую."

# game/script.rpy:3338
translate russian ruta_normal_27_9f148813:

    # J "Una vez que el fuego te alcanza, no hay vuelta atrás."
    J "Как только огонь настигнет тебя, дороги назад уже не будет."

# game/script.rpy:3339
translate russian ruta_normal_27_adbe995a:

    # "Para tu sorpresa, su tono de voz se marchita."
    "К вашему удивлению, в его голосе что-то угасает."

# game/script.rpy:3342
translate russian ruta_normal_27_30f88e9c:

    # pov "Para pagar lo que estás bebiendo, digo."
    pov "Чтобы заплатить за напитки."

# game/script.rpy:3343
translate russian ruta_normal_27_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:3344
translate russian ruta_normal_27_fe362c51:

    # J "Normalmente mataría al bartender."
    J "Обычно я просто убиваю бармена."

# game/script.rpy:3345
translate russian ruta_normal_27_54f26506:

    # "Sientes una sonrisa burlona en su voz."
    "Вы чувствуете в его голосе насмешку."

# game/script.rpy:3346
translate russian ruta_normal_27_c6251083:

    # J "Pero prometí que me comportaría, así que tendrás que invitarme."
    J "Но я пообещал вести себя прилично, так что тебе придётся меня угостить."

# game/script.rpy:3349
translate russian ruta_normal_27_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3350
translate russian ruta_normal_27_992b49fd:

    # "Supsiras en rendición."
    "Вы вздыхаете, сдаваясь."

# game/script.rpy:3351
translate russian ruta_normal_27_02e833ca:

    # pov "De acuerdo, sólo porque no quiero que me asocien contigo si te arrancas."
    pov "Ладно, но только потому, что я не хочу, чтобы меня потом связали с тобой, если ты сорвёшься."

# game/script.rpy:3352
translate russian ruta_normal_27_2ad9eeae:

    # "Jeff resopló una risa corta y ligera, victorioso."
    "Джефф тихо, довольно усмехается."

# game/script.rpy:3357
translate russian ruta_normal_27_f3c857fb:

    # pov "¿Qué-?, ¡Nah-ah!"
    pov "Что? Не-а!"

# game/script.rpy:3358
translate russian ruta_normal_27_c0117adb:

    # J "Si-ih."
    J "Ага."

# game/script.rpy:3359
translate russian ruta_normal_27_760bfd0a:

    # "Él tocó la punta de tu nariz con su dedo, juguetonamente."
    "Он игриво касается кончиком пальца вашего носа."

# game/script.rpy:3360
translate russian ruta_normal_27_cdc0c994:

    # J "Si no lo haces, me iré corriendo y tendrás que pagar igual."
    J "Если не заплатишь — я просто сбегу, а расплачиваться всё равно придётся тебе."

# game/script.rpy:3361
translate russian ruta_normal_27_f67650fa:

    # J "¿No sería mejor evitar el mal rato y que te miren mal por juntarte con alguien que no paga la cuenta?"
    J "Разве не лучше сэкономить себе нервы и не огребать косые взгляды за компанию с тем, кто не платит?"

# game/script.rpy:3362
translate russian ruta_normal_27_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:3363
translate russian ruta_normal_27_2a310e9c:

    # pov "Te odio."
    pov "Ненавижу тебя."

# game/script.rpy:3364
translate russian ruta_normal_27_619e8b75:

    # J "Heh."
    J "Хех."

# game/script.rpy:3365
translate russian ruta_normal_27_344cd34b:

    # "Lejos de sentirse molesto, Jeff se ríe entre dientes."
    "Джефф усмехается, вообще не выглядя обиженным."

# game/script.rpy:3368
translate russian ruta_normal_27_14360a18_6:

    # J "…"
    J "..."

# game/script.rpy:3369
translate russian ruta_normal_27_cda0de51:

    # J "Muy personal, ¿No crees?"
    J "Слишком личный вопрос, не находишь?"

# game/script.rpy:3370
translate russian ruta_normal_27_f3055ac4:

    # pov "Me fuiste a matar a mi casa, creo que tengo derecho a saber un poco más de ti."
    pov "Ты ворвался ко мне домой, чтобы убить — думаю, я имею право узнать о тебе хоть что-то."

# game/script.rpy:3371
translate russian ruta_normal_27_14360a18_7:

    # J "…"
    J "..."

# game/script.rpy:3372
translate russian ruta_normal_27_1d8c5b27:

    # J "No te atrevas a juzgarme."
    J "Даже не вздумай меня осуждать."

# game/script.rpy:3373
translate russian ruta_normal_27_a73890d5:

    # pov "Lo intentaré."
    pov "Постараюсь."

# game/script.rpy:3374
translate russian ruta_normal_27_0f4f8710:

    # "Jeff gruñó por lo bajo."
    "Джефф проворчал что-то себе под нос."

# game/script.rpy:3375
translate russian ruta_normal_27_f78af336:

    # J "… Me la corté yo."
    J "...Я сам его порезал."

# game/script.rpy:3376
translate russian ruta_normal_27_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:3377
translate russian ruta_normal_27_06316e8b_1:

    # pov "¿Por qué?"
    pov "Зачем?"

# game/script.rpy:3378
translate russian ruta_normal_27_ac95bb4e:

    # "Jeff deja salir un quejido frustrado."
    "Джефф раздражённо вздыхает."

# game/script.rpy:3379
translate russian ruta_normal_27_df6d16c8:

    # J "Era un angsty teen, era otra época, estaba pasando por algo…"
    J "Я был проблемным подростком, тогда проходил через дерьмовый период..."

# game/script.rpy:3384
translate russian ruta_normal_27_537ebd21:

    # pov "Increíble, ¿A quién tratabas de emular?"
    pov "Невероятно. Кому ты пытался подражать?"

# game/script.rpy:3385
translate russian ruta_normal_27_fdf1da16:

    # "Él te enfrenta, con molestia."
    "Он раздражённо поворачивается к вам."

# game/script.rpy:3386
translate russian ruta_normal_27_7813825a:

    # "No se veía enojado, por lo que estabas a salvo por ahora."
    "Не похоже, что он злится — пока можете дышать спокойно."

# game/script.rpy:3387
translate russian ruta_normal_27_94e8552e:

    # J "¡A nadie!"
    J "Ни на кого!"

# game/script.rpy:3388
translate russian ruta_normal_27_8cbb3165:

    # J "Este es mi estilo original."
    J "Это мой оригинальный стиль."

# game/script.rpy:3389
translate russian ruta_normal_27_401e9d61:

    # J "Y no me arrepiento."
    J "И я ни о чём не жалею."

# game/script.rpy:3390
translate russian ruta_normal_27_c0737491:

    # J "Me gusta cómo soy."
    J "Мне нравится."

# game/script.rpy:3391
translate russian ruta_normal_27_b6b1c0a7:

    # "Asientes en silencio, con una falsa expresión de comprensión."
    "Вы молча киваете, изобразив понимающее выражение."

# game/script.rpy:3394
translate russian ruta_normal_27_8e82615f:

    # pov "Hey, está bien."
    pov "Эй, всё в порядке."

# game/script.rpy:3395
translate russian ruta_normal_27_b4613844:

    # pov "Yo también pasé por fases en la adolescencia."
    pov "У меня в подростковом возрасте тоже было подобное."

# game/script.rpy:3396
translate russian ruta_normal_27_ba57f941:

    # pov "Es normal."
    pov "Это нормально."

# game/script.rpy:3397
translate russian ruta_normal_27_14360a18_8:

    # J "…"
    J "..."

# game/script.rpy:3398
translate russian ruta_normal_27_806236b5:

    # "Jeff se rasca la cabeza."
    "Джефф почесал затылок."

# game/script.rpy:3403
translate russian ruta_normal_28_8104acb1:

    # J "No te acomodes tanto, mañana volveré a buscarte."
    J "Не расслабляйся, завтра я снова за тобой приду."

# game/script.rpy:3404
translate russian ruta_normal_28_42baa75b:

    # pov "Oh, si, cierto."
    pov "Ага, точно."

# game/script.rpy:3405
translate russian ruta_normal_28_79ef3c2e:

    # pov "Me estás acosando."
    pov "Ты же меня преследуешь."

# game/script.rpy:3406
translate russian ruta_normal_28_1fc1710f:

    # pov "Por un momento lo olvidé. Pasar el tiempo contigo como alguien normal no es tan malo."
    pov "На секунду даже забыли об этом. Знаешь, проводить с тобой время, будто ты обычный человек, оказалось не так уж плохо."

# game/script.rpy:3407
translate russian ruta_normal_28_24bc2d63:

    # pov "Podría llamarlo una cita, incluso."
    pov "Можно даже назвать это свиданием."

# game/script.rpy:3408
translate russian ruta_normal_28_dca56c1e:

    # "Estás hablando por hablar, pero puedes presenciar que tus palabras crearon una reacción en Jeff."
    "Вы говорите скорее в шутку, но замечаете, как ваши слова заставляют Джеффа слегка напрячься."

# game/script.rpy:3409
translate russian ruta_normal_28_14360a18:

    # J "…"
    J "..."

# game/script.rpy:3410
translate russian ruta_normal_28_ff8cf2ae:

    # J "¿Crees que alguien como yo puede experimentar cosas normales?"
    J "Ты правда думаешь, что кто-то вроде меня способен на что-то нормальное?"

# game/script.rpy:3411
translate russian ruta_normal_28_49b83eda:

    # J "¿Cómo una cita?"
    J "Например, на свидание?"

# game/script.rpy:3417
translate russian ruta_normal_28_08f5c536:

    # pov "Si, claro."
    pov "Конечно."

# game/script.rpy:3420
translate russian ruta_normal_28_7f1e7d9c:

    # pov "Nah, para nada."
    pov "Вообще нет."

# game/script.rpy:3430
translate russian ruta_normal_29_f2d59205:

    # "Él se queda un segundo en silencio, para después depositar el vaso vacío sobre la barra y levantarse de su asiento."
    "Он ненадолго замолкает, затем ставит пустой стакан на стойку и поднимается со своего места."

# game/script.rpy:3431
translate russian ruta_normal_29_25341a6a:

    # "Seguiste el movimiento de él, girándote desde el taburete."
    "Вы следите за его движением, поворачиваясь на стуле."

# game/script.rpy:3432
translate russian ruta_normal_29_043ec79a:

    # J "Buenas noches, [povname], suerte para mañana."
    J "Спокойной ночи, [povname]. Удачи завтра."

# game/script.rpy:3434
translate russian ruta_normal_29_840d146b:

    # "Jeff hace el ademán de acercarse, alzando su mano hacia ti."
    "Джефф жестом просит подойти ближе, поднося к вам руку."

# game/script.rpy:3435
translate russian ruta_normal_29_330de78c:

    # "Ves que no saca el cuchillo, por lo que te inclinas a él."
    "Вы замечаете, что нож он не достаёт, так что подходите ближе."

# game/script.rpy:3439
translate russian ruta_normal_29_31e2d9cc:

    # "Estrechas tu mano con la de él, en un apretón suave y cordial."
    "Вы мягко, почти дружелюбно пожимаете ему руку."

# game/script.rpy:3440
translate russian ruta_normal_29_03cf4942:

    # "Ojalá lo hubieras conocido en este contexto mundano."
    "Жаль, что вы не познакомились с ним в такой обыденной обстановке."

# game/script.rpy:3441
translate russian ruta_normal_29_af51d501:

    # pov "Me esforzaré."
    pov "Я постараюсь."

# game/script.rpy:3442
translate russian ruta_normal_29_0d12932b:

    # "Jeff asiente silenciosamente y se retira."
    "Джефф молча кивает и уходит."

# game/script.rpy:3448
translate russian ruta_normal_29_7560e31e:

    # "Sujetas la mano de él con la tuya, pero lo atraes hacia ti y apoyas tu mejilla contra el costado de su rostro cubierto por la bandana."
    "Вы сжимаете его руку, но не отпускаете — наоборот, притягиваете к себе, прижимая щеку к его лицу, наполовину скрытому под повязкой."

# game/script.rpy:3449
translate russian ruta_normal_29_f95088bd:

    # pov "Nos vemos luego, Jeff."
    pov "Ещё увидимся, Джефф."

# game/script.rpy:3450
translate russian ruta_normal_29_895f962a:

    # "Susurras suavemente, cerca del oído de él."
    "Шепчете вы едва слышно, почти у самого уха."

# game/script.rpy:3451
translate russian ruta_normal_29_a677f41f:

    # "Él no responde, de hecho sientes un espasmo en la mano de él."
    "Он не отвечает — вы лишь чувствуете, как содрогнулась его рука."

# game/script.rpy:3452
translate russian ruta_normal_29_69c2eff9:

    # "Jeff se retira lentamente, ocultando sus ojos tras el fleco y la capucha."
    "Джефф медленно отстраняется, пряча взгляд под чёлкой и капюшоном."

# game/script.rpy:3458
translate russian ruta_normal_30_86a40ef8:

    # "Observas cómo él desaparece por la puerta del bar, y entonces te das cuenta que hay algo en tu mano."
    "Вы провожаете его взглядом, пока он не скрывается за дверью бара, и вдруг замечаете, что в вашей руке что-то лежит."

# game/script.rpy:3460
translate russian ruta_normal_30_48b9879b:

    # "Es un papel arrugado, y cuando lo estiras ves que es un billete."
    "Смятый комок бумаги. Разгладив его, вы понимаете, что это купюра."

# game/script.rpy:3463
translate russian ruta_normal_30_7a87f7c0:

    # "Manchado con sangre."
    "Испачканная кровью."

# game/script.rpy:3464
translate russian ruta_normal_30_93835778:

    # "Así que sí tenía para pagar después de todo."
    "Значит, заплатить он всё-таки мог."

# game/script.rpy:3467
translate russian ruta_normal_30_441f6153:

    # "De todas maneras, no podías usar ese billete, te verán con sospecha."
    "Впрочем, воспользоваться ей вы не можете — на вас сразу начнут косо смотреть."

# game/script.rpy:3468
translate russian ruta_normal_30_e768e166:

    # "Decides quedarte un rato más, reflexionando sobre todo lo que acaba de pasar."
    "Вы решаете задержаться ещё немного, прокручивая в голове всё, что только что произошло."

# game/script.rpy:3469
translate russian ruta_normal_30_6552b585:

    # "Ahora, sabes con seguridad que esta noche no va a pasar nada."
    "Теперь вы точно знаете, что сегодня с вами ничего не случится."

# game/script.rpy:3470
translate russian ruta_normal_30_0943c4cb:

    # "Pero debes tener cuidado, mañana se retoma el juego."
    "Но завтра игра продолжится — нужно быть начеку."

# game/script.rpy:3487
translate russian ruta_normal_30_f5a3f63b:

    # "Despiertas como siempre en la seguridad de tu habitación, con la diferencia de que no dejas de pensar lo que pasó la noche anterior."
    "Вы просыпаетесь, как обычно, в безопасности своей комнаты — только мысли о вчерашнем не дают покоя."

# game/script.rpy:3488
translate russian ruta_normal_30_77aae322:

    # "Aún conservas el billete manchado con sangre que te dió Jeff."
    "Купюра, испачканная кровью, которую дал вам Джефф, по-прежнему лежит у вас."

# game/script.rpy:3489
translate russian ruta_normal_30_abdaacac:

    # "Seguramente te lo dió sabiendo que no podías gastarlo, lo hizo a propósito."
    "Он явно отдал её нарочно, зная, что вы не сможете ей расплатиться."

# game/script.rpy:3490
translate russian ruta_normal_30_9b8e54df:

    # "Era… extraño."
    "Это было... странно."

# game/script.rpy:3491
translate russian ruta_normal_30_a32941b4:

    # "Por experiencia propia, sabes que él se comporta erráticamente."
    "Вы уже по своему горьку опыту знаете, что он непредсказуем."

# game/script.rpy:3492
translate russian ruta_normal_30_f5da1d8a:

    # "Claro, de alguna forma te la has ingeniado para interactuar con él en momentos peligrosos donde tu vida está en juego."
    "Конечно, каким-то образом вам удавалось взаимодействовать с ним даже в те минуты, когда от этого зависела ваша жизнь."

# game/script.rpy:3493
translate russian ruta_normal_30_630ea33b:

    # "Pero eso no quita que haya sido increíble que Jeff, tan impredecible como es, haya establecido cierta relación contigo."
    "И всё же невероятно, что настолько непредсказуемый человек, как Джефф, вообще установил с вами определённую связь."

# game/script.rpy:3494
translate russian ruta_normal_30_feb9a5a7:

    # "Podías admitir que había momentos donde su compañía, cuando él no trataba de enterrar un cuchillo en tus entrañas, no era tan desagradable."
    "Вы можете признать, что в те редкие моменты, когда он не пытался всадить вам нож в живот, его компания не такая уж невыносимая."

# game/script.rpy:3495
translate russian ruta_normal_30_b57459d0:

    # "Era como si Jeff tuviera dos lados: Uno es el asesino desquiciado, y el otro es un tipo arrogante que no salía de su fase edgy."
    "Будто в Джеффе живут два человека: один — невменяемый убийца, другой — самодовольный парень, застрявший в периоде подросткового бунта."

# game/script.rpy:3496
translate russian ruta_normal_30_9d8a2c49:

    # "Oh no."
    "О нет."

# game/script.rpy:3497
translate russian ruta_normal_30_17a5966c:

    # "¿Esto se trataba del síndrome de Estocolmo?"
    "Неужели это Стокгольмский синдром?"

# game/script.rpy:3498
translate russian ruta_normal_30_7677e467:

    # "Otra casilla del bingo de novela visual."
    "Ещё одно попадание в бинго визуальной новеллы."

# game/script.rpy:3500
translate russian ruta_normal_30_d379f5f2:

    # "De todas formas, hoy tenías que estar más en guardia."
    "Как бы то ни было, сегодня стоит быть начеку."

# game/script.rpy:3501
translate russian ruta_normal_30_8ba2b14a:

    # "Jeff volvería, y él ya conoce el terreno de tu departamento, por lo que estabas en desventaja."
    "Джефф наверняка вернётся, а он уже знает планировку вашей квартиры — значит, вы в невыгодном положении."

# game/script.rpy:3502
translate russian ruta_normal_30_3d9de359:

    # "Tal vez tengas más chance si te vas a un hotel por esta noche."
    "Может, было бы безопаснее провести ночь в отеле."

# game/script.rpy:3503
translate russian ruta_normal_30_d02c7242:

    # "Lo más probable es que te siga la pista, pero las oportunidades de que te ataque caerían enormemente."
    "Он, конечно, наверняка найдёт вас и там; но шанс, что нападёт сразу, заметно снизится."

# game/script.rpy:3504
translate russian ruta_normal_30_836b2dc3:

    # "Sonaba como una estrategia. Cambiar frecuentemente tu ubicación."
    "Пожалуй, звучит как хорошая стратегия — постоянно менять местонахождение."

# game/script.rpy:3507
translate russian ruta_normal_30_dd14c851:

    # "De repente, tu timbre suena en medio de tu reflexión."
    "Внезапно ваши размышления прерывает звонок в дверь."

# game/script.rpy:3508
translate russian ruta_normal_30_ce617998:

    # "…"
    "..."

# game/script.rpy:3509
translate russian ruta_normal_30_a2d2ba46:

    # "No puede tratarse de Jeff, ¿Cierto?"
    "Это же не Джефф, правда?"

# game/script.rpy:3510
translate russian ruta_normal_30_fb3c4b3c:

    # "Él no es de la clase que toca timbres."
    "Он не из тех, кто звонит в дверь."

# game/script.rpy:3511
translate russian ruta_normal_30_2e416f3f:

    # "¿Qué tan gracioso sería que fuera él?"
    "Хотя, было бы забавно, если бы это был именно он."

# game/script.rpy:3513
translate russian ruta_normal_30_ce617998_1:

    # "…"
    "..."

# game/script.rpy:3516
translate russian ruta_normal_30_db1d330f:

    # "Te diriges a la puerta aún con tu ropa para dormir y te asomas por la mirilla en silencio."
    "Вы подходите к двери, всё ещё в пижаме, и бесшумно заглядываете в глазок."

# game/script.rpy:3517
translate russian ruta_normal_30_01dd2783:

    # "Reconoces de inmediato el cabello castaño del Dr. Salazar."
    "Сразу же узнаёте каштановые волосы доктора Салазара."

# game/script.rpy:3520
translate russian ruta_normal_30_63e8a612:

    # "Si, no."
    "Ну уж нет."

# game/script.rpy:3521
translate russian ruta_normal_30_9373d708:

    # "Es mejor no arriesgarte."
    "Лучше не рисковать."

# game/script.rpy:3522
translate russian ruta_normal_30_9c4a2d94:

    # DR "… ¿[povname]?"
    DR "...[povname]?"

# game/script.rpy:3523
translate russian ruta_normal_30_c60084f6:

    # "Te sobresaltas al escuchar la voz apagada del Dr. Salazar del otro lado."
    "Вы вздрагиваете, услышав приглушённый голос доктора Салазара по ту сторону двери."

# game/script.rpy:3524
translate russian ruta_normal_30_764bbfb7:

    # "Bueno, sustos que dan gusto dice el dicho."
    "Ну, как говорится — страхи бывают приятными."

# game/script.rpy:3531
translate russian lol_94ad48cc:

    # "Desbloqueas las cerraduras de la puerta y la abres, dejándolo pasar."
    "Вы отпираете замки и приоткрываете дверь, впуская его внутрь."

# game/script.rpy:3534
translate russian lol_124b3d7f:

    # pov "¿Qué haces aquí?"
    pov "Что ты здесь делаешь?"

# game/script.rpy:3535
translate russian lol_10d7a055:

    # "Salazar juega con sus manos nerviosamente."
    "Салазар нервно теребит руки."

# game/script.rpy:3536
translate russian lol_2f0b1666:

    # DR "Lo siento… No pude evitar preocuparme."
    DR "Прости... Не мог не переживать."

# game/script.rpy:3537
translate russian lol_a8e28c4b:

    # pov "¿Huh?"
    pov "А?"

# game/script.rpy:3538
translate russian lol_7e9f5557:

    # DR "Unos detectives me contactaron, preguntaron por tu ojo."
    DR "Со мной связались детективы. Спрашивали насчёт твоего глаза."

# game/script.rpy:3539
translate russian lol_7878583a:

    # pov "¿... Ok?"
    pov "...Ладно?"

# game/script.rpy:3540
translate russian lol_7ef0c636:

    # DR "[povname]... No lo tengo."
    DR "[povname]... У меня его нет."

# game/script.rpy:3541
translate russian lol_74267743:

    # pov "¿Disculpa?"
    pov "Прошу прощения?"

# game/script.rpy:3542
translate russian lol_298d2928:

    # DR "Según el informe, cuando te trasladaron al hospital, recuperaron tu ojo."
    DR "Согласно отчёту, когда тебя доставили в больницу, твой глаз нашли и забрали."

# game/script.rpy:3543
translate russian lol_c8901a34:

    # pov "¿Para qué recogerían un ojo inservible?"
    pov "Зачем вообще подбирать бесполезный глаз?"

# game/script.rpy:3544
translate russian lol_5980ee67:

    # "Salazar carraspea."
    "Салазар прокашлялся."

# game/script.rpy:3545
translate russian lol_51055ef4:

    # DR "Es protocolo, tanto policial como médico. Todo lo encontrado en escena debe guardarse."
    DR "Таков протокол — и у полиции, и у медиков. Всё, что найдено на месте происшествия, должно быть сохранено."

# game/script.rpy:3546
translate russian lol_d9b6a177:

    # pov "De acuerdo, entiendo eso, ¿Pero qué quieres decir con que no lo tienes?"
    pov "Хорошо, я понимаю. Но как у тебя его нет?"

# game/script.rpy:3547
translate russian lol_67cbcdce:

    # DR "Eso es lo extraño. Tu ojo está registrado en el hospital, pero cuando fui a revisar, no estaba."
    DR "Это и странно. Твой глаз числится в базе больницы, но когда я решил проверить — его там не оказалось."

# game/script.rpy:3548
translate russian lol_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:3549
translate russian lol_93291e2c:

    # "Podías adivinar quién lo pudo haber tomado."
    "Вы догадываетесь, кто именно его забрал."

# game/script.rpy:3550
translate russian lol_92bf0841:

    # DR "Creo que tu atacante está obsesionado contigo, ¿Has sentido que te siguen últimamente?"
    DR "Мне кажется, твой нападавший помешан на тебе. Ты не замечали, что последнее время за тобой следят?"

# game/script.rpy:3551
translate russian lol_0e33cbe8:

    # "Oh, el dulce e ingenuo doctor no tiene idea."
    "Ах, милый, наивный доктор даже представить себе не может."

# game/script.rpy:3552
translate russian lol_fbd2e09c:

    # "Te limitas a encogerte de hombros."
    "Вы просто пожимаете плечами."

# game/script.rpy:3553
translate russian lol_855a37c6:

    # pov "Supongo."
    pov "Наверное."

# game/script.rpy:3554
translate russian lol_c209892a:

    # DR "Yo… Tengo razones para pensar que vendrá por ti."
    DR "Я... У меня есть основания полагать, что он снова придёт за тобой."

# game/script.rpy:3555
translate russian lol_3dfc5c25:

    # "Vaya, este doctor hace mucho más que sólo operarte, aparentemente. Se ofrece para ser tu príncipe de brillante armadura."
    "Надо же, доктор оказался не только хирургом — похоже, возомнил себя ещё и рыцарем в сияющих доспехах."

# game/script.rpy:3556
translate russian lol_3e06fb14:

    # pov "¿Eso quiere decir que estás aquí por mí?"
    pov "То есть ты пришёл ради меня?"

# game/script.rpy:3557
translate russian lol_a6c98f36:

    # DR "Eh.. yo…"
    DR "Эм... я..."

# game/script.rpy:3558
translate russian lol_79b54982:

    # pov "¿Vienes a cuidarme, Paul?"
    pov "Ты пришёл присмотреть за мной, Пол?"

# game/script.rpy:3559
translate russian lol_419c25af:

    # pov "¿No crees que eso es favoritismo para un paciente entre muchos?"
    pov "Не думаешь, что это слишком особое отношение к одному пациенту из многих?"

# game/script.rpy:3562
translate russian lol_72b198f4:

    # "El labio inferior de Salazar empezó a temblar levemente, sorprendiéndote."
    "Нижняя губа Салазара чуть подрагивает, чему вы удивляетесь."

# game/script.rpy:3563
translate russian lol_f0f94bf6:

    # pov "Wow, cálmate, no es para tanto."
    pov "Воу, полегче, это не так страшно."

# game/script.rpy:3564
translate russian lol_9002dd5b:

    # DR "Tampoco lo entiendo…"
    DR "Я и сам... не понимаю..."

# game/script.rpy:3566
translate russian lol_82db7efd:

    # "Tienes la sensación de deja vu, ya que alguien más te había dicho algo igual."
    "Вас охватывает ощущение дежавю — кажется, кое-кто уже говорил вам нечто подобное."

# game/script.rpy:3568
translate russian lol_a02f3068:

    # DR "Eres… Increíble."
    DR "Ты... невероятны."

# game/script.rpy:3569
translate russian lol_403ba90b:

    # DR "Nunca tuve un paciente como tú. Desde que despertaste y hablamos, me produces taquicardia, sudoración, confusión…"
    DR "У меня никогда не было такого пациента. С тех пор, как ты пришли в сознание и мы поговорили, у меня началась тахикардия, потливость, спутанность сознания..."

# game/script.rpy:3570
translate russian lol_457fb31a:

    # "Pareciera que lo estás haciendo sentir enfermo con tanto término médico."
    "Из-за использования стольких медицинских терминов кажется, что вы заставляете его плохо себя чувствовать."

# game/script.rpy:3571
translate russian lol_af12650c:

    # "Pero entiendes la idea."
    "Но общий смысл вы уловили."

# game/script.rpy:3572
translate russian lol_84e8e4f6:

    # DR "¿Esto es lo que… llamarían amor a primera vista?"
    DR "Это то... что называют любовью с первого взгляда?"

# game/script.rpy:3573
translate russian lol_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:3574
translate russian lol_29cf2a55:

    # "Ok, estabas en una situación algo complicada."
    "Ну, вы в довольно сложной ситуации."

# game/script.rpy:3575
translate russian lol_301590d2:

    # "No todos los días viene tu doctor a tu departamento y confiesa su amor por ti."
    "Не каждый день ваш лечащий врач приходит к вам домой и признаётся в любви."

# game/script.rpy:3576
translate russian lol_848ae8f7:

    # "Pero ya te han pasado demasiadas cosas inusuales como para sorprenderte."
    "Хотя после всего, что с вами случилось, удивить вас теперь сложно."

# game/script.rpy:3577
translate russian lol_c6f61278:

    # pov "Paul, yo-"
    pov "Пол, я—"

# game/script.rpy:3580
translate russian lol_b96599aa:

    # "Antes de que puedas responder, se escucha un toque en la puerta."
    "Прежде чем вы успеваете договорить, раздаётся стук в дверь."

# game/script.rpy:3581
translate russian lol_3cb5aa16:

    # "¿Cuáles son las posibilidades?"
    "Каковы шансы?"

# game/script.rpy:3582
translate russian lol_8ec664eb:

    # C "¡Soy yo!"
    C "Это я!"

# game/script.rpy:3584
translate russian lol_9bed6c34:

    # "Te volteas a Salazar con una sonrisa torcida."
    "Вы поворачиваетесь к Салазару с косой улыбкой."

# game/script.rpy:3585
translate russian lol_8a51d2d5:

    # pov "Disculpa, tengo que atender-"
    pov "Извини, нужно открыть—"

# game/script.rpy:3587
translate russian lol_6dd11a02:

    # DR "[povname]."
    DR "[povname]."

# game/script.rpy:3588
translate russian lol_04c38799:

    # "Repentinamente, él te sujeta la mano con firmeza, lo que te desconcierta."
    "Внезапно он крепко сжимает вашу руку, что сбивает вас с толку."

# game/script.rpy:3589
translate russian lol_c1609263:

    # "Los ojos comúnmente calmos de él brillaban con desesperación."
    "Его глаза, обычно спокойные, вдруг вспыхивают отчаянным блеском."

# game/script.rpy:3590
translate russian lol_c3c70fbb:

    # "No sabes qué pensar."
    "Вы не знаете, что и думать."

# game/script.rpy:3592
translate russian lol_1c1fd878:

    # "Los golpes en la puerta se vuelven más insistentes."
    "Стук в дверь становится настойчивее."

# game/script.rpy:3593
translate russian lol_0a54cd1d:

    # C "¡Llamaré a la policía si no obtengo respuesta en 1…!"
    C "Я вызову полицию, если не услышу ответа через 1..!"

# game/script.rpy:3595
translate russian lol_ee816c05:

    # "Te liberas del agarre de Salazar y te apresuras a abrir la puerta."
    "Вы вырываете руку из хватки Салазара и поспешно идёте к двери."

# game/script.rpy:3596
translate russian lol_5bff04d3:

    # pov "¡Ya voy, ya voy!, geez, estoy en algo aquí."
    pov "Иду я, иду! Боже, я тут немного заняты!"

# game/script.rpy:3603
translate russian lol_7fe0a190:

    # "Cindy te mira con seriedad desde el momento que abres la puerta. Ella entra, con un montón de papeles en sus brazos."
    "С того момента, как вы открываете дверь, Синди смотрит на вас со всей серьёзностью. Она проходит со стопкой бумаги в руках."

# game/script.rpy:3604
translate russian lol_d1552d0a:

    # C "Esto es urgente, tenemos- ¿Qué mierda?"
    C "Это срочно, у нас— Какого чёрта?"

# game/script.rpy:3605
translate russian lol_8b263ba6:

    # "Cindy se detiene en medio de la sala, viendo con confusión a Salazar, el cual se mantiene de brazos cruzados apoyado en una pared."
    "Синди замирает посреди гостиной, удивлённо глядя на Салазара, который стоит, прислонившись к стене и скрестив руки на груди."

# game/script.rpy:3606
translate russian lol_0d78abe0:

    # C "¿Qué hace él aquí?"
    C "И что он тут делает?"

# game/script.rpy:3607
translate russian lol_77281e97:

    # pov "Oh, ehm… vino a verme."
    pov "О, эм... он пришёл навестить меня."

# game/script.rpy:3608
translate russian lol_4046e08d:

    # "Ella alza una ceja hacia ti."
    "Она приподнимает бровь."

# game/script.rpy:3609
translate russian lol_7badbd4d:

    # C "¿Para qué?"
    C "Зачем?"

# game/script.rpy:3610
translate russian lol_6cd7a3a3:

    # pov "Estaba preocupado por mí."
    pov "Волновался за меня."

# game/script.rpy:3611
translate russian lol_b62e81f2:

    # "Salazar desvía la mirada incómodamente."
    "Салазар нервно отводит взгляд в сторону."

# game/script.rpy:3612
translate russian lol_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:3613
translate russian lol_696f658b:

    # C "¿Síndrome de Florence Nightingale?"
    C "Синдром Флоренс Найтингейл?"

# game/script.rpy:3615
translate russian lol_6c10fbfd:

    # "Salazar se ruboriza en su lugar."
    "Салазар вдруг краснеет."

# game/script.rpy:3616
translate russian lol_a769160a:

    # DR "¡Eso es-!"
    DR "Это—!"

# game/script.rpy:3617
translate russian lol_39de5245:

    # pov "¿Qué es eso?"
    pov "Что это?"

# game/script.rpy:3619
translate russian lol_30a4c58c:

    # C "Cuando el cuidador se enamora del paciente."
    C "Когда врач или сиделка влюбляется в своего пациента."

# game/script.rpy:3620
translate russian lol_d59119c0:

    # pov "Oh, entonces sí."
    pov "А, тогда да."

# game/script.rpy:3621
translate russian lol_56c83cbd:

    # DR "¡[povname]!"
    DR "[povname]!"

# game/script.rpy:3622
translate russian lol_c750a803:

    # "Salazar protestó con las mejillas aún encendidas."
    "Салазар протестует, его щёки всё такие же красные."

# game/script.rpy:3623
translate russian lol_d0c5d05c:

    # "Te encoges de hombros despreocupadamente."
    "Вы беспечно пожимаете плечами."

# game/script.rpy:3624
translate russian lol_d0430941:

    # pov "Tu viniste por tu cuenta."
    pov "Ты сам сюда пришёл."

# game/script.rpy:3625
translate russian lol_33964f79:

    # DR "Pensé que seríamos nosotros dos."
    DR "Я думал, мы будем вдвоём."

# game/script.rpy:3631
translate russian lol_9455b903:

    # "Cindy pasa a la cocina y deja el montón de papeles sobre tu mesa, mirando de soslayo a Salazar."
    "Синди проходит на кухню и кладёт кипу бумаг на ваш стол, украдкой бросая взгляд на Салазара."

# game/script.rpy:3632
translate russian lol_940093e2:

    # pov "Ah, si, ¿A qué viniste, Cin?"
    pov "Ах да, зачем ты пришла, Син?"

# game/script.rpy:3633
translate russian lol_f05c477a:

    # C "Averigüe cosas sobre el rarito de la tienda."
    C "Мне удалось найти кое-какие сведения про того странного типа из магазина."

# game/script.rpy:3634
translate russian lol_5cb80255:

    # "Tomas asiento, mirando con curiosidad los papeles."
    "Вы садитесь, с любопытством разглядывая бумаги."

# game/script.rpy:3635
translate russian lol_21bfa775:

    # "Varían de noticias impresas de sitios web, hojas de peridódico con párrafos destacados, fotos de personas e informes."
    "Там и распечатанные статьи с новостных сайтов, и газетные вырезки с подчёркнутыми абзацами, и фотографии людей, и какие-то отчёты."

# game/script.rpy:3636
translate russian lol_3f3663cf:

    # pov "¿De dónde sacaste todo esto?"
    pov "Откуда у тебя это всё?"

# game/script.rpy:3637
translate russian lol_0b624bf8:

    # C "Tengo mis medios."
    C "У меня свои источники."

# game/script.rpy:3638
translate russian lol_6150d308:

    # "Cindy tomó asiento contigo, apuntando las hojas de papel."
    "Синди садится рядом, указывая на бумаги."

# game/script.rpy:3639
translate russian lol_df2a2a58:

    # C "Este tipo, Jeff, está involucrado en muchos asesinatos, y también incendios."
    C "Этот тип — Джефф — замешан во множестве убийств, а также поджогов."

# game/script.rpy:3640
translate russian lol_e7187687:

    # C "Lleva fugitivo al menos 15 años. No tiene un perfil de víctimas en específico, son desde borrachos en la calle hasta familias de los suburbios."
    C "Он в розыске уже не меньше 15 лет. Причём у него нет определённого типа жертв, они варьируются от уличных пьяниц до семей из пригорода."

# game/script.rpy:3641
translate russian lol_437b958a:

    # C " Sigue el mismo modus operandi, apuñala a sus víctimas en lugares vitales y les corta la boca, con un cuchillo de cocina."
    C "Он всегда действует по одному и тому же шаблону — бьёт кухонным ножом в жизненно важные органы и разрезает рты жертв."

# game/script.rpy:3642
translate russian lol_bedd6fae_2:

    # pov "…"
    pov "..."

# game/script.rpy:3643
translate russian lol_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3644
translate russian lol_7f76495a_1:

    # C "…"
    C "..."

# game/script.rpy:3645
translate russian lol_fc98751c:

    # C "El peor arma, si me preguntas a mí."
    C "По-моему, худшее оружие."

# game/script.rpy:3646
translate russian lol_5418c542:

    # "Pones los ojos en blanco ante el comentario de ella."
    "Вы закатываете глаза на её комментарий."

# game/script.rpy:3647
translate russian lol_e78d9ab4:

    # pov "Continúa, por favor."
    pov "Продолжай, пожалуйста."

# game/script.rpy:3649
translate russian lol_3cd16a17:

    # "Cindy frunce el ceño, esparciendo los papeles para verlos todos juntos."
    "Синди хмурится и раскладывает бумаги по столу, чтобы видеть всё сразу."

# game/script.rpy:3650
translate russian lol_e549f191:

    # C "Lo extraño es que nunca lo han atrapado."
    C "Странно, что его до сих пор ни разу не поймали."

# game/script.rpy:3651
translate russian lol_8df4386b:

    # C "El tipo es muy descuidado. Usa ropa blanca, fácil de manchar, lleva el pelo largo, sin importarle dejar ADN, no lleva guantes, deja sus huellas por todas partes."
    C "Он же крайне неосторожен — носит белую одежду, которую легко запачкать, длинные волосы, не старается скрыть ДНК, не пользуется перчатками, оставляет отпечатки где попало."

# game/script.rpy:3652
translate russian lol_c4fa7ff1:

    # C "Lo buscan en varias regiones, y aún así nunca lo han arrestado."
    C "Его разыскивают в нескольких регионах, и всё равно так и не поймали."

# game/script.rpy:3653
translate russian lol_e804627b:

    # C "No tiene dirección ni familia, ni siquiera se sabe con exactitud su pasado ni quién era antes."
    C "У него нет ни адреса, ни семьи, да и прошлое его толком неизвестно. Никто не знает, кем он был раньше."

# game/script.rpy:3654
translate russian lol_e964df60:

    # C "Lo que me llama la atención… Es que para ser un simple tipo, su nivel de conveniencia supera lo normal."
    C "А что самое удивительное... для обычного человека он слишком уж везучий."

# game/script.rpy:3655
translate russian lol_f4e250cc:

    # C "Logra escapar del fuego, evita las cámaras de seguridad, incluso sabe trepar muros. Es cómo… Si tuviera el guión de su lado."
    C "Он умудряется спасаться от огня, избегать камер, перелезать через стены... как будто у него на руках сценарий, написанный в его пользу."

# game/script.rpy:3656
translate russian lol_2660c90d:

    # pov "Haha, ¿Guión?, ¿De qué hablas?"
    pov "Ха-ха, «сценарий»? Ты о чём вообще?"

# game/script.rpy:3657
translate russian lol_f7362b9f:

    # C "No lo digo literalmente. Es como si el universo estuviera de su lado."
    C "Не буквально. Просто такое ощущение, что сама вселенная на его стороне."

# game/script.rpy:3658
translate russian lol_e2a4bb75:

    # "Uf, eso estuvo cerca. No necesitamos otro personaje con autoconciencia narrativa."
    "Уф, пронесло. Не хватало ещё одного персонажа, осознающего, что он внутри сюжета."

# game/script.rpy:3659
translate russian lol_ac3ecb47:

    # "Pero ahora que Cindy lo menciona, es verdad."
    "Но если вдуматься, в словах Синди есть доля правды."

# game/script.rpy:3660
translate russian lol_f45fef9a:

    # "Se supone que dieron su descripción física por las noticias, y aún así, se las arregla para seguirte durante el día, o para ir a un bar por la noche."
    "Про его внешность уже сообщали по новостям, но он всё равно ухитряется спокойно следить за вами днём и появляться в барах по вечерам."

# game/script.rpy:3661
translate russian lol_2578041a:

    # "Es como… Si fuera invisible para los demás."
    "Как будто... его никто, кроме вас, не видит."

# game/script.rpy:3662
translate russian lol_b29a36ef:

    # "No, no hay plot twist de que en realidad él es parte de tu imaginación, o que es un fantasma."
    "Нет, никаких сюжетных поворотов в духе «он плод вашего воображения» или «призрак»."

# game/script.rpy:3663
translate russian lol_4a9fa1c2:

    # "Jeff es solamente muy escurridizo."
    "Джефф просто слишком хорошо умеет скрываться."

# game/script.rpy:3665
translate russian lol_ee49931c:

    # DR "Con mayor razón tienes que tener cuidado, [povname]."
    DR "Тогда тебе тем более стоит быть осторожнее, [povname]."

# game/script.rpy:3666
translate russian lol_8049b509:

    # DR "Volverá por ti."
    DR "Он снова придёт за тобой."

# game/script.rpy:3667
translate russian lol_975b7c12:

    # "Ya lo hizo y lo volverá hacer, pero no puedes decir eso en voz alta."
    "Он уже приходил — и придёт ещё, но этого, разумеется, нельзя говорить вслух."

# game/script.rpy:3668
translate russian lol_cfe8a43d:

    # C "¿De qué hablas?"
    C "О чём ты вообще?"

# game/script.rpy:3669
translate russian lol_39f73aa1:

    # DR "Creo que está obsesionado con [povname]."
    DR "Мне кажется, он одержим [povname]."

# game/script.rpy:3670
translate russian lol_fd51d5a5:

    # "Cindy te mira con seriedad."
    "Синди смотрит на вас серьёзно."

# game/script.rpy:3671
translate russian lol_5b3d5093:

    # C "Si ese es el caso, no puedes quedarte aquí, al menos no por tu cuenta."
    C "Если это действительно так, ты не можешь оставаться тут в одиночестве."

# game/script.rpy:3672
translate russian lol_8b9cbd70:

    # pov "¿Entonces cuál es la idea, piensan quedarse conmigo 24/7?"
    pov "И что, по-вашему, вы собираетесь дежурить у меня сутками напролёт?"

# game/script.rpy:3675
translate russian lol_7f76495a_2:

    # C "…"
    C "..."

# game/script.rpy:3676
translate russian lol_723c69de_1:

    # DR "…"
    DR "..."

# game/script.rpy:3677
translate russian lol_86305ee3:

    # pov "Oh no, lo es."
    pov "О нет, вы серьёзно."

# game/script.rpy:3678
translate russian lol_5548f283:

    # C "No es la solución más elegante, pero me aseguraré de que estés bien."
    C "Это не самое идеальное решение, но я прослежу, чтобы с тобой всё было в порядке."

# game/script.rpy:3679
translate russian lol_f2355920:

    # DR "Yo puedo protegerte."
    DR "Я могу тебя защитить."

# game/script.rpy:3680
translate russian lol_3e9dd253:

    # "De repente, Cindy y Salazar se miran en silencio."
    "Внезапно Синди и Салазар молча смотрят друг на друга."

# game/script.rpy:3682
translate russian lol_9b99acfd:

    # C "Yo me quedaré con [povname]. Soy su compañera de trabajo, nos conocemos desde hace más tiempo."
    C "Я останусь с [povname]. Мы коллеги, и знакомы дольше."

# game/script.rpy:3683
translate russian lol_b08290d3:

    # DR "Soy su doctor, tengo el deber de velar por su bienestar."
    DR "А я их лечащий врач. Я обязан заботиться об их благополучии."

# game/script.rpy:3684
translate russian lol_467ef742:

    # C "Lo que estás haciendo, y me refiero venir a su casa, no es para nada profesional para un doctor."
    C "То, что ты делаешь, приходя к ним домой, совершенно непрофессионально для врача."

# game/script.rpy:3685
translate russian lol_0aeb9634:

    # C "Podría decir que estás acosando a [povname]. ¿Cómo supiste donde vivía?, ¿Lo viste en su expediente?"
    C "Можно даже сказать, что ты преследуешь [povname]. Откуда ты вообще знаешь, где они живут? Из личного дела?"

# game/script.rpy:3687
translate russian lol_95da8c07:

    # DR "¡Nos encontramos ayer!, fue pura casualidad- hasta me atrevería decir que fue el destino."
    DR "Мы встретились вчера! Случайно! Я бы даже сказал, что сама судьба свела нас."

# game/script.rpy:3688
translate russian lol_bf7fb264:

    # "Cindy resopla una risa irónica."
    "Синди иронично усмехается."

# game/script.rpy:3689
translate russian lol_6e81cb9f:

    # C "¿Vas a hablar de destino?, ¿En serio?"
    C "Ты собираешься говорить о судьбе? Серьёзно?"

# game/script.rpy:3691
translate russian lol_0b9c060c:

    # pov "Chicos, ¿Podemos relajarnos un momento?"
    pov "Ребята, можем хотя бы на минуту успокоиться?"

# game/script.rpy:3692
translate russian lol_1d7d2b6f:

    # "Los dos se callan y te miran."
    "Они оба замолкают и переводят взгляд на вас."

# game/script.rpy:3693
translate russian lol_6f8b19e9:

    # "Los miras con aburrimiento."
    "Вы устало смотрите на них в ответ."

# game/script.rpy:3694
translate russian lol_766bc61f:

    # pov "¿Me dejan ir a bañarme?, Todavía estoy en mi ropa para dormir."
    pov "Можно я хотя бы душ приму? Я до сих пор в пижаме."

# game/script.rpy:3697
translate russian lol_6409361a:

    # "Repentinamente, ambos desvían la mirada, con las mejillas encendidas."
    "Они тут же отводят взгляд, их щёки заливаются краской."

# game/script.rpy:3698
translate russian lol_6429ba86:

    # C "Ah, claro, claro…"
    C "А, да, конечно..."

# game/script.rpy:3699
translate russian lol_a2956b58:

    # DR "Lo siento, adelante…"
    DR "Прости, иди..."

# game/script.rpy:3700
translate russian lol_83f7f650:

    # "Te retiras de la cocina y vas al baño."
    "Вы выходите из кухни и направляетесь в ванную."

# game/script.rpy:3702
translate russian lol_4a6713e5:

    # "No esperabas recibir tanta visita, tampoco que vinieran a tu rescate."
    "Вы не ожидали стольких гостей, тем более тех, кто внезапно решит вас спасать."

# game/script.rpy:3703
translate russian lol_432caa29:

    # "Parecía casi como si te hubieras echado perfume de feromonas o algo así, ya que atraes a tanta gente."
    "Вы как будто набрызгались духами с феромонами, раз привлекаете столько людей."

# game/script.rpy:3709
translate russian lol_8c76ab47:

    # "Al final, ellos decidieron quedarse contigo durante el día."
    "В итоге они решили остаться с вами на весь день."

# game/script.rpy:3710
translate russian lol_bce6c146:

    # "El plan de ir a un hotel se había ido por la borda, ya que se podría decir que te atraparon dentro de tu departamento."
    "План с отелем, разумеется, накрылся — можно сказать, вас просто заперли в собственной квартире."

# game/script.rpy:3711
translate russian lol_0ad70050:

    # "Si mostrabas interés en salir, Cindy y Salazar saltaban de sus lugares y te seguían como patitos bebés hacia su mamá pato."
    "Стоило вам только намекнуть на то, что вы хотите выйти, как Синди и Салазар тут же вскакивали и шли следом, словно утята за мамой-уткой."

# game/script.rpy:3712
translate russian lol_9461ca12:

    # "Así que no podías costear ir a un hotel con dos personas más, además de que no querías estar en deuda con ellos si se ofrecían a pagar."
    "А номер на троих вы не могли себе позволить. К тому же вы не хотели быть им обязанными, если бы они предложили заплатить."

# game/script.rpy:3713
translate russian lol_1846f626:

    # "Se estaba tornando cansador la vigilancia sobre ti."
    "Постоянное наблюдение начинало утомлять."

# game/script.rpy:3715
translate russian lol_2685493b:

    # "Hasta que llegó la noche."
    "Пока не наступила ночь."

# game/script.rpy:3716
translate russian lol_c0f66587:

    # "Con cada minuto, los nervios subían por tu cuerpo, ya que mientras más se oscurecía, más grande era la probabilidad de que Jeff llegara."
    "С каждой минутой тревога росла — чем темнее становилось за окном, тем выше казалась вероятность, что Джефф появится снова."

# game/script.rpy:3722
translate russian lol_82578fa0:

    # DR "Se está volviendo tarde, Cindy, deberías volver a tu casa pronto."
    DR "Уже поздновато, Синди. Тебе пора домой."

# game/script.rpy:3724
translate russian lol_d27eb48a:

    # C "¿Yo?, ¿Qué me dices de ti?, ¿No tienes un trabajo que hacer en el hospital?"
    C "Мне? А что насчёт тебя? Разве у тебя нет работы в больнице?"

# game/script.rpy:3725
translate russian lol_affcc77f:

    # DR "Mi turno empieza mañana."
    DR "Моя смена начинается завтра."

# game/script.rpy:3726
translate russian lol_3d9ed6fc:

    # C "Sí, bueno, conozco mejor a [povname]. Si alguien debería quedarse en la noche, debería ser yo."
    C "Да, но я лучше знаю [povname]. Если кто-то и должен остаться, то это я."

# game/script.rpy:3727
translate russian lol_1f361abf:

    # DR "¿Qué es más seguro que un doctor?"
    DR "А что может быть надёжнее, чем врач рядом?"

# game/script.rpy:3728
translate russian lol_642f7fb6:

    # "Cindy y Salazar se fulminan con la mirada, mientras tú aguantas."
    "Синди и Салазар обмениваются злобными взглядами, пока вы ждёте."

# game/script.rpy:3729
translate russian lol_920a57f1:

    # pov "No quiero tener a los dos aquí esta noche, fue suficiente tenerlos todo el día."
    pov "Я не хочу, чтобы вы оба торчали тут всю ночь. Одного дня с вами уже хватило."

# game/script.rpy:3730
translate russian lol_86f95e7b:

    # C "Entonces tu decide."
    C "Тогда ты решай."

# game/script.rpy:3731
translate russian lol_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:3732
translate russian lol_d5700b15:

    # DR "O nos quedamos ambos, o uno. Pero no ninguno."
    DR "Либо мы оба остаёмся, либо кто-то один. Вариант «никто» даже не обсуждается."

# game/script.rpy:3733
translate russian lol_6b3229ea:

    # "Para acorralarte, saben trabajar en equipo, ¿no?"
    "Они умеют работать в команде только тогда, когда нужно загнать вас в угол, что ли?"

# game/script.rpy:3747
translate russian salazar_2f7b6d00:

    # pov "Elijo al doctor."
    pov "Выбираю доктора."

# game/script.rpy:3749
translate russian salazar_9cb1e624:

    # "Salazar sonríe, triunfante."
    "Салазар торжествующе улыбается."

# game/script.rpy:3750
translate russian salazar_fb97a381:

    # C "¿En serio?"
    C "Серьёзно?"

# game/script.rpy:3751
translate russian salazar_c191c049:

    # "Te encoges de hombros."
    "Вы пожимаете плечами."

# game/script.rpy:3752
translate russian salazar_58759d1e:

    # "¿La oportunidad de pasar la noche con un doctor guapo?, No querías desperdiciarlo."
    "Не хотелось упускать шанс провести ночь с симпатичным врачом."

# game/script.rpy:3753
translate russian salazar_f841f260:

    # DR "No te preocupes, cuidaré bien de [povname]."
    DR "Не волнуйся, я позабочусь о [povname]."

# game/script.rpy:3754
translate russian salazar_af0d704a:

    # C "Más te vale."
    C "Смотри мне."

# game/script.rpy:3759
translate russian salazar_5827f328:

    # "Cindy toma sus cosas y se dirige a la puerta, tu la sigues para abrirle y despedirla."
    "Синди собирает вещи и направляется к двери; вы идёте за ней, чтобы открыть и попрощаться."

# game/script.rpy:3760
translate russian salazar_c98342b6:

    # pov "Gracias por venir, en serio."
    pov "Спасибо, что пришла, правда."

# game/script.rpy:3761
translate russian salazar_16c87ee6:

    # pov "Creo… Que me hacía falta sentir que me cuidan."
    pov "Наверное... мне и правда не хватало заботы."

# game/script.rpy:3763
translate russian salazar_f7b50ae9:

    # "Cindy te mira de reojo, y sonríe levemente."
    "Синди косится на вас и слегка улыбается."

# game/script.rpy:3764
translate russian salazar_45625aa7:

    # C "Sí, cuando quieras."
    C "Ага, не за что."

# game/script.rpy:3766
translate russian salazar_2945ae96:

    # "Ella rodea tu hombro con el brazo y te da un beso en la mejilla como despedida."
    "Она обнимает вас за плечи и целует в щёку на прощание."

# game/script.rpy:3767
translate russian salazar_feb8ea57:

    # "Cindy desaparece tras la puerta, y te quedas con Salazar."
    "Синди исчезает за дверью, и вы остаётесь наедине с Салазаром."

# game/script.rpy:3771
translate russian salazar_03245aa1:

    # pov "¿Quieres cenar?"
    pov "Хочешь поужинать?"

# game/script.rpy:3772
translate russian salazar_7114bff8:

    # DR "Oh, puedo cocinar algo."
    DR "О, я могу что-нибудь приготовить."

# game/script.rpy:3773
translate russian salazar_7bb763ab:

    # pov "No señor, ya haces demasiado con quedarte aquí, déjame servirte."
    pov "Нет, сэр, ты и так достаточно сделал одним своим присутствием, позволь мне обслужить тебя."

# game/script.rpy:3774
translate russian salazar_9422ccca:

    # DR "Te ayudaré entonces."
    DR "Тогда я помогу."

# game/script.rpy:3775
translate russian salazar_a1785aa4:

    # "Te ríes levemente ante la insistencia de él."
    "Вы тихо усмехаетесь его настойчивости."

# game/script.rpy:3776
translate russian salazar_148da79d:

    # "Es indiscutiblemente adorable."
    "Бесспорно, он очарователен."

# game/script.rpy:3777
translate russian salazar_cb598581:

    # "Ustedes empiezan a moverse dentro de la cocina."
    "Вы начинаете вместе суетиться на кухне."

# game/script.rpy:3782
translate russian salazar_e58c7bc0:

    # pov "Así que, ¿Eres oculista o algo así?"
    pov "Так ты офтальмолог или вроде того?"

# game/script.rpy:3783
translate russian salazar_d8a40bc7:

    # DR "Soy cirujano."
    DR "Я хирург."

# game/script.rpy:3784
translate russian salazar_f98a817f:

    # pov "¿Hace cuánto que ejerces?"
    pov "И давно практикуешь?"

# game/script.rpy:3785
translate russian salazar_25502407:

    # DR "Completé mi residencia hace 4 años. Fue duro, sobre todo porque tengo TDAH."
    DR "Ординатуру закончил 4 года назад. Было нелегко, особенно с моим СДВГ."

# game/script.rpy:3786
translate russian salazar_35031104:

    # DR "Pero con ayuda de profesores pude sobrellevarlo."
    DR "Но с помощью преподавателей всё-таки справился."

# game/script.rpy:3787
translate russian salazar_75cb5173:

    # pov "Me alegro. Soy la prueba viviente de que haces un estupendo trabajo."
    pov "Рады слышать. Я — живое доказательство, что ты отлично справляешься со своей работой."

# game/script.rpy:3790
translate russian salazar_9b834060:

    # pov "Entonces, ¿El destino, amor a primera vista?"
    pov "Значит, судьба, любовь с первого взгляда?"

# game/script.rpy:3791
translate russian salazar_1b4aadbd:

    # pov "Como hombre de ciencia, no pensé que creerías en esas cosas."
    pov "Не ожидали услышать такое от человека науки."

# game/script.rpy:3793
translate russian salazar_54f0d528:

    # "Ves como Salazar se sonroja."
    "Вы замечаете, как Салазар краснеет."

# game/script.rpy:3794
translate russian salazar_d6ef3f8e:

    # DR "No te burles de mí."
    DR "Не дразни меня."

# game/script.rpy:3795
translate russian salazar_09ec5844:

    # pov "No, no, es lindo."
    pov "Нет-нет, это мило."

# game/script.rpy:3796
translate russian salazar_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3797
translate russian salazar_db415736:

    # DR "¿Tu crees?"
    DR "Думаешь?"

# game/script.rpy:3798
translate russian salazar_c0662a5c:

    # pov "Claro."
    pov "Конечно."

# game/script.rpy:3805
translate russian salazar2_3494407d:

    # "Salazar sonríe ante tus palabras, observándote mientras sacas los ingredientes para cocinar."
    "Салазар улыбается вашим словам, наблюдая, как вы достаёте продукты."

# game/script.rpy:3806
translate russian salazar2_4162d12c:

    # DR "¿Qué vamos a cenar?"
    DR "Что будет на ужин?"

# game/script.rpy:3809
translate russian salazar2_a83a462a:

    # pov "Risotto de champiñones."
    pov "Ризотто с грибами."

# game/script.rpy:3810
translate russian salazar2_13695833:

    # pov "¿Está bien?"
    pov "Подойдёт?"

# game/script.rpy:3811
translate russian salazar2_ba2b2537:

    # DR "Por supuesto, no soy quisquilloso."
    DR "Конечно, я не привиредливый."

# game/script.rpy:3813
translate russian salazar2_1c968cb7:

    # pov "Espagueti con boloñesa."
    pov "Спагетти с болоньезе."

# game/script.rpy:3814
translate russian salazar2_4660b495:

    # DR "Ah, que rico."
    DR "О, это вкусно."

# game/script.rpy:3815
translate russian salazar2_4c98e8bf:

    # pov "¿Te gusta?"
    pov "Нравится?"

# game/script.rpy:3816
translate russian salazar2_332976ea:

    # DR "Diría que es mi platillo favorito."
    DR "Наверное, это моё любимое блюдо."

# game/script.rpy:3818
translate russian salazar2_f59c34cc:

    # "Ustedes toman asiento en la mesa y comen."
    "Вы садитесь за стол и начинаете ужинать."

# game/script.rpy:3819
translate russian salazar2_12195f94:

    # "La velada es bastante íntima, parece… como si tuvieran una cita."
    "Вечер кажется на удивление тёплым, почти... как на свидании."

# game/script.rpy:3823
translate russian salazar2_a1876a9b:

    # pov "Así que al final pudimos tener nuestra cita."
    pov "Выходит, у тебя всё-таки получилось добиться свидания."

# game/script.rpy:3825
translate russian salazar2_0d81ac85:

    # DR "¿Huh?"
    DR "А?"

# game/script.rpy:3826
translate russian salazar2_5254ae5c:

    # pov "Qué estrategia. Venir a protegerme para lograrlo."
    pov "Хитрый ход — прийти под предлогом защиты."

# game/script.rpy:3828
translate russian salazar2_ecd68f72:

    # "Salazar carraspea y se limpia la boca."
    "Салазар откашливается и вытирает рот."

# game/script.rpy:3829
translate russian salazar2_a23fa959:

    # DR "Te aseguro que mis intenciones son genuinamente de preocupación."
    DR "Уверяю тебя, я здесь исключительно из-за беспокойства."

# game/script.rpy:3830
translate russian salazar2_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3832
translate russian salazar2_73fa7511:

    # DR "Que eso haya acabado en una cita fue un bonus."
    DR "То, что это закончилось свиданием, просто бонус."

# game/script.rpy:3833
translate russian salazar2_cabb102c:

    # pov "¡Hey!"
    pov "Эй!"

# game/script.rpy:3834
translate russian salazar2_e4991e5b:

    # "Salazar se ríe ante tu reacción a su respuesta."
    "Салазар смеётся, глядя на вашу реакцию."

# game/script.rpy:3835
translate russian salazar2_2b92f220:

    # "Parece que se está acostumbrando a ti."
    "Кажется, он начинает привыкать к вам."

# game/script.rpy:3838
translate russian salazar2_10a26677:

    # pov "¿Se adapta a tu gusto?"
    pov "Ну как, нравится?"

# game/script.rpy:3839
translate russian salazar2_17f89897:

    # DR "Sí, definitivamente."
    DR "Да, ещё как."

# game/script.rpy:3840
translate russian salazar2_e0c893cc:

    # DR "Cocinas bien."
    DR "Ты хорошо готовишь."

# game/script.rpy:3841
translate russian salazar2_9e3b862c:

    # pov "No exageres, es algo simple."
    pov "Не преувеличивай, это блюдо простое."

# game/script.rpy:3842
translate russian salazar2_36c3d5d5:

    # "Salazar te sonríe levemente, murmurando para sí mismo."
    "Салазар слегка улыбается вам, бормоча про себя."

# game/script.rpy:3843
translate russian salazar2_67311c74:

    # DR "Podría comerlo todos los días…"
    DR "Я мог бы есть это каждый день..."

# game/script.rpy:3848
translate russian salazar3_aa583df7:

    # DR "Así que, dime [povname], ¿A qué te dedicas?"
    DR "Ну, [povname], расскажи, где ты работаешь?"

# game/script.rpy:3849
translate russian salazar3_1f7f5268:

    # pov "Oh, no es la gran cosa, sólo soy dependiente en una tienda de películas."
    pov "А, ничего особенного — просто продавец в видеопрокате."

# game/script.rpy:3850
translate russian salazar3_29e9b86a:

    # DR "Oh, ¿Como un blockbuster?"
    DR "Вроде Blockbuster?"

# game/script.rpy:3851
translate russian salazar3_78bdadea:

    # pov "Básicamente, pero es sólo una tienda local, no una cadena."
    pov "Типа того, только это не сеть, а местный магазин."

# game/script.rpy:3852
translate russian salazar3_6d594a6a:

    # pov "El dueño es un amante del séptimo arte, y también el padre de Cin."
    pov "Хозяин — киноман, ну и отец Син."

# game/script.rpy:3853
translate russian salazar3_05d5ba1d:

    # DR "Ah, ya veo."
    DR "А, понятно."

# game/script.rpy:3854
translate russian salazar3_9e8a2215:

    # DR "¿No hay nepotismo?"
    DR "Без кумовства?"

# game/script.rpy:3855
translate russian salazar3_d186a46f:

    # pov "Para nada. De hecho, creo que a mi jefe le frustra que Cindy no comparta su pasión."
    pov "Вовсе нет. Думаю, моему боссу даже обидно, что Синди не разделяет его киноманию."

# game/script.rpy:3856
translate russian salazar3_2cbac6b6:

    # DR "¿Qué me dices de ti?"
    DR "А ты?"

# game/script.rpy:3857
translate russian salazar3_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:3858
translate russian salazar3_a72770d2:

    # DR "¿Te apasionan las películas?"
    DR "Ты тоже увлекаешься кино?"

# game/script.rpy:3860
translate russian salazar3_5336a684:

    # pov "Claro, es lo que me hace disfrutar un poco más mi trabajo."
    pov "Конечно, это и делает мою работу немного приятнее."

# game/script.rpy:3862
translate russian salazar3_fa1b1549:

    # pov "La verdad es que no mucho."
    pov "Если честно, не очень."

# game/script.rpy:3863
translate russian salazar3_f178c85e:

    # pov "El trabajo me sirve porque está cerca de donde vivo y la paga es buena."
    pov "Я работаю там потому, что магазин находится рядом с домом, и зарплата хорошая."

# game/script.rpy:3864
translate russian salazar3_732ab2cd:

    # pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "В любом случае, последние воспоминания о работе не самые приятные."

# game/script.rpy:3865
translate russian salazar3_356b26c9:

    # pov "Todavía tenía los dos ojos."
    pov "Тогда у меня ещё были оба глаза."

# game/script.rpy:3867
translate russian salazar3_2c86f2d5:

    # "Salazar se remueve incómodo ante tu comentario."
    "Салазар неловко ёрзает от вашего комментария."

# game/script.rpy:3868
translate russian salazar3_fb8e715b:

    # DR "Me hubiera gustado poder recuperar tu ojo, pero…"
    DR "Я хотел бы спасти твой глаз, но..."

# game/script.rpy:3869
translate russian salazar3_3d4aeb98:

    # pov "Lo entiendo, no te preocupes."
    pov "Я понимаю, не волнуйся."

# game/script.rpy:3870
translate russian salazar3_cde22bdc:

    # pov "El cuerpo humano es frágil."
    pov "Человеческое тело хрупкое."

# game/script.rpy:3872
translate russian salazar3_487c2e57:

    # DR "Cierto. Es imposible para nosotros crear un órgano o extremidad a gusto, hay que proteger nuestro cuerpo."
    DR "Точно. Мы не можем просто так отрастить себе орган или конечность — всё, что у нас есть, нужно беречь."

# game/script.rpy:3873
translate russian salazar3_f0fa9ff9:

    # "La seriedad en la voz de Salazar te deja en silencio. Claro, siendo doctor, es parte de su trabajo velar por la seguridad del cuerpo humano."
    "Серьёзность в голосе Салазара заставляет вас замолчать. Неудивительно — он ведь врач, забота о человеческом теле часть его работы."

# game/script.rpy:3874
translate russian salazar3_944eea90:

    # "Pero podías ver preocupación verdadera por la vida."
    "Но в его глазах читается искренняя забота о жизни."

# game/script.rpy:3876
translate russian salazar3_52a9f735:

    # "Viendo los platos vacíos, haces el ademán de levantarte, pero Salazar te detiene con un gesto de su mano."
    "Увидев пустые тарелки, вы собираетесь встать, но Салазар останавливает вас движением руки."

# game/script.rpy:3877
translate russian salazar3_c8695aa7:

    # DR "Yo lavaré los platos."
    DR "Я помою посуду."

# game/script.rpy:3878
translate russian salazar3_a5c191d7:

    # "Alzas las manos en derrota."
    "Вы поднимаете руки, сдаваясь."

# game/script.rpy:3879
translate russian salazar3_364f35a4:

    # pov "Lo que digas."
    pov "Как скажешь."

# game/script.rpy:3881
translate russian salazar3_92a5850d:

    # "Observas cómo él se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "Вы наблюдаете, как он собирает тарелки, приборы и стаканы, и идёт к раковине, начиная возиться с водой и моющим средством."

# game/script.rpy:3882
translate russian salazar3_e6f7560f:

    # "Te quedas cerca, admirando la figura de su espalda ancha y sus brazos moviéndose."
    "Вы остаётесь рядом, любуясь его широкой спиной и движущимися руками."

# game/script.rpy:3883
translate russian salazar3_afcbbbf2:

    # pov "Así que… Sólo tengo una cama."
    pov "Итак... У меня только одна кровать."

# game/script.rpy:3885
translate russian salazar3_7fd2734b:

    # "Los platos se le caen de las manos a Salazar, pero afortunadamente dentro del lavadero."
    "Тарелки выскальзывают из рук Салазара, но, к счастью, падают прямо в раковину."

# game/script.rpy:3887
translate russian salazar3_afe607a0:

    # DR "N-no te preocupes, puedo dormir en el sofá."
    DR "Н-не беспокойся, я могу спать на диване."

# game/script.rpy:3888
translate russian salazar3_2399dfd5:

    # DR "No podría abusar de tu hospitalidad…"
    DR "Не хочу злоупотреблять твоим гостеприимством..."

# game/script.rpy:3892
translate russian salazar3_ca4afc7e:

    # pov "Hey, tranquilo."
    pov "Эй, успокойся."

# game/script.rpy:3893
translate russian salazar3_10e5d453:

    # pov "No tenemos que hacer nada."
    pov "Я тебя ни к чему не принуждаю."

# game/script.rpy:3894
translate russian salazar3_8ffabcbf:

    # pov "Pero no me gusta la idea de dejarte solo con un asesino suelto, mejor juntos que separados, ¿No?"
    pov "Просто не нравится мысль, что ты останешься один, пока где-то шастает убийца. Лучше вместе, чем порознь, верно?"

# game/script.rpy:3897
translate russian salazar3_d3ec7b81:

    # pov "No te preocupes, no va a pasar nada."
    pov "Не переживай, ничего не случится."

# game/script.rpy:3898
translate russian salazar3_7afa90de:

    # pov "Mi cama es lo suficientemente grande."
    pov "Кровать у меня большая."

# game/script.rpy:3899
translate russian salazar3_1b10b761:

    # pov "Me sentiré mal si te dejo durmiendo en mi duro sofá."
    pov "Мне будет неловко, если оставлю тебя спать на жёстком диване."

# game/script.rpy:3906
translate russian salazar4_723c69de:

    # DR "…"
    DR "..."

# game/script.rpy:3907
translate russian salazar4_005c554f:

    # DR "De acuerdo."
    DR "Хорошо."

# game/script.rpy:3908
translate russian salazar4_05f7534a:

    # "Asientes levemente, retirándote de la cocina."
    "Вы едва заметно киваете и уходите с кухни."

# game/script.rpy:3909
translate russian salazar4_89c67d48:

    # pov "Iré a prepararme para dormir."
    pov "Я пойду готовиться ко сну."

# game/script.rpy:3911
translate russian salazar4_d3bb59d0:

    # "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "Вы направляетесь в ванную, принимаете душ и надеваете пижаму."

# game/script.rpy:3912
translate russian salazar4_36efb37c:

    # "Por un momento te detienes frente al espejo."
    "На мгновение вы задерживаетесь перед зеркалом."

# game/script.rpy:3913
translate russian salazar4_812d7ddc:

    # "Tienes un poco de nervios por pasar la noche con Salazar, pero había algo más…"
    "Вы немного нервничаете из-за того, что придётся провести ночь с Салазаром, но кроме этого..."

# game/script.rpy:3914
translate russian salazar4_744ba675:

    # "Si Jeff venía…"
    "Если Джефф придёт..."

# game/script.rpy:3915
translate russian salazar4_4c031422:

    # "No, no debías pensar así."
    "Нет, нельзя думать в этом ключе."

# game/script.rpy:3916
translate russian salazar4_44f55333:

    # "Él era un cobarde, sólo te atacaba cuando estabas a solas."
    "Он — трус. Нападал только тогда, когда вы были одни."

# game/script.rpy:3917
translate russian salazar4_a9ad4690:

    # "Si, eso era seguro."
    "Да, в этом нет сомнений."

# game/script.rpy:3918
translate russian salazar4_2f8afdd7:

    # "Técnicamente, tener a alguien contigo era evitarlo."
    "Технически, раз вы не одни, то прийти он не должен."

# game/script.rpy:3919
translate russian salazar4_2d44ad4c:

    # "Él mismo lo había dicho, este juego era entre ustedes dos. Así que Jeff no debería involucrar a Salazar."
    "Он сам сказал, что эта игра только между вами. Так что Джефф не должен тронуть Салазара."

# game/script.rpy:3923
translate russian salazar4_c68da183:

    # "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Salazar."
    "С этой мыслью вы выходите из ванной и возвращаетесь на кухню, чтобы найти Салазара."

# game/script.rpy:3924
translate russian salazar4_dccb1337:

    # pov "El baño está libre, por si quieres usarlo. Es la puerta al fondo del pasillo, a la izquierda."
    pov "Ванная свободна, если хочешь — можешь воспользоваться. Дверь в конце коридора, слева."

# game/script.rpy:3925
translate russian salazar4_5d91858d:

    # DR "Oh, gracias."
    DR "О, спасибо."

# game/script.rpy:3926
translate russian salazar4_f0b8251b:

    # pov "Mi habitación es la puerta de enfrente."
    pov "Моя комната — прямо напротив."

# game/script.rpy:3927
translate russian salazar4_723c69de_1:

    # DR "…"
    DR "..."

# game/script.rpy:3928
translate russian salazar4_bf6b01c5:

    # DR "S-sí…"
    DR "Д-да..."

# game/script.rpy:3929
translate russian salazar4_c1b51dda:

    # "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    "Вы молча киваете и возвращаетесь обратно, на этот раз направляясь в свою комнату."

# game/script.rpy:3933
translate russian salazar4_3b666ceb:

    # "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Salazar."
    "Ложитесь на кровать, стараясь оставить Салазару место."

# game/script.rpy:3934
translate russian salazar4_0bec2b3e:

    # "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "Из комнаты доносятся звуки — щёлканье выключателя, шум воды."

# game/script.rpy:3935
translate russian salazar4_8ab1535a:

    # "Unos instantes después, Salazar avanzaba hacia ti, lentamente, como si temiera sobresaltarte."
    "Спустя некоторое время Салазар медленно подходит к вам, будто боясь напугать."

# game/script.rpy:3936
translate russian salazar4_86f6bfdc:

    # pov "Adelante, no muerdo."
    pov "Давай, я не кусаюсь."

# game/script.rpy:3943
translate russian salazar4_daf8ad5e:

    # "Con la escasa luz, alcanzas a ver que él sonreía levemente ante tu broma, pero se mantuvo en silencio mientras se acomodaba bajo las sábanas junto a ti."
    "В полумраке вы замечаете лёгкую улыбку на его лице — он оценил вашу шутку, хотя ничего не ответил, устраиваясь под одеялом рядом с вами."

# game/script.rpy:3944
translate russian salazar4_4df2ba05:

    # "Él fue cuidadoso, pero no pudo evitar rozar su pierna con la tuya."
    "Он осторожен, но всё же его нога невольно касается вашей."

# game/script.rpy:3945
translate russian salazar4_dd316d3a:

    # DR "Lo siento, yo no-"
    DR "Прости, я не—"

# game/script.rpy:3946
translate russian salazar4_73aa2c46:

    # pov "Está bien."
    pov "Всё хорошо."

# game/script.rpy:3947
translate russian salazar4_2ba06661:

    # pov "No soy tan frágil, ¿Sabes?"
    pov "Я не настолько хрупкие, знаешь ли."

# game/script.rpy:3948
translate russian salazar4_3f0ad104:

    # "Él te mira, sus ojos brillando con la escasa luz."
    "Он смотрит на вас — в тусклом свете его глаза поблёскивают."

# game/script.rpy:3949
translate russian salazar4_ddd79075:

    # DR "Temo que por pensar así, no vas a tener cuidado."
    DR "Боюсь, если будешь так думать, то перестанешь быть осторожными."

# game/script.rpy:3950
translate russian salazar4_e65934ca:

    # "Bueno, no estaba del todo equivocado."
    "Ну, тут он прав."

# game/script.rpy:3951
translate russian salazar4_3135bcf1:

    # "Al final, todo se remonta a lo que sucedió con Jeff."
    "Всё так или иначе возвращается к тому, что произошло с Джеффом."

# game/script.rpy:3952
translate russian salazar4_07d3ac4f:

    # "Tal vez si no te hubiera atacado, nunca hubieras conocido a Salazar."
    "Может, если бы не то нападение, вы бы никогда не встретили Салазара."

# game/script.rpy:3953
translate russian salazar4_5aacd7c1:

    # pov "¿Por qué yo?"
    pov "Почему я?"

# game/script.rpy:3954
translate russian salazar4_7b9a00e2:

    # pov "¿Qué tengo de especial?"
    pov "Что во мне особенного?"

# game/script.rpy:3956
translate russian salazar4_a6a132c5:

    # "Inesperadamente, sientes que la mano de él roza tu mejilla, y acaricia con su pulgar delicadamente."
    "Неожиданно вы чувствуете, как его ладонь касается вашей щеки, большой палец мягко скользит по коже."

# game/script.rpy:3957
translate russian salazar4_7c9a1f9a:

    # DR "No lo sé, porque eres tú."
    DR "Не знаю, просто ты — это ты."

# game/script.rpy:3958
translate russian salazar4_6905f509:

    # "Él se ríe levemente."
    "Он тихо смеётся."

# game/script.rpy:3959
translate russian salazar4_246d0cac:

    # DR "Es extraño, siento que conozco tu rostro, pero no puedo describirlo con palabras."
    DR "Странно. Такое чувство, будто я знаю твоё лицо, но не могу описать его словами."

# game/script.rpy:3960
translate russian salazar4_24a51992:

    # DR "Pero aún así, me gustas."
    DR "И всё же, ты мне нравишься."

# game/script.rpy:3962
translate russian salazar4_c99d28b0:

    # "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    "Ваше сердце начинает биться быстрее, а воздух между вами словно нагревается."

# game/script.rpy:3963
translate russian salazar4_7d52aa18:

    # pov "B-buenas noches."
    pov "Д-доброй ночи."

# game/script.rpy:3964
translate russian salazar4_bc9280c2:

    # DR "Descansa, [povname]."
    DR "Отдыхай, [povname]."

# game/script.rpy:3967
translate russian salazar4_b6855784:

    # "Cierras tu ojo, concentrándote en tu respiración y la de él para dormir."
    "Вы закрываете глаз, прислушиваясь к своему дыханию и его, постепенно погружаясь в сон."

# game/script.rpy:3968
translate russian salazar4_c71d7ef8:

    # "Pronto, lo logras."
    "Вскоре вам это удаётся."

# game/script.rpy:3970
translate russian salazar4_c8c6c79c:

    # "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Salazar, te das cuenta de que no está en la cama."
    "Неясно, спите вы или нет, когда вдруг слышите какой-то шум. Вы тянетесь рукой к Салазару — и вдруг понимаете, что кровать пуста."

# game/script.rpy:3973
translate russian salazar4_b0a34dc6:

    # "Te levantas y sigilosamente sales de tu habitación."
    "Вы встаёте и тихо выходите из комнаты."

# game/script.rpy:3974
translate russian salazar4_2c0d1dba:

    # "No escuchas nada, pero eso no te calma."
    "Вы ничего не слышите, но это вас не успокоило."

# game/script.rpy:3976
translate russian salazar4_6558a98d:

    # "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    "Вы сразу же попадаете в гостиную, где становитесь свидетелем худшего сценария."

# game/script.rpy:3982
translate russian salazar4_2defa1a6:

    # "Jeff tiene a Salazar sujetado desde el cuello, apuntando la punta del cuchillo contra su garganta."
    "Джефф держит Салазара, сжимая его шею, а лезвие ножа упирается прямо в горло."

# game/script.rpy:3983
translate russian salazar4_e90ea612:

    # "¿En qué momento entró Jeff, Salazar se levantó y se enfrentaron?"
    "В какой момент вошёл Джефф, встал Салазар и они столкнулись?"

# game/script.rpy:3984
translate russian salazar4_1dcafc75:

    # "Eso debió producir un ruido, pero no tenías idea."
    "Всё это должно было сопровождаться шумом, но вы ничего не слышали."

# game/script.rpy:3985
translate russian salazar4_c380c9fc:

    # "Parece que Jeff es muy bueno en lo que hace."
    "Кажется, Джефф очень хорош в своём деле."

# game/script.rpy:3986
translate russian salazar4_2ebc0818:

    # J "[povname]... Dije que volvería."
    J "[povname]... Я же говорил, что вернусь."

# game/script.rpy:3987
translate russian salazar4_ff798c78:

    # pov "… Si, puedo darme cuenta."
    pov "...Ага, я вижу."

# game/script.rpy:3988
translate russian salazar4_fdb72a44:

    # J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    J "Советую следить за словами. Кто-то может пострадать."

# game/script.rpy:3989
translate russian salazar4_bfc95450:

    # "Jeff acercó más el cuchillo al cuello de Salazar."
    "Джефф подносит нож ещё ближе к шее Салазара."

# game/script.rpy:3992
translate russian salazar4_7d652c82:

    # pov "N-no le hagas daño."
    pov "Н-не трогай его."

# game/script.rpy:3993
translate russian salazar4_80f14a61:

    # J "¿Oh?"
    J "О?"

# game/script.rpy:3994
translate russian salazar4_9f2d13ed:

    # J "¿Así que te preocupas por este bastardo?"
    J "Значит, переживаешь за этого ублюдка?"

# game/script.rpy:3995
translate russian salazar4_3a8de979:

    # pov "Hey, no le digas así."
    pov "Эй, не называй его так."

# game/script.rpy:3996
translate russian salazar4_0b6f4b11:

    # J "Sigues probando mi punto."
    J "Только подтверждаешь мои слова."

# game/script.rpy:3998
translate russian salazar4_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:3999
translate russian salazar4_e95a949d:

    # pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
    pov "Тебя уже разыскивают за нападение на меня, а теперь ты хочешь навредить ещё одному человеку?"

# game/script.rpy:4000
translate russian salazar4_e3b99848:

    # pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
    pov "Подумай, Джефф. Ещё больше копов будут искать тебя."

# game/script.rpy:4001
translate russian salazar4_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4003
translate russian salazar4_8320052c:

    # J "Entonces… No te importará si hago esto, ¿O sí?"
    J "Тогда... ты не возражаешь, если я сделаю вот так?"

# game/script.rpy:4005
translate russian salazar4_439a6e00:

    # "Jeff hace un corte en la mejilla de Salazar, el cual suelta un quejido ahogado mientras la hoja corta su piel."
    "Джефф проводит лезвием по щеке Салазара. Тот лишь глухо стонет, когда лезвие рассекает его кожу."

# game/script.rpy:4006
translate russian salazar4_b0290aa3:

    # pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "Подожди, стой! Это между нами, забыл?"

# game/script.rpy:4007
translate russian salazar4_7b2d9b72:

    # pov "No hay por qué involucrarlo."
    pov "Не нужно его в это впутывать."

# game/script.rpy:4008
translate russian salazar4_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4023
translate russian muerte_salazar_8fad5404:

    # "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por la garganta de Salazar."
    "Джефф полностью игнорирует ваши слова и проводит лезвием ножа по горлу Салазара."

# game/script.rpy:4025
translate russian muerte_salazar_9318ba06:

    # "Él gorgotea y Jeff lo suelta."
    "Тот хрипит, и Джефф отпускает его."

# game/script.rpy:4028
translate russian muerte_salazar_aeb4ad77:

    # "Salazar se lleva las manos al cuello, tratando de parar la hemorragia, pero sus piernas ceden y él cae."
    "Салазар хватается за шею в попытке остановить кровотечение, но его ноги подкашиваются, и он падает."

# game/script.rpy:4029
translate russian muerte_salazar_4c449a05:

    # "Te petrificas en tu lugar, viendo que debajo de Salazar crece un charco oscuro."
    "Вы застываете, наблюдая, как под телом Салазара растекается тёмная лужа."

# game/script.rpy:4032
translate russian muerte_salazar_cb65dbdc:

    # J "Hah… Eres tan hipócrita."
    J "Хах... Как лицемерно."

# game/script.rpy:4033
translate russian muerte_salazar_4eef6bc5:

    # "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Джефф делает шаг к вам, равнодушно ступая в кровь."

# game/script.rpy:4034
translate russian muerte_salazar_423bd7b9:

    # "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "Он хватает вас за воротник, поднимая окровавленный нож."

# game/script.rpy:4035
translate russian muerte_salazar_48a4acbc:

    # "Tú aún no puedes desviar tu mirada atónita del cadáver de Salazar en el suelo."
    "Вы не можете отвести взгляд от трупа Салазара на полу."

# game/script.rpy:4036
translate russian muerte_salazar_ac78924b:

    # J "Te advertí que me aburro fácilmente."
    J "Я же предупреждал, что мне легко наскучить."

# game/script.rpy:4037
translate russian muerte_salazar_ed84a216:

    # "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    "Последнее, что вы видите, — Джефф, поднимающий свой нож, не сводя с вас взгляда."

# game/script.rpy:4043
translate russian muerte_salazar_f4ec26fd:

    # "{b}Final V: Lo Decepcionaste{/b}"
    "{b}Концовка V: Вы его разочаровали{/b}"

# game/script.rpy:4053
translate russian hisotria_continua_salazar_7dd60366:

    # "Jeff aleja el cuchillo del cuello de Salazar, y en cambio lo entierra en su hombro."
    "Джефф убирает нож от шеи Салазара и вместо этого вонзает его в плечо."

# game/script.rpy:4054
translate russian hisotria_continua_salazar_c794cb8d:

    # "Salazar deja salir un alarido que es prontamente callado por la mano de Jeff."
    "Салазар издаёт крик, моментально приглушённый рукой Джеффа."

# game/script.rpy:4057
translate russian hisotria_continua_salazar_ed4b3062:

    # "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo y Salazar cae al suelo, su herida sangrando constantemente."
    "Вы наблюдаете, как они борются, пока Джефф не выдёргивает нож. Салазар падает на пол, его рана непрерывно кровоточит."

# game/script.rpy:4058
translate russian hisotria_continua_salazar_2c9160f8:

    # DR "[povname]... Corre…"
    DR "[povname]... Беги..."

# game/script.rpy:4061
translate russian hisotria_continua_salazar_d1f17cd0:

    # J "No te molestes, guapo."
    J "Не утруждайся, красавчик."

# game/script.rpy:4062
translate russian hisotria_continua_salazar_a01357f1:

    # "Jeff estiró una sonrisa burlona."
    "Джефф издевательски улыбается."

# game/script.rpy:4063
translate russian hisotria_continua_salazar_1f8a5cca:

    # J "Hay nueva jurisdicción."
    J "Правила изменились."

# game/script.rpy:4065
translate russian hisotria_continua_salazar_7738fd5b:

    # "Jeff ignora el cuerpo de Salazar y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Джефф игнорирует тело Салазара и просто идёт к вам, его мутноватые глаза мерцают в полумраке."

# game/script.rpy:4066
translate russian hisotria_continua_salazar_8bb827e8:

    # "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    "Вы бросаетесь прочь — возможно, к ванной или к своей комнате."

# game/script.rpy:4068
translate russian hisotria_continua_salazar_041dc4c4:

    # "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    "Но Джефф успевает схватить вас за запястье, не давая сдвинуться с места."

# game/script.rpy:4069
translate russian hisotria_continua_salazar_b5dd6c81:

    # J "Es curioso… No quiero dañarte, no como antes al menos."
    J "Забавно... Я не хочу причинять тебе боль. По крайней мере не так, как раньше."

# game/script.rpy:4070
translate russian hisotria_continua_salazar_b0000ffa:

    # J "¿Por qué será?"
    J "Интересно, почему?"

# game/script.rpy:4074
translate russian hisotria_continua_salazar_a84a1a84:

    # pov "T-tal vez es porque te gusto."
    pov "М-может, потому что я тебе нравлюсь."

# game/script.rpy:4076
translate russian hisotria_continua_salazar_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4077
translate russian hisotria_continua_salazar_a56d14b5:

    # J "¿Cómo dices?"
    J "Что?"

# game/script.rpy:4078
translate russian hisotria_continua_salazar_801770c2:

    # pov "Ya sabes, ¿Te intereso?"
    pov "Ну, я же тебе интересны?"

# game/script.rpy:4079
translate russian hisotria_continua_salazar_0b12aa55:

    # pov "¿Tienes un crush conmigo?"
    pov "Ты влюбился в меня?"

# game/script.rpy:4082
translate russian hisotria_continua_salazar_1612e3fd:

    # pov "Quizás quieres dejarme en paz."
    pov "Может, ты хочешь оставить меня в покое."

# game/script.rpy:4084
translate russian hisotria_continua_salazar_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4085
translate russian hisotria_continua_salazar_a781321d:

    # J "Nah, no es eso. Todo lo contrario."
    J "Не-а, точно нет. Даже наоборот."

# game/script.rpy:4086
translate russian hisotria_continua_salazar_9a4e417d:

    # pov "Entonces… ¿Tienes una fijación conmigo?"
    pov "Так... Ты ко мне неравнодушен?"

# game/script.rpy:4087
translate russian hisotria_continua_salazar_a713ab28:

    # J "¿Ah?"
    J "А?"

# game/script.rpy:4093
translate russian salazar5_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4094
translate russian salazar5_29180233:

    # "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    "Вы просто ляпнули первое, что пришло в голову, в надежде, что он остановится."

# game/script.rpy:4096
translate russian salazar5_50dfff11:

    # J "¡Oh, ya veo!"
    J "А, вот оно что!"

# game/script.rpy:4097
translate russian salazar5_be1402e7:

    # "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    "Джефф наклоняется к вам, его улыбка неестественно растягивается, пока он сверлит вас взглядом."

# game/script.rpy:4099
translate russian salazar5_7071d957:

    # J "¡Te deseo!"
    J "Я хочу тебя!"

# game/script.rpy:4100
translate russian salazar5_6474133b:

    # J "¡A ti!"
    J "Тебя!"

# game/script.rpy:4101
translate russian salazar5_01867340:

    # "Jeff suelta una carcajada estridente."
    "Джефф издаёт пронзительный смех."

# game/script.rpy:4102
translate russian salazar5_c0728fa7:

    # "No sabes si sonreír u horrorizarte."
    "Вы не знаете, улыбнуться в ответ или ужаснуться."

# game/script.rpy:4103
translate russian salazar5_90770e2a:

    # J "¡Eso explica muchas cosas!"
    J "Многое объясняет!"

# game/script.rpy:4105
translate russian salazar5_bdec5f1d:

    # "El agarre en tu mano se hace más fuerte, y él tira de ti."
    "Хватка на вашей руке усиливается, и тянет вас ближе."

# game/script.rpy:4106
translate russian salazar5_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Подожди, что ты делаешь?"

# game/script.rpy:4107
translate russian salazar5_d764cb51:

    # J "Ya descubrí lo que quiero."
    J "Я наконец понял, чего хочу."

# game/script.rpy:4108
translate russian salazar5_82658285:

    # J "No quiero seguir jugando contigo."
    J "Больше не хочу с тобой играть."

# game/script.rpy:4109
translate russian salazar5_35012658:

    # "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    "На мгновение вас охватывает облегчение от его слов, но когда Джефф притягивает вас к себе, и вы сталкиваетесь с его грудью, по телу пробегает холод."

# game/script.rpy:4110
translate russian salazar5_4f0b84e3:

    # J "Quiero tenerte para mí."
    J "Я хочу, чтобы ты принадлежали только мне."

# game/script.rpy:4111
translate russian salazar5_bba5eefc:

    # "Entonces te das cuenta que te está guiando a la salida."
    "И тут вы понимаете, что он ведёт вас к выходу."

# game/script.rpy:4112
translate russian salazar5_d27395d2:

    # "En un instante, viste el cuerpo de Salazar aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    "Вы оглядываетесь на тело Салазара, неподвижно лежащее на полу, и вас охватывает беспокойство."

# game/script.rpy:4113
translate russian salazar5_1276a7ba:

    # pov "¿Qué hay de-?"
    pov "А как же—?"

# game/script.rpy:4114
translate russian salazar5_886cf72a:

    # J "No pienses en él."
    J "Не думай о нём."

# game/script.rpy:4117
translate russian salazar5_279d16da:

    # "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Холодные, большие руки обхватывают ваши щёки, и вы чувствуете, как что-то влажное попадает на кожу."

# game/script.rpy:4118
translate russian salazar5_2b9a40af:

    # "Por el olor, te das cuenta que es sangre."
    "По запаху вы понимаете, что это кровь."

# game/script.rpy:4119
translate russian salazar5_727428c4:

    # "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    "Чёлка Джеффа слегка касается вашего лба, и всё, что вы видите — это его глаза."

# game/script.rpy:4120
translate russian salazar5_e83bba11:

    # J "Sólo céntrate en mí."
    J "Смотри только на меня."

# game/script.rpy:4121
translate russian salazar5_a2a404e6:

    # "Has visto de lo que es capaz."
    "Вы видели, на что он способен."

# game/script.rpy:4122
translate russian salazar5_35f60b9f:

    # "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "Он причиняет боль не только вам, а всем, кто оказывается рядом."

# game/script.rpy:4123
translate russian salazar5_e921f59d:

    # "Eso te hizo considerar sus palabras, profundamente."
    "Это заставляет вас всерьёз задуматься над его словами."

# game/script.rpy:4134
translate russian cindy_85122899:

    # pov "Elijo a Cindy."
    pov "Выбираю Синди."

# game/script.rpy:4137
translate russian cindy_de96dad9:

    # "Ella sonríe satisfecha, y él suspira decepcionado."
    "Она довольно улыбается, а он лишь тяжело вздыхает."

# game/script.rpy:4138
translate russian cindy_dee4bd4c:

    # DR "De acuerdo, comprendo."
    DR "Ладно, я понимаю."

# game/script.rpy:4139
translate russian cindy_c42bc9b2:

    # "Preferías pasar la noche con alguien a quien conoces mejor, además de que fue a la academia de policía. Eso inspira seguridad."
    "Вы решили остаться с тем, кого знаете лучше; к тому же Синди училась в полицейской академии. Это внушает чувство безопасности."

# game/script.rpy:4144
translate russian cindy_31c2ce66:

    # "Salazar se dirige a la puerta, tú lo sigues para abrirle y despedirlo."
    "Салазар направляется к двери, а вы идёте за ним, чтобы открыть дверь и попрощаться."

# game/script.rpy:4145
translate russian cindy_c98342b6:

    # pov "Gracias por venir, en serio."
    pov "Спасибо, что пришёл, правда."

# game/script.rpy:4146
translate russian cindy_16c87ee6:

    # pov "Creo… Que me hacía falta sentir que me cuidan."
    pov "Наверное... мне и правда не хватало заботы."

# game/script.rpy:4148
translate russian cindy_2f1925a4:

    # "Salazar te mira de reojo, y sonríe levemente."
    "Салазар бросает на вас короткий взгляд и слегка улыбается."

# game/script.rpy:4149
translate russian cindy_c48996a4:

    # DR "Siempre estaré para ti."
    DR "Я всегда буду рядом."

# game/script.rpy:4151
translate russian cindy_9a81af9f:

    # "Él acaricia suavemente la parte superior de tu cabeza."
    "Он ласково гладит вас по голове."

# game/script.rpy:4152
translate russian cindy_ed1f49d8:

    # "Salazar desaparece tras la puerta, y te quedas con Cindy."
    "Салазар исчезает за дверью, и вы остаётесь наедине с Синди."

# game/script.rpy:4156
translate russian cindy_03245aa1:

    # pov "¿Quieres cenar?"
    pov "Хочешь поужинать?"

# game/script.rpy:4157
translate russian cindy_c4ae6c73:

    # C "Seguro."
    C "Конечно."

# game/script.rpy:4158
translate russian cindy_c317b3f8:

    # pov "¿Prefieres cocinar o pedir algo?"
    pov "Предпочитаешь приготовить или заказать что-нибудь?"

# game/script.rpy:4159
translate russian cindy_efc83638:

    # C "Conozco un buen restaurante chino a domicilio cerca de aquí."
    C "Я знаю хорошую китайскую доставку неподалёку."

# game/script.rpy:4160
translate russian cindy_ddb4b8d6:

    # "Asientes con la cabeza."
    "Вы киваете."

# game/script.rpy:4161
translate russian cindy_1cb031e6:

    # pov "De acuerdo."
    pov "Хорошо."

# game/script.rpy:4162
translate russian cindy_afbd33e0:

    # "Ella saca su teléfono, y los adornos colgados en el aparato tintinean con cada movimiento."
    "Она достаёт телефон, и маленькие подвески, украшающие чехол, звенят при каждом движении."

# game/script.rpy:4163
translate russian cindy_7bacd44e:

    # C "¿Alguna alergia, algo que no comas?"
    C "Есть аллергии? Что-то, что не ешь?"

# game/script.rpy:4165
translate russian cindy_ecc3b640:

    # pov "La opción vegana para mí, por favor."
    pov "Мне что-нибудь веганское, пожалуйста."

# game/script.rpy:4167
translate russian cindy_19a768c6:

    # pov "Nada que reportar."
    pov "Нет, ничего."

# game/script.rpy:4168
translate russian cindy_d51028a4:

    # "Cindy asiente y hace el pedido."
    "Синди кивает и делает заказ."

# game/script.rpy:4172
translate russian cindy_1557af9b:

    # "Mientras ustedes esperan en el sofá, se mantienen en silencio."
    "Вы молча ждёте на диване."

# game/script.rpy:4176
translate russian cindy_a1a4d364:

    # pov "Así que, ¿Policía?"
    pov "Значит, полиция?"

# game/script.rpy:4177
translate russian cindy_1f540cdc:

    # pov "Honestamente, no me lo esperaba."
    pov "Честно говоря, я не ожидали."

# game/script.rpy:4178
translate russian cindy_a6daf0ab:

    # C "Seh, lo sé."
    C "Ага, знаю."

# game/script.rpy:4179
translate russian cindy_918fb9a0:

    # C "En lo académico resaltaba, pero tenía desventaja en lo físico."
    C "С учёбой у меня всё было отлично, но вот с физподготовкой — не очень."

# game/script.rpy:4180
translate russian cindy_c2563f85:

    # C "Aún si las llaves funcionan por la gravedad, se requiere cierta cantidad de fuerza."
    C "Даже если удержание делается за счёт рычага, всё равно нужна сила."

# game/script.rpy:4181
translate russian cindy_bb5f9ff5:

    # C "Fuerza que no tengo"
    C "Которой у меня нет."

# game/script.rpy:4184
translate russian cindy_f7b8e4e1:

    # pov "Entonces, ¿Hiciste toda una investigación policial sólo por mi?"
    pov "Так ты провела целое полицейское расследование ради меня?"

# game/script.rpy:4185
translate russian cindy_860c5ad7:

    # "Cindy te mira de reojo"
    "Синди бросает на вас косой взгляд."

# game/script.rpy:4186
translate russian cindy_bebfd7e8:

    # C "¿Cuál es tu punto?"
    C "Ты это к чему?"

# game/script.rpy:4187
translate russian cindy_34caae46:

    # pov "Oh, nada."
    pov "А, ни к чему."

# game/script.rpy:4188
translate russian cindy_dcf5477d:

    # pov "Sólo que aparentemente estás dispuesta a varias cosas por mí."
    pov "Просто выглядит так, будто ты готова на многое ради меня."

# game/script.rpy:4189
translate russian cindy_cd2202af:

    # pov "Como pasar la noche."
    pov "Например, остаться на ночь."

# game/script.rpy:4191
translate russian cindy_1b1b255f:

    # "Cindy desvía la mirada, pero notas cómo sus mejillas se encienden levemente."
    "Синди отводит взгляд, но вы замечаете, как её щёки чуть розовеют."

# game/script.rpy:4192
translate russian cindy_dea0df56:

    # C "No te hagas ilusiones."
    C "Не обольщайся."

# game/script.rpy:4198
translate russian cindy2_4d1df216:

    # "Ustedes pasan los siguientes minutos esperando por el pedido, y cuando llega, se sirven en la cocina."
    "Вы проводите несколько минут в ожидании заказа, а когда еда наконец приезжает, вы относите всё на кухню."

# game/script.rpy:4202
translate russian cindy2_4ea9e78f:

    # "Cindy come lentamente, picoteando la comida."
    "Синди ест медленно, ковыряясь в еде."

# game/script.rpy:4203
translate russian cindy2_5f75150b:

    # "Parece estar pensando en otra cosa."
    "Кажется, она думает о чём-то другом."

# game/script.rpy:4207
translate russian cindy2_24c2f3f2:

    # pov "¿En qué piensas tanto?"
    pov "О чём задумалась?"

# game/script.rpy:4208
translate russian cindy2_8de00294:

    # "Cindy regresa la mirada hacia ti, para después apoyar su mejilla en su mano."
    "Синди переводит взгляд на вас, потом опирается щекой на ладонь."

# game/script.rpy:4209
translate russian cindy2_c60f3936:

    # C "Quizás no sea tan buena idea quedarnos acá."
    C "Может, не лучшая идея оставаться здесь."

# game/script.rpy:4210
translate russian cindy2_cc13a16b:

    # pov "¿Por qué lo dices?"
    pov "Почему?"

# game/script.rpy:4211
translate russian cindy2_6b9e82e8:

    # C "Ese loco puede saber dónde vives hasta este punto."
    C "Тот псих, наверное, уже знает, где ты живёшь."

# game/script.rpy:4212
translate russian cindy2_e218229e:

    # C "Quedarnos puede ser demasiado peligroso."
    C "Оставаться тут может быть слишком опасно."

# game/script.rpy:4213
translate russian cindy2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4216
translate russian cindy2_1691c671:

    # pov "Tienes razón, es bastante bueno."
    pov "И правда вкусно."

# game/script.rpy:4217
translate russian cindy2_7f76495a:

    # C "…"
    C "..."

# game/script.rpy:4218
translate russian cindy2_ba5896e3:

    # "Tu intento de charlar no funciona."
    "Ваша попытка завязать разговор не срабатывает."

# game/script.rpy:4219
translate russian cindy2_c25a2975:

    # "Lo más probable es que siga preocupada por el asunto de Jeff."
    "Похоже, мысли Синди всё ещё заняты Джеффом."

# game/script.rpy:4224
translate russian cindy3_d3393c43:

    # "Cindy era realmente perspicaz, ¿No?"
    "Синди довольно проницательна, да?"

# game/script.rpy:4225
translate russian cindy3_0692b525:

    # "Parece ser el personaje con más sentido común."
    "Она кажется самой здравомыслящей."

# game/script.rpy:4226
translate russian cindy3_dfb6e972:

    # "Pero ese no es el tema."
    "Но дело не в этом."

# game/script.rpy:4227
translate russian cindy3_9e950122:

    # "Jeff es un cobarde, sólo te ha atacado cuando no hay nadie."
    "Джефф — трус, он нападал только тогда, когда рядом никого не было."

# game/script.rpy:4228
translate russian cindy3_999a9ac0:

    # "Además, el juego que tienen es entre ustedes, él no tiene por qué involucrar a Cindy."
    "К тому же, эта игра только между вами. Он не должен вовлекать в это Синди."

# game/script.rpy:4229
translate russian cindy3_099f4a4e:

    # "Así que todo va a estar bien."
    "Так что всё будет хорошо."

# game/script.rpy:4230
translate russian cindy3_98d38427:

    # pov "Todo va a estar bien."
    pov "Всё будет хорошо."

# game/script.rpy:4231
translate russian cindy3_fdc69509:

    # "Lo dices en voz alta no sólo para asegurarte a ti, también a Cindy."
    "Вы произносите это вслух, чтобы убедить не только себя, но и Синди."

# game/script.rpy:4233
translate russian cindy3_63c265b8:

    # "Ella te dedica una leve sonrisa desganada, pero termina por suspirar rendida."
    "Она устало улыбается, а затем сдаётся и тяжело выдыхает."

# game/script.rpy:4234
translate russian cindy3_01fc2712:

    # C "Tu ganas, tengamos algo de charla trivial."
    C "Ладно, сдаюсь. Давай поболтаем."

# game/script.rpy:4236
translate russian cindy3_23163547:

    # C "¿Cómo te estabas sintiendo con el trabajo?"
    C "Как тебе вообще работа?"

# game/script.rpy:4237
translate russian cindy3_0854763a:

    # C "Antes de todo esto."
    C "Ну, до всего этого."

# game/script.rpy:4238
translate russian cindy3_84dc4d63:

    # pov "Yo creo que bien."
    pov "Думаю, неплохо."

# game/script.rpy:4239
translate russian cindy3_9037e8af:

    # pov "Lo siento, pero tendré que faltar durante un tiempo."
    pov "Прости, но, кажется, мне придётся на время взять паузу."

# game/script.rpy:4240
translate russian cindy3_a3fe3ae4:

    # C "No te culpo, de todas maneras cerramos temporalmente."
    C "Я тебя не виню, мы всё равно временно закрыты."

# game/script.rpy:4241
translate russian cindy3_cf3975fa:

    # C "No sé en tu caso, pero puedo vivir sin películas."
    C "Не знаю, как ты, но я без фильмов проживу."

# game/script.rpy:4243
translate russian cindy3_fe58a779:

    # pov "Yo no podría, me encantan."
    pov "Я бы не смогли. Я их обожаю."

# game/script.rpy:4245
translate russian cindy3_04d14352:

    # pov "Seh, yo también."
    pov "Ага, я тоже."

# game/script.rpy:4246
translate russian cindy3_732ab2cd:

    # pov "De todas maneras, mi último recuerdo de allá no es muy agradable."
    pov "В любом случае, последние воспоминания о работе не самые приятные."

# game/script.rpy:4247
translate russian cindy3_356b26c9:

    # pov "Todavía tenía los dos ojos."
    pov "Тогда у меня ещё были оба глаза."

# game/script.rpy:4249
translate russian cindy3_9ba67740:

    # "Cindy hace una mueca de incomodidad, tratando de desviar la mirada de tu parche, fallando."
    "Синди неловко морщится, пытаясь отвести взгляд от вашей повязки на глазу, но безуспешно."

# game/script.rpy:4251
translate russian cindy3_55043449:

    # "Viendo los platos vacíos, haces el ademán de levantarte, pero Cindy te detiene con un gesto de su mano."
    "Увидев пустые тарелки, вы собираетесь встать, но Синди останавливает вас движением руки."

# game/script.rpy:4252
translate russian cindy3_33d877ae:

    # C "No te esfuerces, ve a prepararte para dormir."
    C "Не напрягайся, иди готовиться ко сну."

# game/script.rpy:4253
translate russian cindy3_a5c191d7:

    # "Alzas las manos en derrota."
    "Вы поднимаете руки, сдаваясь."

# game/script.rpy:4254
translate russian cindy3_364f35a4:

    # pov "Lo que digas."
    pov "Как скажешь."

# game/script.rpy:4256
translate russian cindy3_057629fa:

    # "Observas cómo ella se levanta con los platos usados, los utensilios, los vasos y va al lavaplatos, empezando a maniobrar con el agua y el detergente."
    "Вы наблюдаете, как она собирает тарелки, приборы и стаканы, и идёт к раковине, начиная возиться с водой и моющим средством."

# game/script.rpy:4257
translate russian cindy3_1cb1aa3f:

    # "Te quedas cerca, admirando la figura de su espalda pequeña y sus brazos moviéndose."
    "Вы остаётесь рядом, любуясь её маленькой спиной и движущимися руками."

# game/script.rpy:4258
translate russian cindy3_afcbbbf2:

    # pov "Así que… Sólo tengo una cama."
    pov "Итак... У меня только одна кровать."

# game/script.rpy:4260
translate russian cindy3_4f8050ea:

    # "Cindy se detiene un segundo, dejando el agua correr."
    "Синди замирает на секунду, позволяя воде течь."

# game/script.rpy:4261
translate russian cindy3_726c6ac6:

    # C "¿...Ok?"
    C "...Ладно?"

# game/script.rpy:4265
translate russian cindy3_b2f861dc:

    # pov "Parece que tendremos pijamada."
    pov "У нас как будто ночёвка."

# game/script.rpy:4268
translate russian cindy3_578ee21a:

    # pov "Si quieres podemos hacer un muro de almohadas."
    pov "Если хочешь, можем построить стену из подушек."

# game/script.rpy:4273
translate russian cindy4_689e76fa:

    # "Cindy asiente con la cabeza y vuelve a lo suyo."
    "Синди кивает и возвращается к посуде."

# game/script.rpy:4275
translate russian cindy4_d3bb59d0:

    # "Te diriges al baño, donde te duchas y te pones tu ropa para dormir."
    "Вы направляетесь в ванную, принимаете душ и надеваете пижаму."

# game/script.rpy:4276
translate russian cindy4_36efb37c:

    # "Por un momento te detienes frente al espejo."
    "На мгновение вы задерживаетесь перед зеркалом."

# game/script.rpy:4277
translate russian cindy4_947fae38:

    # "Tienes un poco de nervios por pasar la noche con Cindy."
    "Вы немного нервничаете из-за того, что придётся провести ночь с Синди."

# game/script.rpy:4278
translate russian cindy4_47b61d0b:

    # "Nunca la habías visto con otros ojos, pero ahora no podías evitar pensar que tienes algo de suerte por pasar la noche con una chica linda."
    "Вы никогда не смотрели на неё в этом свете, но сейчас невольно ловите себя на мысли, что вам повезло провести ночь с такой милой девушкой."

# game/script.rpy:4279
translate russian cindy4_a1b1e90d:

    # "Claro, no va a pasar nada."
    "Конечно, ничего не случится."

# game/script.rpy:4280
translate russian cindy4_9d47684d:

    # "Ella ni siquiera es tu amiga, técnicamente."
    "Технически, она даже не совсем ваша подруга."

# game/script.rpy:4281
translate russian cindy4_d3161c28:

    # "¿O podría decirse que sí?"
    "Или всё же можно считать её подругой?"

# game/script.rpy:4285
translate russian cindy4_074d3ad5:

    # "Con eso en mente, sales del baño y vuelves a la cocina, para buscar a Cindy."
    "С этой мыслью вы выходите из ванной и возвращаетесь на кухню, чтобы найти Синди."

# game/script.rpy:4286
translate russian cindy4_74fee88d:

    # pov "El baño está libre, por si quieres usarlo."
    pov "Ванная свободна, если хочешь — можешь воспользоваться."

# game/script.rpy:4287
translate russian cindy4_dbed95e7:

    # "Ella ya había estado aquí antes, por lo que sabía dónde estaba todo."
    "Она тут уже не впервые, так что знает, где что находится."

# game/script.rpy:4288
translate russian cindy4_c0af09f0:

    # C "De acuerdo."
    C "Хорошо."

# game/script.rpy:4289
translate russian cindy4_c1b51dda:

    # "Asientes en silencio y regresas por donde viniste, esta vez dirigiéndote a tu habitación."
    "Вы молча киваете и возвращаетесь обратно, на этот раз направляясь в свою комнату."

# game/script.rpy:4293
translate russian cindy4_43d1e267:

    # "Tomaste lugar en la cama, cerciorándote de dejarle espacio a Cindy."
    "Ложитесь на кровать, стараясь оставить Синди место."

# game/script.rpy:4294
translate russian cindy4_0bec2b3e:

    # "Escuchaste desde tu lugar las luces apagándose, encendiéndose y el agua corriendo."
    "Из комнаты доносятся звуки — щёлканье выключателя, шум воды."

# game/script.rpy:4295
translate russian cindy4_49e87eee:

    # "Unos instantes después, Cindy entra a la habitación."
    "Спустя некоторое время Синди заходит в комнату."

# game/script.rpy:4296
translate russian cindy4_78b379bd:

    # "En silencio, ella se adentra bajo las sábanas junto a ti."
    "Она молча забирается под одеяло рядом с вами."

# game/script.rpy:4303
translate russian cindy4_505286fb:

    # "Sientes el aroma de su perfume, es dulce."
    "Вы улавливаете сладкий аромат её духов."

# game/script.rpy:4304
translate russian cindy4_c18f24cd:

    # "Alcanzas a ver que los ojos de ella brillan, aún con la escasa luz."
    "В тусклом свете видно, как поблёскивают её глаза."

# game/script.rpy:4305
translate russian cindy4_d4e9ed84:

    # pov "¿Por qué te preocupas tanto por mí?"
    pov "Почему ты так обо мне заботишься?"

# game/script.rpy:4306
translate russian cindy4_e626486c:

    # pov "¿Qué cambió?"
    pov "Что поменялось?"

# game/script.rpy:4308
translate russian cindy4_5c00b803:

    # "Inesperadamente, sientes que la mano de ella roza tu mejilla, y acaricia con su pulgar delicadamente."
    "Неожиданно вы чувствуете, как её ладонь касается вашей щеки, большой палец мягко скользит по коже."

# game/script.rpy:4309
translate russian cindy4_54c99404:

    # C "Me dí cuenta que eres importante para mí."
    C "Я поняла, что ты мне дороги."

# game/script.rpy:4310
translate russian cindy4_1d8fafcc:

    # "Ella se ríe levemente."
    "Она тихо смеётся."

# game/script.rpy:4311
translate russian cindy4_ee7d37af:

    # C "Es extraño, siento que te conozco, pero no puedo pensar en algún momento que pasé contigo en específico."
    C "Странно. Такое чувство, будто я тебя знаю, но не могу вспомнить ни одного конкретного момента, который мы провели вместе."

# game/script.rpy:4312
translate russian cindy4_d26e3082:

    # C "Pero aún así, me importas"
    C "Но всё же, ты мне небезразличны."

# game/script.rpy:4314
translate russian cindy4_c99d28b0:

    # "Tu corazón se acelera ante sus palabras, sintiendo que el aire entre ustedes dos se ha vuelto tibio."
    "Ваше сердце начинает биться быстрее, а воздух между вами словно нагревается."

# game/script.rpy:4315
translate russian cindy4_7d52aa18:

    # pov "B-buenas noches."
    pov "Д-доброй ночи."

# game/script.rpy:4316
translate russian cindy4_7ab769fb:

    # C "Descansa bien."
    C "Отдыхай."

# game/script.rpy:4319
translate russian cindy4_b192bc49:

    # "Cierras tu ojo, concentrándote en tu respiración y la de ella para dormir."
    "Вы закрываете глаз, прислушиваясь к своему дыханию и её, постепенно погружаясь в сон."

# game/script.rpy:4320
translate russian cindy4_c71d7ef8:

    # "Pronto, lo logras."
    "Вскоре вам это удаётся."

# game/script.rpy:4322
translate russian cindy4_9ef5798e:

    # "No sabes si estás soñando cuando te parece escuchar un ruido, pero cuando alzas la mano para alcanzar a Cindy, te das cuenta de que no está en la cama."
    "Неясно, спите вы или нет, когда вдруг слышите какой-то шум. Вы тянетесь рукой к Синди — и вдруг понимаете, что кровать пуста."

# game/script.rpy:4325
translate russian cindy4_b0a34dc6:

    # "Te levantas y sigilosamente sales de tu habitación."
    "Вы встаёте и тихо выходите из комнаты."

# game/script.rpy:4326
translate russian cindy4_2c0d1dba:

    # "No escuchas nada, pero eso no te calma."
    "Вы ничего не слышите, но это вас не успокоило."

# game/script.rpy:4327
translate russian cindy4_6558a98d:

    # "Llegas inmediatamente a la sala, donde presencias el peor escenario."
    "Вы сразу же попадаете в гостиную, где становитесь свидетелем худшего сценария."

# game/script.rpy:4333
translate russian cindy4_30487e3f:

    # "Jeff tiene sujetada a Cindy desde el cuello, tapando su boca, y apuntando la punta del cuchillo contra su cintura."
    "Джефф держит Синди за шею, закрывая рот рукой и направляя остриё ножа к её талии."

# game/script.rpy:4334
translate russian cindy4_ad48664c:

    # "¿En qué momento entró Jeff, Cindy se levantó y se enfrentaron?"
    "В какой момент вошёл Джефф, встала Синди и они столкнулись?"

# game/script.rpy:4335
translate russian cindy4_1dcafc75:

    # "Eso debió producir un ruido, pero no tenías idea."
    "Всё это должно было сопровождаться шумом, но вы ничего не слышали."

# game/script.rpy:4336
translate russian cindy4_c380c9fc:

    # "Parece que Jeff es muy bueno en lo que hace."
    "Кажется, Джефф очень хорош в своём деле."

# game/script.rpy:4337
translate russian cindy4_2ebc0818:

    # J "[povname]... Dije que volvería."
    J "[povname]... Я же говорил, что вернусь."

# game/script.rpy:4338
translate russian cindy4_ff798c78:

    # pov "… Si, puedo darme cuenta."
    pov "...Ага, я вижу."

# game/script.rpy:4339
translate russian cindy4_fdb72a44:

    # J "Te aconsejo que tengas cuidado con lo que dices, alguien podría salir lastimado."
    J "Советую следить за словами. Кто-то может пострадать."

# game/script.rpy:4340
translate russian cindy4_475ee4a1:

    # "Jeff acercó más el cuchillo a la piel de Cindy."
    "Джефф подносит нож ещё ближе к коже Синди."

# game/script.rpy:4343
translate russian cindy4_7d652c82:

    # pov "N-no le hagas daño."
    pov "Н-не трогай её."

# game/script.rpy:4344
translate russian cindy4_80f14a61:

    # J "¿Oh?"
    J "О?"

# game/script.rpy:4345
translate russian cindy4_7a410f0f:

    # J "¿Así que te preocupas por esta perra?"
    J "Значит, переживаешь за эту суку?"

# game/script.rpy:4346
translate russian cindy4_3a8de979:

    # pov "Hey, no le digas así."
    pov "Эй, не называй её так."

# game/script.rpy:4347
translate russian cindy4_0b6f4b11:

    # J "Sigues probando mi punto."
    J "Только подтверждаешь мои слова."

# game/script.rpy:4349
translate russian cindy4_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:4350
translate russian cindy4_e95a949d:

    # pov "¿Te buscan por atacarme y ahora vas a dañar a otra persona?"
    pov "Тебя уже разыскивают за нападение на меня, а теперь ты хочешь навредить ещё одному человеку?"

# game/script.rpy:4351
translate russian cindy4_e3b99848:

    # pov "Piensa un poco Jeff, eso significa más policías buscando tu cabeza."
    pov "Подумай, Джефф. Ещё больше копов будут искать тебя."

# game/script.rpy:4352
translate russian cindy4_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4354
translate russian cindy4_8320052c:

    # J "Entonces… No te importará si hago esto, ¿O sí?"
    J "Тогда... ты не возражаешь, если я сделаю вот так?"

# game/script.rpy:4356
translate russian cindy4_edf1629f:

    # "Jeff hace un corte en el costado de Cindy, la cual suelta un quejido ahogado contra la mano de él."
    "Джефф проводит ножом по боку Синди, и она издаёт приглушённый стон, когда лезвие рассекает её кожу."

# game/script.rpy:4357
translate russian cindy4_b0290aa3:

    # pov "¡Espera, espera!, Esto es entre nosotros dos, ¿Lo olvidaste?"
    pov "Подожди, стой! Это между нами, забыл?"

# game/script.rpy:4358
translate russian cindy4_fab5f323:

    # pov "No hay por qué involucrarla."
    pov "Не нужно её в это впутывать."

# game/script.rpy:4359
translate russian cindy4_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4373
translate russian muerte_cindy_f489d8e9:

    # "Jeff ignora por completo tus palabras y desliza la hoja del cuchillo por el estómago de Cindy."
    "Джефф полностью игнорирует ваши слова и вонзает лезвие ножа в живот Синди."

# game/script.rpy:4374
translate russian muerte_cindy_e62bfee0:

    # "La sangre y entrañas se derramaron y Jeff la suelta."
    "Кровь и внутренности выплёскиваются наружу, и Джефф отпускает её."

# game/script.rpy:4377
translate russian muerte_cindy_38d8850f:

    # "Cindy se lleva las manos al estómago, tratando de parar la hemorragia, pero sus piernas ceden y ella cae."
    "Синди хватается за живот в попытке остановить кровотечение, но её ноги подкашиваются, и она падает."

# game/script.rpy:4378
translate russian muerte_cindy_f6f45eb3:

    # "Te petrificas en tu lugar, viendo que debajo de Cindy crece un charco oscuro."
    "Вы застываете, наблюдая, как под телом Синди растекается тёмная лужа."

# game/script.rpy:4381
translate russian muerte_cindy_cb65dbdc:

    # J "Hah… Eres tan hipócrita."
    J "Хах... Как лицемерно."

# game/script.rpy:4382
translate russian muerte_cindy_4eef6bc5:

    # "Jeff avanza hacia ti, pisando el charco de sangre con indiferencia."
    "Джефф делает шаг к вам, равнодушно ступая в кровь."

# game/script.rpy:4383
translate russian muerte_cindy_423bd7b9:

    # "Te sujeta del cuello de tu ropa, alzando el cuchillo ensangrentado."
    "Он хватает вас за воротник, поднимая окровавленный нож."

# game/script.rpy:4384
translate russian muerte_cindy_6d74fe34:

    # "Tú aún no puedes desviar tu mirada atónita del cadáver de Cindy en el suelo."
    "Вы не можете отвести взгляд от трупа Синди на полу."

# game/script.rpy:4385
translate russian muerte_cindy_ac78924b:

    # J "Te advertí que me aburro fácilmente."
    J "Я же предупреждал, что мне легко наскучить."

# game/script.rpy:4386
translate russian muerte_cindy_ed84a216:

    # "Lo último que ves, es que Jeff alza su cuchillo en alto, mirándote fijamente."
    "Последнее, что вы видите, — Джефф, поднимающий свой нож, не сводя с вас взгляда."

# game/script.rpy:4392
translate russian muerte_cindy_f4ec26fd:

    # "{b}Final V: Lo Decepcionaste{/b}"
    "{b}Концовка V: Вы его разочаровали{/b}"

# game/script.rpy:4402
translate russian historia_continua_cindy_273ec03e:

    # "Jeff entierra lentamente la punta del cuchillo en el costado de Cindy."
    "Джефф медленно вонзает остриё ножа в бок Синди."

# game/script.rpy:4403
translate russian historia_continua_cindy_de1297ee:

    # "Ella deja salir un grito acallado contra la mano de él."
    "Она издаёт крик, моментально приглушённый рукой Джеффа."

# game/script.rpy:4406
translate russian historia_continua_cindy_f5cb29b7:

    # "Ves cómo ambos forcejean hasta que Jeff retira el cuchillo, y Cindy cae al suelo."
    "Вы наблюдаете, как они борются, пока Джефф не выдёргивает нож, и Синди падает на пол."

# game/script.rpy:4407
translate russian historia_continua_cindy_9054e9ce:

    # C "[povname]... Vete…"
    C "[povname]... Уходи..."

# game/script.rpy:4410
translate russian historia_continua_cindy_a80c7a6b:

    # J "No te molestes, linda."
    J "Не утруждайся, милая."

# game/script.rpy:4411
translate russian historia_continua_cindy_a01357f1:

    # "Jeff estiró una sonrisa burlona."
    "Джефф издевательски улыбается."

# game/script.rpy:4412
translate russian historia_continua_cindy_1f8a5cca:

    # J "Hay nueva jurisdicción."
    J "Правила изменились."

# game/script.rpy:4414
translate russian historia_continua_cindy_9e073087:

    # "Jeff ignora el cuerpo de Cindy y avanza hacia ti, sus ojos lechosos brillando en la tenue luz."
    "Джефф игнорирует тело Синди и просто идёт к вам, его мутноватые глаза мерцают в полумраке."

# game/script.rpy:4415
translate russian historia_continua_cindy_8bb827e8:

    # "Atinas a correr, quizás a encerrarte en el baño o tu habitación."
    "Вы бросаетесь прочь — возможно, к ванной или к своей комнате."

# game/script.rpy:4417
translate russian historia_continua_cindy_041dc4c4:

    # "Pero tu muñeca es sujetada por Jeff, impidiendo que te muevas."
    "Но Джефф успевает схватить вас за запястье, не давая сдвинуться с места."

# game/script.rpy:4418
translate russian historia_continua_cindy_b5dd6c81:

    # J "Es curioso… No quiero dañarte, no como antes al menos."
    J "Забавно... Я не хочу причинять тебе боль. По крайней мере не так, как раньше."

# game/script.rpy:4419
translate russian historia_continua_cindy_b0000ffa:

    # J "¿Por qué será?"
    J "Интересно, почему?"

# game/script.rpy:4423
translate russian historia_continua_cindy_a84a1a84:

    # pov "T-tal vez es porque te gusto."
    pov "М-может, потому что я тебе нравлюсь."

# game/script.rpy:4425
translate russian historia_continua_cindy_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4426
translate russian historia_continua_cindy_a56d14b5:

    # J "¿Cómo dices?"
    J "Что?"

# game/script.rpy:4427
translate russian historia_continua_cindy_801770c2:

    # pov "Ya sabes, ¿Te intereso?"
    pov "Ну, я же тебе интересны?"

# game/script.rpy:4428
translate russian historia_continua_cindy_0b12aa55:

    # pov "¿Tienes un crush conmigo?"
    pov "Ты влюбился в меня?"

# game/script.rpy:4431
translate russian historia_continua_cindy_1612e3fd:

    # pov "Quizás quieres dejarme en paz."
    pov "Может, ты хочешь оставить меня в покое."

# game/script.rpy:4433
translate russian historia_continua_cindy_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4434
translate russian historia_continua_cindy_a781321d:

    # J "Nah, no es eso. Todo lo contrario."
    J "Не-а, точно нет. Даже наоборот."

# game/script.rpy:4435
translate russian historia_continua_cindy_9a4e417d:

    # pov "Entonces… ¿Tienes una fijación conmigo?"
    pov "Так... Ты ко мне неравнодушен?"

# game/script.rpy:4436
translate russian historia_continua_cindy_a713ab28:

    # J "¿Ah?"
    J "А?"

# game/script.rpy:4442
translate russian cindy5_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4443
translate russian cindy5_29180233:

    # "Sólo dijiste lo primero que se te vino a la mente, con la esperanza de que se detenga."
    "Вы просто ляпнули первое, что пришло в голову, в надежде, что он остановится."

# game/script.rpy:4445
translate russian cindy5_50dfff11:

    # J "¡Oh, ya veo!"
    J "А, вот оно что!"

# game/script.rpy:4446
translate russian cindy5_be1402e7:

    # "Jeff se inclina hacia ti, su sonrisa estirada más de lo normal y sus ojos desorbitados fijos en ti."
    "Джефф наклоняется к вам, его улыбка неестественно растягивается, пока он сверлит вас взглядом."

# game/script.rpy:4448
translate russian cindy5_7071d957:

    # J "¡Te deseo!"
    J "Я хочу тебя!"

# game/script.rpy:4449
translate russian cindy5_e168bd54:

    # J "¡A tí!"
    J "Тебя!"

# game/script.rpy:4450
translate russian cindy5_01867340:

    # "Jeff suelta una carcajada estridente."
    "Джефф издаёт пронзительный смех."

# game/script.rpy:4451
translate russian cindy5_c0728fa7:

    # "No sabes si sonreír u horrorizarte."
    "Вы не знаете, улыбнуться в ответ или ужаснуться."

# game/script.rpy:4452
translate russian cindy5_90770e2a:

    # J "¡Eso explica muchas cosas!"
    J "Многое объясняет!"

# game/script.rpy:4454
translate russian cindy5_bdec5f1d:

    # "El agarre en tu mano se hace más fuerte, y él tira de ti."
    "Хватка на вашей руке усиливается, и тянет вас ближе."

# game/script.rpy:4455
translate russian cindy5_5ad99f85:

    # pov "Espera, ¿Qué haces?"
    pov "Подожди, что ты делаешь?"

# game/script.rpy:4456
translate russian cindy5_d764cb51:

    # J "Ya descubrí lo que quiero."
    J "Я наконец понял, чего хочу."

# game/script.rpy:4457
translate russian cindy5_82658285:

    # J "No quiero seguir jugando contigo."
    J "Больше не хочу с тобой играть."

# game/script.rpy:4458
translate russian cindy5_35012658:

    # "Una parte de ti sintió alivio ante las palabras de él, pero cuando Jeff te atrajo hacia él, haciendo que chocaras contra su pecho, sentiste frío."
    "На мгновение вас охватывает облегчение от его слов, но когда Джефф притягивает вас к себе, и вы сталкиваетесь с его грудью, по телу пробегает холод."

# game/script.rpy:4459
translate russian cindy5_4f0b84e3:

    # J "Quiero tenerte para mí."
    J "Я хочу, чтобы ты принадлежали только мне."

# game/script.rpy:4460
translate russian cindy5_bba5eefc:

    # "Entonces te das cuenta que te está guiando a la salida."
    "И тут вы понимаете, что он ведёт вас к выходу."

# game/script.rpy:4461
translate russian cindy5_7f401476:

    # "En un instante, viste el cuerpo de Cindy aún inmóvil sobre el suelo, y una punzada de preocupación te atravesó."
    "Вы оглядываетесь на тело Синди, неподвижно лежащее на полу, и вас охватывает беспокойство."

# game/script.rpy:4462
translate russian cindy5_1276a7ba:

    # pov "¿Qué hay de-?"
    pov "А как же—?"

# game/script.rpy:4463
translate russian cindy5_004bb96d:

    # J "No pienses en ella."
    J "Не думай о ней."

# game/script.rpy:4466
translate russian cindy5_279d16da:

    # "Tus mejillas son sujetadas por dos manos grandes y frías, y sientes que algo mojado salpica tu piel."
    "Холодные, большие руки обхватывают ваши щёки, и вы чувствуете, как что-то влажное попадает на кожу."

# game/script.rpy:4467
translate russian cindy5_2b9a40af:

    # "Por el olor, te das cuenta que es sangre."
    "По запаху вы понимаете, что это кровь."

# game/script.rpy:4468
translate russian cindy5_727428c4:

    # "El fleco de Jeff roza con tu frente, y lo único que puedes ver son sus ojos."
    "Чёлка Джеффа слегка касается вашего лба, и всё, что вы видите — это его глаза."

# game/script.rpy:4469
translate russian cindy5_e83bba11:

    # J "Sólo céntrate en mí."
    J "Смотри только на меня."

# game/script.rpy:4470
translate russian cindy5_a2a404e6:

    # "Has visto de lo que es capaz."
    "Вы видели, на что он способен."

# game/script.rpy:4471
translate russian cindy5_35f60b9f:

    # "No se limitaba a hacerte daño a ti, sino que a cualquiera."
    "Он причиняет боль не только вам, а всем, кто оказывается рядом."

# game/script.rpy:4472
translate russian cindy5_e921f59d:

    # "Eso te hizo considerar sus palabras, profundamente."
    "Это заставляет вас всерьёз задуматься над его словами."

# game/script.rpy:4492
translate russian day6_16ba099f:

    # "La sensación bajo tu cuerpo es dura y áspera."
    "Поверхность под вашим телом — жёсткая и шероховатая."

# game/script.rpy:4493
translate russian day6_5e27d95d:

    # "El colchón evidentemente es muy viejo y de mala calidad."
    "Матрас, по всей видимости, довольно старый и плохого качества."

# game/script.rpy:4494
translate russian day6_33578e4c:

    # "Aunque hayas despertado, mantienes tu ojo cerrado, reflexionando sobre lo que sucedió para que te llevara a donde estás."
    "Хотя вы уже проснулись, вы продолжаете держать глаз закрытым, пытаясь осознать, что произошло и как вы здесь оказались."

# game/script.rpy:4497
translate russian day6_a076dbbd:

    # "Jeff tiró de ti, obligándote a correr con él."
    "Джефф тащил вас за собой, вынуждая бежать вместе с ним."

# game/script.rpy:4498
translate russian day6_79365ed4:

    # "El frío de la madrugada entraba a tus pulmones, mientras las luces de los faroles alumbraban su camino."
    "Холод предрассветного воздуха наполнял лёгкие, а уличные фонари освещали дорогу."

# game/script.rpy:4499
translate russian day6_8e5f086f:

    # "Recorrieron muchas calles, no sabías que tan lejos te estaba llevando."
    "Вы пересекли множество улиц; даже не знали, как далеко он вас увёл."

# game/script.rpy:4502
translate russian day6_0269c8eb:

    # "A petición tuya, en ocasiones le pedías que se detuviera para descansar. Jeff aceptaba, y mientras tú recuperabas el aliento, él vigilaba los alrededores."
    "Иногда вы просили его остановиться, чтобы перевести дух. Джефф соглашался, и пока вы отдыхали, он наблюдал за окрестностями."

# game/script.rpy:4503
translate russian day6_0e9d7eff:

    # "A penas te sentías mejor, él tomaba tu muñeca y nuevamente te arrastraba."
    "Стоило вам немного прийти в себя, как он снова хватал вас за запястье и тащил вперёд."

# game/script.rpy:4504
translate russian day6_61776a71:

    # "Finalmente habían llegado a un barrio de mala a muerte, lleno de basura, campamentos y casas en mal estado."
    "Наконец вы добрались до полузаброшенного района — вокруг валялись кучи мусора, стояли палатки и шаткие лачуги."

# game/script.rpy:4505
translate russian day6_f4e686db:

    # "La casa de Jeff no fue la excepción."
    "Дом Джеффа не был исключением."

# game/script.rpy:4507
translate russian day6_f1a5215f:

    # "Recuerdas que él dijo que era el lugar donde se quedaba por el momento, mientras te invitaba a pasar en una pequeña casa destartalada."
    "Вы вспомнили, как он обмолвился, что живёт здесь временно, приглашая вас войти в маленький, покосившийся домик."

# game/script.rpy:4508
translate russian day6_51ff449a:

    # "Como era de noche y él no quiso encender las luces, en el caso de que tuviera electricidad, no viste bien como era el interior."
    "Была ночь, и он не стал зажигать свет — если электричество вообще было — поэтому разглядеть внутри толком ничего не удалось."

# game/script.rpy:4509
translate russian day6_ad5e91a0:

    # "Pero por el olor a humedad y polvo, además del crujido bajo tus pies, podías asumir que el lugar no estaba en buen estado."
    "По запаху сырости и пыли, по скрипу половиц под ногами вы поняли, что место не в самом лучшем состоянии."

# game/script.rpy:4510
translate russian day6_ff4372e5:

    # "Afortunadamente, Jeff ofreció la cama especialmente para ti, diciendo que tenía cosas que hacer."
    "К счастью, Джефф уступил вам кровать, сказав, что у него есть дела."

# game/script.rpy:4511
translate russian day6_6a8f05d2:

    # J "¿Vas a seguir fingiendo dormir?"
    J "Всё ещё притворяешься, что спишь?"

# game/script.rpy:4512
translate russian day6_cfc5541b:

    # "Maldices internamente ante la voz de Jeff."
    "Вы выругались про себя, услышав голос Джеффа."

# game/script.rpy:4517
translate russian day6_7fe62379:

    # "Abres tu ojo, y te encuentras con algo que no esperabas que sería lo primero que vieras en el día."
    "Открыв глаза, вы видите то, чего совсем не ожидали увидеть первым делом этим утром."

# game/script.rpy:4518
translate russian day6_18aff43c:

    # J "Buenos días, [povname]."
    J "Доброе утро, [povname]."

# game/script.rpy:4519
translate russian day6_37ac9348:

    # "Jeff está apoyado en el borde de la cama, a centímetros de ti."
    "Джефф сидит на краю кровати, почти вплотную к вам."

# game/script.rpy:4520
translate russian day6_d27b5198:

    # "Te mira fijamente, recorriendo cada centímetro de tu rostro."
    "Он пристально смотрит на вас, изучая каждый сантиметр вашего лица."

# game/script.rpy:4521
translate russian day6_e208128f:

    # pov "Buenas…"
    pov "Доброе..."

# game/script.rpy:4522
translate russian day6_e7791ccb:

    # "Era raro estar con Jeff y que no tenga la intención de herirte."
    "Странное чувство — находиться рядом с Джеффом и понимать, что он не собирается вам вредить."

# game/script.rpy:4523
translate russian day6_c448a695:

    # "Claro, sucedió lo del bar, pero aún estabas en guardia por lo que hizo anoche."
    "Да, была история с баром, но вы всё ещё настороже после того, что произошло прошлой ночью."

# game/script.rpy:4524
translate russian day6_d88485c6:

    # "También era… curioso verlo sin la sudadera blanca de siempre."
    "И... довольно любопытно видеть его без привычного белого худи."

# game/script.rpy:4525
translate russian day6_9b310ba8:

    # "Ver los brazos desnudos y la silueta de la cintura de Jeff se sentía como ver los tobillos de una mujer victoriana."
    "Видеть его обнажённые руки и очертания талии — всё равно, что видеть щиколотки викторианской дамы."

# game/script.rpy:4526
translate russian day6_98eceaf6:

    # "Jeff asintió levemente ante tu saludo, manteniendo su sonrisa."
    "Джефф слегка кивает в ответ на ваше приветствие, всё так же улыбаясь."

# game/script.rpy:4527
translate russian day6_258ed24c:

    # J "No hay necesidad de tanta cautela."
    J "Не надо так осторожничать."

# game/script.rpy:4528
translate russian day6_af6dac57:

    # J "Ya no quiero matarte."
    J "Я больше не хочу тебя убивать."

# game/script.rpy:4529
translate russian day6_f771528d:

    # "Bueno, eso sonaba tranquilizador."
    "Ну, это звучит обнадёживающе."

# game/script.rpy:4530
translate russian day6_41f11f90:

    # "Pero se trataba de Jeff."
    "Но это же Джефф."

# game/script.rpy:4531
translate russian day6_1e42b635:

    # "El tipo era todo menos confiable."
    "Он что угодно, только не надёжный."

# game/script.rpy:4535
translate russian day6_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:4540
translate russian day6_11052a4e:

    # pov "No te creo."
    pov "Я тебе не верю."

# game/script.rpy:4545
translate russian ruta_normal_31_f7332dde:

    # "Jeff ríe entre dientes, tocando la punta de tu nariz con su índice."
    "Джефф тихо усмехается и касается кончиком пальца вашего носа."

# game/script.rpy:4546
translate russian ruta_normal_31_b4f97ccb:

    # J "Vayamos a desayunar."
    J "Пойдём завтракать."

# game/script.rpy:4547
translate russian ruta_normal_31_ce617998:

    # "…"
    "..."

# game/script.rpy:4548
translate russian ruta_normal_31_d424802a:

    # "Él te evitó, ¿Cierto?"
    "Он это проигнорировал?"

# game/script.rpy:4550
translate russian ruta_normal_31_d7bb31f1:

    # "Él se levanta y se mantiene de pie junto a la cama, mirándote expectante."
    "Он поднимается и встаёт рядом с кроватью, выжидающе на вас глядя."

# game/script.rpy:4555
translate russian ruta_normal_31_8ac00f36:

    # "Te levantas lentamente, y te ves en una habitación demasiado amplia, pero bastante destartalada."
    "Вы тоже медленно поднимаетесь и оглядываетесь — комната довольно просторная, но обшарпанная."

# game/script.rpy:4556
translate russian ruta_normal_31_d75f57b3:

    # "No había muebles además de la cama, pero al menos la ventana no estaba rota."
    "Кроме кровати здесь нет ни единого предмета мебели, зато окно хотя бы целое."

# game/script.rpy:4557
translate russian ruta_normal_31_ce64e646:

    # "Entonces te das cuenta que sólo estás en ropa para dormir y sin zapatos."
    "И тут вы замечаете, что на вас только пижама и никакой обуви."

# game/script.rpy:4558
translate russian ruta_normal_31_7778d3b1:

    # "¿Realmente corriste por varias calles sin pisar un clavo o un pedazo de vidrio?, que suerte que no te haya dado tétanos."
    "Вы действительно бежали через кучу улиц босиком, ни разу не наступив на гвоздь или осколок? Повезло, что вы не подхватили столбняк."

# game/script.rpy:4559
translate russian ruta_normal_31_4fec3241:

    # pov "No tengo zapatos…"
    pov "У меня нет обуви..."

# game/script.rpy:4561
translate russian ruta_normal_31_41b05a8a:

    # "Jeff desvía la mirada pensativo."
    "Джефф задумчиво отводит взгляд."

# game/script.rpy:4562
translate russian ruta_normal_31_ef303fc2:

    # J "Espera un momento."
    J "Подожди."

# game/script.rpy:4564
translate russian ruta_normal_31_7cce5824:

    # "Jeff desaparece por la puerta, y escuchas movimiento desde el otro lado de la habitación."
    "Джефф выходит за дверь, и вы слышите шорохи где-то в соседней комнате."

# game/script.rpy:4567
translate russian ruta_normal_31_fee15d7d:

    # "Pronto, Jeff reaparece, con dos pantuflas, de distinto tamaño cada una."
    "Вскоре Джефф возвращается с двумя тапочками, причём разного размера."

# game/script.rpy:4568
translate russian ruta_normal_31_6c8a2e83:

    # J "Es lo que encontré a mano, luego buscaremos ropa para ti."
    J "Что нашёл, то нашёл. Потом подберём тебе одежду."

# game/script.rpy:4569
translate russian ruta_normal_31_5d253cdc:

    # "Aceptas con resignación las pantuflas."
    "Вы покорно принимаете тапочки."

# game/script.rpy:4570
translate russian ruta_normal_31_da1c9d8c:

    # "No están rotas ni mugrosas, sólo con algo de polvo."
    "Они не порваны и не грязные — просто немного пыльные."

# game/script.rpy:4571
translate russian ruta_normal_31_b0e8de99:

    # "Son de distinta talla, una te queda bien y la otra te queda suelta, pero era mejor que andar pisando tétanos."
    "Они разного размера: один сидит как влитой, а другой болтается. Но всё же это лучше, чем подхватить столбняк."

# game/script.rpy:4572
translate russian ruta_normal_31_d1e890a4:

    # pov "Gracias."
    pov "Спасибо."

# game/script.rpy:4574
translate russian ruta_normal_31_de9b7ba1:

    # "Jeff sonrió ampliamente ante tu agradecimiento, incluso pudiste ver como el color subía a su rostro."
    "Джефф расплывается в широкой улыбке; вы даже замечаете, как лёгкий румянец проступает на его лице."

# game/script.rpy:4575
translate russian ruta_normal_31_9de67b00:

    # J "Ven."
    J "Идём."

# game/script.rpy:4577
translate russian ruta_normal_31_371f22b9:

    # "Jeff tomó tu muñeca, el agarre era firme, pero no te hacía daño. Él tiró de ti, pero a diferencia de otras veces, fue suave y calmo."
    "Джефф берёт вас за запястье — хватка крепкая, но совсем не грубая. Он тянет вас за собой, на этот раз мягко и спокойно."

# game/script.rpy:4579
translate russian ruta_normal_31_2fbd8868:

    # "Te guió por el interior de la casa, hasta llegar a lo que sería un comedor, por la mesa y dos sillas. Había un minirefri y una cocina en la habitación contigua, pero dudabas de que funcionaran."
    "Он ведёт вас по дому, пока вы не доходите до комнаты, похожей на кухню, со столом и двумя стульями. В смежной комнате видно мини-холодильник и плиту, но вы сомневаетесь, что они работают."

# game/script.rpy:4582
translate russian ruta_normal_31_64b40913:

    # J "Traje el desayuno."
    J "Я принёс завтрак."

# game/script.rpy:4587
translate russian ruta_normal_31_d89112bb:

    # J "Un latte con leche de soya."
    J "Латте на соевом молоке."

# game/script.rpy:4589
translate russian ruta_normal_31_8d233d3d:

    # J "Un latte con leche descremada."
    J "Латте на обезжиренном молоке."

# game/script.rpy:4590
translate russian ruta_normal_31_a87c16fe:

    # "Él te extiende un vaso de cartón, y tu lo recibes entre tus manos, está tibio."
    "Он протягивает вам картонный стаканчик, и вы берёте его. Ещё тёплый."

# game/script.rpy:4592
translate russian ruta_normal_31_46b605bc:

    # pov "¿Cómo-?"
    pov "Откуда—?"

# game/script.rpy:4593
translate russian ruta_normal_31_6d7d8495:

    # J "¿Supe tu preferencia?"
    J "Откуда я знаю, что ты любишь?"

# game/script.rpy:4595
translate russian ruta_normal_31_114eee96:

    # "La sonrisa de él se tornó burlona."
    "На его лице появляется насмешливая улыбка."

# game/script.rpy:4596
translate russian ruta_normal_31_e950be2e:

    # J "Vamos, [povname], eres inteligente."
    J "Давай, [povname], ты же умные."

# game/script.rpy:4597
translate russian ruta_normal_31_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4598
translate russian ruta_normal_31_1c6bb11a:

    # "Por supuesto, es porque te siguió durante días."
    "Конечно, он просто преследовал вас всё это время."

# game/script.rpy:4599
translate russian ruta_normal_31_24e12323:

    # "Seguramente averiguó esas cosas tras vigilarte."
    "Наверняка узнал это, наблюдая за вами."

# game/script.rpy:4600
translate russian ruta_normal_31_725b544e:

    # J "No creas que olvidé lo comestible."
    J "Не думай, что я забыл про еду."

# game/script.rpy:4605
translate russian ruta_normal_31_841d20fd:

    # J "También te traje un muffin."
    J "Я ещё принёс тебе маффин."

# game/script.rpy:4610
translate russian ruta_normal_31_78d74fa2:

    # J "Te conseguí un sandwich."
    J "Я купил тебе сэндвич."

# game/script.rpy:4612
translate russian ruta_normal_31_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:4613
translate russian ruta_normal_31_93a90f6b:

    # pov "Ok, iré al grano."
    pov "Ладно, сразу к делу."

# game/script.rpy:4614
translate russian ruta_normal_31_6e532a75:

    # pov "¿Estás intentando ser algo así como un novio atento?"
    pov "Ты сейчас пытаешься изображать заботливого парня?"

# game/script.rpy:4616
translate russian ruta_normal_31_80e50a4a:

    # "Jeff ladeó la cabeza interrogativamente."
    "Джефф вопросительно наклоняет голову."

# game/script.rpy:4617
translate russian ruta_normal_31_13024660:

    # J "¿De qué hablas?"
    J "О чём ты?"

# game/script.rpy:4618
translate russian ruta_normal_31_1f4faf37:

    # pov "Me arrancaste un ojo, te colaste a mi habitación de hospital, te metiste en mi casa, ¿Quieres que olvide todo eso?"
    pov "Ты вырвал мне глаз, пробрался в больничную палату, вломился в мой дом. Хочешь, чтобы я просто забыли об этом?"

# game/script.rpy:4619
translate russian ruta_normal_31_22cf5fca:

    # pov "¿Cómo se supone que yo crea que me amas si me has hecho pasar un infierno?"
    pov "Как я вообще должны поверить, что ты меня любишь, если ты заставил меня пройти через этот ад?"

# game/script.rpy:4622
translate russian ruta_normal_31_fd817c26:

    # "Jeff te mira con curiosidad, para luego dirigirse al minirefri."
    "Джефф смотрит на вас с любопытством, затем направляется к мини-холодильнику."

# game/script.rpy:4623
translate russian ruta_normal_31_fa265151:

    # J "No quiero que olvides lo que hice."
    J "Я не хочу, чтобы ты забывали, что я сделал."

# game/script.rpy:4624
translate russian ruta_normal_31_77916e09:

    # "Él musitó suavemente, sacando un frasco del mini refri."
    "Он тихо бормочет, доставая из холодильника банку."

# game/script.rpy:4625
translate russian ruta_normal_31_ebdadfbd:

    # J "Sólo que lo veas desde una perspectiva diferente."
    J "Просто хочу, чтобы ты посмотрели на это с другой стороны."

# game/script.rpy:4632
translate russian ruta_normal_31_63ce932d:

    # "Él puso el fresco frente a ti."
    "Он ставит банку перед вами."

# game/script.rpy:4633
translate russian ruta_normal_31_d6c2f881:

    # "Dentro, había un líquido transparente espeso, que rozaba con el amarillo. En el interior, al fondo, ves una mancha de color rojo oscuro mezclado con negro."
    "Внутри — густая прозрачная жидкость, с лёгким желтоватым оттенком. На самом дне виднеется тёмно-красное пятно, вперемешку с чёрным."

# game/script.rpy:4634
translate russian ruta_normal_31_823b8798:

    # "Entonces, él lo gira."
    "Он поворачивает банку."

# game/script.rpy:4642
translate russian ruta_normal_31_2571b751:

    # "Es tu ojo."
    "В ней ваш глаз."

# game/script.rpy:4643
translate russian ruta_normal_31_2aa646a4:

    # "Sientes frío."
    "Вас пробирает холод."

# game/script.rpy:4646
translate russian ruta_normal_31_1a0e26a1:

    # J "Tu ojo es tan lindo… No pude evitar guardarlo."
    J "Твой глаз такой красивый... Я не мог не сохранить его."

# game/script.rpy:4650
translate russian ruta_normal_31_05f357bd:

    # "Jeff se dirige a ti, sujetando tus mejillas entre sus manos."
    "Джефф подходит ближе и обхватывает ваши щёки ладонями."

# game/script.rpy:4651
translate russian ruta_normal_31_f8f0edeb:

    # J "Pero ahora tengo algo mejor, a ti."
    J "Но теперь у меня есть кое-что получше — ты."

# game/script.rpy:4652
translate russian ruta_normal_31_53b5cb31:

    # "Él acaricia tu piel con sus pulgares, bajando los ojos hacia tus labios."
    "Он проводит большими пальцами по вашей коже, опуская взгляд на ваши губы."

# game/script.rpy:4653
translate russian ruta_normal_31_90387985:

    # J "Lo que tenemos es especial… Y me aseguraré de que también lo veas."
    J "У нас с тобой особенная связь... И я позабочусь о том, чтобы ты это поняли."

# game/script.rpy:4654
translate russian ruta_normal_31_e213b787:

    # "Sientes que un escalofrío te atraviesa. Llegas a la conclusión de que no tienes escapatoria."
    "Вас пробирает дрожь. Постепенно приходит осознание — пути назад нет."

# game/script.rpy:4655
translate russian ruta_normal_31_411f3080:

    # "Físicamente, es casi imposible escapar de Jeff. Incluso si lo intentas, por cómo él se expresa, no crees que dude en encadenarte a su lado o cortarte las piernas para que no huyas."
    "Физически сбежать от Джеффа почти невозможно. Даже если вы попробуете, по его интонации ясно: он не задумается ни на секунду, прежде чем приковать вас или отрезать вам ноги, чтобы вы не смогли уйти."

# game/script.rpy:4656
translate russian ruta_normal_31_3fa08942:

    # "Tampoco puedes pedir ayuda, Jeff mataría a cualquiera que se acerque a ti. Lo sabes por experiencia."
    "Просить помощи тоже бессмысленно — Джефф убьёт любого, кто к вам приблизится. Вы знаете это по своему горькому опыту."

# game/script.rpy:4662
translate russian ruta_normal_31_fde358df:

    # pov "Estás demente…"
    pov "Ты псих..."

# game/script.rpy:4664
translate russian ruta_normal_31_b681b637:

    # "Jeff suelta una carcajada estridente, bajando sus manos a tus hombros."
    "Джефф разражается смехом, опуская руки вам на плечи."

# game/script.rpy:4665
translate russian ruta_normal_31_d35a1ad6:

    # J "Completamente."
    J "Абсолютно."

# game/script.rpy:4668
translate russian ruta_normal_31_d51b3aa1:

    # pov "Seh, entiendo lo que dices."
    pov "Ага, понимаю, о чём ты."

# game/script.rpy:4670
translate russian ruta_normal_31_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4671
translate russian ruta_normal_31_71a1df4f:

    # J "Me sorprende que lo aceptes tan fácilmente."
    J "Удивительно, как спокойно ты это принимаешь."

# game/script.rpy:4676
translate russian ruta_normal_32_1d5838c0:

    # pov "Ok, ok."
    pov "Ладно, ладно."

# game/script.rpy:4677
translate russian ruta_normal_32_3e6fe275:

    # pov "Tomaré tu tonto desayuno."
    pov "Съем твой дурацкий завтрак."

# game/script.rpy:4679
translate russian ruta_normal_32_6ece30ea:

    # "Jeff sonrió ampliamente, inclinándose hacia ti."
    "Джефф широко улыбается и наклоняется к вам."

# game/script.rpy:4680
translate russian ruta_normal_32_08b0726f:

    # "En un momento pensaste que te iba a besar, por lo que cerraste tu ojo, pero entonces sentiste un toque ligero en tu frente."
    "На мгновение вам кажется, что он собирается вас поцеловать, поэтому закрываете глаз, но чувствуете лишь лёгкое прикосновение ко лбу."

# game/script.rpy:4682
translate russian ruta_normal_32_4239d584:

    # "Jeff besa tu frente por unos segundos, para después liberarte y tomar asiento en la mesa."
    "Джефф несколько секунд целует ваш лоб, затем отпускает вас и садится за стол."

# game/script.rpy:4685
translate russian ruta_normal_32_69771d33:

    # "Sigues su ejemplo y tomas asiento."
    "Вы следуете его примеру и садитесь."

# game/script.rpy:4686
translate russian ruta_normal_32_0169e7f5:

    # "En silencio, bebes el latte y comes el bocadillo que te trajo."
    "Молча отпиваете немного латте и начинаете есть принесённый им перекус."

# game/script.rpy:4687
translate russian ruta_normal_32_16773c69:

    # pov "¿De dónde sacaste esto?"
    pov "Где ты это взял?"

# game/script.rpy:4688
translate russian ruta_normal_32_5dca7d2e:

    # J "¿Crees que no sé sobre las cadenas de comida?"
    J "Думаешь, я не в курсе о сетевых магазинах?"

# game/script.rpy:4689
translate russian ruta_normal_32_64c58861:

    # J "A varias calles de aquí hay una sucursal de una cafetería."
    J "В паре кварталов отсюда есть филиал одной кофейни."

# game/script.rpy:4690
translate russian ruta_normal_32_994f58f1:

    # pov "¿Tú tomaste desayuno?"
    pov "А ты сам завтракал?"

# game/script.rpy:4692
translate russian ruta_normal_32_d0cbca46:

    # "Jeff se sonroja levemente, sonriendo afectuosamente."
    "Джефф слегка краснеет и ласково улыбается."

# game/script.rpy:4693
translate russian ruta_normal_32_cea94b78:

    # J "Si, hace horas."
    J "Да, несколько часов назад."

# game/script.rpy:4694
translate russian ruta_normal_32_e1a49023:

    # J "Lamento no acompañarte, pero nuestros horarios son diferentes."
    J "Прости, что не ем с тобой — у нас слишком разные графики."

# game/script.rpy:4698
translate russian ruta_normal_32_f9f09698:

    # pov "¿Y eso por qué?"
    pov "И почему так?"

# game/script.rpy:4700
translate russian ruta_normal_32_7c52190c:

    # J "Al ser un fugitivo, suelo comprar y comer en la madrugada."
    J "Я же беглец. Обычно покупаю еду и ем глубокой ночью."

# game/script.rpy:4701
translate russian ruta_normal_32_2d9a03fe:

    # J "Los empleados están cansados y malhumorados, así que no me prestan atención."
    J "К этому времени сотрудники уставшие и раздражённые, так что внимания на меня не обращают."

# game/script.rpy:4706
translate russian ruta_normal_32_cb9dbbbe:

    # pov "¿Y si en la cena te unes a mí?"
    pov "А если поешь со мной?"

# game/script.rpy:4708
translate russian ruta_normal_32_9ac12320:

    # J "Oh, eso me encantaría."
    J "О, с радостью."

# game/script.rpy:4709
translate russian ruta_normal_32_b539c844:

    # "Escuchas cómo él suspira levemente."
    "Вы слышите, как он тихо вздыхает."

# game/script.rpy:4714
translate russian ruta_normal_33_6d631ceb:

    # pov "Espera, ¿Pagaste esto con dinero?"
    pov "Подожди, ты это за деньги купил?"

# game/script.rpy:4716
translate russian ruta_normal_33_c772f825:

    # "Jeff ladea la cabeza, como si estuviera alzando una ceja que no tiene."
    "Джефф склоняет голову набок, будто поднимая бровь, которой у него нет."

# game/script.rpy:4717
translate russian ruta_normal_33_35a88c7e:

    # J "¿De qué otra forma pude haberlo conseguido?"
    J "А как ещё?"

# game/script.rpy:4718
translate russian ruta_normal_33_607291cb:

    # pov "No sé, robo a mano armada."
    pov "Не знаю, вооружённое ограбление."

# game/script.rpy:4720
translate russian ruta_normal_33_c0eecd4e:

    # J "Tch, no soy tan descuidado."
    J "Тц, я не настолько безалаберный."

# game/script.rpy:4721
translate russian ruta_normal_33_acba4af7:

    # J "Ya me buscan por asesinato e incendio provocado, no voy a agregar robo a esa lista."
    J "Меня и так ищут за убийства и поджоги, не собираюсь добавлять в этот список ограбление."

# game/script.rpy:4722
translate russian ruta_normal_33_ac8ebcf9:

    # pov "¿Y de donde sacas el dinero?"
    pov "Тогда откуда у тебя деньги?"

# game/script.rpy:4724
translate russian ruta_normal_33_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4725
translate russian ruta_normal_33_22ca5f90:

    # J "Bueno, sería un desperdicio no quedarse con el dinero de algunas de las personas que mato."
    J "Ну, было бы глупо не пользоваться деньгами тех, кого я убиваю."

# game/script.rpy:4726
translate russian ruta_normal_33_83521234:

    # "La manera en que él admite matar gente tan relajado es escalofriante."
    "То, с какой лёгкостью он признаётся в убийствах, вызывает дрожь."

# game/script.rpy:4727
translate russian ruta_normal_33_933d1ccf:

    # pov "Geez, eres patético. No te vale con matar gente, también le robas."
    pov "Господи, какой же ты жалкий. Тебе мало людей убивать — ещё и обираешь их."

# game/script.rpy:4728
translate russian ruta_normal_33_b8252e52:

    # J "Hey, al menos esos asesinatos no son atribuidos a mí. Se alejan de mi modus operandi, y pasan a considerarse robo."
    J "Эй, по крайней мере, эти убийства не приписывают мне. Они выбиваются из моего почерка, так что их считают грабежами."

# game/script.rpy:4729
translate russian ruta_normal_33_f6f67e20:

    # pov "Eso no es razón de estar orgulloso, Jeff."
    pov "Это не повод для гордости, Джефф."

# game/script.rpy:4730
translate russian ruta_normal_33_fa773a75:

    # pov "Nada de lo que dices es razón para estarlo."
    pov "Вообще ничего из того, что ты говоришь, не может быть поводом для гордости."

# game/script.rpy:4731
translate russian ruta_normal_33_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4733
translate russian ruta_normal_33_dce8af4b:

    # J "Eres adorable cuando me juzgas."
    J "Ты такие милые, когда осуждаешь меня."

# game/script.rpy:4734
translate russian ruta_normal_33_fbe721e8:

    # "Oh no, ha caído por completo."
    "О нет, он окончательно поехавший."

# game/script.rpy:4735
translate russian ruta_normal_33_63c7759e:

    # "Pero no puedes bajar la guardia, tampoco tomar ventaja de eso."
    "Но вы не можете ни ослабить бдительность, ни воспользоваться этим."

# game/script.rpy:4736
translate russian ruta_normal_33_bfa8cd89:

    # "Por más tonto de amor que se vea, sigue siendo un desquiciado que, por lo que has aprendido recientemente, es más calculador de lo que aparenta."
    "Каким бы влюблённым придурком он ни казался, перед вами всё тот же маньяк, к тому же куда более расчётливый, чем кажется."

# game/script.rpy:4737
translate russian ruta_normal_33_510ce023:

    # pov "¿Nunca te habías enamorado antes?"
    pov "Ты когда-нибудь влюблялся?"

# game/script.rpy:4739
translate russian ruta_normal_33_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4740
translate russian ruta_normal_33_7932a8d4:

    # J "Creo que una vez, si se le puede llamar así."
    J "Кажется, лишь однажды. Если это вообще можно так назвать."

# game/script.rpy:4741
translate russian ruta_normal_33_1328bb2c:

    # pov "Oh, ¿De quién?"
    pov "О, и в кого?"

# game/script.rpy:4743
translate russian ruta_normal_33_5982e346:

    # J "Una mujer con la que pasé tres noches."
    J "В женщину, с которой я провёл три ночи."

# game/script.rpy:4744
translate russian ruta_normal_33_f60c587f:

    # pov "Asco."
    pov "Фу."

# game/script.rpy:4746
translate russian ruta_normal_33_03fedf7b:

    # J "¡No de esa forma!, Fue íntimo de otra manera."
    J "Не в таком смысле! Это была близость другого рода."

# game/script.rpy:4748
translate russian ruta_normal_33_a41793da:

    # J "Hablamos todo el tiempo. Sentí que ella me comprendía."
    J "Мы всё время разговаривали. Я чувствовал, что она меня понимает."

# game/script.rpy:4750
translate russian ruta_normal_33_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:4751
translate russian ruta_normal_33_f8201474:

    # J "¿Qué me dices de ti?"
    J "А ты?"

# game/script.rpy:4752
translate russian ruta_normal_33_0b838cd8:

    # J "¿Te has enamorado antes?"
    J "Ты когда-нибудь влюблялись?"

# game/script.rpy:4756
translate russian ruta_normal_33_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:4757
translate russian ruta_normal_33_f24ea46c:

    # J "Pero eso ya pasó, ¿No?"
    J "Но это уже в прошлом, да?"

# game/script.rpy:4758
translate russian ruta_normal_33_5e8dbdaf:

    # "Cierto, él es el tipo celoso."
    "Точно, он ведь из ревнивых."

# game/script.rpy:4759
translate russian ruta_normal_33_97f17220:

    # pov "Obviamente."
    pov "Конечно."

# game/script.rpy:4763
translate russian ruta_normal_33_adb437bd:

    # "Jeff amplió su sonrisa"
    "Улыбка Джеффа становится шире."

# game/script.rpy:4769
translate russian character_8_a6d414ee:

    # J "¿Entonces cuál es tu preferencia?"
    J "Тогда какие у тебя предпочтения?"

# game/script.rpy:4770
translate russian character_8_d730ab6e:

    # J "¿Hombre, mujer, ambos?"
    J "Мужчины, женщины, оба?"

# game/script.rpy:4775
translate russian character_8_eef15567:

    # J "Me aseguraré de que no pienses en ninguno más que yo."
    J "Я позабочусь о том, чтобы ты не думали ни о ком, кроме меня."

# game/script.rpy:4778
translate russian character_8_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4780
translate russian character_8_20fad819:

    # J "No puedo evitar ser un hombre."
    J "Я не могу не быть мужчиной."

# game/script.rpy:4782
translate russian character_8_380d298b:

    # J "Pero no te dejaré ir sólo por eso."
    J "Но не отпущу тебя только из-за этого."

# game/script.rpy:4786
translate russian character_8_f0f85b68:

    # J "Ah, tengo doble competencia."
    J "А, значит, у меня двойная конкуренция."

# game/script.rpy:4787
translate russian character_8_6fe70448:

    # J "Te aseguro que no suelo perder."
    J "Уверяю, я не из тех, кто привык проигрывать."

# game/script.rpy:4791
translate russian character_8_6fe96c38:

    # "Jef se ríe levemente, contento."
    "Джефф тихо смеётся, явно довольный."

# game/script.rpy:4792
translate russian character_8_e3a88074:

    # J "Eres como yo."
    J "В этом мы похожи."

# game/script.rpy:4793
translate russian character_8_19dd0302:

    # J "A mí tampoco me importa."
    J "Мне тоже всё равно."

# game/script.rpy:4794
translate russian character_8_bd4ba19a:

    # J "A ti te amo porque eres tú."
    J "Я люблю тебя просто за то, что ты — это ты."

# game/script.rpy:4798
translate russian character_8_8a93848e:

    # J "Huh."
    J "Хм."

# game/script.rpy:4799
translate russian character_8_dffe318c:

    # "La sonrisa de él se volvió traviesa."
    "Его улыбка становится лукавой."

# game/script.rpy:4800
translate russian character_8_f26d8ce2:

    # J "Haré que me consideres a mí, y sólo a mí."
    J "Я заставлю тебя думать только обо мне."

# game/script.rpy:4805
translate russian character_9_db2102ac:

    # J "Mientras más sé cosas sobre ti, más me gustas."
    J "Чем больше узнаю о тебе, тем сильнее ты мне нравишься."

# game/script.rpy:4806
translate russian character_9_95a61e2b:

    # pov "¿Puedo saber cosas de ti también?"
    pov "А я могу узнать что-нибудь о тебе?"

# game/script.rpy:4807
translate russian character_9_fac559cf:

    # J "Por supuesto."
    J "Конечно."

# game/script.rpy:4813
translate russian character_9_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4814
translate russian character_9_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Разумеется, когда-то у меня была семья."

# game/script.rpy:4815
translate russian character_9_6dfaad92:

    # J "Una madre, un padre."
    J "Мать, отец."

# game/script.rpy:4816
translate russian character_9_4b5c3a9e:

    # J "… Un hermano."
    J "...Брат."

# game/script.rpy:4817
translate russian character_9_424f497b:

    # J "Pero los perdí."
    J "Но я их потерял."

# game/script.rpy:4822
translate russian character_9_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4824
translate russian character_9_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Джефф безрадостно усмехается."

# game/script.rpy:4825
translate russian character_9_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "Ты знаешь меня лучше, чем я думал."

# game/script.rpy:4828
translate russian character_9_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4829
translate russian character_9_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], ты умные. Уверен, ответ уже знаешь."

# game/script.rpy:4833
translate russian character_9_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "Раньше я жил кое с кем."

# game/script.rpy:4834
translate russian character_9_a5531769:

    # J "Era una casa grande, éramos varios."
    J "То был большой дом, нас было несколько."

# game/script.rpy:4835
translate russian character_9_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "И у каждого... свои тараканы в голове."

# game/script.rpy:4837
translate russian character_9_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "Но они были ближе всех к тому, что можно называть друзьями."

# game/script.rpy:4840
translate russian character_9_becae388:

    # J "No lo eran, créeme."
    J "Вообще нет, поверь."

# game/script.rpy:4841
translate russian character_9_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Зачем, по-твоему, кому-то жить под одной крышей с убийцей вроде меня?"

# game/script.rpy:4842
translate russian character_9_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4843
translate russian character_9_37b98de6:

    # J "Así es, mataban gente también."
    J "Правильно, они тоже убивали людей."

# game/script.rpy:4848
translate russian character_9_a46e5454:

    # J "Hah, lo eran."
    J "Ха, ещё как."

# game/script.rpy:4850
translate russian character_9_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "Хозяин дома был... безэмоциональным."

# game/script.rpy:4851
translate russian character_9_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "Один из них был каннибалом... Думаю, его можно так назвать?"

# game/script.rpy:4852
translate russian character_9_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Другой всё время торчал за видеоиграми."

# game/script.rpy:4853
translate russian character_9_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "Третий наряжался клоуном, а парочка ребят постоянно что-то снимала на камеру."

# game/script.rpy:4854
translate russian character_9_af0d79a7:

    # J "Así que sí, son raros."
    J "Так что да, они странные."

# game/script.rpy:4858
translate russian character_9_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:4859
translate russian character_9_d5ff44d8:

    # J "No te diré."
    J "Не скажу."

# game/script.rpy:4860
translate russian character_9_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Да ладно тебе!"

# game/script.rpy:4861
translate russian character_9_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "Хотя бы диапазон назови?"

# game/script.rpy:4862
translate russian character_9_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:4863
translate russian character_9_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "А тебе сколько?"

# game/script.rpy:4866
translate russian character_9_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:4867
translate russian character_9_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "Но ты же совершеннолетние, да?"

# game/script.rpy:4868
translate russian character_9_97bf5def:

    # pov "Por supuesto."
    pov "Разумеется."

# game/script.rpy:4869
translate russian character_9_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Отлично, я не встречаюсь с несовершеннолетними."

# game/script.rpy:4870
translate russian character_9_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "Это... хорошо, наверное?"

# game/script.rpy:4871
translate russian character_9_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "Что вообще может быть хорошего в убийце?"

# game/script.rpy:4872
translate russian character_9_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "...Но я значительно старше."

# game/script.rpy:4873
translate russian character_9_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Не переживай, со взрослыми я справляюсь."

# game/script.rpy:4876
translate russian character_9_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Ладно, я старше тебя."

# game/script.rpy:4877
translate russian character_9_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "Даже не скажешь, насколько?"

# game/script.rpy:4878
translate russian character_9_290da55e:

    # "Jeff refunfuñó."
    "Джефф ворчит."

# game/script.rpy:4879
translate russian character_9_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "Значит, постарше, да?"

# game/script.rpy:4882
translate russian character_9_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "Мы примерно одного возраста, довольны?"

# game/script.rpy:4883
translate russian character_9_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "Значит, тебе за тридцать, да?"

# game/script.rpy:4885
translate russian character_9_dbe4fbfd:

    # J "Cállate."
    J "Заткнись."

# game/script.rpy:4890
translate russian character_9_ffcd567a:

    # pov "Estás en buena forma."
    pov "Ты в отличной форме."

# game/script.rpy:4892
translate russian character_9_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Даже если не так уж молод, выглядишь ты хорошо."

# game/script.rpy:4894
translate russian character_9_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Конечно, если не считать изуродованное лицо."

# game/script.rpy:4895
translate russian character_9_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Джефф молчит, но вы замечаете, как у него краснеют щёки."

# game/script.rpy:4898
translate russian character_9_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "Для старика ты хорошо выглядишь."

# game/script.rpy:4899
translate russian character_9_b1bf0aaa:

    # "Jeff resopla."
    "Джефф фыркает."

# game/script.rpy:4911
translate russian familia0_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "Раньше я жил кое с кем."

# game/script.rpy:4912
translate russian familia0_a5531769:

    # J "Era una casa grande, éramos varios."
    J "То был большой дом, нас было несколько."

# game/script.rpy:4913
translate russian familia0_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "И у каждого... свои тараканы в голове."

# game/script.rpy:4915
translate russian familia0_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "Но они были ближе всех к тому, что можно называть друзьями."

# game/script.rpy:4918
translate russian familia0_becae388:

    # J "No lo eran, créeme."
    J "Вообще нет, поверь."

# game/script.rpy:4919
translate russian familia0_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Зачем, по-твоему, кому-то жить под одной крышей с убийцей вроде меня?"

# game/script.rpy:4920
translate russian familia0_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:4921
translate russian familia0_37b98de6:

    # J "Así es, mataban gente también."
    J "Правильно, они тоже убивали людей."

# game/script.rpy:4926
translate russian familia0_a46e5454:

    # J "Hah, lo eran."
    J "Ха, ещё как."

# game/script.rpy:4928
translate russian familia0_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "Хозяин дома был... безэмоциональным."

# game/script.rpy:4929
translate russian familia0_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "Один из них был каннибалом... Думаю, его можно так назвать?"

# game/script.rpy:4930
translate russian familia0_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Другой всё время торчал за видеоиграми."

# game/script.rpy:4931
translate russian familia0_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "Третий наряжался клоуном, а парочка ребят постоянно что-то снимала на камеру."

# game/script.rpy:4932
translate russian familia0_af0d79a7:

    # J "Así que sí, son raros."
    J "Так что да, они странные."

# game/script.rpy:4936
translate russian familia0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4937
translate russian familia0_d5ff44d8:

    # J "No te diré."
    J "Не скажу."

# game/script.rpy:4938
translate russian familia0_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Да ладно тебе!"

# game/script.rpy:4939
translate russian familia0_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "Хотя бы диапазон назови?"

# game/script.rpy:4940
translate russian familia0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4941
translate russian familia0_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "А тебе сколько?"

# game/script.rpy:4944
translate russian familia0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:4945
translate russian familia0_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "Но ты же совершеннолетние, да?"

# game/script.rpy:4946
translate russian familia0_97bf5def:

    # pov "Por supuesto."
    pov "Разумеется."

# game/script.rpy:4947
translate russian familia0_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Отлично, я не встречаюсь с несовершеннолетними."

# game/script.rpy:4948
translate russian familia0_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "Это... хорошо, наверное?"

# game/script.rpy:4949
translate russian familia0_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "Что вообще может быть хорошего в убийце?"

# game/script.rpy:4950
translate russian familia0_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "...Но я значительно старше."

# game/script.rpy:4951
translate russian familia0_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Не переживай, со взрослыми я справляюсь."

# game/script.rpy:4953
translate russian familia0_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Ладно, я старше тебя."

# game/script.rpy:4954
translate russian familia0_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "Даже не скажешь, насколько?"

# game/script.rpy:4955
translate russian familia0_290da55e:

    # "Jeff refunfuñó."
    "Джефф ворчит."

# game/script.rpy:4956
translate russian familia0_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "Значит, постарше, да?"

# game/script.rpy:4958
translate russian familia0_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "Мы примерно одного возраста, довольны?"

# game/script.rpy:4959
translate russian familia0_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "Значит, тебе за тридцать, да?"

# game/script.rpy:4961
translate russian familia0_dbe4fbfd:

    # J "Cállate."
    J "Заткнись."

# game/script.rpy:4966
translate russian familia0_ffcd567a:

    # pov "Estás en buena forma."
    pov "Ты в отличной форме."

# game/script.rpy:4968
translate russian familia0_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Даже если не так уж молод, выглядишь ты хорошо."

# game/script.rpy:4970
translate russian familia0_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Конечно, если не считать изуродованное лицо."

# game/script.rpy:4971
translate russian familia0_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Джефф молчит, но вы замечаете, как у него краснеют щёки."

# game/script.rpy:4974
translate russian familia0_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "Для старика ты хорошо выглядишь."

# game/script.rpy:4975
translate russian familia0_b1bf0aaa:

    # "Jeff resopla."
    "Джефф фыркает."

# game/script.rpy:4985
translate russian amigos0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:4986
translate russian amigos0_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Разумеется, когда-то у меня была семья."

# game/script.rpy:4987
translate russian amigos0_6dfaad92:

    # J "Una madre, un padre."
    J "Мать, отец."

# game/script.rpy:4988
translate russian amigos0_4b5c3a9e:

    # J "… Un hermano."
    J "...Брат."

# game/script.rpy:4989
translate russian amigos0_424f497b:

    # J "Pero los perdí."
    J "Но я их потерял."

# game/script.rpy:4994
translate russian amigos0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:4996
translate russian amigos0_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Джефф безрадостно усмехается."

# game/script.rpy:4997
translate russian amigos0_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "Ты знаешь меня лучше, чем я думал."

# game/script.rpy:5000
translate russian amigos0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5001
translate russian amigos0_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], ты умные. Уверен, ответ уже знаешь."

# game/script.rpy:5005
translate russian amigos0_14360a18_3:

    # J "…"
    J "..."

# game/script.rpy:5006
translate russian amigos0_d5ff44d8:

    # J "No te diré."
    J "Не скажу."

# game/script.rpy:5007
translate russian amigos0_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Да ладно тебе!"

# game/script.rpy:5008
translate russian amigos0_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "Хотя бы диапазон назови?"

# game/script.rpy:5009
translate russian amigos0_14360a18_4:

    # J "…"
    J "..."

# game/script.rpy:5010
translate russian amigos0_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "А тебе сколько?"

# game/script.rpy:5013
translate russian amigos0_14360a18_5:

    # J "…"
    J "..."

# game/script.rpy:5014
translate russian amigos0_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "Но ты же совершеннолетние, да?"

# game/script.rpy:5015
translate russian amigos0_97bf5def:

    # pov "Por supuesto."
    pov "Разумеется."

# game/script.rpy:5016
translate russian amigos0_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Отлично, я не встречаюсь с несовершеннолетними."

# game/script.rpy:5017
translate russian amigos0_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "Это... хорошо, наверное?"

# game/script.rpy:5018
translate russian amigos0_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "Что вообще может быть хорошего в убийце?"

# game/script.rpy:5019
translate russian amigos0_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "...Но я значительно старше."

# game/script.rpy:5020
translate russian amigos0_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Не переживай, со взрослыми я справляюсь."

# game/script.rpy:5023
translate russian amigos0_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Ладно, я старше тебя."

# game/script.rpy:5024
translate russian amigos0_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "Даже не скажешь, насколько?"

# game/script.rpy:5025
translate russian amigos0_290da55e:

    # "Jeff refunfuñó."
    "Джефф ворчит."

# game/script.rpy:5026
translate russian amigos0_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "Значит, постарше, да?"

# game/script.rpy:5029
translate russian amigos0_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "Мы примерно одного возраста, довольны?"

# game/script.rpy:5030
translate russian amigos0_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "Значит, тебе за тридцать, да?"

# game/script.rpy:5032
translate russian amigos0_dbe4fbfd:

    # J "Cállate."
    J "Заткнись."

# game/script.rpy:5037
translate russian amigos0_ffcd567a:

    # pov "Estás en buena forma."
    pov "Ты в отличной форме."

# game/script.rpy:5039
translate russian amigos0_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Даже если не так уж молод, выглядишь ты хорошо."

# game/script.rpy:5041
translate russian amigos0_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Конечно, если не считать изуродованное лицо."

# game/script.rpy:5042
translate russian amigos0_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Джефф молчит, но вы замечаете, как у него краснеют щёки."

# game/script.rpy:5045
translate russian amigos0_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "Для старика ты хорошо выглядишь."

# game/script.rpy:5046
translate russian amigos0_b1bf0aaa:

    # "Jeff resopla."
    "Джефф фыркает."

# game/script.rpy:5056
translate russian edad0_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5057
translate russian edad0_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Разумеется, когда-то у меня была семья."

# game/script.rpy:5058
translate russian edad0_6dfaad92:

    # J "Una madre, un padre."
    J "Мать, отец."

# game/script.rpy:5059
translate russian edad0_4b5c3a9e:

    # J "… Un hermano."
    J "...Брат."

# game/script.rpy:5060
translate russian edad0_424f497b:

    # J "Pero los perdí."
    J "Но я их потерял."

# game/script.rpy:5065
translate russian edad0_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5067
translate russian edad0_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Джефф безрадостно усмехается."

# game/script.rpy:5068
translate russian edad0_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "Ты знаешь меня лучше, чем я думал."

# game/script.rpy:5071
translate russian edad0_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5072
translate russian edad0_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], ты умные. Уверен, ответ уже знаешь."

# game/script.rpy:5077
translate russian edad0_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "Раньше я жил кое с кем."

# game/script.rpy:5078
translate russian edad0_a5531769:

    # J "Era una casa grande, éramos varios."
    J "То был большой дом, нас было несколько."

# game/script.rpy:5079
translate russian edad0_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "И у каждого... свои тараканы в голове."

# game/script.rpy:5081
translate russian edad0_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "Но они были ближе всех к тому, что можно называть друзьями."

# game/script.rpy:5084
translate russian edad0_becae388:

    # J "No lo eran, créeme."
    J "Вообще нет, поверь."

# game/script.rpy:5085
translate russian edad0_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Зачем, по-твоему, кому-то жить под одной крышей с убийцей вроде меня?"

# game/script.rpy:5086
translate russian edad0_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5087
translate russian edad0_37b98de6:

    # J "Así es, mataban gente también."
    J "Правильно, они тоже убивали людей."

# game/script.rpy:5092
translate russian edad0_a46e5454:

    # J "Hah, lo eran."
    J "Ха, ещё как."

# game/script.rpy:5094
translate russian edad0_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "Хозяин дома был... безэмоциональным."

# game/script.rpy:5095
translate russian edad0_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "Один из них был каннибалом... Думаю, его можно так назвать?"

# game/script.rpy:5096
translate russian edad0_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Другой всё время торчал за видеоиграми."

# game/script.rpy:5097
translate russian edad0_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "Третий наряжался клоуном, а парочка ребят постоянно что-то снимала на камеру."

# game/script.rpy:5098
translate russian edad0_af0d79a7:

    # J "Así que sí, son raros."
    J "Так что да, они странные."

# game/script.rpy:5110
translate russian familia1_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5111
translate russian familia1_1_d5ff44d8:

    # J "No te diré."
    J "Не скажу."

# game/script.rpy:5112
translate russian familia1_1_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Да ладно тебе!"

# game/script.rpy:5113
translate russian familia1_1_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "Хотя бы диапазон назови?"

# game/script.rpy:5114
translate russian familia1_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5115
translate russian familia1_1_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "А тебе сколько?"

# game/script.rpy:5118
translate russian familia1_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5119
translate russian familia1_1_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "Но ты же совершеннолетние, да?"

# game/script.rpy:5120
translate russian familia1_1_97bf5def:

    # pov "Por supuesto."
    pov "Разумеется."

# game/script.rpy:5121
translate russian familia1_1_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Отлично, я не встречаюсь с несовершеннолетними."

# game/script.rpy:5122
translate russian familia1_1_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "Это... хорошо, наверное?"

# game/script.rpy:5123
translate russian familia1_1_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "Что вообще может быть хорошего в убийце?"

# game/script.rpy:5124
translate russian familia1_1_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "...Но я значительно старше."

# game/script.rpy:5125
translate russian familia1_1_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Не переживай, со взрослыми я справляюсь."

# game/script.rpy:5128
translate russian familia1_1_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Ладно, я старше тебя."

# game/script.rpy:5129
translate russian familia1_1_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "Даже не скажешь, насколько?"

# game/script.rpy:5130
translate russian familia1_1_290da55e:

    # "Jeff refunfuñó."
    "Джефф ворчит."

# game/script.rpy:5131
translate russian familia1_1_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "Значит, постарше, да?"

# game/script.rpy:5134
translate russian familia1_1_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "Мы примерно одного возраста, довольны?"

# game/script.rpy:5135
translate russian familia1_1_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "Значит, тебе за тридцать, да?"

# game/script.rpy:5137
translate russian familia1_1_dbe4fbfd:

    # J "Cállate."
    J "Заткнись."

# game/script.rpy:5142
translate russian familia1_1_ffcd567a:

    # pov "Estás en buena forma."
    pov "Ты в отличной форме."

# game/script.rpy:5144
translate russian familia1_1_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Даже если не так уж молод, выглядишь ты хорошо."

# game/script.rpy:5146
translate russian familia1_1_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Конечно, если не считать изуродованное лицо."

# game/script.rpy:5147
translate russian familia1_1_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Джефф молчит, но вы замечаете, как у него краснеют щёки."

# game/script.rpy:5150
translate russian familia1_1_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "Для старика ты хорошо выглядишь."

# game/script.rpy:5151
translate russian familia1_1_b1bf0aaa:

    # "Jeff resopla."
    "Джефф фыркает."

# game/script.rpy:5161
translate russian familia1_2_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "Раньше я жил кое с кем."

# game/script.rpy:5162
translate russian familia1_2_a5531769:

    # J "Era una casa grande, éramos varios."
    J "То был большой дом, нас было несколько."

# game/script.rpy:5163
translate russian familia1_2_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "И у каждого... свои тараканы в голове."

# game/script.rpy:5165
translate russian familia1_2_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "Но они были ближе всех к тому, что можно называть друзьями."

# game/script.rpy:5168
translate russian familia1_2_becae388:

    # J "No lo eran, créeme."
    J "Вообще нет, поверь."

# game/script.rpy:5169
translate russian familia1_2_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Зачем, по-твоему, кому-то жить под одной крышей с убийцей вроде меня?"

# game/script.rpy:5170
translate russian familia1_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5171
translate russian familia1_2_37b98de6:

    # J "Así es, mataban gente también."
    J "Правильно, они тоже убивали людей."

# game/script.rpy:5176
translate russian familia1_2_a46e5454:

    # J "Hah, lo eran."
    J "Ха, ещё как."

# game/script.rpy:5178
translate russian familia1_2_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "Хозяин дома был... безэмоциональным."

# game/script.rpy:5179
translate russian familia1_2_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "Один из них был каннибалом... Думаю, его можно так назвать?"

# game/script.rpy:5180
translate russian familia1_2_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Другой всё время торчал за видеоиграми."

# game/script.rpy:5181
translate russian familia1_2_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "Третий наряжался клоуном, а парочка ребят постоянно что-то снимала на камеру."

# game/script.rpy:5182
translate russian familia1_2_af0d79a7:

    # J "Así que sí, son raros."
    J "Так что да, они странные."

# game/script.rpy:5195
translate russian amigos1_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5196
translate russian amigos1_1_d5ff44d8:

    # J "No te diré."
    J "Не скажу."

# game/script.rpy:5197
translate russian amigos1_1_a3d7f3e2:

    # pov "¡Oh, vamos!"
    pov "Да ладно тебе!"

# game/script.rpy:5198
translate russian amigos1_1_347f0a54:

    # pov "¿Al menos me das un rango?"
    pov "Хотя бы диапазон назови?"

# game/script.rpy:5199
translate russian amigos1_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5200
translate russian amigos1_1_955d53c2:

    # J "¿Qué edad tienes tú?"
    J "А тебе сколько?"

# game/script.rpy:5203
translate russian amigos1_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5204
translate russian amigos1_1_c192f762:

    # J "Pero eres mayor de edad, ¿Cierto?"
    J "Но ты же совершеннолетние, да?"

# game/script.rpy:5205
translate russian amigos1_1_97bf5def:

    # pov "Por supuesto."
    pov "Разумеется."

# game/script.rpy:5206
translate russian amigos1_1_d26ef4b6:

    # J "Menos mal, no salgo con menores."
    J "Отлично, я не встречаюсь с несовершеннолетними."

# game/script.rpy:5207
translate russian amigos1_1_d58afe41:

    # pov "Eso es… ¿bueno, supongo?"
    pov "Это... хорошо, наверное?"

# game/script.rpy:5208
translate russian amigos1_1_05f95411:

    # "¿Qué tantas cosas positivas pueden haber en un asesino?"
    "Что вообще может быть хорошего в убийце?"

# game/script.rpy:5209
translate russian amigos1_1_6e9e9741:

    # J "… Pero, soy considerablemente mayor."
    J "...Но я значительно старше."

# game/script.rpy:5210
translate russian amigos1_1_f53fc894:

    # pov "No te preocupes, puedo lidiar con hombres maduros."
    pov "Не переживай, со взрослыми я справляюсь."

# game/script.rpy:5213
translate russian amigos1_1_0a27ffb3:

    # J "De acuerdo, soy mayor que tú."
    J "Ладно, я старше тебя."

# game/script.rpy:5214
translate russian amigos1_1_de7f6d71:

    # pov "¿En serio no me vas a decir qué tanto?"
    pov "Даже не скажешь, насколько?"

# game/script.rpy:5215
translate russian amigos1_1_290da55e:

    # "Jeff refunfuñó."
    "Джефф ворчит."

# game/script.rpy:5216
translate russian amigos1_1_298bd41d:

    # pov "Así que mayor, ¿Eh?"
    pov "Значит, постарше, да?"

# game/script.rpy:5219
translate russian amigos1_1_4d368fb4:

    # J "Estamos iguales, ¿Feliz?"
    J "Мы примерно одного возраста, довольны?"

# game/script.rpy:5220
translate russian amigos1_1_12306922:

    # pov "Así que treintañero, ¿Eh?"
    pov "Значит, тебе за тридцать, да?"

# game/script.rpy:5222
translate russian amigos1_1_dbe4fbfd:

    # J "Cállate."
    J "Заткнись."

# game/script.rpy:5227
translate russian amigos1_1_ffcd567a:

    # pov "Estás en buena forma."
    pov "Ты в отличной форме."

# game/script.rpy:5229
translate russian amigos1_1_6d0c70c9:

    # pov "Incluso si no eres tan joven, te ves bien."
    pov "Даже если не так уж молод, выглядишь ты хорошо."

# game/script.rpy:5231
translate russian amigos1_1_1fd71d62:

    # "Ignorando lo destrozada que estaba su cara, claro."
    "Конечно, если не считать изуродованное лицо."

# game/script.rpy:5232
translate russian amigos1_1_90a03c5c:

    # "Jeff no dice nada, pero notas que sus mejillas se encienden."
    "Джефф молчит, но вы замечаете, как у него краснеют щёки."

# game/script.rpy:5235
translate russian amigos1_1_cc3d221c:

    # pov "Para ser tan viejo, te ves bien."
    pov "Для старика ты хорошо выглядишь."

# game/script.rpy:5236
translate russian amigos1_1_b1bf0aaa:

    # "Jeff resopla."
    "Джефф фыркает."

# game/script.rpy:5246
translate russian amigos1_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5247
translate russian amigos1_2_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Разумеется, когда-то у меня была семья."

# game/script.rpy:5248
translate russian amigos1_2_6dfaad92:

    # J "Una madre, un padre."
    J "Мать, отец."

# game/script.rpy:5249
translate russian amigos1_2_4b5c3a9e:

    # J "… Un hermano."
    J "...Брат."

# game/script.rpy:5250
translate russian amigos1_2_424f497b:

    # J "Pero los perdí."
    J "Но я их потерял."

# game/script.rpy:5255
translate russian amigos1_2_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5257
translate russian amigos1_2_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Джефф безрадостно усмехается."

# game/script.rpy:5258
translate russian amigos1_2_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "Ты знаешь меня лучше, чем я думал."

# game/script.rpy:5261
translate russian amigos1_2_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5262
translate russian amigos1_2_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], ты умные. Уверен, ответ уже знаешь."

# game/script.rpy:5275
translate russian edad1_1_7e3fac49:

    # J "Hubo un tiempo en que viví con unos tipos."
    J "Раньше я жил кое с кем."

# game/script.rpy:5276
translate russian edad1_1_a5531769:

    # J "Era una casa grande, éramos varios."
    J "То был большой дом, нас было несколько."

# game/script.rpy:5277
translate russian edad1_1_6d00dded:

    # J "Cada uno tenía… Sus peculiaridades."
    J "И у каждого... свои тараканы в голове."

# game/script.rpy:5279
translate russian edad1_1_3fb49aba:

    # J "Pero son lo más cercano a lo que puedo llamar amigos."
    J "Но они были ближе всех к тому, что можно называть друзьями."

# game/script.rpy:5282
translate russian edad1_1_becae388:

    # J "No lo eran, créeme."
    J "Вообще нет, поверь."

# game/script.rpy:5283
translate russian edad1_1_b3a1e0b9:

    # J "¿Por qué crees que vivían con un asesino como yo?"
    J "Зачем, по-твоему, кому-то жить под одной крышей с убийцей вроде меня?"

# game/script.rpy:5284
translate russian edad1_1_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5285
translate russian edad1_1_37b98de6:

    # J "Así es, mataban gente también."
    J "Правильно, они тоже убивали людей."

# game/script.rpy:5290
translate russian edad1_1_a46e5454:

    # J "Hah, lo eran."
    J "Ха, ещё как."

# game/script.rpy:5292
translate russian edad1_1_05e1a011:

    # J "El dueño de la casa era… inexpresivo."
    J "Хозяин дома был... безэмоциональным."

# game/script.rpy:5293
translate russian edad1_1_9eacf127:

    # J "Uno de ellos era caníbal… ¿Creo que se le puede llamar así?"
    J "Один из них был каннибалом... Думаю, его можно так назвать?"

# game/script.rpy:5294
translate russian edad1_1_7b4528fc:

    # J "Otro se la pasaba jugando videojuegos."
    J "Другой всё время торчал за видеоиграми."

# game/script.rpy:5295
translate russian edad1_1_813624b1:

    # J "Uno se vestía de payaso, y un par se la pasaban grabando."
    J "Третий наряжался клоуном, а парочка ребят постоянно что-то снимала на камеру."

# game/script.rpy:5296
translate russian edad1_1_af0d79a7:

    # J "Así que sí, son raros."
    J "Так что да, они странные."

# game/script.rpy:5307
translate russian edad1_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5308
translate russian edad1_2_1126bd9d:

    # J "Obviamente la tuve al inicio."
    J "Разумеется, когда-то у меня была семья."

# game/script.rpy:5309
translate russian edad1_2_6dfaad92:

    # J "Una madre, un padre."
    J "Мать, отец."

# game/script.rpy:5310
translate russian edad1_2_4b5c3a9e:

    # J "… Un hermano."
    J "...Брат."

# game/script.rpy:5311
translate russian edad1_2_424f497b:

    # J "Pero los perdí."
    J "Но я их потерял."

# game/script.rpy:5316
translate russian edad1_2_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5318
translate russian edad1_2_eefaef35:

    # "Jeff suelta una carcajada desganada."
    "Джефф безрадостно усмехается."

# game/script.rpy:5319
translate russian edad1_2_324f2e7c:

    # J "Me conoces mejor de lo que creí."
    J "Ты знаешь меня лучше, чем я думал."

# game/script.rpy:5322
translate russian edad1_2_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5323
translate russian edad1_2_b8d16f40:

    # J "[povname], eres inteligente, de seguro que sabes la respuesta."
    J "[povname], ты умные. Уверен, ответ уже знаешь."

# game/script.rpy:5331
translate russian ruta_normal_36_f0bc6ff2:

    # J "¿Estás feliz con todo lo que preguntaste?"
    J "Утолили своё любопытство?"

# game/script.rpy:5332
translate russian ruta_normal_36_1fa7d4ad:

    # pov "Depende, tengo una pregunta más."
    pov "Почти, у меня остался ещё один вопрос."

# game/script.rpy:5333
translate russian ruta_normal_36_604a6d99:

    # pov "¿Por qué matas?"
    pov "Зачем ты убиваешь?"

# game/script.rpy:5335
translate russian ruta_normal_36_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5337
translate russian ruta_normal_36_704f299d:

    # "Jeff desvía la mirada, pensativo."
    "Джефф задумчиво отводит взгляд."

# game/script.rpy:5338
translate russian ruta_normal_36_edf26648:

    # J "A este punto… Es como preguntarle a un pájaro por qué vuela."
    J "Знаешь... это всё равно, что спросить у птицы, зачем она летает."

# game/script.rpy:5340
translate russian ruta_normal_36_6a86aba2:

    # J "Es lo que soy."
    J "Это просто моя природа."

# game/script.rpy:5341
translate russian ruta_normal_36_22bd8e25:

    # pov "Pero empezó por algo, ¿No?, ¿Qué pasó?"
    pov "Но с чего-то же началось, правда? Что случилось?"

# game/script.rpy:5342
translate russian ruta_normal_36_5156b7fa:

    # "Jeff se encoge de hombros."
    "Джефф пожимает плечами."

# game/script.rpy:5343
translate russian ruta_normal_36_b65db1f2:

    # J "Era un niño cuando empezó."
    J "Я был ребёнком, когда это началось."

# game/script.rpy:5344
translate russian ruta_normal_36_157de133:

    # J "El mundo era un lugar sin sentido, y los humanos me parecen desagradables, en general."
    J "Мир казался бессмысленным, да и я в целом ненавижу людей."

# game/script.rpy:5345
translate russian ruta_normal_36_8b78ef51:

    # J "Quería hacer del mundo un lugar hermoso."
    J "Я хотел сделать мир лучшим местом."

# game/script.rpy:5346
translate russian ruta_normal_36_3f1585ed:

    # J "Y fue así durante años."
    J "И так продолжалось годами."

# game/script.rpy:5350
translate russian ruta_normal_36_cdb64694:

    # pov "Que rara razón para matar."
    pov "Довольно странная причина убивать."

# game/script.rpy:5351
translate russian ruta_normal_36_4b21052d:

    # pov "Yo pensaba que tenías una vida trágica."
    pov "Я-то думали, что у тебя была какая-нибудь трагическая история."

# game/script.rpy:5353
translate russian ruta_normal_36_22166c46:

    # J "Heh, lamento decepcionarte, amor."
    J "Хех, прости, что разочаровал, дорогуша."

# game/script.rpy:5358
translate russian ruta_normal_36_bb0baae6:

    # pov "Vaya, eso es jodido."
    pov "Вау, это полный пиздец."

# game/script.rpy:5360
translate russian ruta_normal_36_ba8ba4be:

    # J "Ni me lo digas."
    J "И не говори."

# game/script.rpy:5361
translate russian ruta_normal_36_ee881a55:

    # pov "Con razón estás tan mal de la cabeza."
    pov "Неудивительно, что ты такой тронутый."

# game/script.rpy:5362
translate russian ruta_normal_36_5adf6b79:

    # J "Heh, que halago, amor."
    J "Хех, ты мне льстишь, дорогуша."

# game/script.rpy:5368
translate russian ruta_normal_37_1c80fb09:

    # J "Pero cuando te conocí… Empecé a sentir cosas que pensé que había olvidado."
    J "Но когда я встретил тебя... во мне снова проснулись чувства, которые, я думал, давно утратил."

# game/script.rpy:5369
translate russian ruta_normal_37_6f0a8a15:

    # "Las palabras querían escapar de tu boca."
    "Слова хотели вырваться у вас изо рта."

# game/script.rpy:5370
translate russian ruta_normal_37_38200748:

    # pov "¿Considerarías dejar de matar?"
    pov "А ты бы смог перестать убивать?"

# game/script.rpy:5371
translate russian ruta_normal_37_73f8d438:

    # pov "¿Por mí?"
    pov "Ради меня?"

# game/script.rpy:5372
translate russian ruta_normal_37_c644c935:

    # "Era tarde, lo dijiste."
    "Уже поздно, вы это сказали."

# game/script.rpy:5373
translate russian ruta_normal_37_f5f36885:

    # "Nuevamente, no eres una santidad que quiere dar una lección moral a una persona evidentemente inmoral, pero era una pregunta hecha por genuina curiosidad."
    "Конечно, вы не святоша, пытающийся читать нотации очевидному безумцу, вы просто задали этот вопрос из искреннего любопытства."

# game/script.rpy:5374
translate russian ruta_normal_37_065221ab:

    # "No era una petición, sólo querías saber."
    "Это даже не просьба, вам просто интересно."

# game/script.rpy:5375
translate russian ruta_normal_37_8f49a284:

    # "Y afortunadamente, parece que Jeff no se lo tomó mal."
    "И, к счастью, Джефф не воспринял ваш вопрос в штыки."

# game/script.rpy:5377
translate russian ruta_normal_37_f4c15bb9:

    # J "Podría llegar a un consenso… Sólo en caso de."
    J "Думаю, мы могли бы найти компромисс... на крайний случай."

# game/script.rpy:5379
translate russian ruta_normal_37_4400accd:

    # "No puedes evitar sentir que tu corazón se acelera."
    "Вы чувствуете, как сердце начинает биться быстрее."

# game/script.rpy:5380
translate russian ruta_normal_37_e286b4e9:

    # "De acuerdo, debías admitir que hasta el momento, dudabas que realmente Jeff estuviera enamorado de ti."
    "Признаться, вы и сами до сих пор сомневались в том, что Джефф действительно в вас влюблён."

# game/script.rpy:5381
translate russian ruta_normal_37_a96bc368:

    # "Pero si este tipo demente dice que podría considerar cambiar sólo por ti, era imposible no conmoverte, aunque sea un poco."
    "Но когда этот псих говорит, что готов измениться только ради вас, невозможно хотя бы немного не растрогаться."

# game/script.rpy:5382
translate russian ruta_normal_37_a41ea3e0:

    # pov "Eso es muy dulce, gracias."
    pov "Это очень мило, спасибо."

# game/script.rpy:5383
translate russian ruta_normal_37_fe5b6d5e:

    # "Era mejor estar en su lado bueno de todas maneras."
    "В любом случае, вам же лучше завоевать его доверие."

# game/script.rpy:5384
translate russian ruta_normal_37_d9737b3c:

    # "Quien sabría lo que pasaría si lo tratabas mal o le rompías el corazón."
    "Кто знает, что он может с вами сделать, если обидеть его или разбить ему сердце."

# game/script.rpy:5385
translate russian ruta_normal_37_ae484c0a:

    # "Algo te dice que él es muy rencoroso."
    "Что-то подсказывает вам, что он до ужаса злопамятный."

# game/script.rpy:5387
translate russian ruta_normal_37_a60fb46a:

    # "De repente, se escucha un golpe en la puerta."
    "Вдруг в дверь раздаётся стук."

# game/script.rpy:5391
translate russian ruta_normal_37_3c8eefc4:

    # "Jeff se torna serio y va a la ventana, asomándose levemente."
    "Лицо Джеффа сразу меняется — он становится серьёзным и подходит к окну, осторожно выглядывая наружу."

# game/script.rpy:5392
translate russian ruta_normal_37_19a7a658:

    # J "Es un policía."
    J "Это коп."

# game/script.rpy:5393
translate russian ruta_normal_37_e5508114:

    # pov "¿Se te olvidó pagar la renta?"
    pov "Ты забыл заплатить за аренду?"

# game/script.rpy:5394
translate russian ruta_normal_37_41b29ebc:

    # "Jeff se mordió la punta de los dedos, pensativo."
    "Джефф задумчиво прикусывает кончики пальцев."

# game/script.rpy:5395
translate russian ruta_normal_37_68220c72:

    # J "No pago renta."
    J "Я не плачу за аренду."

# game/script.rpy:5396
translate russian ruta_normal_37_cc6d045d:

    # pov "Ah, eres un ocupa."
    pov "А, так ты сквоттер."

# game/script.rpy:5398
translate russian ruta_normal_37_707998f3:

    # J "Ya- deja de bromear."
    J "Я— Не время для шуток."

# game/script.rpy:5400
translate russian ruta_normal_37_30d54e91:

    # "El llamado a la puerta se torna insistente."
    "Стук в дверь становится настойчивее."

# game/script.rpy:5402
translate russian ruta_normal_37_257bec56:

    # J "Responde tú."
    J "Открой ты."

# game/script.rpy:5403
translate russian ruta_normal_37_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:5404
translate russian ruta_normal_37_708da300:

    # J "Estoy siendo buscado, no pueden verme."
    J "Меня разыскивают. Они не должны меня видеть."

# game/script.rpy:5405
translate russian ruta_normal_37_2d5567bd:

    # J "Tendrás que hablar con él."
    J "Придётся тебе поговорить с ним."

# game/script.rpy:5406
translate russian ruta_normal_37_7d62c96a:

    # pov "Pero yo-"
    pov "Но я—"

# game/script.rpy:5407
translate russian ruta_normal_37_ff89448d:

    # J "Confiaré en ti."
    J "Я доверяю тебе."

# game/script.rpy:5410
translate russian ruta_normal_37_d9c604af:

    # "Sin esperar una respuesta, Jeff desapareció tras adentrarse en la casa."
    "Не дожидаясь ответа, Джефф растворяется в глубине дома."

# game/script.rpy:5411
translate russian ruta_normal_37_d252a13e:

    # "Te removiste en tu lugar con nervios, dirigiéndote a la puerta."
    "Вы нервно переминаетесь с ноги на ногу и направляетесь к двери."

# game/script.rpy:5412
translate russian ruta_normal_37_efe30f99:

    # "Todo va a estar bien, [povname], ya le has mentido a la policía antes. Será pan comido."
    "Всё будет нормально, [povname], вы уже врали полиции. Пустяки."

# game/script.rpy:5414
translate russian ruta_normal_37_7474732d:

    # "Abres la puerta y frente a ti está un policía uniformado."
    "Вы открываете дверь, перед вами стоит полицейский в форме."

# game/script.rpy:5415
translate russian ruta_normal_37_c24ae79f:

    # P "Buenos días, siento molestar tan temprano."
    P "Доброе утро. Простите, что так рано тревожу."

# game/script.rpy:5416
translate russian ruta_normal_37_ee04b04d:

    # pov "No importa…"
    pov "Ничего страшного..."

# game/script.rpy:5417
translate russian ruta_normal_37_88d9f83e:

    # P "Estamos monitoreando la zona, es sólo rutina. ¿Has presenciado actividad inusual últimamente?"
    P "Мы просто патрулируем район, обычная проверка. Не замечали тут ничего подозрительного в последнее время?"

# game/script.rpy:5422
translate russian ruta_normal_37_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5423
translate russian ruta_normal_37_437ca9c0:

    # pov "La verdad… "
    pov "Если честно..."

# game/script.rpy:5424
translate russian ruta_normal_37_13203473:

    # "Bajas el volumen de tu voz."
    "Вы понижаете голос."

# game/script.rpy:5425
translate russian ruta_normal_37_917931b2:

    # pov "Me secuestraron."
    pov "Меня похитили."

# game/script.rpy:5426
translate russian ruta_normal_37_ce801928:

    # pov "Él… está dentro de la casa."
    pov "Он... внутри дома."

# game/script.rpy:5427
translate russian ruta_normal_37_221f4e65:

    # "El policía te miró en silencio por unos segundos, analizando si estabas diciendo la verdad."
    "Полицейский смотрит на вас несколько секунд, пытаясь понять, говорите ли вы правду."

# game/script.rpy:5428
translate russian ruta_normal_37_eb0eea22:

    # "Entonces, él desenfundó su arma y abrió la puerta."
    "Затем вынимает оружие и открывает дверь."

# game/script.rpy:5429
translate russian ruta_normal_37_8fe7dce3:

    # P "Espera aquí."
    P "Ждите здесь."

# game/script.rpy:5430
translate russian ruta_normal_37_aabb9b54:

    # "Él entra sigilosamente, apoyando su hombro contra las superficies a medida que entraba a la casa."
    "Он входит тихо, прислоняется плечом к поверхностям, пока проходит внутрь дома."

# game/script.rpy:5431
translate russian ruta_normal_37_d879d0d6:

    # "Esperaste en la puerta principal, el silencio pesado en el aire."
    "Вы остаётесь ждать у входной двери, в воздухе висит напряжённая тишина."

# game/script.rpy:5433
translate russian ruta_normal_37_0328c4cd:

    # "De repente escuchas el primer disparo."
    "И вдруг — первый выстрел."

# game/script.rpy:5437
translate russian ruta_normal_37_a3959b3c:

    # "Luego el segundo y el tercero."
    "За ним второй и третий."

# game/script.rpy:5439
translate russian ruta_normal_37_1f027b95:

    # "Por la sopresa e incertidumbre, te congelas en tu lugar."
    "От неожиданности и страха вы замираете, не в силах пошевелиться."

# game/script.rpy:5440
translate russian ruta_normal_37_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:5441
translate russian ruta_normal_37_74aee10f:

    # "El alarido de Jeff te hace temblar."
    "Крик Джеффа заставляет вас вздрогнуть."

# game/script.rpy:5444
translate russian ruta_normal_37_7b67c4af:

    # "Él aparece por el pasillo, apoyado contra la pared y con una herida en el costado."
    "Он появляется в конце коридора, держась за стену — из его бока течёт кровь."

# game/script.rpy:5447
translate russian ruta_normal_37_6d1a183c:

    # "Jeff se abalanza hacia ti, aplastandote con su cuerpo."
    "Джефф бросается на вас, наваливаясь всем телом."

# game/script.rpy:5448
translate russian ruta_normal_37_b823f5fb:

    # J "¡Te vas a ir conmigo!"
    J "Ты идёшь со мной!"

# game/script.rpy:5449
translate russian ruta_normal_37_426efe63:

    # "Sonaba molesto, pero más que eso, se veía dolido, seguramente por haberlo delatado."
    "В его голосе звучит злость, но ещё сильнее — боль, очевидно, потому что вы его предали."

# game/script.rpy:5452
translate russian ruta_normal_37_4adc1fb1:

    # "Él sujetó tu cabeza con fuerza, y enterró su pulgar en tu ojo restante."
    "Он хватает вас за голову, вжимая большой палец в оставшийся глаз."

# game/script.rpy:5453
translate russian ruta_normal_37_fad995a0:

    # "Soltaste un alarido de agonía, sintiendo que la punzada de dolor te invadía de la cabeza a los pies."
    "Вы мучительно вопите, чувствуя, как боль пронизывает всё тело."

# game/script.rpy:5454
translate russian ruta_normal_37_77bac699:

    # "Tus brazos se sacudieron contra él, pero eso no evitó nada."
    "Вы колотите его руками, но это ничего не даёт."

# game/script.rpy:5455
translate russian ruta_normal_37_95ab12a1:

    # "Sientes que el dedo de él se entierra más, atravesando tu cuenca."
    "Палец Джеффа проникает глубже, пронзая вашу глазницу."

# game/script.rpy:5456
translate russian ruta_normal_37_238b3be2:

    # "No te queda fuerza para seguir luchando, tu voz se ahoga ante el dolor."
    "Сил бороться больше нет, ваш голос заглушается болью."

# game/script.rpy:5458
translate russian ruta_normal_37_7cac2ea6:

    # "Lo último que escuchas es un último disparo."
    "И последнее, что вы успеваете услышать, — ещё один выстрел."

# game/script.rpy:5462
translate russian ruta_normal_37_246c251f:

    # "{b}Final VI: Lo Traicionaste{/b}"
    "{b}Концовка VI: Вы предали его{/b}"

# game/script.rpy:5467
translate russian ruta_normal_37_8e6d1651:

    # pov "No he visto nada."
    pov "Я ничего не видели."

# game/script.rpy:5468
translate russian ruta_normal_37_5b31f7d1:

    # P "…"
    P "..."

# game/script.rpy:5469
translate russian ruta_normal_37_672edfc0:

    # P "De acuerdo."
    P "Хорошо."

# game/script.rpy:5470
translate russian ruta_normal_37_497fff62:

    # P "Intenta tener cuidado, este barrio es peligroso."
    P "Будьте осторожны, этот район небезопасен."

# game/script.rpy:5471
translate russian ruta_normal_37_613711b3:

    # "Quizás notó que no eres precisamente de ahí."
    "Похоже, он понял, что вы совсем не отсюда."

# game/script.rpy:5472
translate russian ruta_normal_37_66a56d4a:

    # P "Cierra bien todas las ventanas y puertas."
    P "Плотно закройте все окна и двери."

# game/script.rpy:5473
translate russian ruta_normal_37_9336b9bb:

    # "El policía hace un ademán con su gorra."
    "Он поправляет фуражку и слегка кивает."

# game/script.rpy:5474
translate russian ruta_normal_37_fd8a2a77:

    # P "Siento de nuevo la molestia."
    P "Извиняюсь за беспокойство."

# game/script.rpy:5480
translate russian historia_continúa_3_38_65457d11:

    # "Ves que el policía se retira, y cuando no lo ves más, cierras la puerta."
    "Вы смотрите, как полицейский уходит, и, убедившись, что он скрылся из виду, закрываете дверь."

# game/script.rpy:5482
translate russian historia_continúa_3_38_5c3bbe3d:

    # "Suspiras pesadamente, y te giras hacia la dirección en la que se fue Jeff."
    "Вы тяжело вздыхаете и оборачиваетесь в сторону, куда ушёл Джефф."

# game/script.rpy:5483
translate russian historia_continúa_3_38_b83a5758:

    # pov "¿Jeff?, Ya puedes salir."
    pov "Джефф? Можешь выходить."

# game/script.rpy:5484
translate russian historia_continúa_3_38_c51f422f:

    # "No obtienes respuesta, por lo que das unos pasos adelante."
    "Ответа не последовало, поэтому вы делаете пару шагов вперёд."

# game/script.rpy:5487
translate russian historia_continúa_3_38_341255e7:

    # "De la oscuridad, Jeff se acerca a ti corriendo, y te estrecha contra sus brazos."
    "Вдруг из темноты выбегает Джефф, обхватывает вас руками и прижимает к себе."

# game/script.rpy:5488
translate russian historia_continúa_3_38_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:5493
translate russian historia_continúa_3_38_afc59af7:

    # "Él te envuelve en un fuerte abrazo, incluso se inclina a un lado para elevarte del suelo unos centímetros."
    "Он крепко вас обнимает, даже наклоняясь вбок, чтобы приподнять над землёй."

# game/script.rpy:5494
translate russian historia_continúa_3_38_eea060a2:

    # J "¡Eres genial!"
    J "Ты просто чудо!"

# game/script.rpy:5495
translate russian historia_continúa_3_38_0e8d543d:

    # pov "Oh, eh, si, intento serlo."
    pov "О, эм, я стараюсь."

# game/script.rpy:5496
translate russian historia_continúa_3_38_c1787262:

    # "No sabes si tomarte bien los elogios, ya que acabas de romper la ley."
    "Вы не до конца понимаете, как реагировать на похвалу, ведь только что нарушили закон."

# game/script.rpy:5497
translate russian historia_continúa_3_38_f16c345c:

    # J "¡Tuviste la oportunidad de delatarme, pero me encubriste!"
    J "У тебя была возможность сдать меня, а ты меня прикрыли!"

# game/script.rpy:5503
translate russian historia_continúa_3_38_bf8bc422:

    # pov "Sí, sí, estuve ahí."
    pov "Да-да, это были я."

# game/script.rpy:5504
translate russian historia_continúa_3_38_1e39ce0d:

    # J "No me importa que me trates fríamente, ¡Igual te adoro!"
    J "Мне всё равно, если ты холодно со мной обходишься, я всё равно тебя обожаю!"

# game/script.rpy:5505
translate russian historia_continúa_3_38_e5eb9f4f:

    # pov "Yo no estaba- Espera, ¿Qué?"
    pov "Я не— Погоди, что?"

# game/script.rpy:5508
translate russian historia_continúa_3_38_8a340a12:

    # pov "No soy capaz de entregarte."
    pov "Я не могу тебя сдать."

# game/script.rpy:5509
translate russian historia_continúa_3_38_bb01a050:

    # J "¡Te lo compensaré por completo!"
    J "Я отплачу тебе за это сполна!"

# game/script.rpy:5510
translate russian historia_continúa_3_38_7254d0cf:

    # pov "… ¿Cómo, precisamente?"
    pov "...Как именно?"

# game/script.rpy:5511
translate russian historia_continúa_3_38_c6164375:

    # J "Lo que sea."
    J "Я сделаю всё, что угодно."

# game/script.rpy:5517
translate russian ruta_normal_39_036040fe:

    # "Jeff te deposita en el suelo y se distancia de ti, pero sus manos se mantienen sobre ti."
    "Джефф ставит вас на землю и чуть отстраняется, но ладони остаются на ваших плечах."

# game/script.rpy:5518
translate russian ruta_normal_39_02a24a4d:

    # pov "No te tomaba por un arrastrado."
    pov "Не думали, что ты способен унижаться."

# game/script.rpy:5519
translate russian ruta_normal_39_e6d0c30a:

    # J "Lameré tus pies si quieres."
    J "Могу ноги вылизать, если хочешь."

# game/script.rpy:5520
translate russian ruta_normal_39_ba25fb0e:

    # pov "¡Asco!, entiendo la idea, eso no fue necesario."
    pov "Фу! Я поняли, это уже лишнее."

# game/script.rpy:5523
translate russian ruta_normal_39_9382a593:

    # "Jeff ríe entre dientes, subiendo sus manos hacia tu cuello."
    "Джефф усмехается, поднимая руки к вашей шее."

# game/script.rpy:5524
translate russian ruta_normal_39_3eb547ea:

    # "Él ladea la cabeza, mirando con atención las marcas de sus dedos en tu cuello, que se habían estado borrado con el pasar de los días."
    "Он наклоняет голову, рассматривая следы от своих пальцев на вашей шее, уже почти исчезнувшие за прошедшие дни."

# game/script.rpy:5525
translate russian ruta_normal_39_4c695437:

    # "Te abstienes de decir algo, pues sientes que el aire cambia a uno… más íntimo."
    "Вы молчите, чувствуя, как атмосфера вдруг становится... более интимной."

# game/script.rpy:5526
translate russian ruta_normal_39_6ce16d0c:

    # "Tus ojos se encuentran por un instante con los de Jeff, sus pupilas normalmente pequeñas estaban ligeramente dilatadas."
    "Ваш взгляд вдруг встречается с его. Зрачки Джеффа, обычно суженные, теперь немного расширены."

# game/script.rpy:5527
translate russian ruta_normal_39_59480a89:

    # "Él se acerca y agacha la cabeza a la altura de tu cuello."
    "Он склоняется и опускает голову к вашей шее."

# game/script.rpy:5528
translate russian ruta_normal_39_df8e40d0:

    # "Lo único que ves es el cabello negro de él sobre tu frente."
    "Перед глазами лишь его чёрные пряди над вашим лбом."

# game/script.rpy:5532
translate russian ruta_normal_39_037db52c:

    # "Retrocedes levemente, pero él te sujeta firmemente."
    "Вы слегка отстраняетесь, но он крепко держит вас."

# game/script.rpy:5533
translate russian ruta_normal_39_2d00ae3d:

    # "Incluso si no quieres, él lo hará de todas maneras."
    "Он не собирается останавливаться, даже если вы против."

# game/script.rpy:5543
translate russian ruta_normal_40_b20398f7:

    # "Sientes que el primer beso sobre tu cuello te produce un escalofrío, y el segundo lo hace peor."
    "Первый поцелуй в шею вызывает у вас дрожь, а второй — только усиливает её."

# game/script.rpy:5545
translate russian ruta_normal_40_178b3cb8:

    # "Jeff se toma su tiempo, lentamente y con calma, besa tu cuello de un extremo a otro, acariciando la piel de tu garganta con sus labios suavemente."
    "Джефф не торопится: медленно, размеренно проводит губами вдоль вашей шеи, нежно лаская кожу."

# game/script.rpy:5546
translate russian ruta_normal_40_5edde5db:

    # "Aprietas los labios, para no emitir ni un sonido."
    "Вы поджимаете губы, стараясь не издать ни звука."

# game/script.rpy:5547
translate russian ruta_normal_40_00d18571:

    # "Tal vez toda la situación está jugando con tu mente, porque una casa destartalada no te parece el peor lugar para hacer esto."
    "Наверное, всё происходящее уже пошатывает ваш рассудок, потому что этот полуразрушенный дом вдруг не кажется таким уж неподобающим местом для этого."

# game/script.rpy:5553
translate russian ruta_normal_40_b2dadfd9:

    # "Sientes cómo él se separa pausadamente y se inclina sobre tu rostro."
    "Затем он медленно отстраняется, поднимаясь к вашему лицу."

# game/script.rpy:5554
translate russian ruta_normal_40_69677d7d:

    # "Su cabello largo y desordenado impide tu visión, pero por la cercanía, puedes ver los ojos brillantes y el corte de su boca cerca de ti."
    "Его длинные, растрёпанные волосы закрывают вам обзор, но на таком расстоянии вы всё же видите отблеск его глаз и линию губ почти у самой кожи."

# game/script.rpy:5556
translate russian ruta_normal_40_0112d28c:

    # "Ves cómo los ojos de él están fijos en tus labios, por lo que no te sorprendes cuando él finalmente te besa."
    "Его взгляд прикован к вашим губам, так что вы не удивляетесь, когда он наконец наклоняется и целует вас."

# game/script.rpy:5557
translate russian ruta_normal_40_a86c36ea:

    # "El toque era suave, pero podías sentir que los labios estaban secos y fríos."
    "Прикосновение мягкое, но губы у него сухие и холодные."

# game/script.rpy:5558
translate russian ruta_normal_40_676a1e17:

    # "Aún así, no era tan malo."
    "Тем не менее, всё не так уж плохо."

# game/script.rpy:5559
translate russian ruta_normal_40_a393b374:

    # "Las manos de él subieron a tu mandíbula, sujetándote firmemente, como si quisiera evitar darte oportunidad para escapar."
    "Его ладони поднимаются к вашей челюсти, удерживая вас так, словно он не хочет дать вам сбежать."

# game/script.rpy:5560
translate russian ruta_normal_40_45e2eede:

    # "Sentías la posesividad en su toque, pero no era agresivo."
    "В его прикосновении чувствуется некая одержимость, но совсем не агрессивная."

# game/script.rpy:5561
translate russian ruta_normal_40_df6c133c:

    # "Más bien, parecía tener cuidado."
    "Скорее, он кажется осторожным."

# game/script.rpy:5562
translate russian ruta_normal_40_7289ed19:

    # "Tomando valentía, alzas tus manos y envuelves los hombros de él."
    "Набравшись смелости, вы поднимаете руки и обнимаете его за плечи."

# game/script.rpy:5566
translate russian ruta_normal_40_7ec8b15a:

    # "Jeff gime suavemente contra tus labios al sentir que tus dedos se enredan en su cabello, separándose un instante sólo para volver a besarte, necesitado."
    "Джефф тихо стонет вам в губы, когда ваши пальцы запутываются в его волосах, и отстраняется всего на мгновение — только чтобы снова прижаться, с ещё большей жадностью."

# game/script.rpy:5568
translate russian ruta_normal_40_90f1a7e8:

    # "Él baja sus manos a tu cintura y te sujeta firmemente."
    "Его руки скользят вниз и крепко обхватывают вашу талию."

# game/script.rpy:5572
translate russian ruta_normal_40_973a400c:

    # "Sacas la lengua y lames ligeramente el labio inferior de Jeff."
    "Вы чуть высовываете язык и легко касаетесь им нижней губы Джеффа."

# game/script.rpy:5573
translate russian ruta_normal_40_1b7b81fd:

    # "Él suspira y abre los labios, dándote camino."
    "Он выдыхает и приоткрывает губы, впуская вас."

# game/script.rpy:5575
translate russian ruta_normal_40_cfdcb93d:

    # "Profundizas el beso, y sientes que Jeff se derrite contra ti."
    "Вы углубляете поцелуй и чувствуете, как Джефф тает в ваших руках."

# game/script.rpy:5576
translate russian ruta_normal_40_7b230679:

    # "Sus dedos en tu cintura y sus labios contra los tuyos tiemblan."
    "Пальцы на вашей талии дрожат, как и его губы, прижатые к вашим."

# game/script.rpy:5578
translate russian ruta_normal_40_f272ae48:

    # "Acaricias su lengua con la tuya, el toque es suave y tibio, húmedo."
    "Вы ласкаете его язык своим — прикосновение мягкое, тёплое и влажное."

# game/script.rpy:5579
translate russian ruta_normal_40_db91c878:

    # "Sientes que tu respiración se entrelaza con la de él."
    "Вы чувствуете, как ваше дыхание переплетается с его."

# game/script.rpy:5580
translate russian ruta_normal_40_12d03c9d:

    # "Él te acerca más, el roce de sus manos sintiéndose caliente sobre tu cuerpo."
    "Он притягивает вас ближе, ладони тепло скользят по вашему телу."

# game/script.rpy:5581
translate russian ruta_normal_40_df200623:

    # "Hasta que sientes que él sube la mano a tu pecho."
    "Пока вы не почувствовали, как его рука поднимается к вашей груди."

# game/script.rpy:5582
translate russian ruta_normal_40_f6169bee:

    # "No te importaría normalmente, ustedes estaban besándose, no era raro que él se entusiasmara."
    "Обычно вам было бы всё равно — вы целуетесь, неудивительно, что он возбуждается."

# game/script.rpy:5583
translate russian ruta_normal_40_43e01031:

    # "Pero cuando sentiste una punzada en tu muslo, decidiste parar."
    "Но когда вы ощущаете, как что-то упирается в бедро, решаете остановиться."

# game/script.rpy:5584
translate russian ruta_normal_40_e0e32284:

    # "Una casa en ruinas no es el mejor lugar para… eso."
    "Полуразрушенный дом — не самое подходящее место для... этого."

# game/script.rpy:5585
translate russian ruta_normal_40_e34315d1:

    # "Incluso si tu estado de ánimo es cachondo, tienes estándares."
    "Даже если вы уже возбуждены, у вас есть свои границы."

# game/script.rpy:5591
translate russian ruta_normal_40_dab0d790:

    # "Te separas lentamente, tu boca y la de él siendo unidas por un hilo de saliva."
    "Вы медленно отстраняетесь, и между вашими губами тянется тонкая нить слюны."

# game/script.rpy:5592
translate russian ruta_normal_40_5a42d2ae:

    # "Los ojos de él se ven nublados, y su respiración está agitada."
    "Глаза Джеффа затуманены, а дыхание сбивчиво."

# game/script.rpy:5596
translate russian ruta_normal_40_200c202f:

    # "Te separas lentamente, creando distancia entre él y tú."
    "Вы медленно отстраняетесь, оставляя между вами пространство."

# game/script.rpy:5602
translate russian beso_1_07c46601:

    # pov "De acuerdo, suficiente por hoy."
    pov "Ладно, на сегодня хватит."

# game/script.rpy:5604
translate russian beso_1_0f0f68fc:

    # "Jeff deja escapar un quejido lastimero, sin querer soltarte."
    "Джефф издаёт жалобный стон, не желая вас отпускать."

# game/script.rpy:5605
translate russian beso_1_c5fc0cbf:

    # J "¿Qué?, ¿Por qué?"
    J "Что? Почему?"

# game/script.rpy:5606
translate russian beso_1_8caaba43:

    # pov "No pienso llegar más lejos contigo en este lugar."
    pov "Потому что я не собираюсь заходить с тобой дальше в таком месте."

# game/script.rpy:5607
translate russian beso_1_41b532e0:

    # pov "Pueden haber cucarachas, ratas… o tétanos."
    pov "Тут могут быть тараканы, крысы... и столбняк заодно."

# game/script.rpy:5609
translate russian beso_1_a1c478e7:

    # J "Tch, ok."
    J "Тц, ладно."

# game/script.rpy:5612
translate russian beso_1_d1992693:

    # "Jeff te libera de su abrazo, pero se mantiene cerca."
    "Джефф отпускает вас из объятий, но остаётся рядом."

# game/script.rpy:5613
translate russian beso_1_f5156207:

    # J "Quería demostrarte lo agradecido que estoy."
    J "Я просто хотел показать, как сильно тебе благодарен."

# game/script.rpy:5614
translate russian beso_1_fae6f35b:

    # pov "Puedes agradecerme de otra forma."
    pov "Ты можешь выразить это другим способом."

# game/script.rpy:5616
translate russian beso_1_f4cf20c4:

    # "El rostro de Jeff se ilumina."
    "Лицо Джеффа тут же просияло."

# game/script.rpy:5617
translate russian beso_1_35bea974:

    # J "¿Puedo lamer tu-?"
    J "Я могу вылизать твои—?"

# game/script.rpy:5618
translate russian beso_1_cd78d3e4:

    # pov "¡No!, ¡Consígueme ropa!"
    pov "Нет! Принеси мне одежду!"

# game/script.rpy:5619
translate russian beso_1_b8c4f232:

    # J "Oh, cierto."
    J "А, точно."

# game/script.rpy:5620
translate russian beso_1_53fa0ff0:

    # "Niegas con la cabeza, en desaprobación por las ocurrencias de él."
    "Вы покачали головой, осуждая его очередную выходку."

# game/script.rpy:5623
translate russian beso_1_e7392379:

    # "Jeff se dirige a un rincón de la sala y recoge algo."
    "Джефф направляется в угол комнаты и поднимает что-то."

# game/script.rpy:5624
translate russian beso_1_bfe1c5f5:

    # J "Ten, mientras consigo ropa para ti."
    J "Держи, потом раздобуду тебе нормальную одежду."

# game/script.rpy:5625
translate russian beso_1_eaa80d37:

    # "Él te ofrece su sudadera blanca… demasiado blanca."
    "Он протягивает вам свою белую толстовку... слишком белую."

# game/script.rpy:5626
translate russian beso_1_b9a546e9:

    # pov "¿Cómo haces para mantenerla tan limpia si te la pasas matando?"
    pov "Как ты вообще умудряешься держать её в такой чистоте, если постоянно кого-то убиваешь?"

# game/script.rpy:5627
translate russian beso_1_825602ef:

    # pov "¿No debería mancharse con la sangre?"
    pov "Разве она не должна быть в крови?"

# game/script.rpy:5628
translate russian beso_1_45e58b3a:

    # "Si resulta que también tiene la habilidad sobrehumana de no mancharse, esta historia se va a catalogar como fantasía."
    "Если окажется, что у него ещё и сверхъестественная способность не пачкаться, то эту историю точно придётся отнести к жанру фэнтези."

# game/script.rpy:5629
translate russian beso_1_a602bf7c:

    # J "Tengo varias de esas."
    J "У меня их несколько."

# game/script.rpy:5630
translate russian beso_1_4e19b462:

    # J "No soy estúpido, sé que no puedo andar con la misma sudadera ensangrentada a todas partes."
    J "Я же не идиот — понимаю, что не могу ходить везде в одной и той же окровавленной толстовке."

# game/script.rpy:5631
translate russian beso_1_3690b86f:

    # pov "¿Pero porqué blancas?"
    pov "Но почему именно белые?"

# game/script.rpy:5632
translate russian beso_1_29e8c837:

    # pov "¿No sería mejor ropa roja, o negra?"
    pov "Разве не логичнее было бы носить красное или чёрное?"

# game/script.rpy:5633
translate russian beso_1_627a29af:

    # J "Tengo una marca."
    J "У меня стиль такой."

# game/script.rpy:5634
translate russian beso_1_f28b1970:

    # pov "¿Una marca?"
    pov "Стиль?"

# game/script.rpy:5636
translate russian beso_1_9983d8d0:

    # J "Claro, ¿Cómo la gente va a saber que se trata de mi si uso ropa diferente?"
    J "Конечно. Как люди узнают, что это я, если я буду ходить в разной одежде?"

# game/script.rpy:5637
translate russian beso_1_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5638
translate russian beso_1_13af4a5f:

    # pov "Dejemos el tema, que me va a dar una embolia."
    pov "Ладно, сменим тему, а то у меня сейчас инсульт случится."

# game/script.rpy:5640
translate russian beso_1_e3e59d8a:

    # J "Haha, eres adorable."
    J "Ха-ха, ты просто прелесть."

# game/script.rpy:5642
translate russian beso_1_5c19e81b:

    # "Te pones la sudadera encima de tu ropa de pijama, y es una fortuna que no te queda ajustada."
    "Вы надеваете толстовку поверх пижамы — к счастью, она не сидит слишком плотно."

# game/script.rpy:5643
translate russian beso_1_43df32cf:

    # "Jeff se ve delgado, pero sus hombros y pecho son más anchos de lo que parecen."
    "Джефф выглядит худым, но при этом его плечи и грудь оказываются шире, чем вы думали."

# game/script.rpy:5644
translate russian beso_1_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5645
translate russian beso_1_29f9a752:

    # J "¿Te gusta lo que ves?"
    J "Нравится?"

# game/script.rpy:5646
translate russian beso_1_ae25903e:

    # "Ah, te quedaste mirándolo fijamente por un momento."
    "А, вы засмотрелись на него."

# game/script.rpy:5650
translate russian beso_1_c0662a5c:

    # pov "Claro."
    pov "Конечно."

# game/script.rpy:5651
translate russian beso_1_63ac03c2:

    # pov "Un tipo con la cara quemada y la boca cortada es sexy."
    pov "Парень с обожжённым лицом и разрезанным ртом — это же чертовски сексуально."

# game/script.rpy:5653
translate russian beso_1_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5654
translate russian beso_1_d7be0c77:

    # J "Incluso si lo dices para burlarte, no me afecta."
    J "Даже если ты шутишь, мне всё равно."

# game/script.rpy:5655
translate russian beso_1_777d1ae6:

    # J "Me gusta cómo me veo."
    J "Мне нравится, как я выгляжу."

# game/script.rpy:5656
translate russian beso_1_db145382:

    # pov "Un hombre con confianza, eso si es atractivo."
    pov "Уверенный в себе мужчина — уже действительно привлекательно."

# game/script.rpy:5658
translate russian beso_1_90bba925:

    # "Jeff se queda en silencio, pero alcanzas a ver que sus mejillas se sonrojan."
    "Джефф молчит, но вы замечаете, как его щёки краснеют."

# game/script.rpy:5661
translate russian beso_1_7e856319:

    # pov "Nah, no realmente."
    pov "Не, не очень."

# game/script.rpy:5663
translate russian beso_1_4b1b161b:

    # J "¡¿Qué?!, ¡¿Por qué no?!"
    J "Что?! Почему?!"

# game/script.rpy:5664
translate russian beso_1_ce640427:

    # pov "Eres muy flacucho para mi gusto."
    pov "Ты для моего вкуса слишком тощий."

# game/script.rpy:5665
translate russian beso_1_d669e20d:

    # J "¡¿Acaso te gustan más musculosos?!"
    J "Так тебе нравятся более мускулистые?!"

# game/script.rpy:5666
translate russian beso_1_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:5667
translate russian beso_1_098527da:

    # J "¿O más rellenos?"
    J "Или полные?"

# game/script.rpy:5668
translate russian beso_1_f3f60a7a:

    # pov "Ok, creo que deberíamos dejarlo hasta ahí."
    pov "Ладно, думаю, на этом стоит закончить."

# game/script.rpy:5677
translate russian character_10_6344afd2:

    # "El saca una sudadera idéntica a la que ya tienes y se cubre el rostro con la bandana y la capucha."
    "Он достаёт толстовку, точно такую же, как на вас, и натягивает на лицо повязку с капюшоном."

# game/script.rpy:5678
translate russian character_10_5d7f1047:

    # pov "¿Vamos a una tienda?"
    pov "Мы идём в магазин?"

# game/script.rpy:5679
translate russian character_10_b96bbdb9:

    # J "Mejor."
    J "Лучше."

# game/script.rpy:5680
translate russian character_10_12d288fb:

    # pov "¿Un mall?"
    pov "В торговый центр?"

# game/script.rpy:5681
translate russian character_10_61a252d8:

    # "Estabas jodiendo, sabías que ustedes no podían salir así como así."
    "Вы, конечно, шутите — вы знаете, что не можете выйти в таком виде."

# game/script.rpy:5682
translate russian character_10_22c7271a:

    # J "Un tipo que recolecta objetos tiene mucha ropa. Va a dar lo que sea por un poco de brandy."
    J "Один тип собирает всякий хлам, у него куча одежды. Отдаст всё за немного бренди."

# game/script.rpy:5683
translate russian character_10_f60c587f:

    # pov "Asco."
    pov "Фу."

# game/script.rpy:5684
translate russian character_10_71bfccc6:

    # J "Relájate, la vamos a lavar… no sé, 5 veces, para que estés en paz."
    J "Спокойно, постираем... не знаю, раз пять, чтобы ты успокоились."

# game/script.rpy:5685
translate russian character_10_8f3e2754:

    # "Que estilo de vida tan precario…"
    "Какой нестабильный образ жизни..."

# game/script.rpy:5686
translate russian character_10_2f117fe5:

    # "¿Qué esperabas de un criminal?"
    "Хотя, чего ещё ждать от преступника?"

# game/script.rpy:5704
translate russian character_10_bdb51e48:

    # "Como lo prometió, Jeff lavó varias veces toda la ropa que se consiguió con un alcohólico de la calle."
    "Как и обещал, Джефф несколько раз постирал всю одежду, которую достал у того уличного пьяницы."

# game/script.rpy:5705
translate russian character_10_fa33ab5f:

    # "Así que ahora contabas con una camiseta, una sudadera propia, pantalones de chándal y zapatillas, que a pesar de ser de tu talla, eran de diferente par."
    "Теперь у вас есть футболка, собственная толстовка, спортивные штаны и кроссовки — хоть и подходящего размера, но из разных пар."

# game/script.rpy:5706
translate russian character_10_902c7dbd:

    # "¿Quién pensaría que irías en picada en una trama de romance-terror?"
    "Кто бы мог подумать, что в романтическом хорроре вам придётся так опуститься."

# game/script.rpy:5707
translate russian character_10_6460e6b1:

    # "Pero al menos, pasar el tiempo con Jeff se volvió algo ameno."
    "Ну, по крайней мере, проводить время с Джеффом стало на удивление приятно."

# game/script.rpy:5708
translate russian character_10_6528e4cc:

    # "Ustedes se la pasaban hablando, reflexionando sobre cosas, aprendiendo uno del otro."
    "Вы много разговаривали, делились мыслями, узнавали друг друга получше."

# game/script.rpy:5709
translate russian character_10_dada0de3:

    # "Incluso se quedaron dormidos mientras hablaban."
    "Вы даже умудрились заснуть посреди разговора."

# game/script.rpy:5714
translate russian character_10_2eea4d95:

    # "Así que no fue raro que él sea lo primero que ves apenas despiertas."
    "Так что неудивительно, что, проснувшись, первым делом вы увидели именно его."

# game/script.rpy:5715
translate russian character_10_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5716
translate russian character_10_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5717
translate russian character_10_41c1c0a1:

    # pov "¿Hace cuánto que me estás mirando?"
    pov "И давно ты на меня смотришь?"

# game/script.rpy:5718
translate russian character_10_f39beda9:

    # J "Desde que desperté."
    J "С самого пробуждения."

# game/script.rpy:5719
translate russian character_10_ba49a443:

    # "Lo miras expectante."
    "Вы испытующе смотрите на него."

# game/script.rpy:5720
translate russian character_10_b72bea62:

    # J "Hace 5 horas."
    J "5 часов."

# game/script.rpy:5721
translate russian character_10_a065aa59:

    # "Ok, esto se estaba saliendo de control."
    "Ну, это уже выходит за рамки разумного."

# game/script.rpy:5722
translate russian character_10_1fa594a8:

    # "No esperabas llamar la atención de un asesino que se volvería en tu acosador de un día para otro."
    "Вы никак не ожидали, что сумеете так привлечь внимание убийцы, который всего за ночь превратился в навязчивого сталкера."

# game/script.rpy:5723
translate russian character_10_ca7cbd8b:

    # "De hecho, eso te abrumaba."
    "В самом деле, это сбивало с толку."

# game/script.rpy:5724
translate russian character_10_6d80ef65:

    # pov "… ¿De verdad te tomó una semana amarme?"
    pov "...Тебе серьёзно понадобилась всего неделя, чтобы влюбиться в меня?"

# game/script.rpy:5725
translate russian character_10_9f01fa29:

    # J "¿Es tan difícil de creer?"
    J "Разве в это так трудно поверить?"

# game/script.rpy:5726
translate russian character_10_beca56bf:

    # J "No sé mucho de romance, pero eres la primera persona que me produce esto."
    J "Я не особо разбираюсь в романтике, но ты первый человек, который вызывает у меня такие чувства."

# game/script.rpy:5727
translate russian character_10_d2372116:

    # J "Quiero estar a tu lado siempre, odio a cualquiera que se te acerque, no soporto la idea que alguien más te haga daño-"
    J "Я хочу быть рядом всегда. Терпеть не могу, когда кто-то к тебе приближается. И не выношу мысли, что кто-то другой может причинить тебе боль—"

# game/script.rpy:5728
translate russian character_10_baa18d07:

    # pov "¿Sigues queriendo hacerme daño, Jeff?"
    pov "А ты ещё хочешь причинять мне боль, Джефф?"

# game/script.rpy:5729
translate russian character_10_1aca37bc:

    # "La sonrisa de Jeff se tensa ante tus palabras, y el aire se vuelve pesado."
    "Улыбка Джеффа замирает от ваших слов, и атмосфера кажется напряжённой."

# game/script.rpy:5730
translate russian character_10_f1736163:

    # "Esa era una pregunta que necesitaba ser respondida."
    "Вам нужно знать ответ на этот вопрос."

# game/script.rpy:5731
translate russian character_10_028d857c:

    # "La idea de estar con Jeff y que él quiera dañarte… Te da mal sabor de boca."
    "Одна только мысль о том, чтобы быть с Джеффом, пока он ещё хочет вас ранить... оставляет неприятный осадок."

# game/script.rpy:5732
translate russian character_10_abf71705:

    # J "Ahora que estamos bien, no tengo porqué."
    J "Теперь у нас всё хорошо, так что и причин на это у меня нет."

# game/script.rpy:5733
translate russian character_10_a226aabc:

    # "¿Eso quería decir que si estuvieran mal, te lastimaría?"
    "Значит, если бы что-то пошло не так, он бы снова навредил вам?"

# game/script.rpy:5734
translate russian character_10_3088a824:

    # "Jeff alza una mano a tu mejilla y la acaricia con la punta de sus dedos, recorriendo con sus ojos cada rincón de tu rostro."
    "Джефф поднимает руку и мягко касается вашей щеки кончиками пальцев, взглядом тщательно изучая каждую черту вашего лица."

# game/script.rpy:5735
translate russian character_10_d618ad07:

    # pov "¿Y qué hay de lo que le hiciste a mi ojo?"
    pov "А как же то, что ты сделал с моим глазом?"

# game/script.rpy:5736
translate russian character_10_6d1c8e3f:

    # "Jeff se ríe entre dientes, y sientes frustración al sentir que no te toma en serio."
    "Джефф усмехается, и вас берёт досада от того, что он не воспринимает вас всерьёз."

# game/script.rpy:5737
translate russian character_10_8bde55a3:

    # J "¿De qué serviría una disculpa cuando el daño ya está hecho?"
    J "Что толку извиняться, когда уже ничего не изменить?"

# game/script.rpy:5738
translate russian character_10_5387222b:

    # "Eso… Tenía cierta lógica, pero eso no significaba que no sientas rencor."
    "В его словах... пожалуй, есть доля правды, но это совсем не значит, что вы не держите на него обиды."

# game/script.rpy:5740
translate russian character_10_307c466b:

    # "Él deslizó sus dedos por debajo de los elásticos del parche, tirando sutilmente hasta desengancharlo de tu cabeza."
    "Он скользит пальцами под резинку повязки и осторожно тянет, снимая её с вашей головы."

# game/script.rpy:5741
translate russian character_10_1fdb99cc:

    # "Te habías quitado el parche adhesivo y la gasa, por lo que cuando él retiró tu parche, dejó al descubierto tu cuenca vacía."
    "Вы уже сняли клейкий пластырь и марлю, так что, когда он убирает повязку, он обнажает вашу пустую глазницу."

# game/script.rpy:5742
translate russian character_10_731cb36d:

    # J "Además, creo que te ves mejor así."
    J "К тому же, по-моему, ты так даже лучше выглядишь."

# game/script.rpy:5743
translate russian character_10_3a57111d:

    # "No sabías si sentir que te elogia o que te está manipulando."
    "Вы не знаете, считать ли это комплиментом или манипуляцией."

# game/script.rpy:5744
translate russian character_10_994eb0d2:

    # "De cualquier forma, su toque era suave y delicado, rozando con la yema de sus dedos la zona alrededor de tu párpado izquierdo."
    "Его прикосновения всё такие же мягкие и бережные, кончиками пальцев он обводит область вокруг вашего левого века."

# game/script.rpy:5745
translate russian character_10_935dcc7e:

    # J "Es uno de mis mejores trabajos."
    J "Одно из моих лучших творений."

# game/script.rpy:5746
translate russian character_10_4133970e:

    # "Sus palabras te producen un escalofrío."
    "От этих слов по позвоночнику пробегает озноб."

# game/script.rpy:5747
translate russian character_10_af75e5a6:

    # "Sientes que tu mente está confusa."
    "Вы в замешательстве."

# game/script.rpy:5748
translate russian character_10_2ebc5031:

    # "No sabes lo que está bien o que está mal a este punto."
    "Вы уже не можете понять, что правильно, а что нет."

# game/script.rpy:5754
translate russian character_10_93dc128a:

    # pov "¿Estoy… perdiendo la cabeza, Jeff?"
    pov "Я... схожу с ума, Джефф?"

# game/script.rpy:5755
translate russian character_10_58c83c7b:

    # "Jeff sonríe afectuosamente, acariciando con su pulgar tu labio inferior."
    "Джефф ласково улыбается, поглаживая большим пальцем вашу нижнюю губу."

# game/script.rpy:5756
translate russian character_10_6a0a4c54:

    # J "¿Qué mejor que enloquecer juntos, [povname]?"
    J "Что может быть лучше, чем свихнуться вместе, [povname]?"

# game/script.rpy:5759
translate russian character_10_b1714a5a:

    # "Él no tiene por qué saberlo."
    "Ему необязательно это знать."

# game/script.rpy:5760
translate russian character_10_b77db6f7:

    # "Puede que alimente más la locura de él."
    "Это только подстегнёт его безумие."

# game/script.rpy:5765
translate russian ruta_normal_41_028ab570:

    # "Te mantienes en silencio, bajo la mirada fija de Jeff."
    "Вы молчите под пристальным взглядом Джеффа."

# game/script.rpy:5766
translate russian ruta_normal_41_afac89f3:

    # "Te estabas acostumbrando a que él se la pase observándote y que no parpadee."
    "Вы постепенно привыкаете к тому, как он постоянно наблюдает за вами и не моргает."

# game/script.rpy:5767
translate russian ruta_normal_41_6f0b4b98:

    # "De hecho, te preguntas si siquiera tiene párpados."
    "Иногда вам даже кажется, что у него вовсе нет век."

# game/script.rpy:5773
translate russian ruta_normal_41_7f0db406:

    # pov "De casualidad… ¿Tienes insomnio?"
    pov "У тебя, случайно... нет бессонницы?"

# game/script.rpy:5774
translate russian ruta_normal_41_43ea234c:

    # "Jeff parece contentarse con tu pregunta."
    "Джефф, похоже, доволен вашим вопросом."

# game/script.rpy:5775
translate russian ruta_normal_41_a2c2926c:

    # J "¿Lo notaste?"
    J "Заметили?"

# game/script.rpy:5778
translate russian ruta_normal_41_6756b687:

    # pov "¿Qué onda con tus ojos?"
    pov "Что у тебя с глазами?"

# game/script.rpy:5779
translate russian ruta_normal_41_1434765a:

    # J "¿Qué hay con ellos?"
    J "А что с ними?"

# game/script.rpy:5780
translate russian ruta_normal_41_be82e546:

    # pov "Eso negro alrededor."
    pov "Вот это чёрное вокруг них."

# game/script.rpy:5781
translate russian ruta_normal_41_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5786
translate russian ruta_normal_42_24a44f96:

    # J "Hace años que tengo insomnio."
    J "Я уже много лет страдаю бессонницей."

# game/script.rpy:5787
translate russian ruta_normal_42_0bf95f64:

    # J "Por lo que se me formaron estas ojeras."
    J "Вот и появились эти круги под глазами."

# game/script.rpy:5788
translate russian ruta_normal_42_724afac0:

    # pov "… Oh."
    pov "...Ох."

# game/script.rpy:5789
translate russian ruta_normal_42_95352187:

    # pov "Entonces, ¿Tienes párpados?"
    pov "Значит, веки всё-таки есть?"

# game/script.rpy:5790
translate russian ruta_normal_42_af96c346:

    # "Jeff resopla, sarcástico."
    "Джефф саркастически фыркает."

# game/script.rpy:5791
translate russian ruta_normal_42_cf8545b5:

    # J "¿Por qué todos piensan que no tengo párpados?"
    J "Почему все думают, что у меня нет век?"

# game/script.rpy:5792
translate russian ruta_normal_42_4ebe7c36:

    # pov "Bueno, por mi parte es porque nunca te he visto parpadear."
    pov "Ну, лично я просто ни разу не видели, чтобы ты моргал."

# game/script.rpy:5793
translate russian ruta_normal_42_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5797
translate russian ruta_normal_42_c410a1d0:

    # J "¿Feliz?"
    J "Довольны?"

# game/script.rpy:5798
translate russian ruta_normal_42_e2a98fa8:

    # pov "Sip, definitivamente ya no tengo dudas."
    pov "Ага, теперь никаких сомнений."

# game/script.rpy:5799
translate russian ruta_normal_42_ab28d806:

    # "Claro, verlo parpadear lo hacía parecer más… normal."
    "Видеть, как он моргает, делает его в ваших глазах чуть более... нормальным."

# game/script.rpy:5800
translate russian ruta_normal_42_0aca7133:

    # pov "Mírate, tan obediente."
    pov "Посмотри на себя, какой послушный."

# game/script.rpy:5801
translate russian ruta_normal_42_889681aa:

    # pov "Pensé que te gustaba dar órdenes más que recibirlas."
    pov "Я-то думали, что тебе больше нравится отдавать приказы, а не выполнять их."

# game/script.rpy:5802
translate russian ruta_normal_42_68aea31a:

    # J "No tengo preferencia."
    J "Я непривередливый."

# game/script.rpy:5803
translate russian ruta_normal_42_ef3e2083:

    # J "Sé lo que quiero, y hago lo que sea por conseguirlo."
    J "Я просто знаю, чего хочу, и сделаю всё, чтобы этого добиться."

# game/script.rpy:5804
translate russian ruta_normal_42_f681bef1:

    # J "Pero estoy dispuesto a recibir lo que me des."
    J "Но я буду рад принять всё, что ты дашь."

# game/script.rpy:5810
translate russian ruta_normal_42_9e27ebdf:

    # pov "¿Estamos hablando de otra cosa?"
    pov "Мы говорим о чём-то другом?"

# game/script.rpy:5812
translate russian ruta_normal_42_26ca1c02:

    # "Las mejillas de Jeff se encienden, y su mirada baja."
    "Щёки Джеффа заливаются румянцем, взгляд опускается вниз."

# game/script.rpy:5813
translate russian ruta_normal_42_bf708034:

    # J "Tómalo como quieras."
    J "Понимай как хочешь."

# game/script.rpy:5817
translate russian ruta_normal_42_82ad5714:

    # pov "¿Si te digo que ladres como perro, lo harás?"
    pov "А если я скажу тебе погавкать, ты послушаешься?"

# game/script.rpy:5818
translate russian ruta_normal_42_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5819
translate russian ruta_normal_42_bf79647c:

    # J "Hay límites."
    J "Есть границы."

# game/script.rpy:5824
translate russian ruta_normal_43_e4b00b8e:

    # "Te ríes entre dientes ante la respuesta de él, y al menos Jeff parece satisfecho con tu reacción."
    "Вы тихо смеётесь над его ответом, и, кажется, Джефф вполне доволен вашей реакцией."

# game/script.rpy:5825
translate russian ruta_normal_43_5ffc6a70:

    # "Alzas tu mano y recorres con suavidad el brazo izquierdo de él, acariciando las marcas y cicatrices a través de la tela."
    "Вы поднимаете руку и мягко проводите по его левой руке, поглаживая рубцы и шрамы через ткань."

# game/script.rpy:5826
translate russian ruta_normal_43_c5681539:

    # pov "¿Qué te sucedió?"
    pov "Что с тобой случилось?"

# game/script.rpy:5827
translate russian ruta_normal_43_aeac4663:

    # "Jeff suspira despreocupado."
    "Джефф беззаботно вздыхает."

# game/script.rpy:5828
translate russian ruta_normal_43_3ac3b774:

    # J "Una mezcla de ocasiones. Algunas son quemaduras por el fuego y ácido, otras son cortes por peleas."
    J "Да всякое. Где-то ожоги от огня и кислоты, где-то порезы от драк."

# game/script.rpy:5829
translate russian ruta_normal_43_35f3e6e7:

    # pov "¿Peleas?, Jeff, no te tomé como uno de esos."
    pov "Драк? Джефф, я не думали, что ты из таких."

# game/script.rpy:5830
translate russian ruta_normal_43_483bfc5e:

    # J "¿Qué esperabas que hiciera?, ¿Dejarme apuñalar?, No gracias."
    J "А что, по-твоему, я должен был делать? Подставляться под нож? Нет уж, спасибо."

# game/script.rpy:5831
translate russian ruta_normal_43_a6b59414:

    # pov "¿Y con quién pelearías tú?"
    pov "И с кем же ты дрался?"

# game/script.rpy:5832
translate russian ruta_normal_43_14360a18:

    # J "…"
    J "..."

# game/script.rpy:5833
translate russian ruta_normal_43_6c4c91a4:

    # J "Muchos enemigos."
    J "У меня много врагов."

# game/script.rpy:5834
translate russian ruta_normal_43_3a63e933:

    # pov "¿Así que has dejado con vida a aún más personas?"
    pov "Значит, ты всё-таки оставил в живых больше людей?"

# game/script.rpy:5835
translate russian ruta_normal_43_0a4069b3:

    # J "Solo te dejé a ti y la chica que mencioné antes."
    J "Нет, только тебя и ту девушку, о которой рассказывал."

# game/script.rpy:5836
translate russian ruta_normal_43_797998e1:

    # J "Los demás lograron escapar o simplemente buscan venganza."
    J "Остальные либо сбежали, либо теперь жаждут мести."

# game/script.rpy:5837
translate russian ruta_normal_43_8f3a4ba3:

    # pov "Vaya, eres todo un chico malo."
    pov "Ого, ты прямо настоящий плохой парень."

# game/script.rpy:5838
translate russian ruta_normal_43_64bcdad3:

    # "Jeff se ríe levemente, su voz es vibrante."
    "Джефф тихо смеётся, его голос звучит бодро."

# game/script.rpy:5839
translate russian ruta_normal_43_292040c6:

    # "Que bueno que se lo tome con humor."
    "Хорошо, что он отнёсся к этому с юмором."

# game/script.rpy:5840
translate russian ruta_normal_43_62c0c923:

    # "Ya que técnicamente, él es todo lo que está mal en el mundo."
    "Ведь, по сути, он воплощение всего неправильного в этом мире."

# game/script.rpy:5841
translate russian ruta_normal_43_34f5eeda:

    # J "Hey, [povname]."
    J "Эй, [povname]."

# game/script.rpy:5842
translate russian ruta_normal_43_d44ab9be:

    # pov "¿Sí?"
    pov "Да?"

# game/script.rpy:5843
translate russian ruta_normal_43_5daf6a2f:

    # J "¿Te gusto?"
    J "Я тебе нравлюсь?"

# game/script.rpy:5844
translate russian ruta_normal_43_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:5845
translate russian ruta_normal_43_30259b8b:

    # pov "Jeff, no me ando besando con cualquiera."
    pov "Джефф, я не целуюсь с кем попало."

# game/script.rpy:5846
translate russian ruta_normal_43_88a8bea5:

    # "Él suspira, aliviado."
    "Он облегчённо выдыхает."

# game/script.rpy:5847
translate russian ruta_normal_43_c02cbc0c:

    # "Jeff hace círculos con su dedo sobre las sábanas, mientras formaba un puchero."
    "Джефф выводит пальцем круги на простыни, надув губы."

# game/script.rpy:5848
translate russian ruta_normal_43_602ff6f0:

    # J "¿Te seguiría gustando si fuera un gusano?"
    J "Ты бы любили меня, если бы я был червём?"

# game/script.rpy:5849
translate russian ruta_normal_43_bedd6fae_1:

    # pov "…"
    pov "..."

# game/script.rpy:5850
translate russian ruta_normal_43_1c6f43bf:

    # "Vaya, parece que él es el tipo de alto mantenimiento."
    "Вау, видимо, он из тех, кто нуждается в повышенном внимании."

# game/script.rpy:5856
translate russian ruta_normal_43_1ec485bf:

    # pov "Por supuesto, adoro los gusanos."
    pov "Разумеется, я обожаю червей."

# game/script.rpy:5857
translate russian ruta_normal_43_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:5858
translate russian ruta_normal_43_8adc974b:

    # J "No-"
    J "Мне—"

# game/script.rpy:5859
translate russian ruta_normal_43_3632f87e:

    # pov "No aprecias mi sarcasmo, lo sé."
    pov "Тебе не нравится мой сарказм, знаю."

# game/script.rpy:5860
translate russian ruta_normal_43_ef35999a:

    # pov "Nunca lo haces, y aún así me amas."
    pov "Он тебе никогда не нравится, но ты всё равно меня любишь."

# game/script.rpy:5863
translate russian ruta_normal_43_9cdd4d20:

    # pov "Ew."
    pov "Фу."

# game/script.rpy:5864
translate russian ruta_normal_43_c37db486:

    # J " … Oh."
    J "...Ох."

# game/script.rpy:5865
translate russian ruta_normal_43_69e5f06c:

    # pov "Me gustas porque eres humano, no me aprovecharé de un gusano."
    pov "Ты мне нравишься, потому что ты человек. Я не собираюсь издеваться над червём."

# game/script.rpy:5866
translate russian ruta_normal_43_2c03d4d3:

    # J "… No era literal."
    J "...Это же не буквально."

# game/script.rpy:5867
translate russian ruta_normal_43_cbde89b1:

    # pov "¿Qué dices?"
    pov "Что?"

# game/script.rpy:5868
translate russian ruta_normal_43_033a96fb:

    # J "Nada."
    J "Ничего."

# game/script.rpy:5873
translate russian ruta_normal_44_440481b4:

    # "Jeff se endereza de la cama y estira la espalda. Él suelta un quejido satisfecho, y se pone de pie."
    "Джефф выпрямляется на кровати и потягивается, издаёт довольный звук и поднимается на ноги."

# game/script.rpy:5874
translate russian ruta_normal_44_425d692c:

    # J "Voy a bañarme."
    J "Пойду приму душ."

# game/script.rpy:5879
translate russian ruta_normal_44_a141d50b:

    # "Una de las cosas buenas de esa casa, es que tenía agua, aunque de manera algo ilegal."
    "Одно из немногих достоинств этого дома — наличие воды, пусть и добытой не совсем законным способом."

# game/script.rpy:5880
translate russian ruta_normal_44_6a143d0d:

    # "Jeff mencionó algo sobre bypass al contador."
    "Джефф говорил что-то про обход счётчиков."

# game/script.rpy:5881
translate russian ruta_normal_44_8596bc29:

    # "Con que ustedes tuvieran agua, te bastaba."
    "Вам этого вполне достаточно — главное, что вода вообще есть."

# game/script.rpy:5887
translate russian ruta_normal_44_22416464:

    # pov "Voy contigo."
    pov "Я с тобой."

# game/script.rpy:5889
translate russian ruta_normal_44_21bc3e19:

    # "Te pones de pie también, pero pronto unas manos sobre tus hombros te detienen."
    "Вы тоже поднимаетесь, но его руки на ваших плечах тут же вас останавливают."

# game/script.rpy:5891
translate russian ruta_normal_44_a3989ea4:

    # J "Si vas conmigo, será un infierno para mí."
    J "Если пойдёшь со мной — для меня это будет чистый ад."

# game/script.rpy:5892
translate russian ruta_normal_44_5d1b697d:

    # pov "Pero pensé-"
    pov "Но я подума—"

# game/script.rpy:5893
translate russian ruta_normal_44_673097c7:

    # J "¡Un infierno!"
    J "Ад!"

# game/script.rpy:5894
translate russian ruta_normal_44_1f741ba3:

    # pov "¡Ok, geez!"
    pov "Ладно, ладно!"

# game/script.rpy:5895
translate russian ruta_normal_44_ee6bcdc0:

    # "Él te suelta, y notas cómo sus manos tiemblan levemente y su respiración está agitada."
    "Он отпускает вас, и вы замечаете, как его руки слегка дрожат, а дыхание учащается."

# game/script.rpy:5896
translate russian ruta_normal_44_8a5959e9:

    # "Ah, esa clase de infierno."
    "А, такой ад."

# game/script.rpy:5903
translate russian ruta_normal_45_7540a646:

    # "Te quedas donde estás, en la habitación."
    "Вы остаётесь на месте, в той же комнате."

# game/script.rpy:5905
translate russian ruta_normal_45_4257e3ed:

    # "Jeff te da una última mirada antes de salir."
    "Джефф бросает на вас последний взгляд, прежде чем выйти."

# game/script.rpy:5906
translate russian ruta_normal_45_d0edd404:

    # "Miras el alrededor, buscando alguna forma de detenerte."
    "Вы оглядываетесь, ища хоть какое-то занятие, чтобы отвлечься."

# game/script.rpy:5907
translate russian ruta_normal_45_b7bf9cfa:

    # "No tenías tu teléfono contigo, y la casa no tenía wifi."
    "Телефона при себе нет, как и Wi-Fi в доме."

# game/script.rpy:5908
translate russian ruta_normal_45_f3330be2:

    # "Con suerte tenía luz."
    "К счастью, есть хотя бы электричество."

# game/script.rpy:5909
translate russian ruta_normal_45_41fb8839:

    # "Así que decides recorrer el lugar."
    "Так что вы решаете осмотреть это место."

# game/script.rpy:5920
translate russian habitacion_j_58816021:

    # "Paseas por el lugar, evitando los escombros."
    "Вы бродите по дому, обходя обломки."

# game/script.rpy:5921
translate russian habitacion_j_a246a1c8:

    # "No hay nada además de la cama."
    "В комнате, кроме кровати, ничего нет."

# game/script.rpy:5926
translate russian sala_j_4038f2d9:

    # "Vas a la sala, e inspeccionas los muebles."
    "Вы проходите в гостиную и осматриваете мебель."

# game/script.rpy:5927
translate russian sala_j_495b13e4:

    # "El sofá es duro, y el cable de la TV está rota."
    "Диван жёсткий, а провод от телевизора оборван."

# game/script.rpy:5928
translate russian sala_j_a44dcc50:

    # "No tienes mucho qué hacer aquí."
    "Здесь нечего делать."

# game/script.rpy:5934
translate russian cocina_j_76985f8a:

    # "Revisas el minirefri."
    "Вы открываете мини-холодильник."

# game/script.rpy:5935
translate russian cocina_j_f8143131:

    # "Hay muchas bebidas energéticas."
    "Внутри много энергетиков."

# game/script.rpy:5936
translate russian cocina_j_ce617998:

    # "…"
    "..."

# game/script.rpy:5937
translate russian cocina_j_4caf3340:

    # "Eso explica el insomnio."
    "Это объясняет его бессонницу."

# game/script.rpy:5942
translate russian baño_j_df58c92c:

    # "Te quedas junto a la puerta, escuchando el sonido de la ducha."
    "Вы останавливаетесь у двери, прислушиваясь к звуку воды в душе."

# game/script.rpy:5943
translate russian baño_j_696ae31a:

    # "Hay un leve tarareo del otro lado de la puerta."
    "С другой стороны двери доносится тихое напевание."

# game/script.rpy:5944
translate russian baño_j_00ef1359:

    # "Sólo tienes tu imaginación contigo, por lo que te resignas."
    "У вас остаётся только собственное воображение, поэтому вы решаете смириться."

# game/script.rpy:5950
translate russian sotano_7e6b1a6d:

    # "Hay una puerta de la que no sabes a dónde va."
    "Есть ещё одна дверь. Вы не знаете, куда она ведёт."

# game/script.rpy:5951
translate russian sotano_3861cc6a:

    # "Considerando que esta es una casa prácticamente abandonada, algo te decía que entrar no sería lindo."
    "Судя по тому, что дом наполовину заброшен, что-то подсказывает вам, что за ней не будет ничего приятного."

# game/script.rpy:5952
translate russian sotano_db2822eb:

    # "Pero la curiosidad era más grande."
    "Но любопытство оказывается сильнее."

# game/script.rpy:5954
translate russian sotano_63b3e76e:

    # "Abres la puerta y el crujido retumba entre las paredes."
    "Вы открываете дверь, и протяжный скрип разносится эхом по стенам."

# game/script.rpy:5956
translate russian sotano_35fcbe5c:

    # "Está oscuro, pero por suerte hay un interruptor al costado, por lo que lo apretas y el lugar se alumbra."
    "Внутри темно. К счастью, рядом есть выключатель — вы нажимаете на него, и помещение заливается светом."

# game/script.rpy:5959
translate russian sotano_62aa1bfe:

    # "Frente a ti, se extienden hacia abajo unas escaleras."
    "Перед вами простирается лестница, ведущая вниз."

# game/script.rpy:5960
translate russian sotano_7b5feef2:

    # "Por supuesto, no faltaba el sótano escalofriante."
    "Конечно же, не обошлось и без жуткого подвала."

# game/script.rpy:5961
translate russian sotano_0a62672d:

    # "Tenías la fortuna que Jeff no era de esos que encadenaba en el sótano a prueba de ruido."
    "Вам повезло, что Джефф не из тех, кто держит людей прикованными в звукоизолированном подвале."

# game/script.rpy:5962
translate russian sotano_ce617998:

    # "…"
    "..."

# game/script.rpy:5963
translate russian sotano_736116c3:

    # "Por ahora."
    "Пока что."

# game/script.rpy:5964
translate russian sotano_860c1880:

    # "Bajas en silencio, apoyándote en el barandal ante los escalones desgastados."
    "Вы осторожно спускаетесь по изношенным ступенькам, держась за перила."

# game/script.rpy:5965
translate russian sotano_9b19232d:

    # "El silencio abunda en el lugar, tus pasos resuenan en el cemento."
    "Тишина окутывает помещение, и каждый ваш шаг отдаётся эхом по бетонному полу."

# game/script.rpy:5967
translate russian sotano_3365f661:

    # "La luz también se encendió abajo, por lo que puedes ver con claridad el lugar."
    "Свет внизу тоже зажёгся, поэтому вы отчётливо всё видите."

# game/script.rpy:5968
translate russian sotano_db32a922:

    # "Es espacioso y frío."
    "Тут просторно и холодно."

# game/script.rpy:5969
translate russian sotano_2e22a5b3:

    # "Las paredes son de piedra y hay algunas tuberías descubiertas, lo que explica el olor a humedad."
    "Каменные стены и оголённые трубы тут же объясняют стойкий запах сырости."

# game/script.rpy:5970
translate russian sotano_359dd3ad:

    # "Pero hay otro olor en el aire."
    "Но в воздухе есть и другой запах."

# game/script.rpy:5971
translate russian sotano_9864e2e8:

    # "No lo reconoces al inicio, pero te diriges a un rincón donde hay un mueble destartalado."
    "Сначала вы не можете его распознать, но подходите ближе к углу, где стоит потрёпанная мебель."

# game/script.rpy:5972
translate russian sotano_70afdb12:

    # "Te asomas para ver mejor."
    "Вы наклоняетесь, чтобы рассмотреть получше."

# game/script.rpy:5984
translate russian sotano_0ce5cfbc:

    # pov "¡Mierda!"
    pov "Блять!"

# game/script.rpy:5985
translate russian sotano_58ea36d8:

    # "Retrocedes con horror, presenciando un cadáver."
    "Вы в ужасе отшатываетесь назад — перед вами труп."

# game/script.rpy:5986
translate russian sotano_42034897:

    # "Con valentía, lo miras a una distancia prudente, porque la escena es demasiado horrible como para verlo de cerca."
    "Собравшись с духом, вы разглядываете его издали, ибо приблизиться к этому невозможно."

# game/script.rpy:5987
translate russian sotano_95baf862:

    # "Reconoces por el cabello corto y el tamaño que es un hombre, pero su rostro es totalmente irreconocible. Está hinchado y con la piel verdosa."
    "По коротким волосам и телосложению ясно, что это мужчина, но лицо совершенно неузнаваемо — опухшее, с зеленоватой кожей."

# game/script.rpy:5988
translate russian sotano_13c6a55c:

    # "Notas el polvo blanco que tiene encima, y no te cuesta entender que se trata de cal."
    "На теле виден слой белесого порошка. Вы без труда понимаете, что это известь."

# game/script.rpy:5989
translate russian sotano_41ec417b:

    # "Si no fuera por la cal, hubieras notado el olor desde el principio."
    "Если бы не она, запах вы бы почувствовали сразу."

# game/script.rpy:5990
translate russian sotano_314d278e:

    # "Sientes que la bilis sube por tu garganta, pero tapas la boca como reflejo para evitarlo."
    "Тошнота подступает к горлу, но вы рефлекторно прикрываете рот рукой, сдерживая рвотный позыв."

# game/script.rpy:5991
translate russian sotano_89464ceb:

    # "Te alejas de la escena para tomar aire."
    "Вы отступаете от ужасной сцены, стараясь перевести дыхание."

# game/script.rpy:5992
translate russian sotano_67c38527:

    # "¿Qué mierda?"
    "Какого чёрта?"

# game/script.rpy:5993
translate russian sotano_a22c5403:

    # "Jeff… ¿Hizo eso?"
    "Джефф... Это он сделал?"

# game/script.rpy:5994
translate russian sotano_5da50264:

    # "Sería lo ideal que él no tuviera nada que ver, pero siendo realistas, lo más probable es que fuera Jeff."
    "Хочется верить, что нет. Но если быть реалистом, всё указывает именно на него."

# game/script.rpy:5995
translate russian sotano_d5463930:

    # "Ese… ¿Era el dueño original de la casa?"
    "Это... прежний хозяин дома?"

# game/script.rpy:5996
translate russian sotano_4404d30b:

    # "Jeff había admitido que consigue dinero en sus asesinatos, por lo que no sería raro que hiciera lo mismo con el alojamiento."
    "Джефф ведь сам признавался, что грабит своих жертв — неудивительно, если жильё досталось ему таким же образом."

# game/script.rpy:5997
translate russian sotano_2d25bcb7:

    # "Él escogió ese barrio peligroso a propósito, porque si la policía aparecía, estarían más ocupados en otras actividades sospechosas típicas del lugar."
    "Он намеренно выбрал этот опасный район. Здесь полиция занята другими, более обычными для такого места преступлениями."

# game/script.rpy:5998
translate russian sotano_9dff71b8:

    # "Era un claro escondite a plena vista."
    "Идеальное укрытие у всех на виду."

# game/script.rpy:5999
translate russian sotano_7e1bd2c8:

    # "¿Pero qué hay con el tema de que Jeff mató al dueño de la casa y lo puso en el sótano?"
    "Но эта мысль не даёт покоя: Джефф убил хозяина дома и спрятал тело в подвале?"

# game/script.rpy:6000
translate russian sotano_b83cb598:

    # "Era horrible, lo miraras donde lo miraras."
    "Как ни посмотри, это чудовищно."

# game/script.rpy:6001
translate russian sotano_2721fb1a:

    # "Jeff mató a mucha gente, entre ellos… gente inocente."
    "Джефф убивал многих, в том числе и... невинных людей."

# game/script.rpy:6002
translate russian sotano_c5a7acb6:

    # "Nunca viste un ápice de remordimiento de su parte y tú…"
    "Вы ни разу не видели в нём даже намёка на раскаяние, и вы..."

# game/script.rpy:6003
translate russian sotano_b1d6c981:

    # "Te volviste su cómplice."
    "Вы стали его сообщником."

# game/script.rpy:6004
translate russian sotano_bccf3662:

    # "Sabías que no eras responsable por las acciones de Jeff."
    "Вы знаете, что не несёте ответственности за поступки Джеффа."

# game/script.rpy:6005
translate russian sotano_77078515:

    # "Pero si tú no las cuestionabas, ¿No eras igual de horrible que él?"
    "Но если вы не ставите их под сомнение, разве это не делает вас такими же ужасными, как он?"

# game/script.rpy:6006
translate russian sotano_eff37787:

    # "Deberías sentir un rechazo absoluto hacia alguien así."
    "Вы должны чувствовать абсолютное отвращение к такому человеку."

# game/script.rpy:6007
translate russian sotano_beb3fc98:

    # "Deberías ser incapaz de charlar amenamente con alguién así."
    "Вы должны быть неспособны мило беседовать с таким человеком."

# game/script.rpy:6008
translate russian sotano_6c1e2681:

    # "Pero… "
    "Но..."

# game/script.rpy:6010
translate russian sotano_d7cb26f8:

    # "¿Por qué… No puedes odiarlo?"
    "Почему... вы не можете его ненавидеть?"

# game/script.rpy:6015
translate russian sotano_36c65282:

    # "No puede ser…"
    "Не может быть..."

# game/script.rpy:6016
translate russian sotano_86fb24a7:

    # "De verdad caíste tan bajo como para enamorarte de un asesino despiadado."
    "Вы действительно пали так низко, что влюбились в безжалостного убийцу."

# game/script.rpy:6017
translate russian sotano_42675485:

    # "Habías perdido realmente la cabeza."
    "Вы и правда сошли с ума."

# game/script.rpy:6021
translate russian sotano_5e953f46:

    # "Él… Es algo así como un amigo."
    "Он... Он вам как друг."

# game/script.rpy:6022
translate russian sotano_4b0f2cd4:

    # "Si, ustedes se besaron, pero fue sólo eso."
    "Да, вы целовались, но не более."

# game/script.rpy:6023
translate russian sotano_87b79c32:

    # "No tenías fuertes sentimientos por él."
    "Никаких сильных чувств вы к нему не испытываете."

# game/script.rpy:6029
translate russian charcater_11_01ffbca1:

    # "De cualquier forma, no podías quedarte en el sótano."
    "В любом случае, оставаться в подвале нельзя."

# game/script.rpy:6030
translate russian charcater_11_05428cbd:

    # "Seguramente Jeff se pregunte dónde estás si no te ve, y quizás se moleste por tu descubrimiento."
    "Если Джефф заметит ваше исчезновение, то начнёт искать, и вряд ли будет рад вашему открытию."

# game/script.rpy:6032
translate russian charcater_11_8a4ecddf:

    # "Subes las escaleras con rapidez, pero conservando precaución ante el deterioro de los escalones."
    "Вы быстро поднимаетесь по лестнице, стараясь осторожно ступать по изношенным ступенькам."

# game/script.rpy:6034
translate russian charcater_11_cbd2d027:

    # "Llegas al pasillo en el momento en que Jeff sale del baño."
    "Как раз в тот момент, когда вы добираетесь до коридора, из ванной выходит Джефф."

# game/script.rpy:6037
translate russian charcater_11_0b7eb8c2:

    # "Su cabello sigue húmedo, por lo que se lo seca con una toalla."
    "Волосы у него ещё влажные, поэтому он сушит их полотенцем."

# game/script.rpy:6038
translate russian charcater_11_e09a5cff:

    # J "Ahí estabas, te estaba buscando."
    J "Вот ты где, я тебя искал."

# game/script.rpy:6039
translate russian charcater_11_12033b61:

    # pov "Seh…"
    pov "Ага..."

# game/script.rpy:6040
translate russian charcater_11_53014a86:

    # "Él frota un extremo de la toalla contra su cabeza y su cabello largo se sacude."
    "Он трёт одним концом полотенца голову и встряхивает длинные волосы."

# game/script.rpy:6041
translate russian charcater_11_ea6bfa3e:

    # J "¿Ya te aburriste de mí?"
    J "Я тебе ещё не надоел?"

# game/script.rpy:6042
translate russian charcater_11_a5d1560d:

    # "La sonrisa de él es divertida, acentuando su sarcasmo."
    "Он шутливо улыбается, подчёркивая сарказм."

# game/script.rpy:6048
translate russian charcater_11_af350310:

    # pov "Nunca me aburriría de ti, Jeff."
    pov "Ты мне никогда не надоешь, Джефф."

# game/script.rpy:6050
translate russian charcater_11_34fd9c69:

    # "No lo dices precisamente por sus aspectos buenos."
    "Вы говорите это не из-за его положительных качеств."

# game/script.rpy:6051
translate russian charcater_11_0ce2a2a3:

    # "Que son muy pocos, o inexistentes."
    "Которых очень мало или нет вовсе."

# game/script.rpy:6052
translate russian charcater_11_07925450:

    # "Pero al menos Jeff parece feliz con tu respuesta."
    "Зато Джефф, похоже, доволен услышанным."

# game/script.rpy:6055
translate russian charcater_11_243ed617:

    # pov "Bueno, tenía que entretenerme de alguna forma."
    pov "Ну, надо же было чем-то себя занять."

# game/script.rpy:6057
translate russian charcater_11_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6058
translate russian charcater_11_adeba0fa:

    # "Jeff te mira atentamente, como si quisiera comprenderte."
    "Джефф пристально смотрит на вас, будто пытается понять."

# game/script.rpy:6065
translate russian ruta_normal_46_d78b7533:

    # "Él siguió frotándose el cabello mojado, que no parecía estar cerca de estar seco."
    "Он продолжает вытирать мокрые волосы, хотя они всё равно остаются влажными."

# game/script.rpy:6066
translate russian ruta_normal_46_a4d452f7:

    # pov "… ¿Es muy optimista pensar que podría haber una secadora de pelo aquí?"
    pov "Слишком оптимистично будет надеяться, что в этом доме найдётся фен?"

# game/script.rpy:6068
translate russian ruta_normal_46_bff58889:

    # "Jeff te mira con sarcasmo."
    "Джефф иронично смотрит на вас."

# game/script.rpy:6069
translate russian ruta_normal_46_de9e1b01:

    # J "¿En este chiquero?, Obvio que no."
    J "В этой помойке? Конечно, нет."

# game/script.rpy:6070
translate russian ruta_normal_46_ed4ac059:

    # pov "Entonces déjamelo a mí."
    pov "Тогда давай я."

# game/script.rpy:6072
translate russian ruta_normal_46_061546f2:

    # "Extiendes tus manos hacia él, apuntando la toalla."
    "Вы протягиваете к нему руки, указывая на полотенце."

# game/script.rpy:6073
translate russian ruta_normal_46_542cf12a:

    # "Él te miró en silencio por unos segundos, interrogativo."
    "Он молча смотрит на вас несколько секунд, будто не понимает."

# game/script.rpy:6075
translate russian ruta_normal_46_72f05f46:

    # "Pero después pareció entender y su expresión se iluminó."
    "Но вскоре до него доходит, и его лицо озаряется."

# game/script.rpy:6076
translate russian ruta_normal_46_183a85f4:

    # J "¡Por supuesto!"
    J "Конечно!"

# game/script.rpy:6081
translate russian ruta_normal_46_da0e6ee7:

    # "Jeff te extiende la toalla y se apresura a tomar asiento en la sala, mirándote expectante."
    "Джефф протягивает вам полотенце и тут же усаживается в гостиной, глядя на вас с нетерпением."

# game/script.rpy:6082
translate russian ruta_normal_46_b0f294cf:

    # "Te acercas y te colocas detrás de él. Él se gira, para darte la espalda."
    "Вы подходите и становитесь у него за спиной. Он разворачивается, предоставляя вам доступ."

# game/script.rpy:6083
translate russian ruta_normal_46_6c431272:

    # "El cabello de él se extiende frente a ti, brillante y lacio."
    "Его волосы мягко рассыпаются перед вами, блестящие и прямые."

# game/script.rpy:6084
translate russian ruta_normal_46_d0cbc585:

    # "Empiezas a frotar las puntas suavemente, algunas veces apretando la toalla para quitar el exceso de agua."
    "Вы начинаете осторожно промакивать кончики, изредка сжимая полотенце, чтобы впитать лишнюю влагу."

# game/script.rpy:6085
translate russian ruta_normal_46_1fb1acb5:

    # pov "Tienes el pelo muy liso."
    pov "У тебя очень прямые волосы."

# game/script.rpy:6087
translate russian ruta_normal_46_4bf5080e:

    # J "Antes lo tenía un poco ondulado, pero desde el accidente, quedó así."
    J "Раньше они были немного волнистыми, но после того случая такими и остались."

# game/script.rpy:6088
translate russian ruta_normal_46_8c51242e:

    # "Ah, claro. No tenías en claro cómo fue exactamente lo que pasó, pero te haces una idea general."
    "А, точно. Вы не до конца понимаете, что именно тогда произошло, но общее представление есть."

# game/script.rpy:6090
translate russian ruta_normal_46_f93a9143:

    # J "También era castaño."
    J "И они были каштановыми."

# game/script.rpy:6091
translate russian ruta_normal_46_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6092
translate russian ruta_normal_46_92856fbf:

    # pov "¿Tienes fotos?"
    pov "У тебя есть фотографии?"

# game/script.rpy:6094
translate russian ruta_normal_46_fa027063:

    # "Jeff resopla divertido."
    "Джефф весело фыркает."

# game/script.rpy:6095
translate russian ruta_normal_46_5c81b105:

    # J "¿De esa época?, Para nada."
    J "С тех времён? Нет."

# game/script.rpy:6096
translate russian ruta_normal_46_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6097
translate russian ruta_normal_46_4f0096fb:

    # J "Quizás en mi vieja cuenta de tumblr."
    J "Ну, может, на моём старом аккаунте в Tumblr."

# game/script.rpy:6098
translate russian ruta_normal_46_e8d55127:

    # pov "Eres tan emo."
    pov "Точно эмо."

# game/script.rpy:6100
translate russian ruta_normal_46_c14a5cfa:

    # J "¡No lo-!, ugh."
    J "Я не—! Эх."

# game/script.rpy:6101
translate russian ruta_normal_46_b7bb16b9:

    # "Te ríes ante la protesta de Jeff."
    "Вы смеётесь над возмущением Джеффа."

# game/script.rpy:6104
translate russian ruta_normal_46_facdf4d3:

    # "Él alza la cabeza, y te mira desde su lugar."
    "Он поднимает голову и смотрит на вас со своего места."

# game/script.rpy:6105
translate russian ruta_normal_46_dfdffcd7:

    # "Su mirada, comúnmente ida, te mira con suavidad. Una humanidad que ves por primera vez en él. "
    "Хотя взгляд у него обычно отстранённый, сейчас он смотрит на вас с нежностью. Вы впервые видите в нём человечность."

# game/script.rpy:6106
translate russian ruta_normal_46_ae795372:

    # "Continuas frotando su cabello, esta vez en la parte superior de su cabeza."
    "Вы продолжаете вытирать его волосы, на этот раз на макушке."

# game/script.rpy:6107
translate russian ruta_normal_46_d51b83de:

    # J "De todas formas, me veo mejor ahora."
    J "В любом случае сейчас я выгляжу лучше."

# game/script.rpy:6108
translate russian ruta_normal_46_9b0f8d89:

    # pov "¿En serio?"
    pov "Правда?"

# game/script.rpy:6109
translate russian ruta_normal_46_651fab21:

    # J "Si, en ese entonces era muy soso. Me comparaban mucho con mi hermano, decían que nos parecíamos mucho."
    J "Да, тогда я был совсем никакой. Меня постоянно сравнивали с братом, говорили, что мы очень похожи."

# game/script.rpy:6110
translate russian ruta_normal_46_b579d4e6:

    # pov "Tiene sentido, si son hermanos."
    pov "Логично, вы же братья."

# game/script.rpy:6111
translate russian ruta_normal_46_19e74d20:

    # pov "… ¿Ustedes eran cercanos?"
    pov "...Вы были близки?"

# game/script.rpy:6112
translate russian ruta_normal_46_679d76c4:

    # J "Si, lo éramos."
    J "Да, были."

# game/script.rpy:6114
translate russian ruta_normal_46_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6116
translate russian ruta_normal_46_6f73e40b:

    # J "La verdad, es que ni siquiera sé si está vivo."
    J "Вообще, я даже не знаю, жив ли он."

# game/script.rpy:6117
translate russian ruta_normal_46_c584c7ef:

    # pov "¿Pensé que tu familia estaba muerta?"
    pov "Я думали, твоя семья погибла?"

# game/script.rpy:6118
translate russian ruta_normal_46_c3c2e2da:

    # J "Mis padres lo están, estoy seguro de eso."
    J "Родители — да, в этом я уверен."

# game/script.rpy:6119
translate russian ruta_normal_46_ca0c1a54:

    # J "Pero de Liu… No tanto."
    J "А вот насчёт Лью... не совсем."

# game/script.rpy:6120
translate russian ruta_normal_46_f9e4d6ea:

    # pov "¿Cómo lo sabes?"
    pov "Откуда ты знаешь?"

# game/script.rpy:6122
translate russian ruta_normal_46_46cbb9c8:

    # J "Es… complicado."
    J "Это... сложно объяснить."

# game/script.rpy:6123
translate russian ruta_normal_46_b2668f41:

    # pov "Entiendo, ¿Es otra de tus aventuras?"
    pov "Понятно, ещё одно из твоих приключений?"

# game/script.rpy:6124
translate russian ruta_normal_46_5b2d8bf1:

    # J "Se podría decir."
    J "Можно и так сказать."

# game/script.rpy:6125
translate russian ruta_normal_46_ed8953f8:

    # pov "Hay tanto sobre ti que me está costando seguir el hilo."
    pov "В тебе столько всего, что я уже путаюсь."

# game/script.rpy:6127
translate russian ruta_normal_46_3f1e8453:

    # "Jeff ríe entre dientes."
    "Джефф усмехается."

# game/script.rpy:6128
translate russian ruta_normal_46_3a1294f8:

    # J "No es necesario que sepas cada detalle de mí."
    J "Не обязательно знать обо мне каждую мелочь."

# game/script.rpy:6129
translate russian ruta_normal_46_54cc20a1:

    # J "Mejor enfócate en disfrutarme."
    J "Лучше просто наслаждайся мной."

# game/script.rpy:6131
translate russian ruta_normal_46_a360b242:

    # "Él se endereza y se gira para enfrentarte."
    "Он выпрямляется и поворачивается к вам лицом."

# game/script.rpy:6132
translate russian ruta_normal_46_9f060a3f:

    # J "¿Qué parte de mí te gusta más?"
    J "Какая часть меня тебе нравится больше всего?"

# game/script.rpy:6137
translate russian ruta_normal_46_e890d35d:

    # J "¿Mis ojos?"
    J "Мои глаза?"

# game/script.rpy:6138
translate russian ruta_normal_46_02fce65a:

    # J "Sí que sabes halagar."
    J "Ты точно умеешь льстить."

# game/script.rpy:6142
translate russian ruta_normal_46_3212c2bc:

    # J "¿De verdad te gusta?"
    J "Тебе правда нравится?"

# game/script.rpy:6144
translate russian ruta_normal_46_7feba57b:

    # J "¡Eso me hace tan feliz!"
    J "Это меня очень радует!"

# game/script.rpy:6148
translate russian ruta_normal_46_14360a18_2:

    # J "…"
    J "..."

# game/script.rpy:6149
translate russian ruta_normal_46_65e31fd2:

    # J "Ten cuidado, [povname]."
    J "Осторожнее, [povname]."

# game/script.rpy:6153
translate russian ruta_normal_46_c487c8bb:

    # J "¡Yo no tengo-!"
    J "Да нет у меня—!"

# game/script.rpy:6154
translate russian ruta_normal_46_008e23e3:

    # "Él se lleva una mano a la cabeza, sintiendo la parte que no tiene cabello."
    "Он подносит руку к голове, ощупывая область без волос."

# game/script.rpy:6156
translate russian ruta_normal_46_3cbd7e72:

    # J "Eso no es calva."
    J "Это не залысина."

# game/script.rpy:6157
translate russian ruta_normal_46_06bd3670:

    # pov "De acuerdo, entradas."
    pov "Ладно, пробор."

# game/script.rpy:6158
translate russian ruta_normal_46_3865c1f7:

    # J "¡Tampoco!; ¡Es parte de mis cicatrices!"
    J "И не он! Это часть моих шрамов!"

# game/script.rpy:6159
translate russian ruta_normal_46_6f714354:

    # "Jeff refunfuña, con un puchero."
    "Джефф ворчит, надув губы."

# game/script.rpy:6165
translate russian favorito_d77317d6:

    # pov "Eres alguien muy vanidoso, ¿No?"
    pov "Ты такой тщеславный, правда?"

# game/script.rpy:6166
translate russian favorito_5156b7fa:

    # "Jeff se encoge de hombros."
    "Джефф пожимает плечами."

# game/script.rpy:6170
translate russian favorito_38c599db:

    # "Rodeas la cabeza de él con la toalla, y tiras suavemente, haciendo que él se incline levemente hacia ti."
    "Вы оборачиваете полотенце вокруг его головы и аккуратно тянете, заставляя его чуть наклониться к вам."

# game/script.rpy:6172
translate russian favorito_1fc7ba55:

    # "Lo miras en silencio, y ves que causa una reacción en él."
    "Вы молча смотрите на него, и это вызывает в нём отклик."

# game/script.rpy:6173
translate russian favorito_a1f63eb0:

    # "Sus mejillas se encienden y él desvía la mirada brevemente con timidez."
    "Щёки его вспыхивают, и он робко отводит взгляд."

# game/script.rpy:6174
translate russian favorito_2089e5d2:

    # "Él… realmente está rendido a ti."
    "Он... и правда влюблён в вас."

# game/script.rpy:6175
translate russian favorito_14e691a5:

    # "Puedes… casi confiar en él."
    "Вы почти... можете доверять ему."

# game/script.rpy:6180
translate russian favorito_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6181
translate russian favorito_11ca74aa:

    # J "Así que te diste cuenta."
    J "Так ты заметили."

# game/script.rpy:6182
translate russian favorito_0eb4316e:

    # J "Ya te lo dije, no tienes que actuar con tanta cautela conmigo."
    J "Я же говорил, не надо со мной так осторожничать."

# game/script.rpy:6188
translate russian favorito_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6189
translate russian favorito_119fc079:

    # J "¿Bajaste?"
    J "Ты ходили в подвал?"

# game/script.rpy:6190
translate russian favorito_28750f70:

    # "No sabes si suena molesto o no."
    "Вы не можете понять, звучит ли он раздражённо."

# game/script.rpy:6191
translate russian favorito_7f51411b:

    # "Pero su tono se había endurecido, lo que te traía malos recuerdos de tus encuentros anteriores con él."
    "Но его тон становится жёстче, что вызывает неприятные воспоминания о ваших прошлых встречах."

# game/script.rpy:6197
translate russian ruta_normal_47_29313ebd:

    # pov "Así que lo mataste."
    pov "Значит, ты его убил."

# game/script.rpy:6198
translate russian ruta_normal_47_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6199
translate russian ruta_normal_47_cf879ae8:

    # J "¿Realmente te extraña?"
    J "Это для тебя новость?"

# game/script.rpy:6200
translate russian ruta_normal_47_b2363fb5:

    # pov "No me extraña… Es sólo que…"
    pov "Нет... просто..."

# game/script.rpy:6201
translate russian ruta_normal_47_0cf214ce:

    # pov "Me sorprendió, eso es todo."
    pov "Это было неожиданно, вот и всё."

# game/script.rpy:6202
translate russian ruta_normal_47_5bbf4168:

    # "Jeff te mira en silencio, pensativo."
    "Джефф молча смотрит на вас, задумавшись."

# game/script.rpy:6203
translate russian ruta_normal_47_ae6b2b34:

    # "Su expresión, comúnmente sonriente y maníaca, es extrañamente calma."
    "Его лицо, обычно озарённое безумной улыбкой, сейчас необычно спокойно."

# game/script.rpy:6204
translate russian ruta_normal_47_cf4891b9:

    # "De hecho, él daba un poco más de miedo cuando era serio."
    "На самом деле он пугает ещё больше, когда серьёзен."

# game/script.rpy:6205
translate russian ruta_normal_47_dc1280b1:

    # pov "Jeff… ¿Has pensado realmente en la situación?"
    pov "Джефф... Ты правда хорошо подумал?"

# game/script.rpy:6206
translate russian ruta_normal_47_13024660:

    # J "¿De qué hablas?"
    J "Ты о чём?"

# game/script.rpy:6207
translate russian ruta_normal_47_ea180864:

    # pov "Hablo de esto."
    pov "Об этом."

# game/script.rpy:6208
translate russian ruta_normal_47_fdd3f91f:

    # "Señalas todo el lugar, las paredes rotas, el suelo lleno de escombros y polvo, los muebles rotos. Ustedes."
    "Вы обводите рукой всё вокруг: разбитые стены, пол, заваленный обломками и пылью, сломанную мебель. Вас двоих."

# game/script.rpy:6209
translate russian ruta_normal_47_5283e120:

    # pov "También lo de ayer, con el policía."
    pov "И вчерашнее с полицейским тоже."

# game/script.rpy:6210
translate russian ruta_normal_47_dd52a775:

    # pov "Si me quedo contigo, ¿Vamos a vivir así?"
    pov "Если я останусь с тобой, мы так и будем жить?"

# game/script.rpy:6213
translate russian ruta_normal_47_495ced28:

    # "Los ojos de Jeff se inyectan en sangre, y su boca forma una mueca."
    "Глаза Джеффа наливаются кровью, а рот искривляется."

# game/script.rpy:6215
translate russian ruta_normal_47_1edee679:

    # "Antes de que te des cuenta, él atrapa tus mejillas entre sus dedos y aprieta, atrayéndote hacia él bruscamente."
    "Вы и опомниться не успеваете, как он хватает ваши щёки пальцами и сжимает, резко притягивая к себе."

# game/script.rpy:6216
translate russian ruta_normal_47_e5c9fde9:

    # "… Duele."
    "...Больно."

# game/script.rpy:6217
translate russian ruta_normal_47_6c587242:

    # J "No hay ninguna condicional en esto, no hay ningún “Si”. Vas a estar conmigo, y punto."
    J "Никаких условий, никаких «если». Ты будешь со мной. И точка."

# game/script.rpy:6218
translate russian ruta_normal_47_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6219
translate russian ruta_normal_47_9dbd1192:

    # "Jeff entierra sus uñas en tu piel, lo que te hace sisear."
    "Джефф впивается ногтями в вашу кожу, заставляя зашипеть."

# game/script.rpy:6220
translate russian ruta_normal_47_6c6e2e87:

    # "Él realmente seguía siendo el mismo."
    "Он и правда не изменился."

# game/script.rpy:6221
translate russian ruta_normal_47_f4bd6119:

    # J "¿Debería arrancarte el otro ojo para que entiendas?"
    J "Вырвать тебе второй глаз, чтобы дошло?"

# game/script.rpy:6225
translate russian ruta_normal_47_9d83cecf:

    # pov "T-tienes razón."
    pov "Т-ты прав."

# game/script.rpy:6226
translate russian ruta_normal_47_beaff3f6:

    # pov "Me equivoqué."
    pov "Я не так выразились."

# game/script.rpy:6227
translate russian ruta_normal_47_75fab125:

    # pov "Sólo quería saber cómo viviríamos, eso es todo."
    pov "Просто хотели понять, как мы будем жить, и всё."

# game/script.rpy:6232
translate russian ruta_normal_47_5df5ec0e:

    # pov "No pretendía nada con lo que dije, sólo quería visualizar nuestra vida juntos."
    pov "Я ничего такого не имели в виду, просто хотели представить нашу совместную жизнь."

# game/script.rpy:6237
translate russian ruta_normal_48_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6241
translate russian ruta_normal_48_00faa907:

    # "Jeff te suelta y guarda distancia."
    "Джефф отпускает вас и отстраняется."

# game/script.rpy:6242
translate russian ruta_normal_48_4a6d70db:

    # "Sientes que vuelves a respirar y que tu corazón se calma."
    "Вы снова дышите свободно, а сердце постепенно успокаивается."

# game/script.rpy:6243
translate russian ruta_normal_48_751bb5f6:

    # J "Vamos a tener que movernos constantemente, para evitar a la policía."
    J "Придётся постоянно перемещаться, чтобы избегать полиции."

# game/script.rpy:6244
translate russian ruta_normal_48_aecf51ec:

    # J "Supongo que podría mejorar los lugares en los que nos quedemos."
    J "Думаю, я могу улучшать места, где мы останавливаемся."

# game/script.rpy:6245
translate russian ruta_normal_48_c8536b52:

    # "Él se llevó un dedo a la barbilla, pensativamente."
    "Он задумчиво подносит палец к подбородку."

# game/script.rpy:6246
translate russian ruta_normal_48_2b8ecbb7:

    # J "Quizás intercalar entre casas y hoteles."
    J "Может, чередовать дома и отели."

# game/script.rpy:6247
translate russian ruta_normal_48_8d6b3a05:

    # J "Pero no te puedo prometer lujos."
    J "Но роскоши обещать не могу."

# game/script.rpy:6249
translate russian ruta_normal_48_cca6d967:

    # pov "Entiendo completamente."
    pov "Понимаю."

# game/script.rpy:6252
translate russian ruta_normal_48_8f1697b2:

    # "Jeff sonríe satisfecho con tu respuesta, levantándose del sofá."
    "Джефф удовлетворённо улыбается вашему ответу и поднимается с дивана."

# game/script.rpy:6254
translate russian ruta_normal_48_20dfd0e2:

    # J "¿Qué te parece desayunar?"
    J "Хочешь позавтракать?"

# game/script.rpy:6255
translate russian ruta_normal_48_6a4f327d:

    # pov "Seguro, ¿Pero qué?"
    pov "Конечно, а что?"

# game/script.rpy:6257
translate russian ruta_normal_48_f7deeb09:

    # J "Conseguí algo de avena y fruta para ti."
    J "Я купил тебе овсянку и фрукты."

# game/script.rpy:6259
translate russian ruta_normal_48_9ca74f67:

    # J "Conseguí unos huevos. Ya cocí algunos."
    J "Я купил яйца. Некоторые уже приготовил."

# game/script.rpy:6260
translate russian ruta_normal_48_7a29add9:

    # pov "Ah, gracias. ¿Vas a comer conmigo?"
    pov "А, спасибо. Будешь есть со мной?"

# game/script.rpy:6262
translate russian ruta_normal_48_c7de1e5a:

    # "Jeff ríe entre dientes, rodeando tus hombros con su brazo y te guió a la cocina."
    "Джефф усмехается, обнимает вас за плечи и ведёт на кухню."

# game/script.rpy:6266
translate russian ruta_normal_48_8fbcdb35:

    # J "Has alterado por completo mi horario, por lo que sí, me uniré a ti."
    J "Ты полностью сбили мой график, так что да, поем с тобой."

# game/script.rpy:6267
translate russian ruta_normal_48_b8ba81dd:

    # "Ustedes llegan a la cocina, y él se dirige al minirefri."
    "Вы заходите на кухню, и он направляется к мини-холодильнику."

# game/script.rpy:6268
translate russian ruta_normal_48_b388df6b:

    # "Él se agacha, en consecuencia, su camiseta se levanta ligeramente, dejando ver la piel de su espalda baja."
    "Он пригибается, и его кофта чуть задирается, обнажая кожу на пояснице."

# game/script.rpy:6269
translate russian ruta_normal_48_b4cc560b:

    # "A diferencia del resto de su piel pálida, está libre de cicatrices, o por lo que puedes ver."
    "В отличие от остальной его бледной кожи, этот участок лишён шрамов. Во всяком случае, насколько удаётся разглядеть."

# game/script.rpy:6270
translate russian ruta_normal_48_abaab087:

    # "Alzas tu mano y tiras del borde de la camiseta, tratando de regresarla a su lugar."
    "Вы протягиваете руку и одёргиваете край кофты, возвращая её на место."

# game/script.rpy:6272
translate russian ruta_normal_48_f300f6a6:

    # "El cuerpo de Jeff se tensa, y se levanta lentamente."
    "Тело Джеффа напрягается, и он медленно выпрямляется."

# game/script.rpy:6273
translate russian ruta_normal_48_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6274
translate russian ruta_normal_48_e7bee6f0:

    # pov "¿Qué?"
    pov "Что?"

# game/script.rpy:6275
translate russian ruta_normal_48_ad8d83d6:

    # "Jeff está con las manos vacías, y te mira expectante."
    "Джефф стоит с пустыми руками и выжидающе на вас смотрит."

# game/script.rpy:6277
translate russian ruta_normal_48_9d0df218:

    # J "… ¿Tienes hambre de otra cosa, [povname]?"
    J "...Ты хочешь что-то другое, [povname]?"

# game/script.rpy:6278
translate russian ruta_normal_48_b274b83f:

    # "Te alarmas en tu lugar."
    "Вы замираете на месте в смятении."

# game/script.rpy:6279
translate russian ruta_normal_48_ac3520ad:

    # pov "¡Estaba arreglando tu ropa!"
    pov "Я просто поправили твою одежду!"

# game/script.rpy:6281
translate russian ruta_normal_48_f1eec89d:

    # "Jeff te mira en silencio, para después desviar la mirada a un lado."
    "Джефф молча смотрит на вас, затем отводит взгляд в сторону."

# game/script.rpy:6282
translate russian ruta_normal_48_0347e6d3:

    # "Es tu idea… ¿O está decepcionado?"
    "Вам кажется... или он расстроен?"

# game/script.rpy:6286
translate russian ruta_normal_48_9b0f8d89:

    # pov "¿En serio?"
    pov "Серьёзно?"

# game/script.rpy:6287
translate russian ruta_normal_48_29bc5504:

    # pov "¿Estás tan ansioso de contacto físico?"
    pov "Тебе настолько не хватает физического контакта?"

# game/script.rpy:6289
translate russian ruta_normal_48_ea07f538:

    # "Jeff se remueve en su lugar, con incomodidad."
    "Джефф неловко переминается с ноги на ногу."

# game/script.rpy:6294
translate russian ruta_normal_48_78cb5281:

    # pov "Vaya, no me lo esperaba."
    pov "Вот уж не ожидали."

# game/script.rpy:6295
translate russian ruta_normal_48_213b2681:

    # pov "¿Tanto quieres que te toque?"
    pov "Тебе так сильно хочется, чтобы я тебя трогали?"

# game/script.rpy:6297
translate russian ruta_normal_48_666e01f3:

    # "Jeff se remueve en su lugar, con timidez."
    "Джефф смущённо мнётся на месте."

# game/script.rpy:6302
translate russian ruta_normal_49_065d72e0:

    # "Niegas levemente con la cabeza, acercándote a él."
    "Вы слегка качаете головой, подходя к нему."

# game/script.rpy:6303
translate russian ruta_normal_49_eaf43915:

    # "Jeff se apoya en el borde de la encimera, mirándote con atención, esperando algo."
    "Джефф опирается на край столешницы, внимательно за вами наблюдая, будто ожидает чего-то."

# game/script.rpy:6305
translate russian ruta_normal_49_e1e03dd7:

    # "Apoyas ambas manos a ambos lados del cuerpo de él, mirándolo desde tu lugar con una sonrisa ladina."
    "Вы кладёте руки по обе стороны от его тела, глядя на него с хитрой улыбкой."

# game/script.rpy:6306
translate russian ruta_normal_49_4b267e6d:

    # pov "¿Estás siendo tímido?"
    pov "Стесняешься?"

# game/script.rpy:6308
translate russian ruta_normal_49_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6309
translate russian ruta_normal_49_8b988325:

    # J "No, sólo quiero recibir lo que me des."
    J "Нет, просто хочу принять то, что ты дашь."

# game/script.rpy:6314
translate russian ruta_normal_49_c7310925:

    # "Tu sonrisa se suaviza, acercándote a él, la distancia entre ustedes es demasiado pequeña como para mantenerla así."
    "Ваша улыбка смягчается, и вы подходите ещё ближе — расстояние между вами слишком мало, чтобы его сохранять."

# game/script.rpy:6315
translate russian ruta_normal_49_812b8061:

    # "Él te mira por unos segundos, para después inclinarse sobre ti."
    "Он смотрит на вас несколько секунд, затем наклоняется ближе."

# game/script.rpy:6317
translate russian ruta_normal_49_4176c709:

    # "Recibes el beso con calma, habiéndolo esperado."
    "Вы спокойно принимаете поцелуй, заранее его ожидая."

# game/script.rpy:6318
translate russian ruta_normal_49_ed433225:

    # "Los labios de Jeff se sienten un poco más suaves contra los tuyos, pero siguen siendo fríos."
    "Губы Джеффа кажутся чуть мягче на ощупь, но они по-прежнему холодные."

# game/script.rpy:6319
translate russian ruta_normal_49_63516907:

    # "La mano de él sube y sujeta tu mandíbula con delicadeza, rozando la yema de sus dedos con la piel de tu mejilla."
    "Его рука поднимается и нежно обхватывает вашу челюсть, пальцы скользят по коже щеки."

# game/script.rpy:6321
translate russian ruta_normal_49_97a7e07d:

    # "Sientes que la respiración se agita levemente, y él te muerde ligeramente el labio inferior, profundizando el beso."
    "Дыхание учащается, и он слегка прикусывает вашу нижнюю губу, углубляя поцелуй."

# game/script.rpy:6331
translate russian ruta_normal_49_52a0e209:

    # "Deslizas lentamente tu mano bajo la camiseta de Jeff, sintiendo la tibia piel de él bajo tus dedos."
    "Вы медленно просовываете руку под кофту Джеффа, ощущая под пальцами его тёплую кожу."

# game/script.rpy:6332
translate russian ruta_normal_49_cf5ac177:

    # "Acaricias suavemente, sintiendo leves relieves."
    "Вы нежно поглаживаете, чувствуя едва заметные рельефы."

# game/script.rpy:6334
translate russian ruta_normal_49_b6176fae:

    # J "!!"
    J "!!"

# game/script.rpy:6335
translate russian ruta_normal_49_1b777edf:

    # J "[povname]..."
    J "[povname]..."

# game/script.rpy:6336
translate russian ruta_normal_49_9714902f:

    # "Él se separa unos centímetros de ti, mirándote con necesidad."
    "Он отстраняется на пару сантиметров, глядя на вас с жаждой."

# game/script.rpy:6337
translate russian ruta_normal_49_a1f10a9d:

    # pov "Sólo estoy tanteando el terreno."
    pov "Просто прощупываю почву."

# game/script.rpy:6338
translate russian ruta_normal_49_96909498:

    # "Acompañado de tus palabras, deslizas tu mano hacia la espalda de él, apretando suavemente la piel, acariciando el hundimiento de su zona lumbar."
    "С этими словами вы скользите рукой к его спине, мягко сжимая кожу и проводя по впадинке поясницы."

# game/script.rpy:6339
translate russian ruta_normal_49_eef83ad6:

    # J "Ngh… "
    J "Нгх..."

# game/script.rpy:6340
translate russian ruta_normal_49_021795b6:

    # pov "¿Te gustan los simples toques?"
    pov "Тебе нравятся такие простые ласки?"

# game/script.rpy:6341
translate russian ruta_normal_49_08b4fe06:

    # pov "No puedo imaginar cómo te pondrías haciendo otras cosas."
    pov "Не представляю, что с тобой будет при чём-то большем."

# game/script.rpy:6342
translate russian ruta_normal_49_d3c27360:

    # J "Ah~... [povname]..."
    J "Ах~... [povname]..."

# game/script.rpy:6343
translate russian ruta_normal_49_e6619cfd:

    # "Su voz, generalmente rasposa, se suaviza ante tu toque."
    "Его голос, обычно хриплый, смягчается под вашими прикосновениями."

# game/script.rpy:6354
translate russian beso_2_da12b541:

    # "Considerando que con eso tuvo suficiente, recoges tus manos y retrocedes un par de pasos."
    "Решив, что этого достаточно, вы убираете руки и отступаете на пару шагов."

# game/script.rpy:6355
translate russian beso_2_ac9751e6:

    # "Miras la condición en la que él está, y te sorprende ver que está ligeramente agitado."
    "Вы оглядываете его и удивляетесь тому, что он слегка возбуждён."

# game/script.rpy:6356
translate russian beso_2_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6357
translate russian beso_2_9a7aefd9:

    # pov "¿Tienes experiencia en esto, Jeff?"
    pov "У тебя есть опыт в этом, Джефф?"

# game/script.rpy:6359
translate russian beso_2_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6361
translate russian beso_2_69a9639f:

    # J "Muy poca."
    J "Немного."

# game/script.rpy:6362
translate russian beso_2_dc602a60:

    # pov "Ya veo…"
    pov "Понятно..."

# game/script.rpy:6364
translate russian beso_2_083081af:

    # J "¿Qué hay de ti?"
    J "А у тебя?"

# game/script.rpy:6368
translate russian beso_2_0c2ade1b:

    # pov "Claro, si tengo."
    pov "Конечно, есть."

# game/script.rpy:6371
translate russian beso_2_a50e68bd:

    # pov "Nop, pero la imaginación me ayuda."
    pov "Не-а, но воображение помогает."

# game/script.rpy:6376
translate russian character_11_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6377
translate russian character_11_58ac9dc1:

    # "Jeff suspira, enderezándose."
    "Джефф вздыхает и выпрямляется."

# game/script.rpy:6379
translate russian character_11_f4af70bd:

    # "Se acerca a ti y besa suavemente tu frente."
    "Он подходит ближе и нежно целует вас в лоб."

# game/script.rpy:6380
translate russian character_11_15ea199c:

    # J "Desayunemos de una vez."
    J "Давай уже позавтракаем."

# game/script.rpy:6382
translate russian character_11_3c4187ad:

    # "Tomas asiento en el comedor, esperando a que él vuelva."
    "Вы садитесь за стол и ждёте, пока он вернётся."

# game/script.rpy:6383
translate russian character_11_b0b87a03:

    # "En realidad, ves que te estás acostumbrando de a poco a la compañía de Jeff."
    "На самом деле вы постепенно привыкаете к компании Джеффа."

# game/script.rpy:6384
translate russian character_11_70388fe1:

    # "Cuando él estaba de buen humor, te trataba bien, pero… Cuando se enojaba, realmente sacaba lo peor."
    "Когда у него хорошее настроение, он обходится с вами хорошо, но... когда злится, проявляет себя с худшей стороны."

# game/script.rpy:6385
translate russian character_11_3f9a5aa5:

    # "Eso… Era una razón para preocuparte."
    "Это... даёт повод для беспокойства."

# game/script.rpy:6388
translate russian character_11_f4cdc579:

    # "Jeff se acerca y deja frente a ti un plato con tu desayuno."
    "Джефф подходит и ставит перед вами тарелку с завтраком."

# game/script.rpy:6389
translate russian character_11_45294cf0:

    # "La mesa sigue estando algo sucia, pero los platos y utensilios estaban limpios."
    "Стол всё ещё немного грязный, но посуда и приборы чистые."

# game/script.rpy:6390
translate russian character_11_8a3b5b7e:

    # "Miras cómo él comía en silencio."
    "Вы молча смотрите, как он ест."

# game/script.rpy:6391
translate russian character_11_c02cbca0:

    # "… Podías ver como un poco de comida se asomaba desde la herida de su boca."
    "...Вы замечаете, как из раны на его рту выглядывает кусочек еды."

# game/script.rpy:6394
translate russian character_11_826d9368:

    # pov "Tienes algo de comida ahí."
    pov "У тебя тут еда."

# game/script.rpy:6396
translate russian character_11_014710ac:

    # "Llamas su atención y apuntas a tu propia boca, para darle la señal."
    "Вы привлекаете его внимание и указываете на свой рот, давая понять."

# game/script.rpy:6397
translate russian character_11_3487469e:

    # "Jeff se lleva una mano a la cara, y nota el pequeño desastre que tiene."
    "Джефф подносит руку к лицу и замечает этот небольшой беспорядок."

# game/script.rpy:6399
translate russian character_11_ac7937bf:

    # J "Oh, esto pasa."
    J "А, бывает."

# game/script.rpy:6400
translate russian character_11_ce617998:

    # "…"
    "..."

# game/script.rpy:6401
translate russian character_11_58613dc4:

    # "Si, esto no estaba funcionando del todo para ti."
    "Да, это отнюдь не идеально для вас."

# game/script.rpy:6402
translate russian character_11_38305b84:

    # "No sólo Jeff no era digno de confianza, era violento, volátil e impredecible."
    "Джефф не только ненадёжен — он ещё и жесток, переменчив, непредсказуем."

# game/script.rpy:6403
translate russian character_11_0b8b4140:

    # "Si en sólo 7 días se enamoró de ti, ¿Cómo sabes si en otros 7 días te va a odiar?"
    "Если он влюбился в вас всего за 7 дней, то как знать, не возненавидит ли он вас ещё через 7?"

# game/script.rpy:6404
translate russian character_11_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6405
translate russian character_11_1f3c2c08:

    # pov "Jeff, tengo algo que preguntarte."
    pov "Джефф, хочу кое о чём спросить."

# game/script.rpy:6406
translate russian character_11_02dcf7c8:

    # J "¿Qué es?"
    J "Что такое?"

# game/script.rpy:6407
translate russian character_11_fb6684ed:

    # pov "… ¿Te sigue importando si te temo o no?"
    pov "...Тебе всё ещё важно, боюсь я тебя или нет?"

# game/script.rpy:6408
translate russian character_11_9a021dd9:

    # "Antes parecía muy fijado en que le temas, pero ahora… No sabes lo que realmente quiere."
    "Раньше он явно стремился внушить вам страх, но теперь... вы уже не понимаете, чего он хочет."

# game/script.rpy:6410
translate russian character_11_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6411
translate russian character_11_38787ceb:

    # J "¿Me temes?"
    J "А ты меня боишься?"

# game/script.rpy:6421
translate russian miedo_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6423
translate russian miedo_51815759:

    # J "Heh…"
    J "Хех..."

# game/script.rpy:6425
translate russian miedo_597fec25:

    # J "¡Hahaha!"
    J "Ха-ха-ха!"

# game/script.rpy:6426
translate russian miedo_d5a915c3:

    # "Él ríe estruendosamente, sorprendiéndote."
    "Он громко смеётся, заставляя вас вздрогнуть."

# game/script.rpy:6427
translate russian miedo_c0c6bc5b:

    # "No sabes si preocuparte por esa reacción o no."
    "Вы не знаете, стоит ли волноваться из-за этой реакции."

# game/script.rpy:6429
translate russian miedo_a3bcc0b5:

    # J "… Hah."
    J "...Хах."

# game/script.rpy:6430
translate russian miedo_4834489d:

    # J "No importaba cuál fuera tu respuesta, no cambia lo que siento por ti."
    J "Неважно, что ты ответишь. Мои чувства к тебе от этого не изменятся."

# game/script.rpy:6431
translate russian miedo_da397893:

    # J "Tampoco cambiaría nuestra situación."
    J "И наша ситуация тоже не поменяется."

# game/script.rpy:6433
translate russian miedo_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6434
translate russian miedo_36de94a2:

    # J "Lo que sí me preocuparía, sería que te aburrieras de mí."
    J "Меня бы больше беспокоило то, что я тебе надоем."

# game/script.rpy:6436
translate russian miedo_66082656:

    # J "Tú… ¿Me dirías si empiezas a aburrirte de mí?"
    J "Ты... скажешь мне, если я начну тебе надоедать?"

# game/script.rpy:6440
translate russian miedo_81156c95:

    # pov "Pfft, eso no va a pasar."
    pov "Пф, этого не случится."

# game/script.rpy:6442
translate russian miedo_6c2811b8:

    # "Jeff suspira, resignado."
    "Джефф смиренно вздыхает."

# game/script.rpy:6447
translate russian miedo_c0662a5c:

    # pov "Claro."
    pov "Конечно."

# game/script.rpy:6448
translate russian miedo_0d72e8f7:

    # "Sabías por experiencia que él prefería la honestidad."
    "Вы по опыту знаете, что он ценит честность."

# game/script.rpy:6450
translate russian miedo_171e15fd:

    # "Jeff sonríe satisfecho."
    "Джефф удовлетворённо улыбается."

# game/script.rpy:6455
translate russian ruta_normal_50_559914fb:

    # "Ustedes dejan el tema, y terminan su desayuno."
    "Вы оставляете эту тему и доедаете завтрак."

# game/script.rpy:6457
translate russian ruta_normal_50_164fd116:

    # "El resto del día es tranquilo, incluso puedes presenciar a Jeff durmiendo. Cosa que nunca habías visto antes."
    "Остаток дня проходит спокойно. Вы даже застаёте Джеффа спящим, чего прежде не случалось."

# game/script.rpy:6458
translate russian ruta_normal_50_c2c2c867:

    # "La realidad parecía estar estableciéndose, y llegó el atardecer."
    "Реальность постепенно входит в колею, и наступает вечер."

# game/script.rpy:6459
translate russian ruta_normal_50_1b0eeffe:

    # "Jeff había mencionado que tenía algunos billetes y que podría comprar una cena para llevar de un restaurante a unas calles."
    "Джефф упоминал, что у него есть наличные — можно заказать еду на вынос в ресторане в паре кварталов отсюда."

# game/script.rpy:6463
translate russian ruta_normal_50_0cdcae2d:

    # "Pero de repente, se escuchan sirenas de policía."
    "Но внезапно раздаются полицейские сирены."

# game/script.rpy:6464
translate russian ruta_normal_50_8f0addf7:

    # "Cada vez se escuchan más fuerte, y parecen ser de varios autos."
    "Они звучат всё громче. Похоже, машин несколько."

# game/script.rpy:6465
translate russian ruta_normal_50_808896c7:

    # pov "… ¿Jeff?"
    pov "...Джефф?"

# game/script.rpy:6469
translate russian ruta_normal_50_3820d195:

    # "Él se pone de pie y va a la sala, asomándose ligeramente por la ventana."
    "Он встаёт и идёт в гостиную, осторожно выглядывая в окно."

# game/script.rpy:6470
translate russian ruta_normal_50_1ee3904d:

    # "Las luces se asoman por las ventanas, y aunque esperas que pasen de largo, se quedan ahí."
    "Вспышки света пробиваются сквозь стёкла. И хотя вы надеетесь, что машины проедут мимо, они останавливаются."

# game/script.rpy:6471
translate russian ruta_normal_50_6812260e:

    # "Las sirenas se apagan, y puedes ver por la cantidad de luces que al menos hay tres patrullas."
    "Сирены замолкают, и по количеству вспышек видно, что там как минимум три патрульные машины."

# game/script.rpy:6472
translate russian ruta_normal_50_9e655069:

    # "Se escucha el chasquido de un megáfono y la voz de alguien resuena."
    "Раздаётся щелчок мегафона и эхо чьего-то голоса."

# game/script.rpy:6473
translate russian ruta_normal_50_d2403323:

    # Stranger "¡Te tenemos rodeado!"
    Stranger "Вы окружены!"

# game/script.rpy:6474
translate russian ruta_normal_50_a2ba409b:

    # Stranger "¡Entrega al rehén!"
    Stranger "Отпустите заложника!"

# game/script.rpy:6476
translate russian ruta_normal_50_b385212e:

    # J "¡Mierda!"
    J "Чёрт!"

# game/script.rpy:6477
translate russian ruta_normal_50_c72ac230:

    # J "¡Ese hijo de puta alcohólico no sabe quedarse callado!"
    J "Этот блядский алкоголик не умеет держать рот на замке!"

# game/script.rpy:6478
translate russian ruta_normal_50_022ea01f:

    # "Claro, era bastante obvio que un tipo que colecciona basura y da lo que sea por brandy no era confiable."
    "Конечно, любой, кто собирает мусор и готов на всё ради бренди, не внушает доверия."

# game/script.rpy:6482
translate russian ruta_normal_50_9d23b791:

    # "Jeff se apresura a un rincón de la sala y se coloca su sudadera blanca."
    "Джефф бросается в угол гостиной и натягивает свою белую толстовку."

# game/script.rpy:6483
translate russian ruta_normal_50_6823016f:

    # pov "¿Qué vas hacer?"
    pov "Что ты собираешься делать?"

# game/script.rpy:6484
translate russian ruta_normal_50_e3c12478:

    # J "¿Entregarme?, ni loco."
    J "Сдаваться? Ни за что."

# game/script.rpy:6485
translate russian ruta_normal_50_9de67b00:

    # J "Ven."
    J "Идём."

# game/script.rpy:6487
translate russian ruta_normal_50_fd2136c4:

    # "Él toma tu mano fuertemente y tira de ti."
    "Он крепко хватает вас за руку и тянет за собой."

# game/script.rpy:6489
translate russian ruta_normal_50_f6a636ae:

    # pov "Pero estamos rodeados, no podemos salir."
    pov "Но нас окружили, мы не выберемся."

# game/script.rpy:6490
translate russian ruta_normal_50_fe7ff9c1:

    # J "Por adelante y atrás no, pero por debajo…"
    J "Спереди и сзади — нет, но снизу..."

# game/script.rpy:6491
translate russian ruta_normal_50_9cdc0d68:

    # "Entiendes lo que él está diciendo cuando se dirige al sótano."
    "Вы понимаете, о чём он, когда он направляется к подвалу."

# game/script.rpy:6493
translate russian ruta_normal_50_151de98f:

    # "Escuchas que la puerta de la entrada es azotada."
    "Вы слышите, как входную дверь выбивают."

# game/script.rpy:6494
translate russian ruta_normal_50_c429e2f1:

    # DS "¡[povname]!"
    DS "[povname]!"

# game/script.rpy:6498
translate russian ruta_normal_50_b80169af:

    # "Reconoces esa voz, pero cuando llegas al sótano, Jeff te suelta y va a un extremo del lugar."
    "Вы узнаёте этот голос, но когда вы добираетесь до подвала, Джефф отпускает вашу руку и уходит в дальний угол."

# game/script.rpy:6499
translate russian ruta_normal_50_edb10030:

    # pov "¿A dónde vamos ahora?"
    pov "Куда теперь?"

# game/script.rpy:6500
translate russian ruta_normal_50_74c1dae5:

    # "Jeff forcejea con algo en el suelo, y ves que levanta un pedazo de cemento que lleva a un lugar abajo."
    "Джефф возится с чем-то на полу, и вы видите, как он откидывает кусок бетонной плиты, открывая проход ниже."

# game/script.rpy:6501
translate russian ruta_normal_50_4987d436:

    # "Vaya, que conveniente."
    "Ну, удобно."

# game/script.rpy:6502
translate russian ruta_normal_50_8dea5eef:

    # J "Por las alcantarillas."
    J "Через канализацию."

# game/script.rpy:6503
translate russian ruta_normal_50_dda4fef6:

    # pov "Ew…"
    pov "Фу..."

# game/script.rpy:6505
translate russian ruta_normal_50_b5a04456:

    # J "¡[povname]!"
    J "[povname]!"

# game/script.rpy:6506
translate russian ruta_normal_50_19da9268:

    # pov "¡Ok, ok!"
    pov "Ладно, ладно!"

# game/script.rpy:6507
translate russian ruta_normal_50_57565f6f:

    # "Obedeces y bajas por la abertura."
    "Вы подчиняетесь и спускаетесь в отверстие."

# game/script.rpy:6509
translate russian ruta_normal_50_1e1c6c77:

    # "Caes en el interior de una alcantarilla, el agua bajo tus pies chapotea por tus movimientos."
    "Вы падаете внутрь канализации, где вода плещется под ногами от ваших движений."

# game/script.rpy:6513
translate russian ruta_normal_50_d13e9e0b:

    # "Jeff salta después de ti y tira de tu brazo."
    "Джефф прыгает следом и дёргает вас за руку."

# game/script.rpy:6514
translate russian ruta_normal_50_f0654ea0:

    # J "¡Vamos!, ¡Nos siguen de cerca!"
    J "Давай! Они совсем рядом!"

# game/script.rpy:6516
translate russian ruta_normal_50_5a6d23ef:

    # "Ustedes corren, escuchando como varias personas los siguen por detrás."
    "Вы мчитесь вперёд, слыша, как за вами следуют несколько человек."

# game/script.rpy:6517
translate russian ruta_normal_50_00bf2340:

    # "Entre la prisa, logras avistar el final del túnel."
    "Среди всей этой спешки удаётся разглядеть конец туннеля."

# game/script.rpy:6518
translate russian ruta_normal_50_fde27518:

    # pov "¿A donde vamos después?"
    pov "А дальше куда?"

# game/script.rpy:6519
translate russian ruta_normal_50_14360a18:

    # J "…"
    J "..."

# game/script.rpy:6520
translate russian ruta_normal_50_f9ed2707:

    # pov "¿Jeff?"
    pov "Джефф?"

# game/script.rpy:6521
translate russian ruta_normal_50_f0a6db74:

    # J "¡Cállate!, ¡Estoy pensando!"
    J "Заткнись! Я думаю!"

# game/script.rpy:6526
translate russian ruta_normal_50_866dabc8:

    # "El agarre en tu brazo se vuelve más fuerte, lo que te lastima."
    "Он сжимает вашу руку сильнее, причиняя боль."

# game/script.rpy:6527
translate russian ruta_normal_50_c39df7cb:

    # "Ustedes salen a un arroyo en medio del bosque, y Jeff apresura el paso."
    "Вы выбегаете к ручью посреди леса, и Джефф ускоряет шаг."

# game/script.rpy:6528
translate russian ruta_normal_50_c42fe6a0:

    # pov "¿No nos vamos a perder?"
    pov "Мы же не заблудимся?"

# game/script.rpy:6529
translate russian ruta_normal_50_14360a18_1:

    # J "…"
    J "..."

# game/script.rpy:6530
translate russian ruta_normal_50_3c926b3d:

    # "Jeff permanecía en silencio, respirando agitadamente."
    "Джефф молчит, тяжело дыша."

# game/script.rpy:6531
translate russian ruta_normal_50_a91defcc:

    # "Parecía… Realmente un criminal buscado."
    "Он выглядит... как настоящий разыскиваемый преступник."

# game/script.rpy:6532
translate russian ruta_normal_50_9b2921a5:

    # "Te has metido en un problema muy grande."
    "Вы нарвались на серьёзные неприятности."

# game/script.rpy:6537
translate russian ruta_normal_50_711f6bd1:

    # "Ustedes se adentran en el bosque, pero tras encontrarse luces provenientes de linternas, toman un desvío."
    "Вы углубляетесь в лес, но, увидев свет фонарей, сворачиваете в сторону."

# game/script.rpy:6538
translate russian ruta_normal_50_a3956cb6:

    # "Sucede lo mismo por el otro camino, ustedes están arrinconados."
    "То же самое и на другой тропе — вас загнали в угол."

# game/script.rpy:6539
translate russian ruta_normal_50_d9afd364:

    # "No tienen de otra que seguir recto, pero adelante sólo hay…"
    "Приходится идти прямо, но впереди только..."

# game/script.rpy:6543
translate russian ruta_normal_50_b4405fe3:

    # "Ustedes llegan al borde del barranco, y Jeff finalmente te suelta."
    "Вы достигаете края обрыва, и Джефф, наконец, отпускает вас."

# game/script.rpy:6544
translate russian ruta_normal_50_75e22c72:

    # "A lo lejos, a la entrada del bosque, se reúnen las luces y avanzan hacia ustedes a gran velocidad."
    "Вдалеке, у входа в лес, огни собираются и стремительно надвигаются на вас."

# game/script.rpy:6545
translate russian ruta_normal_50_f76c8657:

    # pov "Jeff…"
    pov "Джефф..."

# game/script.rpy:6547
translate russian ruta_normal_50_26b4ccdd:

    # J "Mierda, mierda, ¡Mierda!"
    J "Чёрт, чёрт, чёрт!"

# game/script.rpy:6548
translate russian ruta_normal_50_cd5fa684:

    # "Las personas se acercan más."
    "Подходят всё больше людей."

# game/script.rpy:6549
translate russian ruta_normal_50_520c5b41:

    # "La multitud es una sombra, pero puedes decir que son muchos."
    "Толпа — сплошная тень, но их явно много."

# game/script.rpy:6550
translate russian ruta_normal_50_80388382:

    # "Ustedes no tienen salida."
    "Выхода нет."

# game/script.rpy:6586
translate russian final_muerte_f76c8657:

    # pov "Jeff…"
    pov "Джефф..."

# game/script.rpy:6588
translate russian final_muerte_c5d8df9b:

    # "Suavemente, alcanzas la mano de él, y entrelazas sus dedos."
    "Вы нежно берёте его за руку и сплетаете ваши пальцы."

# game/script.rpy:6590
translate russian final_muerte_2cc11ef3:

    # "Jeff te mira desesperado, pero al encontrarse con tus ojos, se tranquiliza."
    "Джефф отчаянно смотрит на вас, но, встретившись с вами взглядом, успокаивается."

# game/script.rpy:6591
translate russian final_muerte_66f9e556:

    # J "[povname]... Te amo."
    J "[povname]... Я люблю тебя."

# game/script.rpy:6592
translate russian final_muerte_d6401e97:

    # "Tu le sonríes afectuosamente."
    "Вы ласково улыбаетесь ему."

# game/script.rpy:6593
translate russian final_muerte_d82da54b:

    # "El sonido de los pasos de las personas se acercan, acompañados por voces desesperadas, gritando que se detengan."
    "Шаги людей всё ближе, а отчаянные голоса кричат остановиться."

# game/script.rpy:6594
translate russian final_muerte_f27876a2:

    # "Ustedes se enfrentan al acantilado, sintiendo la brisa del mar golpearlos, como si les estuviera advirtiendo de lo que los esperaba."
    "Вы стоите лицом к обрыву. Морской ветер бьёт в лицо, словно предвещая неминуемое."

# game/script.rpy:6595
translate russian final_muerte_50f2067d:

    # "Apretaste la mano de él, con decisión."
    "Вы решительно сжимаете его руку."

# game/script.rpy:6596
translate russian final_muerte_d619f187:

    # "Ustedes dan un paso al frente, y el suelo desaparece de sus pies."
    "Вы делаете шаг вперёд, и земля исчезает из-под ног."

# game/script.rpy:6598
translate russian final_muerte_283b6c32:

    # "Lo último que sientes, es el viento chocando con tu rostro, y el agarre en tu mano que nunca se soltó."
    "Последнее, что вы чувствуете: ветер хлещет по лицу, а хватка его руки остаётся крепкой до самого конца."

# game/script.rpy:6601
translate russian final_muerte_89ce31a0:

    # "{b}Final VII: Juntos Para Siempre{/b}"
    "{b}Концовка VII: Вместе навсегда{/b}"

# game/script.rpy:6607
translate russian final_neutral_9bacc2b9:

    # pov "Jeff… Tengo miedo."
    pov "Джефф... Мне страшно."

# game/script.rpy:6610
translate russian final_neutral_de633d1c:

    # "Jeff sujeta tus mejillas entre sus manos, y te mira sin saber qué hacer."
    "Джефф обхватывает ваши щёки ладонями и растерянно смотрит, не зная, что делать."

# game/script.rpy:6612
translate russian final_neutral_7058a783:

    # "Sintiendo que los demás se acercan, los hombros de él caen con resignación, y él te sonríe con tristeza."
    "Чувствуя, как остальные надвигаются, он опускает плечи и в смирении грустно улыбается вам."

# game/script.rpy:6613
translate russian final_neutral_4a1d5273:

    # J "Hah, logré que temieras por tu vida."
    J "Хах, мне удалось заставить тебя бояться за свою жизнь."

# game/script.rpy:6615
translate russian final_neutral_f6a1ae21:

    # "Tienes las palabras en la boca, escuchas el sonido de un disparo demasiado cerca como para alarmarte.."
    "Вы хотите ответить, но раздаётся выстрел — слишком близко, чтобы не встревожиться."

# game/script.rpy:6617
translate russian final_neutral_c1795435:

    # "El pecho de Jeff se tiñe de rojo, y una fuerza lo empuja hacia el acantilado."
    "Грудь Джеффа окрашивается алым, и отдача толкает его к обрыву."

# game/script.rpy:6619
translate russian final_neutral_2560efd9:

    # pov "¡NO!"
    pov "НЕТ!"

# game/script.rpy:6621
translate russian final_neutral_c1dc0d46:

    # "Tratas de alcanzar la mano de él, y seguramente hubieras caído también si la alcanzabas, pero un agarre en tu cintura te lo impide."
    "Вы тянетесь к его руке; наверняка полетели бы следом, если бы схватили, но чья-то хватка на талии удерживает вас."

# game/script.rpy:6622
translate russian final_neutral_2a723026:

    # DS "¡[povname]!, ¡Ya acabó!"
    DS "[povname]! Всё кончено!"

# game/script.rpy:6623
translate russian final_neutral_da8efc1d:

    # "Tratas de liberarte, sintiendo que las lágrimas corren por tus mejillas."
    "Вы вырываетесь, чувствуя, как слёзы текут по щекам."

# game/script.rpy:6624
translate russian final_neutral_a1206f2f:

    # pov "¡Jeff, Jeff!"
    pov "Джефф, Джефф!"

# game/script.rpy:6625
translate russian final_neutral_2f132b69:

    # "Llamas su nombre, pues aún recuerdas a unos instantes atrás, estaba a tu lado."
    "Вы выкрикиваете его имя, ведь только что он был рядом."

# game/script.rpy:6627
translate russian final_neutral_3bc79863:

    # "Sean te obliga a caer sobre tus rodillas, y te rompes por completo."
    "Шон заставляет вас упасть на колени, и вы сдаётесь окончательно."

# game/script.rpy:6629
translate russian final_neutral_eb16df10:

    # "Ella te envuelve en tus brazos, pero no se siente del todo bien."
    "Она обнимает вас, но от этого не легче."

# game/script.rpy:6630
translate russian final_neutral_5512b450:

    # DS "Ssh, ya acabó…"
    DS "Ш-ш, всё закончилось..."

# game/script.rpy:6631
translate russian final_neutral_df0b26a5:

    # "Su voz es tranquilizante, pero no te consuela por completo."
    "Её голос успокаивает, но не приносит полного облегчения."

# game/script.rpy:6635
translate russian final_neutral_ce617998:

    # "…"
    "..."

# game/script.rpy:6638
translate russian final_neutral_93803e97:

    # pov "Así que eso pasó."
    pov "Так это и произошло."

# game/script.rpy:6639
translate russian final_neutral_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6640
translate russian final_neutral_7f1fee85:

    # T "Por como lo veo yo, [povname], lograste lo que muchos no han podido."
    T "Как по мне, [povname], ты сделали то, чего не удалось многим."

# game/script.rpy:6641
translate russian final_neutral_02f2d8bd:

    # T "Pudiste sobrevivir."
    T "Ты выжили."

# game/script.rpy:6642
translate russian final_neutral_7b41b66e:

    # pov "… ¿Entonces porque siento que algo está mal?"
    pov "...Тогда почему кажется, что что-то не так?"

# game/script.rpy:6643
translate russian final_neutral_0caf702c:

    # T "Construiste una relación socio-afectiva con Jeff. Él se volvió el monstruo y tu salvador a la vez, es difícil desligarse de alguien que significó tanto para ti."
    T "Ты выстроили с Джеффом эмоциональную связь. Он стал одновременно монстром и спасителем. Трудно оторваться от того, кто столько для тебя значил."

# game/script.rpy:6644
translate russian final_neutral_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6645
translate russian final_neutral_8310e204:

    # T "Con el tiempo, podrás llenar el vacío que él dejó. Es parte del proceso de sanar."
    T "Со временем ты заполнишь пустоту, которую он оставил. Это часть процесса исцеления."

# game/script.rpy:6646
translate russian final_neutral_a654e86b:

    # "Te mantienes en silencio, tratando de encontrar un lugar en tu mente que acepte lo que el terapeuta está diciendo."
    "Вы молчите, пытаясь отыскать в сознании уголок, который примет слова психолога."

# game/script.rpy:6647
translate russian final_neutral_779533f1:

    # T "Nuestro tiempo se acabó, ¿Alguien viene por ti?"
    T "Наше время вышло. Кто-нибудь зайдёт за тобой?"

# game/script.rpy:6649
translate russian final_neutral_783cbeca:

    # pov "Sí, Paul me está esperando afuera."
    pov "Да, Пол ждёт меня снаружи."

# game/script.rpy:6650
translate russian final_neutral_b48f564f:

    # "Resulta que él pudo ser llevado al hospital a tiempo."
    "Как оказалось, его успели вовремя доставить в больницу."

# game/script.rpy:6651
translate russian final_neutral_926f09dc:

    # "Fue la primera persona a la que viste cuando te recuperaron."
    "Он был первым человеком, которого вы увидели, как только пришли в себя."

# game/script.rpy:6653
translate russian final_neutral_3118e67a:

    # pov "Cindy no tarda nada en llegar."
    pov "Синди скоро будет."

# game/script.rpy:6654
translate russian final_neutral_38a6eb07:

    # "Resulta que ella pudo ser llevada al hospital a tiempo."
    "Как оказалось, её успели вовремя доставить в больницу."

# game/script.rpy:6655
translate russian final_neutral_926f09dc_1:

    # "Fue la primera persona a la que viste cuando te recuperaron."
    "Она была первым человеком, которого вы увидели, как только пришли в себя."

# game/script.rpy:6656
translate russian final_neutral_066856a9:

    # T "Ah, veo que ustedes siguen en contacto."
    T "Ах, вижу, вы до сих пор общаетесь."

# game/script.rpy:6660
translate russian final_neutral_47a414b1:

    # "No te costó mucho entender que era mucho mejor salir con alguien que estaba bien de la cabeza."
    "Вам быстро стало ясно, что куда приятнее встречаться с теми, кто в здравом уме."

# game/script.rpy:6664
translate russian final_neutral_230850f3:

    # "Él fue el que te convenció de ir a terapia, por más que te negaras."
    "Именно он убедил вас ходить к психологу, несмотря на все ваши отказы."

# game/script.rpy:6666
translate russian final_neutral_d3b0968c:

    # "Gracias a su compañía, lograste muchas cosas, incluso volver al trabajo."
    "Благодаря её поддержке вы многого добились, даже вернулись к работе."

# game/script.rpy:6671
translate russian final_n_5b9b6f94:

    # T "Me alegro por ti."
    T "Рад за тебя."

# game/script.rpy:6672
translate russian final_n_6ab328c7:

    # "Asientes por la simple cortesía."
    "Вы киваете из простой вежливости."

# game/script.rpy:6674
translate russian final_n_0b1edc78:

    # "Sales de la consulta, y respiras profundamente, sintiendo que un gran peso se liberaba de tus hombros."
    "Вы выходите из кабинета и глубоко вдыхаете, чувствуя, как с плеч спадает огромный груз."

# game/script.rpy:6678
translate russian final_n_1e79f087:

    # DR "¿Cómo te fue?"
    DR "Как всё прошло?"

# game/script.rpy:6679
translate russian final_n_6bc4f3ca:

    # pov "Bien, hablé mucho."
    pov "Нормально, я много говорили."

# game/script.rpy:6680
translate russian final_n_7e6ae12d:

    # "Salazar sonríe cálidamente."
    "Салазар тепло улыбается."

# game/script.rpy:6681
translate russian final_n_bbbcb1fd:

    # "Su brazo ya había sanado."
    "Его рука зажила."

# game/script.rpy:6685
translate russian final_n_d10ac37b:

    # C "¿Todo bien?"
    C "Всё хорошо?"

# game/script.rpy:6686
translate russian final_n_05e081b1:

    # "Sientes el toque en tu hombro, y asientes con una pequeña sonrisa."
    "Вы чувствуете её прикосновение к плечу и киваете с лёгкой улыбкой."

# game/script.rpy:6687
translate russian final_n_caf0ea3f:

    # "Lejos de ocultar la cicatriz que le ocasionó el incidente, lo portaba con orgullo."
    "Она не скрывает шрам с того случая, а наоборот, носит с гордостью."

# game/script.rpy:6690
translate russian final_n_60310fbe:

    # "Ustedes caminan por la calle, bajo la luz del sol y con un silencio cómodo."
    "Вы идёте по улице под солнечным светом, в комфортной тишине."

# game/script.rpy:6691
translate russian final_n_8f0403e6:

    # "No sabes lo que te depara de ahora en adelante."
    "Вы не знаете, что вас ждёт впереди."

# game/script.rpy:6692
translate russian final_n_97ace942:

    # "Nunca olvidarás lo que sucedió esa semana."
    "Ту неделю вы никогда не забудете."

# game/script.rpy:6693
translate russian final_n_6684d3d9:

    # "Nunca olvidarás a Jeff, lo que te hizo sentir y cuestionar."
    "Не забудете и Джеффа. Как и всё, что он заставил вас чувствовать, о чём заставил задуматься."

# game/script.rpy:6694
translate russian final_n_de30a3d3:

    # "Pero sabes con seguridad, que todo acabó. Tu vida volvió a la normalidad."
    "Но одно вы знаете точно: всё позади. Жизнь вернулась в нормальное русло."

# game/script.rpy:6695
translate russian final_n_430500b4:

    # "{b}Final Normal: Vivirá En Tu Memoria{/b}"
    "{b}Нормальная концовка: Он останется в вашей памяти{/b}"

# game/script.rpy:6700
translate russian final_verdadero_4e6cf994:

    # pov "Jeff… Ven aquí."
    pov "Джефф... Иди сюда."

# game/script.rpy:6704
translate russian final_verdadero_f9ab2645:

    # "Jeff te mira con duda, pero obedece."
    "Джефф смотрит на вас с сомнением, но повинуется."

# game/script.rpy:6705
translate russian final_verdadero_576f3b86:

    # "Sujetas su cabeza entre tus manos, y lo atraes hacia ti."
    "Вы обхватываете его голову ладонями и притягиваете к себе."

# game/script.rpy:6706
translate russian final_verdadero_0b88d550:

    # "Rozas tus labios contra la oreja de él, y susurras algo en voz baja."
    "Ваши губы касаются его уха, вы что-то тихо шепчете."

# game/script.rpy:6708
translate russian final_verdadero_2131ede1:

    # "Él se sobresalta, y cuando se endereza, te mira con desconcierto."
    "Он вздрагивает, выпрямляется и смотрит на вас в недоумении."

# game/script.rpy:6709
translate russian final_verdadero_7b726b3b:

    # "Tú le sonríes."
    "Вы улыбаетесь ему."

# game/script.rpy:6710
translate russian final_verdadero_98779d41:

    # DS "¡Quieto!"
    DS "Стоять!"

# game/script.rpy:6711
translate russian final_verdadero_03bde726:

    # "Escuchas cómo los policías llegaron a ustedes, por lo que actúas con rapidez."
    "Вы слышите, как полицейские приближаются, и действуете мгновенно."

# game/script.rpy:6713
translate russian final_verdadero_a242d65e:

    # "Pones tus manos sobre el pecho de Jeff, y empujas con todas tus fuerzas."
    "Вы упираетесь ладонями в грудь Джеффа и толкаете со всей силы."

# game/script.rpy:6716
translate russian final_verdadero_4989045a:

    # "Jeff no puso resistencia, y mientras caía hacia el vacío, pudiste ver sus ojos desorbitados, observándote."
    "Джефф не сопротивляется. Падая в пустоту, он смотрит на вас широко распахнутыми глазами."

# game/script.rpy:6718
translate russian final_verdadero_8f96635d:

    # "Miras abajo desde el borde del acantilado, y sientes que alguien se pone a tu lado."
    "Вы смотрите вниз с края обрыва и чувствуете, как кто-то встаёт рядом."

# game/script.rpy:6719
translate russian final_verdadero_da05cf6f:

    # "Por el rabillo del ojo, sabes que se trata de Sean."
    "Краем глаза вы замечаете Шон."

# game/script.rpy:6720
translate russian final_verdadero_4e4ea233:

    # pov "Ya todo acabó."
    pov "Всё кончено."

# game/script.rpy:6724
translate russian final_verdadero_ce617998:

    # "…"
    "..."

# game/script.rpy:6727
translate russian final_verdadero_8ece5da7:

    # pov "Y eso pasó."
    pov "Так это и произошло."

# game/script.rpy:6728
translate russian final_verdadero_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6729
translate russian final_verdadero_40b141f9:

    # "El terapeuta mira el suelo pensativamente."
    "Психолог задумчиво смотрит в пол."

# game/script.rpy:6730
translate russian final_verdadero_817e32f8:

    # T "Bueno, definitivamente… El mérito es tuyo."
    T "Что ж, безусловно... заслуга твоя."

# game/script.rpy:6731
translate russian final_verdadero_216c93e8:

    # T "Lograste vencer el mal que te acechaba, no tienes que sentirte culpable."
    T "Ты одолели зло, которое преследовало тебя. Не нужно винить себя."

# game/script.rpy:6732
translate russian final_verdadero_5a298b23:

    # T "Fue en defensa propia, eras tú o él."
    T "Это была самооборона — или ты, или он."

# game/script.rpy:6733
translate russian final_verdadero_c0662a5c:

    # pov "Claro."
    pov "Конечно."

# game/script.rpy:6734
translate russian final_verdadero_3de04149_1:

    # T "…"
    T "..."

# game/script.rpy:6735
translate russian final_verdadero_bd335c55:

    # T "¿Cómo te sientes al respecto?"
    T "Как ты себя чувствуешь по этому поводу?"

# game/script.rpy:6736
translate russian final_verdadero_bedd6fae:

    # pov "…"
    pov "..."

# game/script.rpy:6740
translate russian final_verdadero_6c095e67:

    # pov "Bueno, definitivamente me siento diferente."
    pov "Ну, я определённо чувствую себя иначе."

# game/script.rpy:6741
translate russian final_verdadero_011b8e56:

    # pov "Maté a alguien."
    pov "Я убили человека."

# game/script.rpy:6744
translate russian final_verdadero_bfacd690:

    # pov "Como siempre."
    pov "Как обычно."

# game/script.rpy:6745
translate russian final_verdadero_6a526be2:

    # "… Como si siempre hubiera algo dentro de ti que estaba mal."
    "...Как будто внутри вас всегда было что-то не так."

# game/script.rpy:6750
translate russian final_v_3de04149:

    # T "…"
    T "..."

# game/script.rpy:6751
translate russian final_v_01c0ba06:

    # T "¿Sigues viviendo por tu cuenta?"
    T "Ты до сих пор живёшь в одиночку?"

# game/script.rpy:6752
translate russian final_v_9310589d:

    # pov "Sip, pero me cambié a otro departamento."
    pov "Да, но переехали в другую квартиру."

# game/script.rpy:6753
translate russian final_v_cda864d1:

    # T "Entonces, ¿No vives con nadie?"
    T "Значит, ни с кем не живёшь?"

# game/script.rpy:6754
translate russian final_v_0348e8ee:

    # pov "No, es un departamento pequeño."
    pov "Нет, квартира маленькая."

# game/script.rpy:6755
translate russian final_v_40ecee7e:

    # T "… De acuerdo, por lo que veo, no sientes tanto apego hacia él."
    T "...Хорошо, судя по всему, ты не так сильно к нему привязаны."

# game/script.rpy:6756
translate russian final_v_0c9d5d4d:

    # T "Eso… Supongo que es porque tienes una mente fuerte."
    T "Это... Наверное, потому что у тебя сильный характер."

# game/script.rpy:6757
translate russian final_v_d1e890a4:

    # pov "Gracias."
    pov "Спасибо."

# game/script.rpy:6758
translate russian final_v_c623af9c:

    # T "Pero… Me gustaría que siguieras viniendo, para ver cómo te sientes en tu vida normal."
    T "Но... я бы хотел, чтобы ты продолжали приходить — посмотрим, как ты себя чувствуешь в обычной жизни."

# game/script.rpy:6760
translate russian final_v_c0c76561:

    # "Te encoges de hombros, poniéndote de pie al ver que tu hora ya terminó."
    "Вы пожимаете плечами и встаёте, видя, что время вышло."

# game/script.rpy:6761
translate russian final_v_8084c690:

    # pov "De acuerdo, ¿El próximo mes?"
    pov "Ладно, в следующем месяце?"

# game/script.rpy:6762
translate russian final_v_4305ce89:

    # T "… Que sea la próxima semana."
    T "...Давай на следующей неделе."

# game/script.rpy:6763
translate russian final_v_727ce6e3:

    # pov "Ok."
    pov "Хорошо."

# game/script.rpy:6765
translate russian final_v_a2eca826:

    # "Sales de la consulta, y viéndote en la calle concurrida de día, sientes que tus hombros se relajan."
    "Вы выходите из кабинета и оказываетесь на оживлённой дневной улице, ваши плечи расслабляются."

# game/script.rpy:6766
translate russian final_v_f2e3fbc0:

    # "Tu vida había vuelto casi a la normalidad, con la excepción de que te mudaste y cambiaste de trabajo."
    "Жизнь почти вернулась в привычное русло, вы переехали и сменили работу."

# game/script.rpy:6767
translate russian final_v_343864e7:

    # "Muchos dirían que lo que pasaste fue un infierno, pero para ti, fue algo especial."
    "Многие назвали бы то, через что вы прошли, адом, но для вас это было чем-то особенным."

# game/script.rpy:6768
translate russian final_v_7df5a380:

    # "Tu… Extrañabas a Jeff. Y no eras tan idiota como para admitirlo con el terapeuta."
    "Вы... скучаете по Джеффу. Но вы не настолько глупы, чтобы признаться в этом психологу."

# game/script.rpy:6770
translate russian final_v_25650239:

    # "Lo amabas, después de todo."
    "Вы любили его, в конце концов."

# game/script.rpy:6772
translate russian final_v_b83e740f:

    # "Fue tu amigo, después de todo."
    "Он был вашим другом, в конце концов."

# game/script.rpy:6773
translate russian final_v_4917d808:

    # "Su risa estruendosa, su cabello largo revuelto, sus manos blancas sujetando tu rostro."
    "Его громкий смех, его длинные растрёпанные волосы, его белые руки, обнимающие ваше лицо."

# game/script.rpy:6774
translate russian final_v_9f85ba35:

    # "Extrañabas todo."
    "Вы скучаете по всему."

# game/script.rpy:6775
translate russian final_v_55f381cf:

    # "Así que te aferrabas a la promesa que hiciste ese día."
    "И потому держите слово, данное в тот день."

# game/script.rpy:6780
translate russian final_v_7c39b2e7:

    # pov "… Te estaré esperando."
    pov "...Я буду ждать тебя."

# game/script.rpy:6782
translate russian final_v_6bdbcd0c:

    # "No explicaste mucho, y aún así, Jeff pareció comprenderlo."
    "Вы ничего не объяснили, но Джефф, похоже, всё понял."

# game/script.rpy:6783
translate russian final_v_ddb77d6a:

    # "Porque él siempre logra escapar."
    "Потому что ему всегда удаётся сбежать."

# game/script.rpy:6784
translate russian final_v_acdd06d8:

    # "Así que aprovechaste la conveniencia de la que él goza, sabiendo que él sobreviviría."
    "И вы воспользовались его умением, зная наверняка: он выживет."

# game/script.rpy:6785
translate russian final_v_a20cefa7:

    # "..."
    "..."

# game/script.rpy:6787
translate russian final_v_ac195da2:

    # "Ya habían pasado semanas de lo ocurrido, pero él aún no aparecía…"
    "С тех пор прошло уже несколько недель, но он всё не появляется..."

# game/script.rpy:6788
translate russian final_v_52f75f3a:

    # "Se estaba tomando su tiempo, eso es seguro."
    "Он не торопится, это точно."

# game/script.rpy:6789
translate russian final_v_1a1f378b:

    # "Pero volvería, lo sabías."
    "Но он вернётся — в этом вы уверены."

# game/script.rpy:6795
translate russian final_v_178becc7:

    # "{b}Final Verdadero: Viene Por Ti{/b}"
    "{b}Истинная концовка: Он идёт за вами{/b}"

translate russian strings:

    # game/script.rpy:11
    old "*+{0}"
    new "*+{0}"

    # game/script.rpy:16
    old "¡Vives!"
    new "Вы выжили!"

    # game/script.rpy:47
    old "{size=70}Este juego contiene {size=80}{color=#F02800}violencia, gore, asesinato, acoso, abuso, manipulación y muerte de personaje principal{/color}{/size}"
    new "{size=70}Эта игра содержит {size=80}{color=#F02800}насилие, кровь, убийства, преследование, абьюз, манипуляции и смерть главного героя{/color}{/size}"

    # game/script.rpy:55
    old "{size=70}Está dirigido a una audiencia {color=#FFED0A}MADURA(+18){/color}{/size}"
    new "{size=70}Игра предназначена для {color=#FFED0A}ВЗРОСЛОЙ АУДИТОРИИ(+18){/color}{/size}"

    # game/script.rpy:63
    old "{size=70}{color=#ffffff}Por favor juega con discreción{/color}{/size}"
    new "{size=70}{color=#ffffff}Играйте на свой страх и риск{/color}{/size}"

    # game/script.rpy:134
    old "Te encantan las películas"
    new "Вам нравятся фильмы"

    # game/script.rpy:134
    old "Las películas están bien"
    new "Фильмы ничего, смотреть можно"

    # game/script.rpy:240
    old "Tu nombre es..."
    new "Вас зовут..."

    # game/script.rpy:245
    old "Agradecer"
    new "Поблагодарить"

    # game/script.rpy:245
    old "Burlarte"
    new "Высмеять"

    # game/script.rpy:308
    old "Si"
    new "Да"

    # game/script.rpy:308
    old "No"
    new "Нет"

    # game/script.rpy:345
    old "Desviar la mirada"
    new "Отвести взгляд"

    # game/script.rpy:345
    old "Corresponder la mirada"
    new "Посмотреть в ответ"

    # game/script.rpy:366
    old "Fantasía"
    new "Фэнтези"

    # game/script.rpy:366
    old "Romance"
    new "Романтика"

    # game/script.rpy:366
    old "Terror"
    new "Хоррор"

    # game/script.rpy:366
    old "Comedia"
    new "Комедия"

    # game/script.rpy:366
    old "Musical"
    new "Мюзикл"

    # game/script.rpy:366
    old "Ciencia Ficción"
    new "Научная фантастика"

    # game/script.rpy:409
    old "Black Swan (2010)"
    new "Чёрный лебедь (2010)"

    # game/script.rpy:409
    old "The Exorcist (1973)"
    new "Изгоняющий дьявола (1973)"

    # game/script.rpy:409
    old "Scream (1996)"
    new "Крик (1996)"

    # game/script.rpy:409
    old "Tremors (1990)"
    new "Дрожь земли (1990)"

    # game/script.rpy:409
    old "Paranormal Activity (2007)"
    new "Паранормальное явление (2007)"

    # game/script.rpy:409
    old "Pulse (2001)"
    new "Пульс (2001)"

    # game/script.rpy:409
    old "The Thing (1982)"
    new "Нечто (1982)"

    # game/script.rpy:489
    old "Seguirle la corriente"
    new "Подыграть"

    # game/script.rpy:489
    old "Ignorarlo"
    new "Проигнорировать"

    # game/script.rpy:513
    old "Ser sutil"
    new "Намекнуть"

    # game/script.rpy:513
    old "Ir al grano"
    new "Сказать прямо"

    # game/script.rpy:540
    old "Chocar su mano"
    new "Дать пять"

    # game/script.rpy:540
    old "Tomar su mano"
    new "Пожать руку"

    # game/script.rpy:569
    old "¿Qué hay con la bandana?"
    new "Зачем эта повязка?"

    # game/script.rpy:569
    old "¿En qué trabajas?"
    new "Кем работаешь?"

    # game/script.rpy:569
    old "¿Tienes pareja?"
    new "У тебя есть пара?"

    # game/script.rpy:573
    old "Curiosidad"
    new "Интересно"

    # game/script.rpy:573
    old "¿Duele?"
    new "Что-то болит?"

    # game/script.rpy:604
    old "Coquetear"
    new "Пофлиртовать"

    # game/script.rpy:604
    old "Encogerte de hombros"
    new "Пожать плечами"

    # game/script.rpy:625
    old "Responder con amabilidad"
    new "Ответить вежливо"

    # game/script.rpy:625
    old "Responder con sarcasmo"
    new "Ответить с сарказмом"

    # game/script.rpy:831
    old "Disculparte"
    new "Извиниться"

    # game/script.rpy:831
    old "Provocarlo"
    new "Поддразнить"

    # game/script.rpy:924
    old "Cara"
    new "Лицо"

    # game/script.rpy:924
    old "Voz"
    new "Голос"

    # game/script.rpy:924
    old "Está loco"
    new "Он сумасшедший"

    # game/script.rpy:924
    old "Te va a matar"
    new "Он собирается убить вас"

    # game/script.rpy:986
    old "Está bien"
    new "Хорошо"

    # game/script.rpy:986
    old "Yo te persigo a ti"
    new "Я буду догонять"

    # game/script.rpy:1008
    old "Ir a la derecha"
    new "Направо"

    # game/script.rpy:1008
    old "Ir a la izquierda"
    new "Налево"

    # game/script.rpy:1157
    old "Rendirte"
    new "Сдаться"

    # game/script.rpy:1157
    old "Desafiarlo"
    new "Сопротивляться"

    # game/script.rpy:1203
    old "Suplicarle"
    new "Умолять"

    # game/script.rpy:1332
    old "Hospital"
    new "В больнице"

    # game/script.rpy:1332
    old "Cielo"
    new "В раю"

    # game/script.rpy:1360
    old "Como él quiera llamarte"
    new "Как он сам захочет вас назвать"

    # game/script.rpy:1360
    old "Di tu nombre"
    new "Назвать своё имя"

    # game/script.rpy:1432
    old "No estás bien"
    new "Вы не в порядке"

    # game/script.rpy:1432
    old "Estarás bien"
    new "Всё будет хорошо"

    # game/script.rpy:1474
    old "No tienes familia"
    new "У вас нет семьи"

    # game/script.rpy:1474
    old "No hablas con tu familia"
    new "Вы не общаетесь со своей семьёй"

    # game/script.rpy:1474
    old "Tu familia vive en otra ciudad"
    new "Ваша семья в другом городе"

    # game/script.rpy:1582
    old "Agradecerle"
    new "Поблагодарить её"

    # game/script.rpy:1582
    old "Cuestionarla"
    new "Допросить её"

    # game/script.rpy:1667
    old "Di la verdad"
    new "Сказать правду"

    # game/script.rpy:1667
    old "Exagera"
    new "Преувеличить"

    # game/script.rpy:1735
    old "Algo dulce"
    new "Что-нибудь сладкое"

    # game/script.rpy:1735
    old "Algo salado"
    new "Что-нибудь солёное"

    # game/script.rpy:1759
    old "Ser amigable"
    new "Проявить вежливость"

    # game/script.rpy:1759
    old "Ser cortante"
    new "Проявить холод"

    # game/script.rpy:1824
    old "Desconfiar"
    new "Проявить недоверие"

    # game/script.rpy:1842
    old "Negociar"
    new "Поговорить"

    # game/script.rpy:1842
    old "Quejarte"
    new "Пожаловаться"

    # game/script.rpy:1863
    old "Decirle lo que te pasó"
    new "Рассказать, что с вами случилось"

    # game/script.rpy:1863
    old "Mostrar interés"
    new "Проявить интерес"

    # game/script.rpy:1995
    old "Confiar en el Dr. Salazar"
    new "Довериться доктору Салазару"

    # game/script.rpy:1995
    old "Guardatelo para ti"
    new "Промолчать"

    # game/script.rpy:2228
    old "Coquetear con Wes"
    new "Пофлиртовать с Уэсом"

    # game/script.rpy:2228
    old "Coquetear con Sean"
    new "Пофлиртовать с Шон"

    # game/script.rpy:2228
    old "Preguntar sobre el caso"
    new "Спросить о деле"

    # game/script.rpy:2322
    old "Posters"
    new "Постеры"

    # game/script.rpy:2322
    old "Luces"
    new "Светильники"

    # game/script.rpy:2322
    old "Muebles"
    new "Мебель"

    # game/script.rpy:2687
    old "Opción vegana"
    new "Веганский вариант"

    # game/script.rpy:2687
    old "Opción normal"
    new "Нормальный вариант"

    # game/script.rpy:2776
    old "Aceptar"
    new "Согласиться"

    # game/script.rpy:2776
    old "Rechazar"
    new "Отказаться"

    # game/script.rpy:3040
    old "Vino"
    new "Вино"

    # game/script.rpy:3040
    old "Cerveza"
    new "Пиво"

    # game/script.rpy:3071
    old "Provocar"
    new "Поддразнить"

    # game/script.rpy:3071
    old "Desafiar"
    new "Сдерзить"

    # game/script.rpy:3111
    old "Tener empatía"
    new "Посочувствовать"

    # game/script.rpy:3143
    old "Comentar de tu día"
    new "Рассказать о своём дне"

    # game/script.rpy:3143
    old "Preguntar sobre el día de él"
    new "Спросить, как прошёл его день"

    # game/script.rpy:3189
    old "Sospechar"
    new "Отнестись с подозрением"

    # game/script.rpy:3221
    old "Indagar"
    new "Расспросить"

    # game/script.rpy:3221
    old "Comprender"
    new "Отнестись с пониманием"

    # game/script.rpy:3246
    old "Liberarte"
    new "Освободиться"

    # game/script.rpy:3246
    old "Gemir"
    new "Простонать"

    # game/script.rpy:3274
    old "Brindar"
    new "Поднять тост"

    # game/script.rpy:3274
    old "Regañar"
    new "Отругать"

    # game/script.rpy:3317
    old "¿Eres celoso?"
    new "Ты ревнуешь?"

    # game/script.rpy:3317
    old "¿De donde sacas el dinero?"
    new "Откуда у тебя деньги?"

    # game/script.rpy:3317
    old "¿Qué te pasó en la boca?"
    new "Что с твоим ртом?"

    # game/script.rpy:3380
    old "Juzgarlo"
    new "Осудить"

    # game/script.rpy:3380
    old "Calmarlo"
    new "Успокоить"

    # game/script.rpy:3413
    old "Sí"
    new "Да"

    # game/script.rpy:3437
    old "Besar su mejilla"
    new "Поцеловать в щёку"

    # game/script.rpy:3514
    old "Abrir"
    new "Открыть"

    # game/script.rpy:3514
    old "No abrir"
    new "Не открывать"

    # game/script.rpy:3735
    old "Cindy"
    new "Синди"

    # game/script.rpy:3735
    old "Salazar"
    new "Салазар"

    # game/script.rpy:3779
    old "Charlar"
    new "Поговорить"

    # game/script.rpy:3821
    old "Mencionarlo"
    new "Упомянуть это"

    # game/script.rpy:3821
    old "No mencionarlo"
    new "Не упоминать"

    # game/script.rpy:3890
    old "Restar importancia"
    new "Преуменьшить"

    # game/script.rpy:4072
    old "Le gustas"
    new "Вы ему нравитесь"

    # game/script.rpy:4072
    old "Quiere dejarte en paz"
    new "Он хочет оставить вас в покое"

    # game/script.rpy:4205
    old "Preguntar"
    new "Спросить"

    # game/script.rpy:4205
    old "No preguntar"
    new "Не спрашивать"

    # game/script.rpy:4263
    old "Ser cool"
    new "Ответить круто"

    # game/script.rpy:4263
    old "Ser indiferente"
    new "Ответить равнодушно"

    # game/script.rpy:4533
    old "Ser optimista"
    new "Отнестись положительно"

    # game/script.rpy:4658
    old "Tiene sentido"
    new "Имеет смысл"

    # game/script.rpy:4696
    old "Proponer cenar juntos"
    new "Предложить поесть вместе"

    # game/script.rpy:4772
    old "Hombres"
    new "Мужчины"

    # game/script.rpy:4772
    old "Mujeres"
    new "Женщины"

    # game/script.rpy:4772
    old "Ambos"
    new "Оба"

    # game/script.rpy:4772
    old "No te importa"
    new "Для вас это не имеет значения"

    # game/script.rpy:4772
    old "No lo has considerado"
    new "Вы не думали об этом"

    # game/script.rpy:4809
    old "¿Tienes familia?"
    new "У тебя есть семья?"

    # game/script.rpy:4809
    old "¿Tienes amigos?"
    new "У тебя есть друзья?"

    # game/script.rpy:4809
    old "¿Qué edad tienes?"
    new "Сколько тебе лет?"

    # game/script.rpy:4809
    old "Eso es todo"
    new "Это всё"

    # game/script.rpy:4818
    old "¿Los mataste?"
    new "Ты убил их?"

    # game/script.rpy:4818
    old "¿Cómo?"
    new "Как?"

    # game/script.rpy:4838
    old "Suenan cool"
    new "Наверное, они крутые"

    # game/script.rpy:4838
    old "Suenan raros"
    new "Наверное, они странные"

    # game/script.rpy:4864
    old "Menos de 20"
    new "Меньше 20"

    # game/script.rpy:4864
    old "En tus 20's"
    new "Больше 20"

    # game/script.rpy:4864
    old "En tus 30's"
    new "Больше 30"

    # game/script.rpy:4886
    old "Halagarlo"
    new "Похвалить"

    # game/script.rpy:5348
    old "Es raro"
    new "Это странно"

    # game/script.rpy:5348
    old "Es jodido"
    new "Это полный пиздец"

    # game/script.rpy:5419
    old "Decir la verdad"
    new "Сказать правду"

    # game/script.rpy:5419
    old "Mentir"
    new "Солгать"

    # game/script.rpy:5499
    old "Ser complaciente"
    new "Ответить покладисто"

    # game/script.rpy:5530
    old "Alejarte"
    new "Отстраниться"

    # game/script.rpy:5530
    old "Dejarlo"
    new "Позволить"

    # game/script.rpy:5570
    old "Incluir lengua (sugestivo)"
    new "Углубить поцелуй (вызывающе)"

    # game/script.rpy:5570
    old "Con eso basta"
    new "Достаточно"

    # game/script.rpy:5648
    old "No es tu tipo"
    new "Он не в вашем вкусе"

    # game/script.rpy:5750
    old "Contarle a Jeff"
    new "Рассказать Джеффу"

    # game/script.rpy:5750
    old "Guardarlo para ti"
    new "Оставить при себе"

    # game/script.rpy:5806
    old "Bromear"
    new "Пошутить"

    # game/script.rpy:5883
    old "Unirte a él"
    new "Пойти с ним"

    # game/script.rpy:6012
    old "Lo amas"
    new "Вы любите его"

    # game/script.rpy:6012
    old "Sólo te agrada"
    new "Он вам просто нравится"

    # game/script.rpy:6044
    old "Nunca"
    new "Никогда"

    # game/script.rpy:6044
    old "Exactamente"
    new "Именно"

    # game/script.rpy:6134
    old "Ojos"
    new "Глаза"

    # game/script.rpy:6134
    old "Sonrisa"
    new "Улыбка"

    # game/script.rpy:6134
    old "Cuerpo"
    new "Тело"

    # game/script.rpy:6134
    old "Calva"
    new "Залысина"

    # game/script.rpy:6177
    old "Preguntar por el antiguo dueño"
    new "Спросить о прежнем владельце"

    # game/script.rpy:6177
    old "Preguntar por el cadáver del sótano"
    new "Спросить о трупе в подвале."

    # game/script.rpy:6323
    old "Acariciarlo (Sugestivo)"
    new "Погладить его (вызывающе)"

    # game/script.rpy:6366
    old "Tienes experiencia"
    new "У вас есть опыт"

    # game/script.rpy:6366
    old "No tienes experiencia"
    new "У вас нет опыта"

    # game/script.rpy:6438
    old "Desviar el tema"
    new "Уйти от темы"

    # game/script.rpy:6562
    old "Quedarse con él"
    new "Остаться с ним"

    # game/script.rpy:6568
    old "Tienes miedo..."
    new "Вам страшно..."

    # game/script.rpy:6576
    old "..."
    new "..."

    # game/script.rpy:6658
    old "Estamos saliendo"
    new "Мы встречаемся"

    # game/script.rpy:6658
    old "Nuestra amistad creció"
    new "Наша дружба стала крепче"

    # game/script.rpy:6738
    old "Diferente"
    new "Иначе"

    # game/script.rpy:6738
    old "Normal"
    new "Нормально"

    # game/script.rpy:6804
    old "{size=70}{color=#27BBF5}Guión, Arte y Programación{/color} by Neesa Complex"
    new "{size=70}{color=#27BBF5}Сценарий, графика и программирование{/color}: Neesa Complex"

    # game/script.rpy:6820
    old "{size=70}{color=#D90000}Jeff The Killer{/color} by Jeff 'Sesseur' Case and 'GameFuelTV'{/size}"
    new "{size=70}{color=#D90000}Джефф Убийца{/color}: Джефф Кейс (Sesseur) и GameFuelTV{/size}"

    # game/script.rpy:6827
    old "{size=70}Muchas gracias por jugar{/size}"
    new "{size=70}Большое спасибо за игру{/size}"

    # game/script.rpy:6834
    old "{size=70}Si quieres seguir viendo mis proyectos, no dudes en apoyarme *{/size}"
    new "{size=70}Если хотите видеть мои новые проекты, поддержите меня *{/size}"

# TODO: Translation updated at 2026-01-07 13:12

translate russian strings:

    # game/script.rpy:82
    old "Easy Mode ON"
    new "Лёгкий режим: ВКЛ"

# TODO: Translation updated at 2026-01-12 14:57

translate russian strings:

    # game/script.rpy:6813
    old "{size=70}{color=#EC96FF}Traducción al Ruso{/color} by regisvinex"
    new "{size=70}{color=#EC96FF}Перевод на русский{/color} выполнен regisvinex"

# TODO: Translation updated at 2026-01-19 10:54

# game/script.rpy:5525
#translate russian ruta_normal_39_7e8b5b2d:

    # "Su tono burlesco te fastidiaba, sólo quería molestarte"
    #"Его насмешливый тон тебя раздражал — он просто хотел тебя подразнить."

# game/script.rpy:5625
translate russian beso_1_8809c5b7:

    # "Esa broma era más molesta que graciosa."
    "Эта шутка была скорее раздражающей, чем смешной."

# game/script.rpy:6621
translate russian final_neutral_aa238c36:

    # "Tienes las palabras en la boca, escuchas el sonido de un disparo demasiado cerca como para alarmarte."
    "Вы хотите ответить, но раздаётся выстрел — слишком близко, чтобы не встревожиться."

# TODO: Translation updated at 2026-01-19 11:00

# game/script.rpy:5525
translate russian ruta_normal_39_056a4c75:

    # "Su tono burlesco te fastidiaba, sólo quería molestarte."
    "Его насмешливый тон тебя раздражал, он просто хотел тебя подразнить."

