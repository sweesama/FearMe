﻿# TODO: Translation updated at 2025-12-29 21:05

translate russian strings:

    # game/screens.rpy:270
    old "Atrás"
    new "Назад"

    # game/screens.rpy:271
    old "Historial"
    new "История"

    # game/screens.rpy:272
    old "Saltar"
    new "Пропуск"

    # game/screens.rpy:273
    old "Auto"
    new "Авто"

    # game/screens.rpy:274
    old "Guardar"
    new "Сохранить"

    # game/screens.rpy:277
    old "Prefs."
    new "Предп."

    # game/screens.rpy:328
    old "Comenzar"
    new "Начать"

    # game/screens.rpy:336
    old "Cargar"
    new "Загрузить"

    # game/screens.rpy:338
    old "Opciones"
    new "Опции"

    # game/screens.rpy:340
    old "Álbum"
    new "Альбом"

    # game/screens.rpy:347
    old "Finaliza repetición"
    new "Закончить повтор"

    # game/screens.rpy:351
    old "Menú principal"
    new "Главное меню"

    # game/screens.rpy:364
    old "Salir"
    new "Выйти"

    # game/screens.rpy:372
    old "Día 1"
    new "День 1"

    # game/screens.rpy:373
    old "Día 2"
    new "День 2"

    # game/screens.rpy:374
    old "Día 3"
    new "День 3"

    # game/screens.rpy:375
    old "Día 4"
    new "День 4"

    # game/screens.rpy:376
    old "Día 5"
    new "День 5"

    # game/screens.rpy:377
    old "Día 6"
    new "День 6"

    # game/screens.rpy:378
    old "Día 7"
    new "День 7"

    # game/screens.rpy:625
    old "Volver"
    new "Вернуться"

    # game/screens.rpy:703
    old "Acerca de"
    new "Об игре"

    # game/screens.rpy:710
    old "Versión [config.version!t]\n"
    new "Версия [config.version!t]\n"

    # game/screens.rpy:716
    old "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Сделано с помощью {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:752
    old "Página {}"
    new "Страница {}"

    # game/screens.rpy:752
    old "Grabación automática"
    new "Автоматическая запись"

    # game/screens.rpy:752
    old "Grabación rápida"
    new "Быстрая запись"

    # game/screens.rpy:795
    old "{#file_time}%A, %d de %B %Y, %H:%M"
    new "{#file_time}%A, %d de %B %Y, %H:%M"

    # game/screens.rpy:795
    old "vacío"
    new "пустой"

    # game/screens.rpy:815
    old "<"
    new "<"

    # game/screens.rpy:819
    old "{#auto_page}A"
    new "{#auto_page}А"

    # game/screens.rpy:822
    old "{#quick_page}R"
    new "{#quick_page}Б"

    # game/screens.rpy:828
    old ">"
    new ">"

    # game/screens.rpy:833
    old "Subir Sync"
    new "Загрузка синхронизации"

    # game/screens.rpy:837
    old "Descargar Sync"
    new "Загрузить синхронизацию"

    # game/screens.rpy:896
    old "Pantalla"
    new "Экран"

    # game/screens.rpy:897
    old "Ventana"
    new "Окно"

    # game/screens.rpy:898
    old "Pantalla completa"
    new "Полноэкранный режим"

    # game/screens.rpy:903
    old "Texto no visto"
    new "Непрочитанный текст"

    # game/screens.rpy:904
    old "Tras elecciones"
    new "После выборов"

    # game/screens.rpy:905
    old "Transiciones"
    new "Переходы"

    # game/screens.rpy:912
    old "Idioma"
    new "Язык"

    # game/screens.rpy:913
    old "Inglés"
    new "English"

    # game/screens.rpy:914
    old "Español"
    new "Español"

    # game/screens.rpy:918
    old "Haz trampa"
    new "Читы"

    # game/screens.rpy:920
    old "Interfaz de afecto"
    new "Интерфейс привязанности"

    # game/screens.rpy:930
    old "Veloc. texto"
    new "Скорость текста"

    # game/screens.rpy:934
    old "Veloc. autoavance"
    new "Время автоматической перемотки"

    # game/screens.rpy:941
    old "Volumen música"
    new "Громкость музыки"

    # game/screens.rpy:948
    old "Volumen sonido"
    new "Громкость звуков"

    # game/screens.rpy:954
    old "Prueba"
    new "Тест"

    # game/screens.rpy:958
    old "Volumen voz"
    new "Громкость озвучки"

    # game/screens.rpy:969
    old "Silenciar todo"
    new "Заглушить все"

    # game/screens.rpy:1088
    old "El historial está vacío."
    new "История пуста."

    # game/screens.rpy:1147
    old "Ayuda"
    new "Помощь"

    # game/screens.rpy:1156
    old "Teclado"
    new "Клавиатура"

    # game/screens.rpy:1157
    old "Ratón"
    new "Мышь"

    # game/screens.rpy:1160
    old "Mando"
    new "Геймпад"

    # game/screens.rpy:1173
    old "Intro"
    new "Enter"

    # game/screens.rpy:1174
    old "Avanza el diálogo y activa la interfaz."
    new "Продвигает диалог и активирует интерфейс."

    # game/screens.rpy:1177
    old "Espacio"
    new "Пробел"

    # game/screens.rpy:1178
    old "Avanza el diálogo sin seleccionar opciones."
    new "Продвигает диалог без выборов."

    # game/screens.rpy:1181
    old "Teclas de flecha"
    new "Стрелки"

    # game/screens.rpy:1182
    old "Navega la interfaz."
    new "Навигация по интерфейсу."

    # game/screens.rpy:1185
    old "Escape"
    new "Escape"

    # game/screens.rpy:1186
    old "Accede al menú del juego."
    new "Доступ к меню игры."

    # game/screens.rpy:1189
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1190
    old "Salta el diálogo mientras se presiona."
    new "Пропускает диалог при зажатии."

    # game/screens.rpy:1193
    old "Tabulador"
    new "Tab"

    # game/screens.rpy:1194
    old "Activa/desactiva el salto de diálogo."
    new "Переключает пропуск диалога."

    # game/screens.rpy:1197
    old "Av. pág."
    new "Page Up"

    # game/screens.rpy:1198
    old "Retrocede al diálogo anterior."
    new "Возвращает к предыдущему диалогу."

    # game/screens.rpy:1201
    old "Re. pág."
    new "Page Down"

    # game/screens.rpy:1202
    old "Avanza hacia el diálogo siguiente."
    new "Переходит к следующему диалогу."

    # game/screens.rpy:1206
    old "Oculta la interfaz."
    new "Скрывает интерфейс."

    # game/screens.rpy:1210
    old "Captura la pantalla."
    new "Скриншот."

    # game/screens.rpy:1214
    old "Activa/desactiva la asistencia por {a=https://www.renpy.org/l/voicing}voz-automática{/a}."
    new "Переключает пользовательскую {a=https://www.renpy.org/l/voicing}самоозвучку{/a}."

    # game/screens.rpy:1218
    old "Abre el menú de accesibilidad."
    new "Открывает меню специальных возможностей."

    # game/screens.rpy:1224
    old "Clic izquierdo"
    new "ЛКМ"

    # game/screens.rpy:1228
    old "Clic medio"
    new "СКМ"

    # game/screens.rpy:1232
    old "Clic derecho"
    new "ПКМ"

    # game/screens.rpy:1236
    old "Rueda del ratón arriba"
    new "Колесо мыши вверх"

    # game/screens.rpy:1240
    old "Rueda del ratón abajo"
    new "Колесо мыши вниз"

    # game/screens.rpy:1247
    old "Gatillo derecho\nA/Botón inferior"
    new "Правый триггер\nA/Нижняя кнопка"

    # game/screens.rpy:1251
    old "Gatillo izquierdo\nBotón sup. frontal izq."
    new "Левый триггер\nЛевый бампер"

    # game/screens.rpy:1255
    old "Botón sup. frontal der."
    new "Правый бампер"

    # game/screens.rpy:1259
    old "D-Pad, Sticks"
    new "Крестовина, стики"

    # game/screens.rpy:1263
    old "Inicio, Guía, B/Botón Derecho"
    new "Начало, Гайд, B/Правая кнопка"

    # game/screens.rpy:1267
    old "Y/Botón superior"
    new "Y/Верхняя кнопка"

    # game/screens.rpy:1270
    old "Calibrar"
    new "Калибровка"

    # game/screens.rpy:1383
    old "Saltando"
    new "Пропуск"

    # game/screens.rpy:1695
    old "Menú"
    new "Меню"

    # game/screens.rpy:280
    #old "[ 'Easy Mode: ON' if easy_mode else 'Easy Mode: OFF' ]"
    #new "[ 'Лёгкий режим: ВКЛ' if easy_mode else 'Лёгкий режим: ВЫКЛ' ]"

# TODO: Translation updated at 2026-01-07 12:56

translate russian strings:

    # game/screens.rpy:281
    old "Easy Mode: OFF"
    new "Лёгкий режим: ВЫКЛ"

# TODO: Translation updated at 2026-01-07 13:03

translate russian strings:

    # game/screens.rpy:281
    old "Easy Mode: ON"
    new "Лёгкий режим: ВКЛ"

# TODO: Translation updated at 2026-01-07 13:05

#translate russian strings:

    # game/screens.rpy:220
    #old "English"
    #new "Английский"

    # game/screens.rpy:222
    #old "Русский"
    #new ""

# TODO: Translation updated at 2026-01-07 13:12

#translate russian strings:

    # game/screens.rpy:222
    #old "Русский"
    #new "Русский"

# TODO: Translation updated at 2026-01-07 13:15

translate russian strings:

    # game/screens.rpy:916
    old "Ruso"
    new "Русский"

# TODO: Translation updated at 2026-01-07 20:16

translate russian strings:

    # game/screens.rpy:281
    old "['Easy Mode: ON') if easy_mode else 'Easy Mode: OFF' ]"
    new "['Лёгкий режим: ВКЛ' if easy_mode else 'Лёгкий режим: ВЫКЛ']"

# TODO: Translation updated at 2026-01-07 20:30

translate russian strings:

    # game/screens.rpy:914
    old "English"
    new "English"

    # game/screens.rpy:916
    old "Русский"
    new "Русский"

# TODO: Translation updated at 2026-01-07 21:31

#translate russian strings:

    # game/screens.rpy:344
    #old "Easy Mode:{vspace=15}ON"
    #new "Лёгкий режим:{vspace=15}ВКЛ"

    # game/screens.rpy:344
    #old "Easy Mode:{vspace=15}OFF"
    #new "Лёгкий режим:{vspace=15}ВЫКЛ"

# TODO: Translation updated at 2026-01-12 14:57

translate russian strings:

    # game/screens.rpy:344
    old "Easy Mode:{vspace=15}ON"
    new "Лёгкий режим:{vspace=15}ВКЛ"

    # game/screens.rpy:344
    old "Easy Mode:{vspace=15}OFF"
    new "Лёгкий режим:{vspace=15}ВЫКЛ"

